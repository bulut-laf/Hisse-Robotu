from __future__ import annotations

from datetime import datetime

from backend.app.integration.three_system_exchange import write_scan_row_opinion

import os
import json
import subprocess
import time
import urllib.error
import urllib.request
import webbrowser
from pathlib import Path
from datetime import date, datetime, timedelta, timezone

import pandas as pd
import streamlit as st
# RPV1_SPRINT02_DASHBOARD_IMPORT
from backend.app.analysis.research_profiles_daily import (
    build_daily_research_profiles,
    research_profile_as_of_from_scan,
    research_profile_contexts_from_bytes,
)
from backend.app.ui.research_profiles_dashboard import (
    render_research_profiles_panel,
)

# RPV1_SPRINT03_PROFILE_MEMORY_IMPORT
from backend.app.analysis.research_profile_memory import (
    persist_research_profile_bundle,
)
from backend.app.market_context.ai_stock_chat import render_stock_ai_chat, store_stock_ai_context

from backend.app.ui.market_context_dashboard import render_market_context_dashboard
from backend.app.ui.market_context_dashboard_s182 import render_market_context_dashboard as _sprint182_render_market_context_dashboard

from backend.app.ui.market_context_dashboard_s157 import render_market_context_dashboard as render_market_context_dashboard_s157
render_market_context_dashboard = render_market_context_dashboard_s157
render_market_context_dashboard = _sprint182_render_market_context_dashboard
from backend.app.ui.news_center_dashboard import render_news_center_dashboard

from backend.app.ui.prebreakout_dashboard import on_yukselis_hazirlik_formu
from backend.app.ui.prebreakout_validation_dashboard import on_yukselis_toplu_dogrulama_formu
from backend.app.ui.bist_daily_market_dashboard import render_bist_daily_market
from backend.app.ui.opportunity_radar_dashboard import render_opportunity_radar

from backend.app.analysis.fundamental_analysis import (
    build_fundamental_snapshot,
)
from backend.app.analysis.divergence_analysis import (
    DivergenceAnalysisError,
    analyze_daily_weekly_divergences,
    divergence_rows,
)
from backend.app.analysis.technical_decision_matrix import (
    DecisionMatrixContext,
    build_technical_decision_matrix,
    decision_matrix_rows,
)
from backend.app.analysis.signal_outcome_tracking import (
    HORIZONS,
    SignalOutcomeError,
    SignalOutcomeJsonStore,
    SignalSnapshot,
    evaluate_signal,
    outcome_rows,
    outcomes_to_csv,
    success_summary,
)
from backend.app.analysis.automatic_signal_tracking import (
    AutomaticSignalTrackingError,
    automatic_record_from_values,
    update_all_signal_outcomes,
)
from backend.app.analysis.shadow_portfolio import (
    CLOSED_STATUS,
    OPEN_STATUS,
    ShadowPortfolioError,
    ShadowPortfolioStore,
    close_shadow_position,
    open_from_signal,
    open_shadow_position,
    position_rows,
    positions_to_csv,
    refresh_all_open_positions,
)
from backend.app.analysis.active_shadow_trader import (
    ACTION_EXIT_REVIEW,
    ACTION_STOP_EXIT,
    NEWS_OPTIONS,
    TECH_OPTIONS,
    ActiveShadowTraderError,
    ActiveShadowTraderStore,
    TraderPolicy,
    assess_shadow_position,
    stable_position_key,
)
from backend.app.analysis.weekly_performance_report import (
    WeeklyPerformanceArchive,
    WeeklyPerformanceReportError,
    build_weekly_performance_report,
    group_rows_for_table,
    summary_rows as weekly_summary_rows,
    weekly_report_csv_bytes,
    weekly_report_pdf_bytes,
)
from backend.app.analysis.success_comparison_report import (
    SuccessComparisonError,
    build_success_comparison_report,
    comparison_csv_bytes,
    comparison_pdf_bytes,
    comparison_rows,
)
from backend.app.analysis.v13_calibration_closeout import (
    DEVAM,
    KALIBRASYON_GEREKLI,
    TEMKINLI_DEVAM,
    build_v13_calibration_decision,
    criterion_rows,
    decision_summary_rows,
)
from backend.app.analysis.indicator_contribution import (
    analyze_indicator_contributions,
    analyze_redundancy,
    contribution_rows,
    contribution_to_csv,
    redundancy_rows,
)
from backend.app.analysis.walk_forward_calibration import (
    WalkForwardCalibrationError,
    aggregate_rows,
    calibration_to_csv,
    run_walk_forward_calibration,
    window_rows,
)
from backend.app.data.delayed_data_pilot import (
    DelayedDataPilotConfig,
    DelayedDataPilotError,
    DelayedDataPilotStore,
    fetch_delayed_snapshot,
    pilot_rows,
    pilot_to_csv,
)
from backend.app.analysis.daily_operation_panel import (
    alert_rows,
    observability_rows,
    build_daily_operation_summary,
    task_rows,
)
from backend.app.analysis.daily_operation_ai_context import (
    load_daily_ai_operation_context,
)
from backend.app.analysis.morning_operation_snapshot import (
    build_morning_operation_snapshot,
)
from backend.app.analysis.morning_candidate_flow import (
    morning_candidate_rows,
)
from backend.app.analysis.daily_buy_decision_cycle import (
    DailyBuyDecisionJsonStore,
    build_daily_buy_decision_snapshot,
    compare_evening_morning,
    compare_evening_morning_replacements,
    daily_buy_decision_change_rows,
    daily_buy_decision_replacement_rows,
    resolve_daily_buy_decision_phase,
)
from backend.app.analysis.daily_buy_decision_closeout import (
    build_daily_buy_decisions,
    daily_buy_decision_rows,
)
from backend.app.analysis.high_conviction_buy_gate import (
    HIGH_CONFIDENCE as HIGH_CONVICTION_BUY,
    NORMAL_CONFIDENCE as NORMAL_CONVICTION_BUY,
    build_high_conviction_buy_gate,
    high_conviction_rows,
)
from backend.app.analysis.morning_final_action_board import (
    build_morning_final_actions,
    morning_final_action_rows,
)
from backend.app.analysis.eod_final_action_board import (
    build_eod_final_actions,
    eod_final_action_rows,
)
from backend.app.analysis.eod_morning_board_delta import (
    build_eod_morning_board_delta,
    eod_morning_board_delta_rows,
)
from backend.app.analysis.daily_buy_decision_output_archive import (
    DecisionOutputArchiveJsonStore,
    daily_decision_archive_delta_rows,
    decision_output_archive_rows,
    decision_output_audit_rows,
    decision_output_board_rows,
    latest_daily_compare,
)

from backend.app.analysis.daily_buy_decision_operational_closeout import (
    build_operational_closeout,
    operational_closeout_rows,
)
from backend.app.operations.daily_buy_decision_scheduled_runner import (
    ScheduledRunAuditJsonStore,
    ScheduledRunJsonStore,
    retry_failed_or_missing_run,
    scheduler_audit_rows,
    scheduler_daily_chain_rows,
    scheduler_health_rows,
    scheduler_status_rows,
)
from backend.app.analysis.daily_buy_decision_outcomes import (
    BuyDecisionOutcomeJsonStore,
    apply_session_prices,
    buy_decision_hit_summary,
    buy_decision_outcome_rows,
    register_buy_decisions,
)
from backend.app.analysis.daily_buy_decision_calibration import (
    build_buy_decision_calibration,
    buy_decision_calibration_rows,
)
from backend.app.analysis.daily_buy_decision_review import (
    build_daily_decision_reviews,
    daily_decision_review_rows,
    daily_decision_review_summary,
)
from backend.app.analysis.daily_buy_decision_threshold_recommendation import (
    build_threshold_recommendations,
    threshold_recommendation_rows,
)
from backend.app.analysis.daily_buy_decision_recommendation_governance import (
    APPROVED as GOVERNANCE_APPROVED,
    REJECTED as GOVERNANCE_REJECTED,
    RecommendationGovernanceJsonStore,
    governance_rows,
    review_governance_record,
    sync_governance_records,
)
from backend.app.analysis.ranking_visibility_service import (
    build_current_visibility_context,
)
from backend.app.market_context.ai_history import (
    load_ai_evaluation_history,
)
from backend.app.market_context.ai_history_view import (
    build_ai_history_view,
)
from backend.app.market_context.ai_trend_analysis import (
    analyze_ai_history_trend,
)
from backend.app.analysis.fundamental_quality import (
    apply_optional_fundamental_filter,
    calculate_fundamental_quality,
)
from backend.app.data.fundamental_settings import (
    FundamentalAnalysisSettings,
    FundamentalSettingsError,
    FundamentalSettingsJsonStore,
)
from backend.app.data.fundamental_score_store import (
    FundamentalScoreJsonStore,
    FundamentalScoreStoreError,
)
from backend.app.analysis.fundamental_score_history import (
    comparison_rows,
    history_rows,
    latest_score_change,
)
from backend.app.analysis.sector_reference import (
    SectorReferenceError,
    build_company_ratio_references,
    compare_company_to_sector,
    references_from_csv_bytes,
    sector_comparison_rows,
)
from backend.app.analysis.sector_score_ranking import (
    SectorScoreRankingError,
    build_sector_score_ranking,
    sector_score_ranking_rows,
)
from backend.app.analysis.sector_strength_map import (
    SectorStrengthMapError,
    build_sector_strength_map,
    sector_strength_rows,
)
from backend.app.reporting.fundamental_report import (
    FundamentalReport,
    FundamentalReportError,
    fundamental_report_csv_bytes,
    fundamental_report_file_names,
    fundamental_report_pdf_bytes,
)
from backend.app.reporting.fundamental_report_archive import (
    FundamentalReportArchiveError,
    FundamentalReportArchiveFilter,
    FundamentalReportJsonArchive,
    archived_reports_csv_bytes,
    archived_reports_pdf_bytes,
    compare_archived_reports,
    report_archive_rows,
    report_comparison_rows,
    search_archived_reports,
)
from backend.app.data.fundamental_data import (
    FundamentalDataError,
    evaluate_fundamental_freshness,
    periods_from_csv_bytes,
    periods_from_json_bytes,
)
from backend.app.data.kap_api_config import (
    load_kap_api_configuration,
    validate_kap_api_configuration,
)

from backend.app.backtest.backtest_service import BacktestServiceError
from backend.app.backtest.same_data_comparison import (
    BAZ_ANALIZ,
    KARSILASTIRMA_ANALIZI,
    SameDataComparisonError,
    SameDataComparisonMetric,
    SameDataComparisonResult,
    SameDataComparisonService,
)
from backend.app.history.backtest_history import (
    GUNCEL_TEKNIK_ANALIZ,
    PORTFOY_ANALIZI,
    TEK_HISSE_ANALIZI,
    BacktestHistoryError,
    BacktestHistoryRecord,
    BacktestHistoryStore,
)
from backend.app.history.backtest_history_comparison import (
    ESIT,
    ILK_KAYIT,
    IKINCI_KAYIT,
    BacktestHistoryComparisonError,
    HistoryComparisonMetric,
    gecmis_kayitlarini_karsilastir,
)
from backend.app.history.backtest_history_filter import (
    BacktestHistoryFilter,
    gecmis_kayitlarini_filtrele,
    kayit_sembolleri,
    kayit_tarih_araligi,
)
from backend.app.history.backtest_history_pagination import (
    SIRALAMA_DUSUS_ARTAN,
    SIRALAMA_EN_ESKI,
    SIRALAMA_EN_YENI,
    SIRALAMA_GETIRI_AZALAN,
    SIRALAMA_SEMBOL_ARTAN,
    gecmis_kayitlarini_sayfala,
    gecmis_kayitlarini_sirala,
)
from backend.app.history.backtest_history_summary import (
    gecmis_ozeti_hesapla,
    gecmis_performans_noktalari,
)
from backend.app.history.backtest_history_backup import (
    BacktestHistoryBackupError,
    BacktestHistoryBackupService,
)
from backend.app.ui.backtest_dashboard import (
    BacktestDashboardService,
    DashboardBacktestRequest,
    DashboardResult,
)
from backend.app.ui.comparison_table import (
    ComparisonDisplayRow,
    compact_comparison_records,
    comparison_leader_records,
    comparison_table_html,
)
from backend.app.ui.portfolio_dashboard import (
    PortfolioDashboardError,
    PortfolioDashboardRequest,
    PortfolioDashboardResult,
    PortfolioDashboardService,
    ozsermaye_eksen_araligi,
)
from backend.app.ui.report_export import (
    ReportExportError,
    portfoy_dosya_adlari,
    portfoy_katki_csv_baytlari,
    portfoy_ozsermaye_csv_baytlari,
    portfoy_pdf_baytlari,
    tek_hisse_dosya_adlari,
    tek_hisse_islem_csv_baytlari,
    tek_hisse_pdf_baytlari,
)
from backend.app.data.data_freshness import BatchDataFreshnessResult, DataFreshnessResult
from backend.app.ui.current_session_snapshot import (
    CurrentSessionSnapshotError,
    guncel_seans_ozeti_getir,
)
from backend.app.ui.market_regime_dashboard import (
    MarketRegimeContext,
    MarketRegimeDashboardError,
    MarketRegimeDashboardService,
    piyasa_rejimi_baglami_olustur,
)
from backend.app.ui.live_analysis_dashboard import (
    LiveAnalysisDashboardError,
    LiveAnalysisDashboardService,
    LiveAnalysisRequest,
    LiveAnalysisResult,
    OpenPositionDashboardRequest,
    OpenPositionDashboardService,
)
from backend.app.analysis.position_monitor import PositionMonitoringResult
from backend.app.analysis.market_scanner import (
    EVREN_OZEL_LISTE,
    TARAMA_EVRENLERI,
    BistMarketScannerService,
    MarketScanRequest,
    MarketScanResult,
    MarketScannerError,
    aday_tablosu_kayitlari,
    ozel_sembol_metinini_ayristir,
)
from backend.app.compliance.dashboard_manual_vbts import (
    DashboardManualVbtsError,
    load_dashboard_vbts_dataset,
)
from backend.app.compliance.dashboard_market_scanner_source_factory import (
    DashboardMarketScannerSourceError,
    build_dashboard_market_scanner,
)
from backend.app.compliance.dashboard_vbts_manager import (
    DashboardVbtsManagerError,
    add_vbts_record,
    audit_events_csv_bytes,
    audit_display_rows,
    build_vbts_record,
    classify_vbts_records,
    configured_vbts_csv_path,
    delete_vbts_record,
    inspect_vbts_backup,
    list_vbts_backups,
    list_vbts_records,
    prune_vbts_backups,
    purge_expired_vbts_records,
    read_audit_events,
    read_operational_status,
    restore_vbts_backup,
    synchronize_vbts_operational_state,
    sync_active_vbts_csv,
    validate_vbts_system_health,
)
from backend.app.compliance.kap_factory import build_kap_vbts_service
from backend.app.analysis.trend_scan_policy import (
    REJIM_POZITIF,
    REJIM_RISKLI,
    REJIM_SECICI,
    rejime_gore_trend_politikasi,
)
from backend.app.analysis.momentum_discovery import (
    SINIF_DIRENCE_YAKLASIYOR,
    SINIF_ERKEN_UYARI,
    SINIF_HACIM_BIRIKIMI,
    SINIF_KALICI_HAZIRLIK,
    SINIF_SIKISMA,
    MomentumCandidate,
    MomentumDiscoveryError,
    MomentumDiscoveryRequest,
    MomentumDiscoveryResult,
    MomentumDiscoveryService,
    momentum_aday_tablosu,
)
from backend.app.analysis.momentum_walk_forward import (
    MomentumWalkForwardError,
    MomentumWalkForwardRequest,
    MomentumWalkForwardResult,
    MomentumWalkForwardService,
    sinyal_gecmisi_tablosu,
    walk_forward_izleme_disi_tablosu,
    walk_forward_tablosu,
)
from backend.app.ui.sprint136_batch_history_ui import (
    render_sprint136_batch_panel,
)
from backend.app.analysis.loss_analysis import (
    LossAnalysisResult,
    analyze_trade_losses,
    cause_table,
    diagnostic_table,
    journal_table,
)
from backend.app.history.trade_journal import (
    DENEME_HESABI,
    GERCEK_HESAP,
    HESAP_TURLERI,
    TradeJournalError,
    TradeJournalStore,
    TradeRecord,
    csv_template_bytes,
    records_from_csv_bytes,
    records_to_csv_bytes,
)
from backend.app.risk.safety_lock import (
    SafetyDecision,
    SafetyPolicy,
    TradeProposal,
    evaluate_trade_safety,
)


GORUNUM_SECENEKLERI = {
    "Pozitif + Nötr": "pozitif-notr",
    "Yalnızca Pozitif": "pozitif",
    "Yalnızca Nötr": "notr",
    "Tümü": "tum",
}

ANALIZ_MODLARI = (
    "Açık Pozisyon İzleme",
    "Analiz Geçmişi",
    "Aynı Veri Karşılaştırması",
    "Başarı Karşılaştırması",
    "BIST Günlük Piyasa",
    "BIST Toplu Tarama",
    "Çoklu Hisse Portföyü",
    "Fırsat Radarı",
    "Fon Analiz Merkezi",
    "Gecikmeli Veri Pilotu",
    "Gölge Portföy",
    "Güncel Teknik Analiz",
    "Günlük Operasyon Paneli",
    "Haftalık Performans Raporu",
    "İşlem Kayıp Analizi",
    "Momentum Keşif",
    "Ön Yükseliş Hazırlık",
    "Ön Yükseliş Toplu Doğrulama",
    "Piyasa Haber, Olay ve Etki Merkezi",
    "Piyasa Rejimi",
    "Seans Öncesi Bağlam",
    "Sinyal Sonuçları",
    "Tek Hisse",
    "Temel Analiz",
    "V1.3 Kalibrasyon Kararı",
)

KULLANIM_AKISI = (
    "Günlük Operasyon",
    "Araştırma",
    "Hisse İnceleme",
    "Karar Terminali",
    "Portföy & Takip",
)

AKIS_MODULLERI = {
    "Günlük Operasyon": (
        "Günlük Operasyon Paneli",
        "Seans Öncesi Bağlam",
        "BIST Günlük Piyasa",
        "Piyasa Haber, Olay ve Etki Merkezi",
        "Piyasa Rejimi",
        "Gecikmeli Veri Pilotu",
    ),
    "Araştırma": (
        "Fırsat Radarı",
        "BIST Toplu Tarama",
        "Momentum Keşif",
        "Ön Yükseliş Hazırlık",
        "Ön Yükseliş Toplu Doğrulama",
    ),
    "Hisse İnceleme": (
        "Tek Hisse",
        "Fon Analiz Merkezi",
        "Temel Analiz",
        "Analiz Geçmişi",
        "Aynı Veri Karşılaştırması",
    ),
    "Karar Terminali": (
        "Güncel Teknik Analiz",
        "V1.3 Kalibrasyon Kararı",
    ),
    "Portföy & Takip": (
        "Çoklu Hisse Portföyü",
        "Açık Pozisyon İzleme",
        "Gölge Portföy",
        "Sinyal Sonuçları",
        "Haftalık Performans Raporu",
        "Başarı Karşılaştırması",
        "İşlem Kayıp Analizi",
    ),
}

if set().union(*map(set, AKIS_MODULLERI.values())) != set(ANALIZ_MODLARI):
    raise RuntimeError("Kullanım akışı mevcut analiz modüllerinin tamamını kapsamalıdır.")
TARAMA_PROFILLERI = {
    "Gevşek": "gevsek",
    "Dengeli": "dengeli",
    "Sıkı": "siki",
}


def yuzde_yaz(deger: float) -> str:
    return f"%{deger:,.2f}"


def para_yaz(deger: float) -> str:
    return f"{deger:,.2f}"


def tarih_saat_yaz(deger: object) -> str:
    """Tarihleri gereksiz gece yarısı bilgisi olmadan gösterir."""

    if hasattr(deger, "to_pydatetime"):
        deger = deger.to_pydatetime()

    if isinstance(deger, datetime):
        if deger.time() == datetime.min.time():
            return deger.strftime("%Y-%m-%d")
        return deger.strftime("%Y-%m-%d %H:%M")

    if isinstance(deger, date):
        return deger.strftime("%Y-%m-%d")

    metin = str(deger)
    if metin.endswith(" 00:00:00"):
        return metin.removesuffix(" 00:00:00")
    return metin


def arayuz_stili_uygula() -> None:
    """Metrikleri ve tabloları dar ekranlarda daha okunabilir tutar."""

    st.markdown(
        """
        <style>
        [data-testid="stMetric"] {
            border: 1px solid rgba(49, 51, 63, 0.16);
            border-radius: 0.75rem;
            padding: 0.75rem 0.85rem;
            min-height: 6.1rem;
        }
        [data-testid="stMetricValue"] {
            font-size: clamp(1.25rem, 2.2vw, 2.05rem);
            line-height: 1.18;
            white-space: normal !important;
            overflow: visible !important;
            text-overflow: clip !important;
            overflow-wrap: anywhere;
            word-break: normal;
        }
        [data-testid="stMetricLabel"] {
            white-space: normal !important;
            overflow: visible !important;
            text-overflow: clip !important;
        }
        [data-testid="stDataFrame"] {
            border: 1px solid rgba(49, 51, 63, 0.12);
            border-radius: 0.65rem;
        }
        @media (max-width: 900px) {
            [data-testid="stMetric"] {
                min-height: 5.4rem;
                padding: 0.6rem 0.7rem;
            }
            [data-testid="stMetricValue"] {
                font-size: 1.25rem;
            }
        }
        </style>
        """,
        unsafe_allow_html=True,
    )


def metrik_izgarasi_goster(
    metrikler: tuple[tuple[str, str], ...],
) -> None:
    """Metrikleri iki sütunlu, taşma yapmayan satırlara böler."""

    for baslangic in range(0, len(metrikler), 2):
        sutunlar = st.columns(2)
        for sutun, (etiket, deger) in zip(
            sutunlar,
            metrikler[baslangic : baslangic + 2],
        ):
            sutun.metric(etiket, deger)

def responsive_karsilastirma_goster(
    rows: tuple[ComparisonDisplayRow, ...],
) -> None:
    """Karşılaştırmayı dar ekran ve yazdırma görünümünde taşmadan gösterir."""

    records = compact_comparison_records(rows)
    if not records:
        st.info("Karşılaştırılacak ölçüt bulunamadı.")
        return

    st.markdown(
        comparison_table_html(rows),
        unsafe_allow_html=True,
    )

    leaders = comparison_leader_records(rows)
    if leaders:
        with st.expander("Ölçüt liderleri", expanded=False):
            st.dataframe(
                pd.DataFrame(leaders),
                width="stretch",
                hide_index=True,
                column_config={
                    "Ölçüt": st.column_config.TextColumn(width="medium"),
                    "Lider": st.column_config.TextColumn(width="medium"),
                },
            )


def indirme_dugmeleri_goster(
    indirmeler: tuple[tuple[str, bytes, str, str], ...],
) -> None:
    """İndirme düğmelerini iki sütunlu, dar ekran dostu düzende gösterir."""

    for baslangic in range(0, len(indirmeler), 2):
        sutunlar = st.columns(2)
        for sutun, (etiket, veri, dosya_adi, mime) in zip(
            sutunlar,
            indirmeler[baslangic : baslangic + 2],
        ):
            sutun.download_button(
                etiket,
                data=veri,
                file_name=dosya_adi,
                mime=mime,
                width="stretch",
                key=f"indir_{dosya_adi}",
            )


def tek_hisse_disari_aktarim_goster(sonuc: DashboardResult) -> None:
    """Tek-hisse sonucu için CSV ve PDF indirme seçeneklerini gösterir."""

    adlar = tek_hisse_dosya_adlari(sonuc)
    indirmeler: list[tuple[str, bytes, str, str]] = [
        (
            "İşlemleri CSV indir",
            tek_hisse_islem_csv_baytlari(sonuc),
            adlar.csv,
            "text/csv; charset=utf-8",
        )
    ]
    try:
        indirmeler.append(
            (
                "PDF raporunu indir",
                tek_hisse_pdf_baytlari(sonuc),
                adlar.pdf,
                "application/pdf",
            )
        )
    except ReportExportError as hata:
        st.warning(str(hata))

    st.subheader("Raporu dışa aktar")
    indirme_dugmeleri_goster(tuple(indirmeler))


def portfoy_disari_aktarim_goster(
    sonuc: PortfolioDashboardResult,
) -> None:
    """Portföy sonucu için CSV ve PDF indirme seçeneklerini gösterir."""

    adlar = portfoy_dosya_adlari(sonuc)
    indirmeler: list[tuple[str, bytes, str, str]] = [
        (
            "Hisse katkısını CSV indir",
            portfoy_katki_csv_baytlari(sonuc),
            adlar.contribution_csv,
            "text/csv; charset=utf-8",
        ),
        (
            "Günlük özsermayeyi CSV indir",
            portfoy_ozsermaye_csv_baytlari(sonuc),
            adlar.equity_csv,
            "text/csv; charset=utf-8",
        ),
    ]
    try:
        indirmeler.insert(
            0,
            (
                "PDF raporunu indir",
                portfoy_pdf_baytlari(sonuc),
                adlar.pdf,
                "application/pdf",
            ),
        )
    except ReportExportError as hata:
        st.warning(str(hata))

    st.subheader("Raporu dışa aktar")
    indirme_dugmeleri_goster(tuple(indirmeler))


def gecmis_zamani_yaz(zaman: str) -> str:
    try:
        deger = datetime.fromisoformat(zaman)
    except ValueError:
        return zaman
    return deger.strftime("%d.%m.%Y %H:%M:%S")


def gecmise_kaydet(
    sonuc: DashboardResult | PortfolioDashboardResult | LiveAnalysisResult,
) -> BacktestHistoryRecord | None:
    """Başarılı sonucu yerel analiz geçmişine kaydeder."""

    depo = BacktestHistoryStore()
    try:
        if isinstance(sonuc, DashboardResult):
            return depo.tek_hisse_kaydet(sonuc)
        if isinstance(sonuc, PortfolioDashboardResult):
            return depo.portfoy_kaydet(sonuc)
        if isinstance(sonuc, LiveAnalysisResult):
            return depo.guncel_analiz_kaydet(sonuc)
        raise TypeError("Desteklenmeyen analiz geçmişi sonucu.")
    except (BacktestHistoryError, OSError, ValueError, TypeError) as hata:
        st.warning(f"Analiz geçmişine kaydedilemedi: {hata}")
        return None


def gecmis_kaydi_etiketi(kayit: BacktestHistoryRecord) -> str:
    tur = {
        TEK_HISSE_ANALIZI: "Tek Hisse",
        PORTFOY_ANALIZI: "Portföy",
        GUNCEL_TEKNIK_ANALIZ: "Güncel Teknik Analiz",
    }.get(kayit.analiz_turu, kayit.analiz_turu)
    semboller = ", ".join(kayit.semboller)
    return (
        f"{gecmis_zamani_yaz(kayit.kaydedilme_zamani)} · "
        f"{tur} · {semboller}"
    )


def karsilastirma_degeri_yaz(
    metrik: HistoryComparisonMetric,
    deger: float,
) -> str:
    if metrik.birim == "para":
        return para_yaz(deger)
    if metrik.birim == "yuzde":
        return yuzde_yaz(deger)
    if metrik.birim == "sayi":
        return f"{deger:,.0f}"
    return f"{deger:,.2f}"


def karsilastirma_farki_yaz(metrik: HistoryComparisonMetric) -> str:
    if metrik.birim == "para":
        return f"{metrik.fark:+,.2f}"
    if metrik.birim == "yuzde":
        return f"{metrik.fark:+,.2f} puan"
    if metrik.birim == "sayi":
        return f"{metrik.fark:+,.0f}"
    return f"{metrik.fark:+,.2f}"


def karsilastirma_lideri_yaz(metrik: HistoryComparisonMetric) -> str:
    if metrik.lider == ILK_KAYIT:
        return "Baz analiz"
    if metrik.lider == IKINCI_KAYIT:
        return "Karşılaştırılan"
    if metrik.lider == ESIT and metrik.iyilik_yonu != "notr":
        return "Eşit"
    return "—"


def analiz_karsilastirmasi_goster(
    depo: BacktestHistoryStore,
    baz_kayit: BacktestHistoryRecord,
    kayitlar: tuple[BacktestHistoryRecord, ...],
) -> None:
    adaylar = tuple(
        kayit
        for kayit in kayitlar
        if kayit.analiz_turu == baz_kayit.analiz_turu
        and kayit.kayit_kimligi != baz_kayit.kayit_kimligi
    )
    st.subheader("Analiz karşılaştırması")
    if not adaylar:
        st.caption(
            "Karşılaştırma için aynı türde en az iki farklı geçmiş kayıt gerekir."
        )
        return

    karsilastirma_acik = st.checkbox(
        "İkinci bir analizle karşılaştır",
        value=False,
        key=f"karsilastirma_acik_{baz_kayit.kayit_kimligi}",
    )
    if not karsilastirma_acik:
        return

    ikinci_kimlik = st.selectbox(
        "Karşılaştırılacak analiz",
        options=tuple(kayit.kayit_kimligi for kayit in adaylar),
        format_func=lambda kimlik: gecmis_kaydi_etiketi(
            next(k for k in adaylar if k.kayit_kimligi == kimlik)
        ),
        key=f"karsilastirma_kaydi_{baz_kayit.kayit_kimligi}",
    )
    ikinci = next(
        kayit for kayit in adaylar if kayit.kayit_kimligi == ikinci_kimlik
    )

    try:
        karsilastirma = gecmis_kayitlarini_karsilastir(
            baz_kayit,
            ikinci,
        )
    except (BacktestHistoryComparisonError, TypeError, ValueError) as hata:
        st.error(str(hata))
        return

    if karsilastirma.dogrudan_karsilastirilabilir:
        if karsilastirma.ayarlar_ayni:
            st.info("Aynı veri ve aynı ayarlarla üretilmiş iki kayıt karşılaştırılıyor.")
        else:
            st.success(
                "Aynı sembol, dönem ve fiyat verisi kullanılmış. "
                "Performans farkı ayar değişikliğini değerlendirmek için uygundur."
            )
    else:
        st.warning(
            "Kayıtlar aynı veri tabanında değil. Farklar yalnızca genel eğilim "
            "olarak yorumlanmalıdır."
        )

    for uyari in karsilastirma.uyarilar:
        st.caption(f"• {uyari}")

    satirlar = tuple(
        ComparisonDisplayRow(
            label=metrik.etiket,
            base_value=karsilastirma_degeri_yaz(
                metrik, metrik.ilk_deger
            ),
            comparison_value=karsilastirma_degeri_yaz(
                metrik, metrik.ikinci_deger
            ),
            difference=karsilastirma_farki_yaz(metrik),
            leader=karsilastirma_lideri_yaz(metrik),
        )
        for metrik in karsilastirma.metrikler
    )
    responsive_karsilastirma_goster(satirlar)

    with st.expander("Karşılaştırma kimlikleri", expanded=False):
        st.write(
            {
                "Baz veri kimliği": baz_kayit.veri_kimligi,
                "Karşılaştırılan veri kimliği": ikinci.veri_kimligi,
                "Baz ayar kimliği": baz_kayit.ayar_kimligi,
                "Karşılaştırılan ayar kimliği": ikinci.ayar_kimligi,
            }
        )


def gecmis_yonetimi_goster(
    depo: BacktestHistoryStore,
    kayitlar: tuple[BacktestHistoryRecord, ...],
    varsayilan_kayit: BacktestHistoryRecord,
) -> None:
    """Seçili geçmiş kayıtları için güvenli ve açık silme akışı gösterir."""

    with st.expander("Geçmiş yönetimi", expanded=False):
        st.warning(
            "Silinen analiz kaydı ve ona ait CSV/PDF dosyaları geri alınamaz. "
            "Proje kaynak dosyaları ve diğer geçmiş kayıtları etkilenmez."
        )
        secili_kimlikler = st.multiselect(
            "Silinecek kayıtlar",
            options=tuple(kayit.kayit_kimligi for kayit in kayitlar),
            default=(varsayilan_kayit.kayit_kimligi,),
            format_func=lambda kimlik: gecmis_kaydi_etiketi(
                next(k for k in kayitlar if k.kayit_kimligi == kimlik)
            ),
            key=f"gecmis_silinecek_{varsayilan_kayit.kayit_kimligi}",
        )
        onay_kutusu = st.checkbox(
            "Seçili kayıtların kalıcı olarak silineceğini anlıyorum.",
            value=False,
            key=f"gecmis_silme_onayi_{varsayilan_kayit.kayit_kimligi}",
        )
        onay_metni = st.text_input(
            "Onaylamak için SİL yazın",
            value="",
            key=f"gecmis_silme_metni_{varsayilan_kayit.kayit_kimligi}",
        )
        silme_hazir = (
            bool(secili_kimlikler)
            and onay_kutusu
            and onay_metni.strip().upper() == "SİL"
        )
        silme_istendi = st.button(
            "Seçili kayıtları kalıcı olarak sil",
            type="primary",
            width="stretch",
            disabled=not silme_hazir,
            key=f"gecmis_sil_{varsayilan_kayit.kayit_kimligi}",
        )
        if not silme_istendi:
            return

        try:
            silinenler = depo.kayitlari_sil(tuple(secili_kimlikler))
        except (BacktestHistoryError, OSError, ValueError, TypeError) as hata:
            st.error(f"Seçili geçmiş kayıtları silinemedi: {hata}")
            return

        st.session_state["gecmis_silme_bildirimi"] = (
            f"{len(silinenler)} analiz kaydı kalıcı olarak silindi."
        )
        st.rerun()


def gecmis_yedekleme_goster(
    depo: BacktestHistoryStore,
    kayitlar: tuple[BacktestHistoryRecord, ...],
) -> None:
    """Analiz geçmişini ZIP olarak yedekler ve güvenle geri yükler."""

    servis = BacktestHistoryBackupService(depo)
    with st.expander("Yedekleme ve geri yükleme", expanded=False):
        st.caption(
            "Yedek yalnızca analiz geçmişi metadata, CSV ve PDF dosyalarını "
            "içerir; proje kaynakları ve piyasa verileri dahil edilmez."
        )
        kimlikten_kayit = {
            kayit.kayit_kimligi: kayit for kayit in kayitlar
        }
        secili_kimlikler = st.multiselect(
            "Yedeklenecek kayıtlar",
            options=tuple(kimlikten_kayit),
            default=tuple(kimlikten_kayit),
            format_func=lambda kimlik: gecmis_kaydi_etiketi(
                kimlikten_kayit[kimlik]
            ),
            key="gecmis_yedeklenecek_kayitlar",
        )
        if secili_kimlikler:
            try:
                yedek = servis.yedek_olustur(tuple(secili_kimlikler))
            except (
                BacktestHistoryBackupError,
                BacktestHistoryError,
                OSError,
                ValueError,
                TypeError,
            ) as hata:
                st.error(f"Analiz geçmişi yedeği oluşturulamadı: {hata}")
            else:
                zaman = datetime.now().strftime("%Y%m%d_%H%M%S")
                st.download_button(
                    "Seçili kayıtları ZIP olarak yedekle",
                    data=yedek,
                    file_name=f"hisse_robotu_analiz_gecmisi_{zaman}.zip",
                    mime="application/zip",
                    width="stretch",
                    key="gecmis_yedek_indir",
                )
        else:
            st.info("ZIP yedeği için en az bir kayıt seçin.")

        st.divider()
        st.markdown("**ZIP yedeğini geri yükle**")
        yuklenen = st.file_uploader(
            "Analiz geçmişi ZIP yedeği",
            type=("zip",),
            accept_multiple_files=False,
            key="gecmis_yedek_yukle",
        )
        if yuklenen is None:
            return

        yedek_baytlari = yuklenen.getvalue()
        try:
            onizleme = servis.yedegi_incele(yedek_baytlari)
        except (
            BacktestHistoryBackupError,
            BacktestHistoryError,
            OSError,
            ValueError,
            TypeError,
        ) as hata:
            st.error(f"Analiz geçmişi yedeği doğrulanamadı: {hata}")
            return

        metrik_izgarasi_goster(
            (
                ("Yedekteki kayıt", str(onizleme.toplam_kayit)),
                ("Yeni kayıt", str(onizleme.yeni_kayit)),
                ("Zaten mevcut", str(onizleme.zaten_mevcut)),
                ("Dosya sayısı", str(onizleme.toplam_dosya)),
            )
        )
        if onizleme.yeni_kayit == 0:
            st.info("Yedekteki kayıtların tamamı analiz geçmişinde zaten mevcut.")

        geri_yukleme_onayi = st.checkbox(
            "Yedekteki yeni kayıtların analiz geçmişine eklenmesini onaylıyorum.",
            value=False,
            key="gecmis_geri_yukleme_onayi",
        )
        geri_yukle = st.button(
            "Yedeği geri yükle",
            type="primary",
            width="stretch",
            disabled=(
                not geri_yukleme_onayi or onizleme.yeni_kayit == 0
            ),
            key="gecmis_yedegi_geri_yukle",
        )
        if not geri_yukle:
            return

        try:
            sonuc = servis.yedegi_geri_yukle(yedek_baytlari)
        except (
            BacktestHistoryBackupError,
            BacktestHistoryError,
            OSError,
            ValueError,
            TypeError,
        ) as hata:
            st.error(f"Analiz geçmişi yedeği geri yüklenemedi: {hata}")
            return

        st.session_state["gecmis_geri_yukleme_bildirimi"] = (
            f"{sonuc.geri_yuklenen} analiz kaydı geri yüklendi; "
            f"{sonuc.atlanan_ayni_kayit} aynı kayıt atlandı."
        )
        st.rerun()



def gecmis_performans_ozeti_goster(
    kayitlar: tuple[BacktestHistoryRecord, ...],
) -> None:
    """Filtrelenmiş analiz geçmişinin risk-getiri özetini gösterir."""

    if not kayitlar:
        return

    try:
        ozet = gecmis_ozeti_hesapla(kayitlar)
        noktalar = gecmis_performans_noktalari(kayitlar)
    except (TypeError, ValueError) as hata:
        st.warning(f"Analiz geçmişi özeti hazırlanamadı: {hata}")
        return

    with st.expander("Geçmiş performans özeti", expanded=True):
        metrik_izgarasi_goster(
            (
                ("Filtrelenmiş kayıt", str(ozet.toplam_kayit)),
                ("Benzersiz sembol", str(ozet.benzersiz_sembol_sayisi)),
                ("Toplam işlem", str(ozet.toplam_tamamlanan_islem)),
                (
                    "Medyan getiri",
                    yuzde_yaz(ozet.medyan_getiri_yuzde)
                    if ozet.medyan_getiri_yuzde is not None
                    else "-",
                ),
                (
                    "Medyan maks. düşüş",
                    yuzde_yaz(ozet.medyan_maksimum_dusus_yuzde)
                    if ozet.medyan_maksimum_dusus_yuzde is not None
                    else "-",
                ),
                (
                    "Ort. kâr faktörü",
                    f"{ozet.ortalama_kar_faktoru:.2f}"
                    if ozet.ortalama_kar_faktoru is not None
                    else "-",
                ),
            )
        )

        lider_sutunlari = st.columns(2)
        en_yuksek = ozet.en_yuksek_getiri_kaydi
        en_dusuk = ozet.en_dusuk_dusus_kaydi
        with lider_sutunlari[0]:
            st.markdown("**En yüksek toplam getiri**")
            if en_yuksek is not None:
                st.write(gecmis_kaydi_etiketi(en_yuksek))
                st.caption(yuzde_yaz(en_yuksek.toplam_getiri_yuzde))
        with lider_sutunlari[1]:
            st.markdown("**En düşük maksimum düşüş**")
            if en_dusuk is not None:
                st.write(gecmis_kaydi_etiketi(en_dusuk))
                st.caption(yuzde_yaz(en_dusuk.maksimum_dusus_yuzde))

        if len(noktalar) >= 2:
            grafik_verisi = pd.DataFrame(
                [
                    {
                        "Analiz": nokta.etiket,
                        "Analiz türü": nokta.analiz_turu,
                        "Maksimum düşüş (%)": nokta.maksimum_dusus_yuzde,
                        "Toplam getiri (%)": nokta.toplam_getiri_yuzde,
                        "Tamamlanan işlem": nokta.tamamlanan_islem_sayisi,
                    }
                    for nokta in noktalar
                ]
            )
            st.subheader("Risk-getiri görünümü")
            st.scatter_chart(
                grafik_verisi,
                x="Maksimum düşüş (%)",
                y="Toplam getiri (%)",
                color="Analiz türü",
                size="Tamamlanan işlem",
                width="stretch",
                height=360,
            )
        else:
            st.info(
                "Risk-getiri grafiği için en az iki filtrelenmiş kayıt gerekir."
            )

        st.caption(
            "Özet, filtrelenmiş kayıtları betimleyici olarak karşılaştırır; "
            "farklı sembol ve ayarları tek bir birleşik portföy sonucu saymaz."
        )

def _gecmis_alt_sozluk(
    kayit: BacktestHistoryRecord,
    anahtar: str,
) -> dict[str, object]:
    bilgiler = kayit.ozel_bilgiler or {}
    deger = bilgiler.get(anahtar, {})
    return deger if isinstance(deger, dict) else {}


def guncel_analiz_gecmis_kaydi_goster(
    kayit: BacktestHistoryRecord,
) -> None:
    """Kaydedilmiş güncel teknik analiz sonucunu yeniden gösterir."""

    fiyat = _gecmis_alt_sozluk(kayit, "fiyat_verisi")
    teknik = _gecmis_alt_sozluk(kayit, "teknik_teyit")
    plan = _gecmis_alt_sozluk(kayit, "islem_plani")
    pozisyon = _gecmis_alt_sozluk(kayit, "risk_ve_pozisyon")
    kimlikler = _gecmis_alt_sozluk(kayit, "kimlikler")

    st.success(kayit.baslik)
    st.caption(
        f"Kaydedilme: {gecmis_zamani_yaz(kayit.kaydedilme_zamani)} · "
        f"{kayit.donem}"
    )
    metrik_izgarasi_goster(
        (
            ("Fiyat verisi", str(fiyat.get("durum") or "—")),
            ("Fiyat veri tarihi", str(fiyat.get("son_veri_tarihi") or "—")),
            ("Teknik teyit skoru", f"{teknik.get('skor', '—')}/100"),
            ("Teyit durumu", str(teknik.get("durum") or "—")),
            ("İşlem kararı", str(plan.get("karar") or "—")),
            ("Plan tipi", str(plan.get("plan_tipi") or "—")),
        )
    )

    teyit_tab, plan_tab, kimlik_tab = st.tabs(
        ("Teknik teyit özeti", "İşlem planı", "Analiz kimlikleri")
    )
    with teyit_tab:
        metrik_izgarasi_goster(
            (
                ("Haftalık yön", str(teknik.get("haftalik_yon") or "—")),
                ("Haftalık skor", str(teknik.get("haftalik_skor") or "—")),
                ("Günlük yön", str(teknik.get("gunluk_yon") or "—")),
                ("Günlük skor", str(teknik.get("gunluk_skor") or "—")),
                ("Saatlik yön", str(teknik.get("saatlik_yon") or "—")),
                ("Saatlik skor", str(teknik.get("saatlik_skor") or "—")),
            )
        )
        aciklama_listesi_goster(
            "Pozitif teyitler",
            tuple(teknik.get("pozitif_nedenler") or ()),
            "Kaydedilmiş pozitif teyit yok.",
        )
        aciklama_listesi_goster(
            "Riskler",
            tuple(teknik.get("riskler") or ()),
            "Kaydedilmiş risk yok.",
        )

    with plan_tab:
        metrik_izgarasi_goster(
            (
                ("Son kapanış", opsiyonel_fiyat_yaz(plan.get("son_kapanis"))),
                ("ATR14", opsiyonel_fiyat_yaz(plan.get("atr14"))),
                ("İzleme tetik seviyesi", opsiyonel_fiyat_yaz(plan.get("izleme_tetik_fiyati"))),
                ("Referans giriş", opsiyonel_fiyat_yaz(plan.get("referans_giris"))),
                ("Stop-loss", opsiyonel_fiyat_yaz(plan.get("stop_loss"))),
                ("Hedef 1", opsiyonel_fiyat_yaz(plan.get("hedef_1"))),
                ("Hedef 2", opsiyonel_fiyat_yaz(plan.get("hedef_2"))),
                ("Lot sayısı", str(pozisyon.get("lot_sayisi") or "—")),
                ("Risk bütçesi", opsiyonel_fiyat_yaz(pozisyon.get("risk_butcesi"))),
                ("Planlanan risk", opsiyonel_fiyat_yaz(pozisyon.get("planlanan_risk"))),
            )
        )
        aciklama_listesi_goster(
            "Beklenen teyitler",
            tuple(plan.get("beklenen_teyitler") or ()),
            "Kaydedilmiş ek teyit yok.",
        )
        aciklama_listesi_goster(
            "Planı geçersiz kılan koşullar",
            tuple(plan.get("gecersizlik_kosullari") or ()),
            "Kaydedilmiş geçersizlik koşulu yok.",
        )

    with kimlik_tab:
        st.write(
            {
                "Veri kimliği": kimlikler.get("veri_kimligi"),
                "Teknik analiz kimliği": kimlikler.get("teknik_analiz_kimligi"),
                "İşlem planı kimliği": kimlikler.get("islem_plani_kimligi"),
            }
        )


def analiz_gecmisi_goster() -> None:
    """Kalıcı geçmişteki önceki analizleri filtreleyip gösterir."""

    with st.sidebar:
        st.header("Analiz geçmişi")
        tur_etiketi = st.selectbox(
            "Kayıt türü",
            options=("Tümü", "Tek Hisse", "Portföy", "Güncel Teknik Analiz"),
            index=0,
        )
        arama = st.text_input(
            "Geçmişte ara",
            value="",
            placeholder="Sembol, başlık veya kimlik",
        )
        siralama_etiketi = st.selectbox(
            "Sıralama",
            options=(
                "En yeni kayıt",
                "En eski kayıt",
                "Toplam getiri: yüksekten düşüğe",
                "Maksimum düşüş: düşükten yükseğe",
                "Sembol: A-Z",
            ),
            index=0,
        )
        sayfa_boyutu = st.selectbox(
            "Sayfa başına kayıt",
            options=(10, 25, 50, 100),
            index=1,
        )

    silme_bildirimi = st.session_state.pop(
        "gecmis_silme_bildirimi",
        None,
    )
    if silme_bildirimi:
        st.success(silme_bildirimi)

    geri_yukleme_bildirimi = st.session_state.pop(
        "gecmis_geri_yukleme_bildirimi",
        None,
    )
    if geri_yukleme_bildirimi:
        st.success(geri_yukleme_bildirimi)

    tur_esleme = {
        "Tümü": None,
        "Tek Hisse": TEK_HISSE_ANALIZI,
        "Portföy": PORTFOY_ANALIZI,
        "Güncel Teknik Analiz": GUNCEL_TEKNIK_ANALIZ,
    }
    depo = BacktestHistoryStore()
    try:
        tum_kayitlar = depo.kayitlari_listele(
            analiz_turu=tur_esleme[tur_etiketi],
            limit=500,
        )
    except (BacktestHistoryError, ValueError) as hata:
        st.error(str(hata))
        return

    sembol_secenekleri = kayit_sembolleri(tum_kayitlar)
    tarih_araligi = kayit_tarih_araligi(tum_kayitlar)
    with st.sidebar:
        secili_semboller = st.multiselect(
            "Sembol filtresi",
            options=sembol_secenekleri,
            default=(),
            help="Boş bırakıldığında tüm semboller gösterilir.",
        )
        baslangic_tarihi = None
        bitis_tarihi = None
        if tarih_araligi is not None:
            tarih_secimi = st.date_input(
                "Kaydedilme tarihi aralığı",
                value=tarih_araligi,
                min_value=tarih_araligi[0],
                max_value=tarih_araligi[1],
                format="DD.MM.YYYY",
                help="Backtest dönemi değil, kaydın oluşturulduğu tarih kullanılır.",
            )
            if isinstance(tarih_secimi, (tuple, list)):
                if len(tarih_secimi) == 2:
                    baslangic_tarihi, bitis_tarihi = tarih_secimi
                elif len(tarih_secimi) == 1:
                    baslangic_tarihi = bitis_tarihi = tarih_secimi[0]
            else:
                baslangic_tarihi = bitis_tarihi = tarih_secimi

    try:
        filtrelenmis_kayitlar = gecmis_kayitlarini_filtrele(
            tum_kayitlar,
            BacktestHistoryFilter(
                arama=arama,
                semboller=tuple(secili_semboller),
                baslangic_tarihi=baslangic_tarihi,
                bitis_tarihi=bitis_tarihi,
            ),
        )
        siralama_esleme = {
            "En yeni kayıt": SIRALAMA_EN_YENI,
            "En eski kayıt": SIRALAMA_EN_ESKI,
            "Toplam getiri: yüksekten düşüğe": SIRALAMA_GETIRI_AZALAN,
            "Maksimum düşüş: düşükten yükseğe": SIRALAMA_DUSUS_ARTAN,
            "Sembol: A-Z": SIRALAMA_SEMBOL_ARTAN,
        }
        sirali_kayitlar = gecmis_kayitlarini_sirala(
            filtrelenmis_kayitlar,
            siralama_esleme[siralama_etiketi],
        )
    except (TypeError, ValueError) as hata:
        st.error(f"Analiz geçmişi filtrelenemedi: {hata}")
        return

    toplam_sayfa = max(
        1,
        (len(sirali_kayitlar) + int(sayfa_boyutu) - 1)
        // int(sayfa_boyutu),
    )
    with st.sidebar:
        sayfa = st.selectbox(
            "Sayfa",
            options=tuple(range(1, toplam_sayfa + 1)),
            index=0,
            format_func=lambda deger: f"{deger} / {toplam_sayfa}",
        )

    try:
        sayfa_sonucu = gecmis_kayitlarini_sayfala(
            sirali_kayitlar,
            sayfa=int(sayfa),
            sayfa_boyutu=int(sayfa_boyutu),
        )
    except (TypeError, ValueError) as hata:
        st.error(f"Analiz geçmişi sayfalanamadı: {hata}")
        return

    kayitlar = sirali_kayitlar
    sayfa_kayitlari = sayfa_sonucu.kayitlar
    if sayfa_sonucu.toplam_kayit:
        st.caption(
            f"Filtre sonucu: {sayfa_sonucu.toplam_kayit} / "
            f"{len(tum_kayitlar)} kayıt · "
            f"Sayfa {sayfa_sonucu.sayfa} / "
            f"{sayfa_sonucu.toplam_sayfa} · "
            f"{sayfa_sonucu.ilk_sira}–{sayfa_sonucu.son_sira}. kayıtlar"
        )
    else:
        st.caption(
            f"Filtre sonucu: 0 / {len(tum_kayitlar)} kayıt"
        )
    gecmis_yedekleme_goster(depo, kayitlar)

    if not tum_kayitlar:
        st.info(
            "Henüz kayıtlı analiz bulunmuyor. Başarılı backtest ve güncel "
            "teknik analiz sonuçları burada saklanacak."
        )
        st.caption(f"Kayıt klasörü: {depo.kok_klasor}")
        return

    if not sirali_kayitlar:
        st.info(
            "Seçilen arama, sembol ve tarih filtreleriyle eşleşen "
            "analiz kaydı bulunamadı."
        )
        st.caption(f"Kayıt klasörü: {depo.kok_klasor}")
        return

    performans_kayitlari = tuple(
        k for k in sirali_kayitlar
        if k.analiz_turu in (TEK_HISSE_ANALIZI, PORTFOY_ANALIZI)
    )
    gecmis_performans_ozeti_goster(performans_kayitlari)

    secilen_kimlik = st.selectbox(
        "Geçmiş analiz",
        options=tuple(kayit.kayit_kimligi for kayit in sayfa_kayitlari),
        format_func=lambda kimlik: gecmis_kaydi_etiketi(
            next(k for k in sayfa_kayitlari if k.kayit_kimligi == kimlik)
        ),
    )
    kayit = next(
        kayit for kayit in sayfa_kayitlari
        if kayit.kayit_kimligi == secilen_kimlik
    )

    if kayit.analiz_turu == GUNCEL_TEKNIK_ANALIZ:
        guncel_analiz_gecmis_kaydi_goster(kayit)
    else:
        st.success(kayit.baslik)
        st.caption(
            f"Kaydedilme: {gecmis_zamani_yaz(kayit.kaydedilme_zamani)} · "
            f"Dönem: {kayit.donem}"
        )
        metrik_izgarasi_goster(
            (
                ("Bitiş sermayesi", para_yaz(kayit.bitis_sermayesi)),
                ("Toplam getiri", yuzde_yaz(kayit.toplam_getiri_yuzde)),
                ("Maksimum düşüş", yuzde_yaz(kayit.maksimum_dusus_yuzde)),
                ("Tamamlanan işlem", str(kayit.tamamlanan_islem_sayisi)),
                ("Atlanan", str(kayit.atlanan_islem_sayisi)),
                (
                    "Kâr faktörü",
                    f"{kayit.kar_faktoru:.2f}"
                    if kayit.kar_faktoru is not None
                    else "-",
                ),
            )
        )

    gecmis_yonetimi_goster(depo, kayitlar, kayit)

    with st.expander("Kayıt ayrıntıları", expanded=False):
        ayrintilar: dict[str, object] = {
            "Semboller": ", ".join(kayit.semboller),
            "Veri kimliği": kayit.veri_kimligi,
            "Ayar kimliği": kayit.ayar_kimligi,
        }
        if kayit.analiz_turu != GUNCEL_TEKNIK_ANALIZ:
            ayrintilar["Güncel düşüş"] = yuzde_yaz(
                kayit.guncel_dusus_yuzde
            )
        if kayit.analiz_kimligi is not None:
            ayrintilar["Analiz kimliği"] = kayit.analiz_kimligi
        if kayit.kazanma_yuzde is not None:
            ayrintilar["Kazanma oranı"] = yuzde_yaz(
                kayit.kazanma_yuzde
            )
        if kayit.ortalama_sermaye_kullanim_yuzde is not None:
            ayrintilar["Ortalama sermaye kullanımı"] = yuzde_yaz(
                kayit.ortalama_sermaye_kullanim_yuzde
            )
        if kayit.maksimum_pozisyon is not None:
            ayrintilar["Maksimum pozisyon"] = kayit.maksimum_pozisyon
        st.write(ayrintilar)

    if kayit.analiz_turu != GUNCEL_TEKNIK_ANALIZ:
        analiz_karsilastirmasi_goster(depo, kayit, kayitlar)

    indirme_etiketleri = {
        "pdf": "PDF raporunu indir",
        "islemler_csv": "İşlemleri CSV indir",
        "katki_csv": "Hisse katkısını CSV indir",
        "ozsermaye_csv": "Günlük özsermayeyi CSV indir",
        "guncel_analiz_csv": "Güncel analiz özetini CSV indir",
    }
    indirmeler: list[tuple[str, bytes, str, str]] = []
    for dosya in kayit.dosyalar:
        try:
            veri = depo.dosya_baytlari(kayit, dosya.tur)
        except BacktestHistoryError as hata:
            st.warning(str(hata))
            continue
        indirmeler.append(
            (
                indirme_etiketleri.get(dosya.tur, dosya.dosya_adi),
                veri,
                dosya.dosya_adi,
                dosya.mime,
            )
        )

    if indirmeler:
        st.subheader("Kayıtlı raporlar")
        indirme_dugmeleri_goster(tuple(indirmeler))
    st.caption(f"Kayıt klasörü: {depo.kok_klasor}")


def tek_hisse_sonucu_goster(sonuc: DashboardResult) -> None:
    ozet = sonuc.ozet

    st.success(f"{ozet.sembol} backtest’i tamamlandı.")
    st.caption(
        f"Fiyat dönemi: {ozet.fiyat_donemi} · "
        f"{ozet.fiyat_bar_sayisi} bar"
    )

    metrik_izgarasi_goster(
        (
            ("Bitiş sermayesi", para_yaz(ozet.bitis_sermayesi)),
            ("Toplam getiri", yuzde_yaz(ozet.toplam_getiri_yuzde)),
            ("Maksimum düşüş", yuzde_yaz(ozet.maksimum_dusus_yuzde)),
            ("Tamamlanan işlem", str(ozet.tamamlanan_islem_sayisi)),
            ("Kazanma oranı", yuzde_yaz(ozet.kazanma_yuzde)),
            (
                "Kâr faktörü",
                (
                    f"{ozet.kar_faktoru:.2f}"
                    if ozet.kar_faktoru is not None
                    else "-"
                ),
            ),
        )
    )

    with st.expander("Analiz ayrıntıları", expanded=False):
        st.write(
            {
                "Analiz kimliği": ozet.analiz_kimligi,
                "Veri kimliği": ozet.veri_kimligi,
                "Ayar kimliği": ozet.ayar_kimligi,
                "Güncel düşüş": yuzde_yaz(
                    ozet.guncel_dusus_yuzde
                ),
                "Atlanan sinyal": ozet.atlanan_sinyal_sayisi,
                "Hizalanmış Al-Tut getirisi": (
                    yuzde_yaz(ozet.al_tut_getiri_yuzde)
                    if ozet.al_tut_getiri_yuzde is not None
                    else "-"
                ),
            }
        )

    st.subheader("Tamamlanan işlemler")
    kayitlar = sonuc.islem_kayitlari()

    if not kayitlar:
        st.info("Seçilen ayarlarda tamamlanan işlem bulunamadı.")
    else:
        tablo = pd.DataFrame(kayitlar)
        st.dataframe(
            tablo,
            width="stretch",
            hide_index=True,
            column_config={
                "Giriş Fiyatı": st.column_config.NumberColumn(
                    format="%.2f"
                ),
                "Çıkış Fiyatı": st.column_config.NumberColumn(
                    format="%.2f"
                ),
                "Net Getiri (%)": st.column_config.NumberColumn(
                    format="%.2f%%"
                ),
            },
        )

    tek_hisse_disari_aktarim_goster(sonuc)


def portfoy_sonucu_goster(
    sonuc: PortfolioDashboardResult,
) -> None:
    ozet = sonuc.ozet

    st.success(
        f"{len(ozet.semboller)} hisselik portföy backtest’i tamamlandı."
    )
    st.caption(
        f"Portföy dönemi: {ozet.portfoy_donemi} · "
        f"{', '.join(ozet.semboller)}"
    )

    metrik_izgarasi_goster(
        (
            ("Bitiş sermayesi", para_yaz(ozet.bitis_sermayesi)),
            ("Toplam getiri", yuzde_yaz(ozet.toplam_getiri_yuzde)),
            ("Maksimum düşüş", yuzde_yaz(ozet.maksimum_dusus_yuzde)),
            (
                "Kâr faktörü",
                f"{ozet.kar_faktoru:.2f}"
                if ozet.kar_faktoru is not None
                else "-",
            ),
            ("Tamamlanan işlem", str(ozet.tamamlanan_islem_sayisi)),
            ("Atlanan işlem", str(ozet.atlanan_islem_sayisi)),
            (
                "Ortalama kullanım",
                yuzde_yaz(ozet.ortalama_sermaye_kullanim_yuzde),
            ),
            (
                "Maksimum pozisyon",
                str(ozet.gerceklesen_maksimum_pozisyon),
            ),
        )
    )

    with st.expander("Portföy ayrıntıları", expanded=False):
        st.write(
            {
                "Ayar kimliği": ozet.ayar_kimligi,
                "Portföy veri kimliği": ozet.portfoy_veri_kimligi,
                "Güncel düşüş": yuzde_yaz(
                    ozet.guncel_dusus_yuzde
                ),
                "Maksimum sermaye kullanımı": yuzde_yaz(
                    ozet.maksimum_sermaye_kullanim_yuzde
                ),
            }
        )

    ozsermaye_kayitlari = sonuc.ozsermaye_kayitlari()
    if ozsermaye_kayitlari:
        st.subheader("Günlük portföy özsermayesi")
        ozsermaye = pd.DataFrame(ozsermaye_kayitlari)
        ozsermaye["Tarih"] = pd.to_datetime(ozsermaye["Tarih"])
        eksen_araligi = ozsermaye_eksen_araligi(ozsermaye_kayitlari)
        grafik_ayari: dict[str, object] = {
            "mark": {"type": "line"},
            "encoding": {
                "x": {
                    "field": "Tarih",
                    "type": "temporal",
                    "title": "Tarih",
                },
                "y": {
                    "field": "Özsermaye",
                    "type": "quantitative",
                    "title": "Özsermaye",
                    "scale": {
                        "zero": False,
                        "domain": list(eksen_araligi)
                        if eksen_araligi is not None
                        else None,
                    },
                },
                "tooltip": [
                    {"field": "Tarih", "type": "temporal", "title": "Tarih"},
                    {
                        "field": "Özsermaye",
                        "type": "quantitative",
                        "title": "Özsermaye",
                        "format": ",.2f",
                    },
                    {
                        "field": "Düşüş (%)",
                        "type": "quantitative",
                        "title": "Düşüş (%)",
                        "format": ".2f",
                    },
                    {
                        "field": "Açık Pozisyon",
                        "type": "quantitative",
                        "title": "Açık Pozisyon",
                    },
                ],
            },
            "height": 340,
        }
        st.vega_lite_chart(
            ozsermaye,
            grafik_ayari,
            width="stretch",
        )

    st.subheader("Hisse bazlı katkı")
    katkilar = sonuc.kompakt_katki_kayitlari()
    if katkilar:
        st.dataframe(
            pd.DataFrame(katkilar),
            width="stretch",
            hide_index=True,
            column_config={
                "Sembol": st.column_config.TextColumn(width="small"),
                "İşlem": st.column_config.NumberColumn(width="small"),
                "Kazanma (%)": st.column_config.NumberColumn(
                    format="%.2f%%",
                    width="small",
                ),
                "Net Kâr": st.column_config.NumberColumn(
                    format="%.2f",
                    width="medium",
                ),
                "Katkı (%)": st.column_config.NumberColumn(
                    format="%.2f%%",
                    width="small",
                ),
            },
        )

        with st.expander("İşlem hacmi ayrıntıları", expanded=False):
            st.caption(
                "Toplam ayrılan sermaye, aynı sermayenin dönem boyunca "
                "yeniden kullanıldığı kümülatif işlem hacmidir."
            )
            st.dataframe(
                pd.DataFrame(sonuc.hacim_kayitlari()),
                width="stretch",
                hide_index=True,
                column_config={
                    "Sembol": st.column_config.TextColumn(width="small"),
                    "Toplam Ayrılan Sermaye": (
                        st.column_config.NumberColumn(
                            format="%.2f",
                            width="large",
                        )
                    ),
                },
            )
    else:
        st.info("Hisse bazlı katkı kaydı bulunamadı.")

    atlanmalar = sonuc.atlanma_kayitlari()
    if atlanmalar:
        with st.expander("Atlanan işlem nedenleri", expanded=False):
            st.dataframe(
                pd.DataFrame(atlanmalar),
                width="stretch",
                hide_index=True,
            )

    portfoy_disari_aktarim_goster(sonuc)



def ayni_veri_degeri_yaz(
    metrik: SameDataComparisonMetric,
    deger: float,
) -> str:
    if metrik.birim == "para":
        return para_yaz(deger)
    if metrik.birim == "yuzde":
        return yuzde_yaz(deger)
    if metrik.birim == "sayi":
        return f"{deger:,.0f}"
    return f"{deger:,.2f}"


def ayni_veri_farki_yaz(metrik: SameDataComparisonMetric) -> str:
    if metrik.birim == "para":
        return f"{metrik.fark:+,.2f}"
    if metrik.birim == "yuzde":
        return f"{metrik.fark:+,.2f} puan"
    if metrik.birim == "sayi":
        return f"{metrik.fark:+,.0f}"
    return f"{metrik.fark:+,.2f}"


def ayni_veri_lideri_yaz(metrik: SameDataComparisonMetric) -> str:
    if metrik.lider == BAZ_ANALIZ:
        return "Baz ayar"
    if metrik.lider == KARSILASTIRMA_ANALIZI:
        return "Karşılaştırma ayarı"
    if metrik.iyilik_yonu == "notr":
        return "—"
    return "Eşit"


def ayni_veri_sonucu_goster(sonuc: SameDataComparisonResult) -> None:
    st.success(
        "Fiyat verisi bir kez alındı; iki ayar aynı veri anlık "
        "görüntüsü üzerinde çalıştırıldı."
    )
    st.caption(
        f"Dönem: {sonuc.fiyat_donemi} · "
        f"Fiyat barı: {sonuc.fiyat_bar_sayisi} · "
        f"Ortak veri kimliği: {sonuc.veri_kimligi}"
    )

    baz = sonuc.baz_sonuc.ozet
    ikinci = sonuc.karsilastirma_sonucu.ozet
    sol, sag = st.columns(2)
    with sol:
        st.subheader("Baz ayar")
        st.caption(f"Ayar kimliği: {baz.ayar_kimligi}")
        st.metric("Toplam getiri", yuzde_yaz(baz.toplam_getiri_yuzde))
        st.metric("Maksimum düşüş", yuzde_yaz(baz.maksimum_dusus_yuzde))
        st.metric("Tamamlanan işlem", str(baz.tamamlanan_islem_sayisi))
    with sag:
        st.subheader("Karşılaştırma ayarı")
        st.caption(f"Ayar kimliği: {ikinci.ayar_kimligi}")
        st.metric("Toplam getiri", yuzde_yaz(ikinci.toplam_getiri_yuzde))
        st.metric("Maksimum düşüş", yuzde_yaz(ikinci.maksimum_dusus_yuzde))
        st.metric("Tamamlanan işlem", str(ikinci.tamamlanan_islem_sayisi))

    st.subheader("Aynı veri performans farkı")
    satirlar = tuple(
        ComparisonDisplayRow(
            label=metrik.etiket,
            base_value=ayni_veri_degeri_yaz(metrik, metrik.baz_deger),
            comparison_value=ayni_veri_degeri_yaz(
                metrik, metrik.karsilastirma_degeri
            ),
            difference=ayni_veri_farki_yaz(metrik),
            leader=ayni_veri_lideri_yaz(metrik),
        )
        for metrik in sonuc.metrikler
    )
    responsive_karsilastirma_goster(satirlar)

    with st.expander("Karşılaştırma kimlikleri", expanded=False):
        st.write(
            {
                "Ortak veri kimliği": sonuc.veri_kimligi,
                "Baz analiz kimliği": baz.analiz_kimligi,
                "Baz ayar kimliği": baz.ayar_kimligi,
                "Karşılaştırma analiz kimliği": ikinci.analiz_kimligi,
                "Karşılaştırma ayar kimliği": ikinci.ayar_kimligi,
            }
        )


def ayni_veri_karsilastirma_formu() -> None:
    with st.sidebar:
        st.header("Aynı veri karşılaştırması")
        st.caption(
            "Fiyat verisi yalnızca bir kez indirilir. İki minimum skor "
            "aynı veri anlık görüntüsü üzerinde karşılaştırılır."
        )

        with st.form("ayni_veri_karsilastirma_formu"):
            sembol = st.text_input(
                "Hisse sembolü",
                value="THYAO",
                help="BIST uzantısı yazılmazsa .IS otomatik eklenir.",
            )
            indirme_donemi = st.selectbox(
                "Veri dönemi",
                options=("1y", "2y", "5y", "10y", "max"),
                index=2,
            )
            islem_gunu = st.number_input(
                "En fazla işlem günü",
                min_value=100,
                max_value=10_000,
                value=1253,
                step=50,
            )
            gorunum_etiketi = st.selectbox(
                "Teknik görünüm",
                options=tuple(GORUNUM_SECENEKLERI),
                index=0,
            )
            baz_minimum_skor = st.slider(
                "Baz minimum skor",
                min_value=0,
                max_value=100,
                value=50,
            )
            karsilastirma_minimum_skor = st.slider(
                "Karşılaştırma minimum skoru",
                min_value=0,
                max_value=100,
                value=55,
            )
            elde_tutma_gunu = st.slider(
                "Elde tutma süresi (bar)",
                min_value=1,
                max_value=30,
                value=10,
            )
            baslangic_sermayesi = st.number_input(
                "Başlangıç sermayesi",
                min_value=1_000.0,
                value=100_000.0,
                step=10_000.0,
            )
            pozisyon_yuzde = st.slider(
                "Pozisyon sermayesi (%)",
                min_value=1.0,
                max_value=100.0,
                value=100.0,
                step=1.0,
            )
            maliyet_yuzde = st.number_input(
                "İşlem maliyeti (%)",
                min_value=0.0,
                max_value=9.99,
                value=0.10,
                step=0.01,
            )
            stop_yuzde = st.number_input(
                "Zarar durdur (%)",
                min_value=0.01,
                max_value=99.0,
                value=5.0,
                step=0.5,
            )
            hedef_yuzde = st.number_input(
                "Hedef (%)",
                min_value=0.01,
                max_value=99.0,
                value=10.0,
                step=0.5,
            )
            calistirildi = st.form_submit_button(
                "Aynı veriyle karşılaştır",
                type="primary",
                width="stretch",
            )

    if not calistirildi:
        st.info(
            "Baz ve karşılaştırma skorlarını seçip sol menüdeki "
            "‘Aynı veriyle karşılaştır’ düğmesine basın."
        )
        return

    ortak = {
        "sembol": sembol,
        "islem_gunu": int(islem_gunu),
        "indirme_donemi": indirme_donemi,
        "gorunum_secimi": GORUNUM_SECENEKLERI[gorunum_etiketi],
        "elde_tutma_gunu": int(elde_tutma_gunu),
        "baslangic_sermayesi": float(baslangic_sermayesi),
        "pozisyon_yuzde": float(pozisyon_yuzde),
        "maliyet_yuzde": float(maliyet_yuzde),
        "stop_yuzde": float(stop_yuzde),
        "hedef_yuzde": float(hedef_yuzde),
    }

    try:
        baz_istek = DashboardBacktestRequest(
            **ortak,
            minimum_skor=int(baz_minimum_skor),
        )
        ikinci_istek = DashboardBacktestRequest(
            **ortak,
            minimum_skor=int(karsilastirma_minimum_skor),
        )
        with st.spinner(
            f"{baz_istek.sembol} verisi bir kez hazırlanıyor; "
            "iki ayar aynı anlık görüntüde çalışıyor..."
        ):
            sonuc = SameDataComparisonService().calistir(
                baz_istek,
                ikinci_istek,
            )
    except (ValueError, TypeError, SameDataComparisonError) as hata:
        st.error(str(hata))
        return

    baz_kayit = gecmise_kaydet(sonuc.baz_sonuc)
    ikinci_kayit = gecmise_kaydet(sonuc.karsilastirma_sonucu)
    if baz_kayit is not None and ikinci_kayit is not None:
        st.caption(
            "Her iki analiz geçmişe kaydedildi ve ortak veri kimliğiyle "
            "doğrudan karşılaştırılabilir."
        )
    ayni_veri_sonucu_goster(sonuc)


def opsiyonel_fiyat_yaz(deger: float | None) -> str:
    return "—" if deger is None else para_yaz(deger)


def aciklama_listesi_goster(
    baslik: str,
    maddeler: tuple[str, ...],
    bos_mesaj: str,
) -> None:
    st.markdown(f"**{baslik}**")
    if maddeler:
        for madde in maddeler:
            st.write(f"• {madde}")
    else:
        st.caption(bos_mesaj)




def veri_tazeligi_kilidi_goster(sonuc: DataFreshnessResult | BatchDataFreshnessResult | None) -> bool:
    """Veri tazeliğini görünür kılar; eski veride analiz sonucunu kilitler."""
    if sonuc is None:
        st.warning("Veri tazeliği doğrulanamadı. Son fiyat tarihini aracı kurumdan kontrol edin.")
        return False

    if isinstance(sonuc, BatchDataFreshnessResult):
        metrik_izgarasi_goster((
            ("Fiyat verisi durumu", sonuc.durum),
            ("Beklenen son işlem günü", str(sonuc.beklenen_tarih)),
            ("En eski fiyat tarihi", str(sonuc.en_eski_tarih or "—")),
            ("En yeni fiyat tarihi", str(sonuc.en_yeni_tarih or "—")),
            ("Güncel sembol", str(sonuc.guncel_sembol)),
            ("Eski/uyumsuz sembol", str(sonuc.eski_sembol + sonuc.veri_yok_sembol)),
        ))
    else:
        metrik_izgarasi_goster((
            ("Fiyat verisi durumu", sonuc.durum),
            ("Son fiyat veri tarihi", str(sonuc.son_veri_tarihi or "—")),
            ("Beklenen son işlem günü", str(sonuc.beklenen_tarih)),
            ("İş günü gecikmesi", str(sonuc.is_gunu_gecikmesi)),
        ))

    if sonuc.kilitli:
        st.error("VERİ TAZELİĞİ KİLİDİ: " + sonuc.aciklama)
        st.caption(f"Kilit aşaması: {sonuc.kilit_asamasi}")
        if sonuc.sonraki_kontrol_zamani is not None:
            st.caption(
                "Önerilen sonraki kontrol: "
                + tarih_saat_yaz(sonuc.sonraki_kontrol_zamani)
            )
        st.warning("Momentum sıralaması, teknik teyit, stop, hedef ve lot değerleri kullanılmamalıdır.")
        return False

    st.success(sonuc.aciklama)
    return True

def guncel_analiz_sonucu_goster(sonuc: LiveAnalysisResult) -> None:
    teknik = sonuc.teknik_teyit
    plan = sonuc.islem_plani

    store_stock_ai_context(st, sonuc)

    st.subheader(f"{teknik.sembol} güncel teknik analiz")
    st.caption(
        "Özet: haftalık ana trend · günlük yön teyidi · saatlik giriş zamanlaması · "        "RSI/MACD uyumsuzluk · karar matrisi · işlem planı"
    )
    metrik_izgarasi_goster(
        (
            ("Teknik teyit skoru", f"{teknik.teyit_skoru}/100"),
            ("Teyit durumu", teknik.teyit_durumu),
            ("İşlem kararı", plan.karar),
            ("Plan tipi", plan.plan_tipi),
            ("Son kapanış", para_yaz(plan.son_kapanis)),
            ("ATR14", f"{para_yaz(plan.atr14)} · %{plan.atr_yuzde:.2f}"),
        )
    )

    (
        zaman_tab,
        teyit_tab,
        uyumsuzluk_tab,
        karar_matrisi_tab,
        plan_tab,
    ) = st.tabs(
        (
            "Zaman dilimleri",
            "Teknik teyit",
            "RSI/MACD uyumsuzluk",
            "Günlük/Haftalık karar matrisi",
            "İşlem planı",
        )
    )

    with zaman_tab:
        satirlar = []
        for rol, zaman in (
            ("Ana trend", teknik.haftalik),
            ("Yön teyidi", teknik.gunluk),
            ("Giriş zamanlaması", teknik.saatlik),
        ):
            satirlar.append(
                {
                    "Rol": rol,
                    "Zaman": zaman.ad,
                    "Son tarih": tarih_saat_yaz(zaman.son_zaman),
                    "Kapanış": round(zaman.kapanis, 2),
                    "Skor": zaman.skor,
                    "Yön": zaman.yon,
                    "Destek": (
                        None if zaman.destek is None else round(zaman.destek, 2)
                    ),
                    "Direnç": (
                        None if zaman.direnc is None else round(zaman.direnc, 2)
                    ),
                    "Kırılım": zaman.kirilim.durum,
                    "RSI14": round(zaman.momentum.rsi14, 2),
                    "Hacim oranı": (
                        None
                        if zaman.kirilim.hacim_orani is None
                        else round(zaman.kirilim.hacim_orani, 2)
                    ),
                }
            )
        st.dataframe(
            pd.DataFrame(satirlar),
            width="stretch",
            hide_index=True,
        )
        st.caption(
            "Haftalık ana trend, günlük yön ve saatlik giriş zamanlaması "
            "birbirinden bağımsız hesaplanır. Destek/direnç, RSI ve hacim teyidi "            "aynı zaman-dilimi bağlamında okunmalıdır."
        )

    with teyit_tab:
        for rol, zaman in (
            ("Haftalık ana trend", teknik.haftalik),
            ("Günlük yön teyidi", teknik.gunluk),
            ("Saatlik giriş zamanlaması", teknik.saatlik),
        ):
            with st.expander(
                f"{rol} · {zaman.yon} · {zaman.skor}/100",
                expanded=(rol == "Günlük yön teyidi"),
            ):
                metrik_izgarasi_goster(
                    (
                        ("EMA 9/21", zaman.ortalamalar.ema9_21_durumu),
                        ("EMA 21/55", zaman.ortalamalar.ema21_55_durumu),
                        ("SMA 50/200", zaman.ortalamalar.uzun_vade_durumu),
                        ("Momentum", zaman.momentum.durum),
                        ("Kırılım", zaman.kirilim.durum),
                        (
                            "Hacim teyidi",
                            "Var" if zaman.kirilim.hacim_teyidi else "Yok",
                        ),
                    )
                )
                aciklama_listesi_goster(
                    "Pozitif unsurlar",
                    zaman.pozitif_nedenler,
                    "Belirgin pozitif unsur yok.",
                )
                aciklama_listesi_goster(
                    "Riskler",
                    zaman.riskler,
                    "Belirgin risk yok.",
                )

        st.divider()
        aciklama_listesi_goster(
            "Ortak pozitif teyitler",
            teknik.pozitif_nedenler,
            "Belirgin ortak pozitif teyit yok.",
        )
        aciklama_listesi_goster(
            "Ortak riskler",
            teknik.riskler,
            "Belirgin ortak risk yok.",
        )

    gunluk_uyumsuzluk = None
    haftalik_uyumsuzluk = None

    with uyumsuzluk_tab:
        st.caption(
            "Fiyat pivotları ile RSI ve MACD histogram pivotları "
            "karşılaştırılır. Yalnızca tamamlanmış ve sağ taraftan "
            "teyit edilmiş pivotlar kullanılır."
        )
        try:
            gunluk_uyumsuzluk, haftalik_uyumsuzluk = (
                analyze_daily_weekly_divergences(
                    sonuc.paket.getir("Günlük").veri,
                    sonuc.paket.getir("Haftalık").veri,
                )
            )
        except (DivergenceAnalysisError, ValueError, TypeError) as hata:
            st.info(f"Uyumsuzluk analizi üretilemedi: {hata}")
        else:
            metrik_izgarasi_goster(
                (
                    ("Günlük pozitif", str(gunluk_uyumsuzluk.positive_count)),
                    ("Günlük negatif", str(gunluk_uyumsuzluk.negative_count)),
                    ("Haftalık pozitif", str(haftalik_uyumsuzluk.positive_count)),
                    ("Haftalık negatif", str(haftalik_uyumsuzluk.negative_count)),
                )
            )
            kayitlar = divergence_rows(
                (gunluk_uyumsuzluk, haftalik_uyumsuzluk)
            )
            if kayitlar:
                st.dataframe(
                    pd.DataFrame(kayitlar),
                    width="stretch",
                    hide_index=True,
                )
            else:
                st.success(
                    "Günlük ve haftalık veride belirgin, güncel "
                    "RSI/MACD uyumsuzluğu bulunmadı."
                )
            st.warning(gunluk_uyumsuzluk.disclaimer)

    with karar_matrisi_tab:
        if gunluk_uyumsuzluk is None or haftalik_uyumsuzluk is None:
            st.info(
                "Karar matrisi için uyumsuzluk analizi üretilemedi."
            )
        else:
            try:
                karar_matrisi = build_technical_decision_matrix(
                    teknik,
                    plan,
                    gunluk_uyumsuzluk,
                    haftalik_uyumsuzluk,
                    context=DecisionMatrixContext(),
                )
            except (ValueError, TypeError) as hata:
                st.info(f"Karar matrisi üretilemedi: {hata}")
            else:
                metrik_izgarasi_goster(
                    (
                        ("Sınıflandırma", karar_matrisi.classification.value),
                        ("Kalite skoru", f"{karar_matrisi.quality_score}/100"),
                        ("Günlük yön", teknik.gunluk.yon),
                        ("Haftalık yön", teknik.haftalik.yon),
                    )
                )
                st.dataframe(
                    pd.DataFrame(decision_matrix_rows(karar_matrisi)),
                    width="stretch",
                    hide_index=True,
                )
                sol, sag = st.columns(2)
                with sol:
                    aciklama_listesi_goster(
                        "Olumlu gerekçeler",
                        karar_matrisi.positive_reasons,
                        "Belirgin olumlu gerekçe yok.",
                    )
                with sag:
                    aciklama_listesi_goster(
                        "Olumsuz gerekçeler",
                        karar_matrisi.negative_reasons,
                        "Belirgin olumsuz gerekçe yok.",
                    )
                st.warning(karar_matrisi.disclaimer)

    with plan_tab:
        metrik_izgarasi_goster(
            (
                ("Karar", plan.karar),
                ("Plan tipi", plan.plan_tipi),
                ("İzleme tetik seviyesi", opsiyonel_fiyat_yaz(plan.izleme_tetik_fiyati)),
                ("Referans giriş", opsiyonel_fiyat_yaz(plan.referans_giris)),
                ("Stop-loss", opsiyonel_fiyat_yaz(plan.stop_loss)),
                ("Hedef 1", opsiyonel_fiyat_yaz(plan.hedef_1)),
                ("Hedef 2", opsiyonel_fiyat_yaz(plan.hedef_2)),
            )
        )

        if plan.giris_alt is not None:
            st.dataframe(
                pd.DataFrame(
                    (
                        {
                            "Seviye": "Giriş bölgesi",
                            "Alt": plan.giris_alt,
                            "Üst": plan.giris_ust,
                            "Kaynak": plan.giris_kaynagi,
                        },
                        {
                            "Seviye": "Stop-loss",
                            "Alt": plan.stop_loss,
                            "Üst": plan.stop_loss,
                            "Kaynak": plan.stop_kaynagi,
                        },
                        {
                            "Seviye": "Hedef 1",
                            "Alt": plan.hedef_1,
                            "Üst": plan.hedef_1,
                            "Kaynak": plan.hedef_1_kaynagi,
                        },
                        {
                            "Seviye": "Hedef 2",
                            "Alt": plan.hedef_2,
                            "Üst": plan.hedef_2,
                            "Kaynak": plan.hedef_2_kaynagi,
                        },
                    )
                ),
                width="stretch",
                hide_index=True,
            )

        if plan.pozisyon is not None:
            pozisyon = plan.pozisyon
            st.markdown("**Pozisyon büyüklüğü**")
            metrik_izgarasi_goster(
                (
                    ("Lot sayısı", str(pozisyon.lot_sayisi)),
                    ("Pozisyon tutarı", para_yaz(pozisyon.pozisyon_tutari)),
                    ("Risk bütçesi", para_yaz(pozisyon.risk_butcesi)),
                    ("Planlanan risk", para_yaz(pozisyon.planlanan_risk)),
                )
            )

        aciklama_listesi_goster(
            "Beklenen teyitler",
            plan.beklenen_teyitler,
            "Ek teyit beklenmiyor.",
        )
        aciklama_listesi_goster(
            "Planı geçersiz kılan koşullar",
            plan.gecersizlik_kosullari,
            "Ek geçersizlik koşulu yok.",
        )
        aciklama_listesi_goster(
            "Notlar",
            plan.notlar,
            "Ek not yok.",
        )

    with st.expander("Analiz kimlikleri", expanded=False):
        st.code(
            "\n".join(
                (
                    f"Veri kimliği: {teknik.veri_kimligi}",
                    f"Teknik analiz kimliği: {teknik.analiz_kimligi}",
                    f"İşlem planı kimliği: {plan.plan_kimligi}",
                )
            )
        )


def guncel_teknik_analiz_formu() -> None:
    st.header("Güncel Teknik Analiz — Tek Hisse Derin İnceleme")
    st.caption(
        "Fırsat Radarı aday bulur; bu ekran seçilen tek hisseyi saatlik, günlük ve haftalık "        "teknik teyitlerle derinleştirir. Teknik Grafik Terminali ise görsel grafik çalışma alanıdır."
    )
    st.info(
        "Bu ekran teknik inceleme ve işlem planı üretir; karar matrisi alım/satım tavsiyesi değildir."
    )
    with st.sidebar:
        st.header("Güncel teknik analiz")
        with st.form("guncel_teknik_analiz_formu"):
            sembol = st.text_input(
                "Hisse sembolü",
                value="THYAO",
                help="BIST uzantısı yazılmazsa .IS otomatik eklenir.",
            )
            sermaye = st.number_input(
                "Sermaye",
                min_value=1_000.0,
                value=100_000.0,
                step=10_000.0,
            )
            risk_yuzde = st.number_input(
                "İşlem başına azami risk (%)",
                min_value=0.10,
                max_value=10.0,
                value=1.0,
                step=0.10,
            )
            calistirildi = st.form_submit_button(
                "Güncel analizi çalıştır",
                type="primary",
                width="stretch",
            )

    if not calistirildi:
        st.info(
            "Sembol ve risk ayarlarını seçip sol menüdeki "
            "‘Güncel analizi çalıştır’ düğmesine basın."
        )
        return

    try:
        istek = LiveAnalysisRequest(
            sembol=sembol,
            sermaye=float(sermaye),
            azami_risk_orani=float(risk_yuzde) / 100.0,
        )
        with st.spinner(
            f"{istek.sembol} için saatlik, günlük ve haftalık veri hazırlanıyor..."
        ):
            sonuc = LiveAnalysisDashboardService().calistir(istek)
    except (ValueError, TypeError, LiveAnalysisDashboardError) as hata:
        st.error(str(hata))
        return

    if not veri_tazeligi_kilidi_goster(sonuc.veri_tazeligi):
        return
    guncel_analiz_sonucu_goster(sonuc)
    kayit = gecmise_kaydet(sonuc)
    if kayit is not None:
        st.caption("Güncel teknik analiz, Analiz Geçmişi'ne kaydedildi.")


def momentum_aday_ayrintisi_goster(aday: MomentumCandidate) -> None:
    st.subheader(
        f"{aday.sembol.removesuffix('.IS')} · "
        f"{aday.momentum_skoru}/100 · {aday.sinif}"
    )
    metrik_izgarasi_goster(
        (
            ("Momentum potansiyeli", f"{aday.momentum_skoru}/100"),
            ("Mevcut teknik skor", f"{aday.teknik_skor}/100"),
            ("Hacim oranı", f"{aday.hacim_orani:.2f}x"),
            ("Hacim eğimi", f"{aday.hacim_egimi:.2f}x"),
            ("Yakın direnç", f"{aday.yakin_direnc:.2f}"),
            ("Kırılım tetiği", f"{aday.kirilim_tetik_seviyesi:.2f}"),
            ("Dirence uzaklık", yuzde_yaz(aday.yirmi_gunluk_zirve_uzakligi * 100)),
            ("Risk/Getiri", f"1:{aday.risk_odul_orani:.2f}"),
            ("Listede gün", str(aday.listedeki_gun)),
            ("İlk görülmeden", yuzde_yaz(aday.ilk_gorulmeden_getiri * 100)),
        )
    )
    st.info(f"Kırılım hazırlığı: {aday.hazirlik_durumu}")
    if aday.kalici_hazirlik:
        st.warning(
            "Bu hisse günlük sınıfı zayıflasa da yakın geçmişteki tekrarlayan "
            "E0-E3 sinyalleri nedeniyle Kalıcı Hazırlık Adayı olarak izleniyor."
        )
    if aday.sinyal_gecmisi:
        st.caption("Sinyal zinciri: " + " → ".join(aday.sinyal_gecmisi))
    if aday.son_guclu_sinyal_tarihi:
        st.caption(f"Son güçlü sinyal tarihi: {aday.son_guclu_sinyal_tarihi}")
    st.caption(
        "Puan bileşenleri: "
        f"Göreceli güç {aday.goreceli_guc_puani}/20 · "
        f"Fiyat ivmesi {aday.fiyat_ivmesi_puani}/15 · "
        f"Hacim {aday.hacim_birikimi_puani}/15 · "
        f"Kırılım hazırlığı {aday.kirilim_hazirligi_puani}/15 · "
        f"Trend {aday.trend_puani}/15 · "
        f"Likidite {aday.likidite_puani}/10 · "
        f"Risk kalitesi {aday.risk_kalitesi_puani}/10"
    )
    sol, sag = st.columns(2)
    with sol:
        aciklama_listesi_goster(
            "Olumlu gerekçeler",
            aday.pozitif_nedenler,
            "Belirgin olumlu gerekçe yok.",
        )
    with sag:
        aciklama_listesi_goster(
            "Riskler",
            aday.riskler,
            "Belirgin risk yok.",
        )



def _csv_baytlari(kayitlar: tuple[dict[str, object], ...]) -> bytes:
    """Tablo kayıtlarını Excel uyumlu UTF-8 BOM içeren CSV'ye dönüştürür."""

    return pd.DataFrame(kayitlar).to_csv(
        index=False,
        lineterminator="\n",
    ).encode("utf-8-sig")


def momentum_disari_aktarim_goster(
    sonuc: MomentumDiscoveryResult,
) -> None:
    """Momentum sonucunun aday, eleme ve hata tablolarını CSV olarak sunar."""

    zaman = datetime.now().strftime("%Y%m%d_%H%M%S")
    indirmeler: list[tuple[str, bytes, str, str]] = []

    aday_kayitlari = momentum_aday_tablosu(sonuc)
    if aday_kayitlari:
        indirmeler.append(
            (
                "Görünen adayları CSV indir",
                _csv_baytlari(aday_kayitlari),
                f"momentum_adaylari_{zaman}.csv",
                "text/csv; charset=utf-8",
            )
        )

    if sonuc.trend_politikasi_elenenler:
        indirmeler.append(
            (
                "Rejimde elenenleri CSV indir",
                _csv_baytlari(
                    tuple(
                        {
                            "Hisse": aday.sembol.removesuffix(".IS"),
                            "Sınıf": aday.sinif,
                            "Momentum": aday.momentum_skoru,
                            "Trend": aday.trend_puani,
                            "Dirence uzaklık (%)": round(
                                aday.yirmi_gunluk_zirve_uzakligi * 100,
                                2,
                            ),
                            "Neden": aday.izleme_disi_nedeni,
                        }
                        for aday in sonuc.trend_politikasi_elenenler
                    )
                ),
                f"momentum_rejim_elenenler_{zaman}.csv",
                "text/csv; charset=utf-8",
            )
        )

    if sonuc.izleme_disi:
        indirmeler.append(
            (
                "İzleme dışını CSV indir",
                _csv_baytlari(
                    tuple(
                        {
                            "Hisse": aday.sembol.removesuffix(".IS"),
                            "Momentum": aday.momentum_skoru,
                            "Neden": aday.izleme_disi_nedeni,
                        }
                        for aday in sonuc.izleme_disi
                    )
                ),
                f"momentum_izleme_disi_{zaman}.csv",
                "text/csv; charset=utf-8",
            )
        )

    if sonuc.hatalar:
        indirmeler.append(
            (
                "Hataları CSV indir",
                _csv_baytlari(
                    tuple(
                        {
                            "Hisse": hata.sembol.removesuffix(".IS"),
                            "Hata": hata.hata,
                        }
                        for hata in sonuc.hatalar
                    )
                ),
                f"momentum_hatalari_{zaman}.csv",
                "text/csv; charset=utf-8",
            )
        )

    if indirmeler:
        st.markdown("### Momentum sonucunu dışa aktar")
        indirme_dugmeleri_goster(tuple(indirmeler))


def momentum_kesif_sonucu_goster(sonuc: MomentumDiscoveryResult) -> None:
    st.subheader(f"{sonuc.evren_adi} momentum keşif taraması")

    st.markdown("### Tarama operasyon özeti")
    metrik_izgarasi_goster(
        (
            (
                "Ön tazelik kontrolü",
                "Yapıldı" if sonuc.on_tazelik_kontrolu else "Atlandı",
            ),
            (
                "Referans sembol",
                sonuc.on_tazelik_referans_sembol or "—",
            ),
            (
                "Toplu tarama",
                "Başlatıldı"
                if sonuc.toplu_tarama_baslatildi
                else "Başlatılmadı",
            ),
            (
                "Toplam süre",
                f"{sonuc.toplam_sure_saniye:.2f} sn",
            ),
            (
                "İndirilen sembol",
                str(sonuc.indirilen_sembol_sayisi),
            ),
            (
                "Analiz edilen sembol",
                str(sonuc.analiz_edilen_sembol_sayisi),
            ),
            (
                "Veri/analiz hatası",
                str(sonuc.veri_hatasi_sayisi),
            ),
            (
                "Yeniden deneme",
                str(sonuc.yeniden_deneme_sayisi),
            ),
            (
                "Veri kaynağı",
                sonuc.veri_kaynagi,
            ),
            (
                "Kilit aşaması",
                sonuc.tazelik_kilit_asamasi or "—",
            ),
            (
                "Sonraki kontrol",
                tarih_saat_yaz(sonuc.sonraki_kontrol_zamani)
                if sonuc.sonraki_kontrol_zamani
                else "—",
            ),
        )
    )

    if not veri_tazeligi_kilidi_goster(sonuc.veri_tazeligi):
        momentum_disari_aktarim_goster(sonuc)
        return

    if sonuc.piyasa_rejimi is not None:
        politika = rejime_gore_trend_politikasi(sonuc.piyasa_rejimi)
        st.markdown("### Rejim bazlı trend filtresi")
        metrik_izgarasi_goster(
            (
                ("Aktif piyasa rejimi", sonuc.piyasa_rejimi),
                ("Minimum momentum", f"{politika.minimum_momentum_skoru}/100"),
                ("Minimum trend", f"{politika.minimum_trend_puani}/15"),
                (
                    "Azami direnç uzaklığı",
                    yuzde_yaz(politika.azami_direnc_uzakligi * 100),
                ),
                ("Filtreyi geçen aday", str(len(sonuc.adaylar))),
                (
                    "Rejim nedeniyle elenen",
                    str(len(sonuc.trend_politikasi_elenenler)),
                ),
            )
        )
        if politika.kirilim_veya_yuksek_hazirlik_zorunlu:
            st.warning(
                "Riskli rejimde yalnızca kırılım veya E3/C/B düzeyinde "
                "yüksek hazırlık gösteren adaylar korunur."
            )
        else:
            st.caption(
                "Momentum, trend ve dirence uzaklık eşikleri aktif piyasa "
                "rejimine göre uygulanmıştır."
            )
    else:
        st.info(
            "Rejim bazlı trend filtresi kapalı. Adaylar yalnızca momentum "
            "keşif koşullarıyla sıralandı."
        )

    metrik_izgarasi_goster(
        (
            ("Tarama evreni", str(sonuc.evren_sembol_sayisi)),
            ("Başarılı analiz", str(sonuc.basarili_sayisi)),
            ("C — İşleme hazır", str(sonuc.isleme_hazir_sayisi)),
            ("B — Kırılım", str(sonuc.kirilim_sayisi)),
            ("E3 — Erken uyarı", str(sonuc.sinif_sayisi(SINIF_ERKEN_UYARI))),
            ("E2 — Dirence yakın", str(sonuc.sinif_sayisi(SINIF_DIRENCE_YAKLASIYOR))),
            ("E1 — Hacim birikimi", str(sonuc.sinif_sayisi(SINIF_HACIM_BIRIKIMI))),
            ("E0 — Sıkışma", str(sonuc.sinif_sayisi(SINIF_SIKISMA))),
            ("K — Kalıcı hazırlık", str(sonuc.sinif_sayisi(SINIF_KALICI_HAZIRLIK))),
            ("D — Aşırı yükselmiş", str(len(sonuc.asiri_yukselmisler))),
        )
    )
    st.caption(
        f"Evren kaynağı: {sonuc.evren_kaynagi} · "
        f"Bileşen tarihi: {sonuc.evren_tarihi}"
    )
    st.info(
        "Momentum skoru bir erken keşif ölçüsüdür; doğrudan alım kararı "
        "değildir. C sınıfı adaylar bile ayrıntılı Güncel Teknik Analiz "
        "ekranında yeniden doğrulanmalıdır. KAP/haber katalizörü bu sürümde "
        "otomatik puanlanmaz ve ayrıca kontrol edilmelidir."
    )

    kayitlar = momentum_aday_tablosu(sonuc)
    if not kayitlar:
        st.warning(
            "Seçilen minimum skoru ve A/B/C sınıflarını karşılayan aday "
            "bulunamadı. Minimum skoru azaltmak yerine evreni ve piyasa "
            "koşullarını yeniden değerlendirin."
        )
    else:
        st.dataframe(
            pd.DataFrame(kayitlar),
            width="stretch",
            hide_index=True,
            column_config={
                "Sıra": st.column_config.NumberColumn(width="small"),
                "Hisse": st.column_config.TextColumn(width="small"),
                "Sınıf": st.column_config.TextColumn(width="large"),
                "Momentum": st.column_config.NumberColumn(width="small"),
                "Teknik": st.column_config.NumberColumn(width="small"),
                "Son kapanış": st.column_config.NumberColumn(format="%.2f"),
                "5G (%)": st.column_config.NumberColumn(format="%.2f%%"),
                "20G (%)": st.column_config.NumberColumn(format="%.2f%%"),
                "Hacim": st.column_config.NumberColumn(format="%.2fx"),
                "Yakın direnç": st.column_config.NumberColumn(format="%.2f"),
                "Kırılım tetiği": st.column_config.NumberColumn(format="%.2f"),
                "Dirence uzaklık (%)": st.column_config.NumberColumn(format="%.2f%%"),
                "Hacim eğimi": st.column_config.NumberColumn(format="%.2fx"),
                "Göreceli güç eğimi (%)": st.column_config.NumberColumn(format="%.2f%%"),
                "Risk/Getiri": st.column_config.NumberColumn(format="1:%.2f"),
                "İlk görülmeden (%)": st.column_config.NumberColumn(format="%.2f%%"),
            },
        )
        secili = st.selectbox(
            "Momentum aday ayrıntısı",
           options=sonuc.adaylar,
            format_func=lambda aday: (
                f"{aday.sembol.removesuffix('.IS')} · "
                f"{aday.momentum_skoru}/100 · {aday.sinif}"
            ),
            key="momentum_kesif_aday_ayrintisi",
        )
        momentum_aday_ayrintisi_goster(secili)

    if sonuc.asiri_yukselmisler:
        with st.expander("D — Aşırı yükselmiş / peşinden koşulmaması gerekenler"):
            st.dataframe(
                pd.DataFrame(
                    {
                        "Hisse": aday.sembol.removesuffix(".IS"),
                        "Momentum": aday.momentum_skoru,
                        "5G (%)": round(aday.getiri_5g * 100, 2),
                        "RSI14": round(aday.rsi14, 2),
                        "Risk": " | ".join(aday.riskler),
                    }
                    for aday in sonuc.asiri_yukselmisler
                ),
                width="stretch",
                hide_index=True,
            )

    if sonuc.trend_politikasi_elenenler:
        with st.expander(
            "Piyasa rejimi filtresinde elenen hisseler ve nedenleri",
            expanded=False,
        ):
            st.dataframe(
                pd.DataFrame(
                    {
                        "Hisse": aday.sembol.removesuffix(".IS"),
                        "Sınıf": aday.sinif,
                        "Momentum": aday.momentum_skoru,
                        "Trend": f"{aday.trend_puani}/15",
                        "Dirence uzaklık (%)": round(
                            aday.yirmi_gunluk_zirve_uzakligi * 100,
                            2,
                        ),
                        "Neden": aday.izleme_disi_nedeni,
                    }
                    for aday in sonuc.trend_politikasi_elenenler
                ),
                width="stretch",
                hide_index=True,
            )

    if sonuc.izleme_disi:
        with st.expander("İzleme Dışı kalan hisseler ve nedenleri"):
            st.dataframe(
                pd.DataFrame(
                    {
                        "Hisse": aday.sembol.removesuffix(".IS"),
                        "Momentum": aday.momentum_skoru,
                        "Son kapanış": round(aday.kapanis, 2),
                        "Yakın direnç": round(aday.yakin_direnc, 2),
                        "Dirence uzaklık (%)": round(
                            aday.yirmi_gunluk_zirve_uzakligi * 100, 2
                        ),
                        "Neden": aday.izleme_disi_nedeni,
                        "Sinyal geçmişi": " → ".join(aday.sinyal_gecmisi),
                    }
                    for aday in sonuc.izleme_disi
                ),
                width="stretch",
                hide_index=True,
            )

    if sonuc.hatalar:
        with st.expander("Verisi alınamayan veya analiz edilemeyen hisseler"):
            st.dataframe(
                pd.DataFrame(
                    {
                        "Hisse": hata.sembol.removesuffix(".IS"),
                        "Hata": hata.hata,
                    }
                    for hata in sonuc.hatalar
                ),
                width="stretch",
                hide_index=True,
            )
    if sonuc.kayit_yolu:
        st.caption(f"Momentum tarama geçmişi kaydedildi: {sonuc.kayit_yolu}")

    momentum_disari_aktarim_goster(sonuc)


def momentum_walk_forward_sonucu_goster(sonuc: MomentumWalkForwardResult) -> None:
    st.subheader(
        f"{sonuc.evren_adi} tarihsel yeniden oynatma · {sonuc.kesim_tarihi}"
    )
    metrik_izgarasi_goster(
        (
            ("Tarama evreni", str(sonuc.evren_sembol_sayisi)),
            ("Kesimde analiz", str(sonuc.basarili_sayisi)),
            ("Gösterilen aday", str(len(sonuc.sonuclar))),
            ("İzleme dışı", str(len(sonuc.izleme_disi))),
            ("20 bar içinde ≥%10", str(sonuc.guclu_hareket_sayisi)),
        )
    )
    st.info(
        "Kesim tarihinden sonraki fiyatlar aday üretiminde kullanılmaz. "
        "5/10/20 günlük kapanış getirileri ile dönem içi en yüksek/düşük "
        "fiyatlar yalnızca sonradan performans ölçümü için hesaplanır."
    )
    if sonuc.sinyal_gecmisi_hesaplandi:
        st.caption(
            "Küçük özel/kayıtlı listelerde son altı haftalık sınıf zinciri "
            "otomatik hesaplanmıştır."
        )

    kayitlar = walk_forward_tablosu(sonuc)
    if kayitlar:
        st.dataframe(
            pd.DataFrame(kayitlar),
            width="stretch",
            hide_index=True,
            column_config={
                "Sinyal fiyatı": st.column_config.NumberColumn(format="%.2f"),
                "Yakın direnç": st.column_config.NumberColumn(format="%.2f"),
                "Kırılım tetiği": st.column_config.NumberColumn(format="%.2f"),
                "Dirence uzaklık (%)": st.column_config.NumberColumn(format="%.2f%%"),
                "5G kapanış (%)": st.column_config.NumberColumn(format="%.2f%%"),
                "10G kapanış (%)": st.column_config.NumberColumn(format="%.2f%%"),
                "20G kapanış (%)": st.column_config.NumberColumn(format="%.2f%%"),
                "Dönem içi en yüksek": st.column_config.NumberColumn(format="%.2f"),
                "Gerçek azami yükseliş (%)": st.column_config.NumberColumn(format="%.2f%%"),
                "Dönem içi en düşük": st.column_config.NumberColumn(format="%.2f"),
                "Azami ters hareket (%)": st.column_config.NumberColumn(format="%.2f%%"),
            },
        )
        secili = st.selectbox(
            "Tarihsel aday ayrıntısı",
            options=sonuc.sonuclar,
            format_func=lambda item: (
                f"{item.aday.sembol.removesuffix('.IS')} · "
                f"{item.aday.momentum_skoru}/100 · {item.aday.sinif}"
            ),
            key="momentum_walk_forward_aday_ayrintisi",
        )
        st.markdown("**İleri dönem fiyat aralığı**")
        metrik_izgarasi_goster(
            (
                ("Sinyal fiyatı", f"{secili.aday.kapanis:.2f}"),
                ("En yüksek fiyat", f"{secili.maksimum_fiyat:.2f}" if secili.maksimum_fiyat is not None else "-"),
                ("En yüksek tarih", secili.maksimum_fiyat_tarihi or "-"),
                ("Gerçek azami yükseliş", yuzde_yaz((secili.maksimum_olumlu_hareket or 0.0) * 100)),
                ("En düşük fiyat", f"{secili.minimum_fiyat:.2f}" if secili.minimum_fiyat is not None else "-"),
                ("Azami ters hareket", yuzde_yaz((secili.maksimum_ters_hareket or 0.0) * 100)),
                ("Yakın direnç", f"{secili.aday.yakin_direnc:.2f}"),
                ("Kırılım tetiği", f"{secili.aday.kirilim_tetik_seviyesi:.2f}"),
            )
        )
        st.markdown("**Güncel seans karşılaştırması**")
        st.caption(
            "Bu karttaki gün içi veri, tarihsel aday üretimine ve walk-forward "
            "sonucuna katılmaz; yalnızca tamamlanmış barlarla güncel seansı "
            "ayrı karşılaştırmak için kullanılır."
        )
        canli_key = f"momentum_canli_seans_{secili.aday.sembol}"
        if st.button(
            "Güncel seans verisini getir",
            key=f"{canli_key}_dugme",
        ):
            try:
                with st.spinner(f"{secili.aday.sembol.removesuffix('.IS')} güncel seansı alınıyor..."):
                    st.session_state[canli_key] = guncel_seans_ozeti_getir(
                        secili.aday.sembol
                    )
            except (CurrentSessionSnapshotError, ValueError) as hata:
                st.session_state.pop(canli_key, None)
                st.warning(str(hata))

        canli = st.session_state.get(canli_key)
        if canli is not None:
            if not canli.bugunku_seans:
                st.warning(
                    "Veri sağlayıcı bugünkü seansı henüz döndürmedi. "
                    f"Gösterilen son mevcut seans: {canli.seans_tarihi}."
                )
            canli_azami = canli.azami_getiri(secili.aday.kapanis)
            canli_son = canli.son_getiri(secili.aday.kapanis)
            canli_ters = canli.azami_ters_hareket(secili.aday.kapanis)
            metrik_izgarasi_goster(
                (
                    ("Seans tarihi", canli.seans_tarihi),
                    ("Son veri zamanı", canli.son_veri_zamani),
                    ("Son fiyat", f"{canli.son_fiyat:.2f}"),
                    ("Gün içi en yüksek", f"{canli.en_yuksek:.2f}"),
                    ("Gün içi en düşük", f"{canli.en_dusuk:.2f}"),
                    (
                        "Sinyale göre son getiri",
                        yuzde_yaz((canli_son or 0.0) * 100),
                    ),
                    (
                        "Canlı seans dâhil azami yükseliş",
                        yuzde_yaz((canli_azami or 0.0) * 100),
                    ),
                    (
                        "Canlı seans ters hareketi",
                        yuzde_yaz((canli_ters or 0.0) * 100),
                    ),
                )
            )
            if (
                secili.maksimum_fiyat is not None
                and canli.en_yuksek > secili.maksimum_fiyat
            ):
                fark = canli.en_yuksek - secili.maksimum_fiyat
                st.success(
                    "Güncel seans tepesi, tamamlanmış barlara dayalı tarihsel "
                    f"tepenin {fark:.2f} üzerinde."
                )

        gecmis_kayitlari = sinyal_gecmisi_tablosu(secili)
        if gecmis_kayitlari:
            st.markdown("**Sinyal sınıfı geçmişi**")
            st.dataframe(
                pd.DataFrame(gecmis_kayitlari),
                width="stretch",
                hide_index=True,
            )
    else:
        st.warning("Kesim tarihinde seçilen koşulları karşılayan aday bulunamadı.")

    izleme_disi = walk_forward_izleme_disi_tablosu(sonuc)
    if izleme_disi:
        with st.expander("Kesimde İzleme Dışı kalan hisseler ve nedenleri"):
            st.dataframe(
                pd.DataFrame(izleme_disi),
                width="stretch",
                hide_index=True,
            )
    if sonuc.hatalar:
        with st.expander("Yeniden oynatmada değerlendirilemeyen hisseler"):
            st.dataframe(
                pd.DataFrame(
                    {
                        "Hisse": hata.sembol.removesuffix(".IS"),
                        "Hata": hata.hata,
                    }
                    for hata in sonuc.hatalar
                ),
                width="stretch",
                hide_index=True,
            )

PIYASA_REJIMI_BAGLAMI_KEY = "aktif_piyasa_rejimi_baglami"


def piyasa_rejimi_baglami_dogrula(
    ham_baglam: object,
    *,
    bugun: date | None = None,
) -> tuple[dict[str, object] | None, str | None]:
    """Oturumdaki rejim bağlamının güncel ve doğrulanmış olduğunu kontrol eder."""

    if not isinstance(ham_baglam, dict):
        return None, (
            "Doğrulanmış piyasa rejimi bulunmuyor. "
            "Önce Piyasa Rejimi ekranında güncel analiz çalıştırın."
        )

    gerekli_alanlar = (
        "rejim",
        "analiz_tarihi",
        "guven_duzeyi",
        "kaynak",
        "veri_durumu",
        "beklenen_tarih",
        "olusturulma_tarihi",
        "gecerli",
    )
    eksikler = tuple(
        alan for alan in gerekli_alanlar
        if alan not in ham_baglam
    )
    if eksikler:
        return None, (
            "Piyasa rejimi bağlamı eksik olduğu için filtre kapatıldı."
        )

    rejim = str(ham_baglam.get("rejim", ""))
    if rejim not in (REJIM_POZITIF, REJIM_SECICI, REJIM_RISKLI):
        return None, (
            "Piyasa rejimi değeri desteklenmediği için filtre kapatıldı."
        )

    if not bool(ham_baglam.get("gecerli")):
        neden = str(
            ham_baglam.get("gecersizlik_nedeni")
            or "Piyasa rejimi doğrulanamadı."
        )
        return None, neden

    if str(ham_baglam.get("veri_durumu")) != "Güncel":
        return None, (
            "Piyasa rejimi verisi güncel olmadığı için filtre kapatıldı."
        )

    bugun_degeri = bugun or date.today()
    if str(ham_baglam.get("olusturulma_tarihi")) != bugun_degeri.isoformat():
        return None, (
            "Oturumdaki piyasa rejimi önceki güne ait. "
            "Rejimi yeniden analiz edin."
        )

    for alan in ("analiz_tarihi", "guven_duzeyi", "kaynak"):
        if not str(ham_baglam.get(alan, "")).strip():
            return None, (
                "Piyasa rejimi kaynağı, tarihi veya güven düzeyi eksik."
            )

    return dict(ham_baglam), None


def piyasa_rejimi_baglami_imzasi(
    baglam: dict[str, object] | None,
) -> tuple[object, ...] | None:
    if baglam is None:
        return None
    return (
        baglam.get("rejim"),
        baglam.get("analiz_tarihi"),
        baglam.get("guven_duzeyi"),
        baglam.get("kaynak"),
        baglam.get("beklenen_tarih"),
        baglam.get("olusturulma_tarihi"),
    )


def momentum_toplu_tarihsel_export_goster(
    *,
    semboller: tuple[str, ...],
    minimum_skor: int,
    maksimum_aday: int,
    internetten_guncelle: bool,
) -> None:
    with st.expander("Toplu tarihsel tarama ve CSV export", expanded=False):
        render_sprint136_batch_panel(
            st,
            minimum_skor=int(minimum_skor),
            maksimum_aday=int(maksimum_aday),
            ozel_semboller=tuple(semboller),
            internetten_guncelle=bool(internetten_guncelle),
            default_start_date=date.today() - timedelta(days=35),
            default_end_date=date.today() - timedelta(days=1),
        )


MOMENTUM_REPLAY_RESULT_KEY = "momentum_walk_forward_sonucu"
MOMENTUM_REPLAY_SIGNATURE_KEY = "momentum_walk_forward_imzasi"
MOMENTUM_DISCOVERY_RESULT_KEY = "momentum_kesif_sonucu"
MOMENTUM_DISCOVERY_SIGNATURE_KEY = "momentum_kesif_imzasi"


def momentum_walk_forward_oturum_imzasi(
    *,
    evren: str,
    semboller: list[str],
    minimum_skor: int,
    maksimum_aday: int,
    internetten_guncelle: bool,
    kesim_tarihi: date,
) -> tuple[object, ...]:
    """Yeniden oynatma sonucunun mevcut sol menü ayarlarıyla eşleşmesini sağlar."""

    return (
        evren,
        tuple(semboller),
        int(minimum_skor),
        int(maksimum_aday),
        bool(internetten_guncelle),
        kesim_tarihi.isoformat(),
    )



def momentum_kesif_oturum_imzasi(
    *,
    evren: str,
    semboller: list[str],
    minimum_skor: int,
    maksimum_aday: int,
    internetten_guncelle: bool,
    piyasa_rejimi: str | None,
    rejim_baglami_imzasi: tuple[object, ...] | None,
) -> tuple[object, ...]:
    """Momentum sonucunu yalnızca aynı ayarlarla yeniden gösterir."""

    return (
        evren,
        tuple(semboller),
        int(minimum_skor),
        int(maksimum_aday),
        bool(internetten_guncelle),
        piyasa_rejimi,
        rejim_baglami_imzasi,
    )


def momentum_kesif_formu() -> None:
    with st.sidebar:
        st.header("Momentum keşif")
        st.caption(
            "BIST evrenini göreceli güç, fiyat ivmesi, hacim birikimi, "
            "sıkışma ve kırılım hazırlığıyla tarar."
        )
        # Geriye dönük kaynak-test uyumluluğu için eski anahtar okunur;
        # güvenlik kararında kullanılmaz. Geçerli kaynak yalnızca tarihli
        # PIYASA_REJIMI_BAGLAMI_KEY bağlamıdır.
        _eski_rejim_uyumluluk = st.session_state.get("aktif_piyasa_rejimi")
        rejim_baglami, rejim_baglami_hatasi = (
            piyasa_rejimi_baglami_dogrula(
                st.session_state.get(PIYASA_REJIMI_BAGLAMI_KEY)
            )
        )
        kayitli_rejim = (
            str(rejim_baglami["rejim"])
            if rejim_baglami is not None
            else None
        )
        rejim_secenekleri = (
            "Kapalı",
            REJIM_POZITIF,
            REJIM_SECICI,
            REJIM_RISKLI,
        )
        varsayilan_rejim = (
            kayitli_rejim
            if kayitli_rejim in rejim_secenekleri
            else "Kapalı"
        )
        piyasa_rejimi_secimi = st.selectbox(
            "Piyasa rejimi filtresi",
            options=rejim_secenekleri,
            index=rejim_secenekleri.index(varsayilan_rejim),
            disabled=rejim_baglami is None,
            help=(
                "Yalnızca bugün üretilmiş, güncel ve doğrulanmış piyasa "
                "rejimi otomatik kullanılabilir."
            ),
            key="momentum_piyasa_rejimi",
        )
        if rejim_baglami is not None:
            st.caption(
                "Rejim bağlamı: "
                f"{rejim_baglami['kaynak']} · "
                f"{tarih_saat_yaz(rejim_baglami['analiz_tarihi'])} · "
                f"Güven: {rejim_baglami['guven_duzeyi']}"
            )
        elif rejim_baglami_hatasi:
            st.caption("Rejim filtresi kapalı: " + rejim_baglami_hatasi)
        # Bu kontroller form dışında tutulur. Streamlit formundaki widget değişiklikleri
        # gönderimden önce yeniden çalıştırılmadığı için, tarih alanı işaretli kutuya
        # rağmen pasif kalabiliyordu. Form dışındaki kontroller anında tepki verir.
        evren = st.selectbox(
            "Keşif evreni",
            options=TARAMA_EVRENLERI,
            index=TARAMA_EVRENLERI.index("BIST Tüm"),
            key="momentum_evreni",
        )
        ozel_liste = st.text_area(
            "Özel keşif listesi",
            value="THYAO, ASELS, TUPRS, SAHOL, KCHOL",
            height=90,
            help=(
                "Bu alan yalnızca Özel Liste evreninde kullanılır. "
                "Virgül, boşluk veya yeni satırla ayırabilirsiniz."
            ),
        )
        minimum_skor = st.slider(
            "Minimum momentum skoru",
            min_value=40,
            max_value=85,
            value=55,
        )
        maksimum_aday = st.slider(
            "Gösterilecek aday sayısı",
            min_value=5,
            max_value=50,
            value=25,
        )
        internetten_guncelle = st.checkbox(
            "BIST evrenini resmi kaynaktan güncelle",
            value=True,
            disabled=(
                evren not in ("BIST 30", "BIST 100", "BIST 500", "BIST Tüm")
            ),
        )
        yeniden_oynat = st.checkbox(
            "Tarihsel yeniden oynatma (walk-forward)",
            value=False,
            help=(
                "Kesim tarihinden sonraki fiyatları aday üretiminden gizler ve "
                "adayların sonraki 5/10/20 günlük performansını ölçer."
            ),
            key="momentum_yeniden_oynat",
        )
        kesim_tarihi = st.date_input(
            "Kesim tarihi",
            value=date.today() - timedelta(days=45),
            max_value=date.today() - timedelta(days=1),
            disabled=not yeniden_oynat,
            key="momentum_kesim_tarihi",
        )
        calistirildi = st.button(
            "Tarihsel testi başlat" if yeniden_oynat else "Momentum keşfini başlat",
            type="primary",
            width="stretch",
            key="momentum_kesif_calistir",
        )

    semboller = ozel_sembol_metinini_ayristir(ozel_liste)
    momentum_toplu_tarihsel_export_goster(
        semboller=tuple(semboller),
        minimum_skor=int(minimum_skor),
        maksimum_aday=int(maksimum_aday),
        internetten_guncelle=bool(internetten_guncelle),
    )
    aktif_rejim = (
        None
        if (
            rejim_baglami is None
            or piyasa_rejimi_secimi == "Kapalı"
        )
        else piyasa_rejimi_secimi
    )
    discovery_imzasi = momentum_kesif_oturum_imzasi(
        evren=evren,
        semboller=semboller,
        minimum_skor=int(minimum_skor),
        maksimum_aday=int(maksimum_aday),
        internetten_guncelle=bool(internetten_guncelle),
        piyasa_rejimi=aktif_rejim,
        rejim_baglami_imzasi=piyasa_rejimi_baglami_imzasi(
            rejim_baglami
        ),
    )
    replay_imzasi = momentum_walk_forward_oturum_imzasi(
        evren=evren,
        semboller=semboller,
        minimum_skor=int(minimum_skor),
        maksimum_aday=int(maksimum_aday),
        internetten_guncelle=bool(internetten_guncelle),
        kesim_tarihi=kesim_tarihi,
    )

    if rejim_baglami is None:
        st.warning(
            "Piyasa rejimi filtresi otomatik olarak Kapalı tutuluyor. "
            + str(rejim_baglami_hatasi)
        )
    else:
        st.info(
            "Doğrulanmış piyasa rejimi bağlamı: "
            f"{rejim_baglami['rejim']} · "
            f"Kaynak {rejim_baglami['kaynak']} · "
            f"Veri {tarih_saat_yaz(rejim_baglami['analiz_tarihi'])} · "
            f"Güven {rejim_baglami['guven_duzeyi']}"
        )

    if not calistirildi:
        kayitli_replay = st.session_state.get(MOMENTUM_REPLAY_RESULT_KEY)
        kayitli_imza = st.session_state.get(MOMENTUM_REPLAY_SIGNATURE_KEY)
        if (
            yeniden_oynat
            and kayitli_imza == replay_imzasi
            and isinstance(kayitli_replay, MomentumWalkForwardResult)
        ):
            # Güncel seans düğmesi Streamlit yeniden çalışması başlatır.
            # Tarihsel sonuç oturumda saklanmazsa bu yeniden çalışmada sonuç
            # ekranı kaybolur ve düğme olayı işlenemez.
            momentum_walk_forward_sonucu_goster(kayitli_replay)
            return
        kayitli_sonuc = st.session_state.get(
            MOMENTUM_DISCOVERY_RESULT_KEY
        )
        kayitli_discovery_imzasi = st.session_state.get(
            MOMENTUM_DISCOVERY_SIGNATURE_KEY
        )
        if (
            not yeniden_oynat
            and kayitli_discovery_imzasi == discovery_imzasi
            and isinstance(kayitli_sonuc, MomentumDiscoveryResult)
        ):
            momentum_kesif_sonucu_goster(kayitli_sonuc)
            return

        if (
            kayitli_discovery_imzasi is not None
            and kayitli_discovery_imzasi != discovery_imzasi
        ):
            st.session_state.pop(MOMENTUM_DISCOVERY_RESULT_KEY, None)
            st.session_state.pop(MOMENTUM_DISCOVERY_SIGNATURE_KEY, None)
            st.info(
                "Momentum ayarları değiştiği için önceki sonuç geçersiz "
                "kılındı. Yeni ayarlarla taramayı başlatın."
            )
            return

        st.info(
            "Keşif evrenini seçip sol menüdeki başlat düğmesine basın. "
            "Tarihsel yeniden oynatma, gelecek veriyi gizleyerek erken uyarı "
            "başarısını ölçer."
        )
        return

    if yeniden_oynat:
        st.session_state.pop(MOMENTUM_DISCOVERY_RESULT_KEY, None)
        st.session_state.pop(MOMENTUM_DISCOVERY_SIGNATURE_KEY, None)
        try:
            istek_replay = MomentumWalkForwardRequest(
                evren=evren,
                kesim_tarihi=kesim_tarihi.isoformat(),
                maksimum_aday=int(maksimum_aday),
                minimum_skor=int(minimum_skor),
                ozel_semboller=semboller,
                internetten_evren_guncelle=bool(internetten_guncelle),
            )
            with st.spinner(
                f"{istek_replay.evren} {istek_replay.kesim_tarihi} "
                "tarihinde yeniden oynatılıyor..."
            ):
                replay_sonucu = MomentumWalkForwardService().calistir(istek_replay)
        except (ValueError, TypeError, MomentumWalkForwardError) as hata:
            st.error(str(hata))
            return
        st.session_state[MOMENTUM_REPLAY_RESULT_KEY] = replay_sonucu
        st.session_state[MOMENTUM_REPLAY_SIGNATURE_KEY] = replay_imzasi
        momentum_walk_forward_sonucu_goster(replay_sonucu)
        return

    st.session_state.pop(MOMENTUM_REPLAY_RESULT_KEY, None)
    st.session_state.pop(MOMENTUM_REPLAY_SIGNATURE_KEY, None)
    ilerleme = st.progress(0, text="Momentum keşfi hazırlanıyor...")
    durum = st.empty()

    def ilerleme_bildir(sira: int, toplam: int, sembol: str) -> None:
        oran = min(max(sira / toplam, 0.0), 1.0)
        ilerleme.progress(
            oran,
            text=f"[{sira}/{toplam}] {sembol} momentum analizi...",
        )
        durum.caption(f"Son işlenen hisse: {sembol}")

    def durum_bildir(mesaj: str) -> None:
        durum.info(mesaj)

    try:
        istek = MomentumDiscoveryRequest(
            evren=evren,
            maksimum_aday=int(maksimum_aday),
            minimum_skor=int(minimum_skor),
            ozel_semboller=semboller,
            internetten_evren_guncelle=bool(internetten_guncelle),
            piyasa_rejimi=(
                aktif_rejim
            ),
        )
        with st.spinner(f"{istek.evren} momentum potansiyeli taranıyor..."):
            sonuc = MomentumDiscoveryService().calistir(
                istek,
                ilerleme_bildirimi=ilerleme_bildir,
                durum_bildirimi=durum_bildir,
            )
    except (ValueError, TypeError, MomentumDiscoveryError) as hata:
        ilerleme.empty()
        durum.empty()
        st.error(str(hata))
        return

    if sonuc.veri_tazeligi is not None and sonuc.veri_tazeligi.kilitli:
        ilerleme.progress(
            1.0,
            text="Veri tazeliği kilidi nedeniyle tarama durduruldu.",
        )
    else:
        ilerleme.progress(1.0, text="Momentum keşfi tamamlandı.")
    durum.empty()
    st.session_state[MOMENTUM_DISCOVERY_RESULT_KEY] = sonuc
    st.session_state[MOMENTUM_DISCOVERY_SIGNATURE_KEY] = discovery_imzasi
    momentum_kesif_sonucu_goster(sonuc)


def vbts_yonetim_paneli_goster() -> bool:
    csv_path = configured_vbts_csv_path()
    tarama_hazir = True

    with st.expander("VBTS kayıt yönetimi", expanded=False):
        st.caption(
            "Yalnızca resmî KAP bildirimlerinden doğrulanmış tedbirleri girin. "
            "Taramada sadece bugün aktif olan kayıtlar kullanılır."
        )

        try:
            lifecycle = synchronize_vbts_operational_state(csv_path)
            records = list_vbts_records(csv_path)
            operational = read_operational_status(csv_path, lifecycle)
        except DashboardVbtsManagerError as hata:
            tarama_hazir = False
            st.warning(
                "VBTS otomatik senkronizasyonu başarısız. "
                "Toplu tarama VBTS uyarı modunda devam edebilir."
            )
            st.caption(str(hata))
            records = ()
            lifecycle = classify_vbts_records(())
            operational = None


        try:
            health = validate_vbts_system_health(csv_path)
        except DashboardVbtsManagerError as hata:
            tarama_hazir = False
            health = None
            st.warning(
                "VBTS sistem sağlık kontrolü tamamlanamadı. "
                "Toplu tarama VBTS uyarı modunda devam edebilir."
            )
            st.caption(str(hata))

        if health is not None:
            if health.healthy:
                st.success("VBTS sistem sağlığı: Sağlıklı")
            else:
                tarama_hazir = False
                st.warning(
                    "VBTS sistem sağlığı: Sorunlu. "
                    "Toplu tarama VBTS uyarı modunda devam edebilir."
                )
            metrik_izgarasi_goster(
                (
                    ("Kayıt arşivi", health.registry_status),
                    ("Aktif CSV", health.active_csv_status),
                    ("Yedek bütünlüğü", health.backup_status),
                    ("Denetim günlüğü", health.audit_status),
                )
            )
            for message in health.messages:
                st.caption(f"• {message}")

        metrik_izgarasi_goster(
            (
                ("Aktif kayıt", str(len(lifecycle.active))),
                ("Gelecekte başlayacak", str(len(lifecycle.future))),
                ("Süresi dolmuş", str(len(lifecycle.expired))),
                ("Toplam arşiv kaydı", str(len(records))),
            )
        )

        if operational is not None:
            st.caption(f"Son otomatik senkronizasyon: {operational.synchronized_at}")
            st.caption(
                "Son VBTS işlemi: "
                + (
                    f"{operational.last_action} · {operational.last_action_at}"
                    if operational.last_action
                    else "Henüz kayıtlı işlem yok"
                )
            )
            st.caption(f"Denetim günlüğü: {operational.audit_log_path}")

        if records:
            st.dataframe(
                pd.DataFrame(record.as_display_row() for record in records),
                width="stretch",
                hide_index=True,
            )
        else:
            st.info("Kayıtlı VBTS tedbiri bulunmuyor.")

        if lifecycle.expired:
            st.warning(
                "Süresi dolmuş kayıtlar arşivde tutuluyor ancak toplu tarama "
                "filtresine dahil edilmiyor."
            )
            cleanup_confirmed = st.checkbox(
                "Süresi dolmuş kayıtların kalıcı olarak silinmesini onaylıyorum.",
                value=False,
                key="vbts_suresi_dolmus_temizlik_onayi",
            )
            cleanup_requested = st.button(
                "Süresi dolmuş kayıtları temizle",
                width="stretch",
                disabled=not cleanup_confirmed,
                key="vbts_suresi_dolmus_temizle",
            )
            if cleanup_requested:
                try:
                    remaining = purge_expired_vbts_records(csv_path)
                except DashboardVbtsManagerError as hata:
                    tarama_hazir = False
                    st.error(str(hata))
                else:
                    st.session_state["vbts_yonetim_bildirimi"] = (
                        "Süresi dolmuş VBTS kayıtları temizlendi. "
                        f"Kalan arşiv kaydı: {len(remaining)}"
                    )
                    st.rerun()


        st.divider()
        with st.expander("VBTS yedekleri ve denetim günlüğü", expanded=False):
            st.caption(
                "Yedek geri yükleme mevcut VBTS kayıt arşivini değiştirir. "
                "Geri yükleme öncesinde mevcut arşiv ayrıca yedeklenir."
            )

            try:
                backups = list_vbts_backups(csv_path)
                audit_events = read_audit_events(csv_path, limit=50)
            except DashboardVbtsManagerError as hata:
                tarama_hazir = False
                st.warning(
                    "VBTS yedek veya denetim verisi doğrulanamadı. "
                    "Toplu tarama VBTS uyarı modunda devam edebilir."
                )
                st.caption(str(hata))
                backups = ()
                audit_events = ()

            if backups:
                backup_map = {
                    (
                        f"{item.created_at} · {item.record_count} kayıt · "
                        f"{item.file_name}"
                    ): item
                    for item in backups
                }
                selected_backup_label = st.selectbox(
                    "Geri yüklenecek VBTS yedeği",
                    options=tuple(backup_map),
                    key="vbts_geri_yuklenecek_yedek",
                )
                selected_backup = backup_map[selected_backup_label]

                try:
                    preview_records, preview_lifecycle = inspect_vbts_backup(
                        csv_path,
                        selected_backup.path,
                    )
                except DashboardVbtsManagerError as hata:
                    tarama_hazir = False
                    st.error(f"Seçilen VBTS yedeği doğrulanamadı: {hata}")
                else:
                    metrik_izgarasi_goster(
                        (
                            ("Yedekteki kayıt", str(len(preview_records))),
                            ("Aktif olacak", str(len(preview_lifecycle.active))),
                            (
                                "Gelecekte başlayacak",
                                str(len(preview_lifecycle.future)),
                            ),
                            (
                                "Süresi dolmuş",
                                str(len(preview_lifecycle.expired)),
                            ),
                        )
                    )
                    st.dataframe(
                        pd.DataFrame(
                            record.as_display_row()
                            for record in preview_records
                        ),
                        width="stretch",
                        hide_index=True,
                    )

                    restore_confirmed = st.checkbox(
                        "Seçilen yedeğin mevcut VBTS arşivinin yerine "
                        "geri yüklenmesini onaylıyorum.",
                        value=False,
                        key="vbts_yedek_geri_yukleme_onayi",
                    )
                    restore_text = st.text_input(
                        "Onaylamak için GERİ YÜKLE yazın",
                        value="",
                        key="vbts_yedek_geri_yukleme_metni",
                    )
                    restore_ready = (
                        restore_confirmed
                        and restore_text.strip().upper() == "GERİ YÜKLE"
                    )
                    restore_requested = st.button(
                        "Seçilen VBTS yedeğini geri yükle",
                        type="primary",
                        width="stretch",
                        disabled=not restore_ready,
                        key="vbts_yedegi_geri_yukle",
                    )
                    if restore_requested:
                        try:
                            restored = restore_vbts_backup(
                                csv_path,
                                selected_backup.path,
                            )
                        except DashboardVbtsManagerError as hata:
                            tarama_hazir = False
                            st.warning(
                                "VBTS yedeği geri yüklenemedi. "
                                "Toplu tarama VBTS uyarı modunda devam edebilir."
                            )
                            st.caption(str(hata))
                        else:
                            st.session_state["vbts_yonetim_bildirimi"] = (
                                f"{len(restored)} VBTS kaydı yedekten "
                                "geri yüklendi."
                            )
                            st.rerun()
            else:
                st.info(
                    "Geri yüklenebilir VBTS kayıt arşivi yedeği bulunmuyor."
                )

            st.markdown("**Son denetim işlemleri**")
            if audit_events:
                st.dataframe(
                    pd.DataFrame(audit_display_rows(audit_events)),
                    width="stretch",
                    hide_index=True,
                )
            else:
                st.info("Henüz VBTS denetim kaydı bulunmuyor.")

            if audit_events:
                st.download_button(
                    "Denetim günlüğünü CSV indir",
                    data=audit_events_csv_bytes(audit_events),
                    file_name="Hisse-Robotu-VBTS-Denetim-Gunlugu.csv",
                    mime="text/csv; charset=utf-8",
                    width="stretch",
                    key="vbts_denetim_csv_indir",
                )

            st.markdown("**Yedek bakım politikası**")
            keep_latest = st.number_input(
                "Saklanacak en yeni yedek sayısı",
                min_value=1,
                max_value=100,
                value=20,
                step=1,
                key="vbts_yedek_saklama_sayisi",
            )
            prune_confirmed = st.checkbox(
                "Belirlenen sınırı aşan eski VBTS yedeklerinin "
                "kalıcı olarak silinmesini onaylıyorum.",
                value=False,
                key="vbts_yedek_temizleme_onayi",
            )
            prune_requested = st.button(
                "Eski VBTS yedeklerini temizle",
                width="stretch",
                disabled=not prune_confirmed,
                key="vbts_yedek_temizle",
            )
            if prune_requested:
                try:
                    removed = prune_vbts_backups(
                        csv_path,
                        keep_latest=int(keep_latest),
                    )
                except DashboardVbtsManagerError as hata:
                    tarama_hazir = False
                    st.error(str(hata))
                else:
                    st.session_state["vbts_yonetim_bildirimi"] = (
                        f"{len(removed)} eski VBTS yedeği temizlendi."
                    )
                    st.rerun()


        st.markdown("**Yeni VBTS kaydı ekle**")
        with st.form("vbts_kaydi_ekle_formu", clear_on_submit=True):
            sol, sag = st.columns(2)
            with sol:
                sembol = st.text_input("Hisse sembolü", value="")
                tedbir_turu = st.text_input("VBTS tedbir türü", value="")
                baslangic = st.date_input(
                    "Başlangıç tarihi",
                    value=date.today(),
                    key="vbts_baslangic_tarihi",
                )
            with sag:
                bitis = st.date_input(
                    "Bitiş tarihi",
                    value=date.today() + timedelta(days=30),
                    key="vbts_bitis_tarihi",
                )
                kap_referansi = st.text_input(
                    "Resmî KAP bildirim referansı",
                    value="",
                )
                resmi_onay = st.checkbox(
                    "Resmî KAP bildirimiyle doğruladım.",
                    value=False,
                )

            ekle = st.form_submit_button(
                "VBTS kaydını ekle",
                type="primary",
                width="stretch",
            )

        if ekle:
            if not resmi_onay:
                st.error(
                    "VBTS kaydı eklemek için resmî KAP bildirimiyle "
                    "doğrulama onayı verilmelidir."
                )
                return tarama_hazir

            try:
                record = build_vbts_record(
                    symbol=sembol,
                    measure_type=tedbir_turu,
                    start_date=baslangic,
                    end_date=bitis,
                    source_reference=kap_referansi,
                )
                updated = add_vbts_record(csv_path, record)
            except DashboardVbtsManagerError as hata:
                tarama_hazir = False
                st.error(str(hata))
            else:
                st.session_state["vbts_yonetim_bildirimi"] = (
                    f"{record.symbol.removesuffix('.IS')} VBTS kaydı eklendi. "
                    f"Toplam arşiv kaydı: {len(updated)}"
                )
                st.rerun()

        if records:
            st.divider()
            record_map = {
                (
                    f"{record.symbol.removesuffix('.IS')} · "
                    f"{record.status()} · {record.measure_type} · "
                    f"{record.source_reference}"
                ): record
                for record in records
            }
            selected_label = st.selectbox(
                "Silinecek VBTS kaydı",
                options=tuple(record_map),
                key="vbts_silinecek_kayit",
            )
            delete_confirmed = st.checkbox(
                "Seçili kaydın arşivden kalıcı olarak kaldırılmasını onaylıyorum.",
                value=False,
                key="vbts_silme_onayi",
            )
            delete_requested = st.button(
                "Seçili VBTS kaydını sil",
                width="stretch",
                disabled=not delete_confirmed,
                key="vbts_kaydi_sil",
            )

            if delete_requested:
                selected = record_map[selected_label]
                try:
                    remaining = delete_vbts_record(
                        csv_path,
                        selected.record_key,
                    )
                except DashboardVbtsManagerError as hata:
                    tarama_hazir = False
                    st.error(str(hata))
                else:
                    st.session_state["vbts_yonetim_bildirimi"] = (
                        "VBTS kaydı silindi. "
                        f"Kalan arşiv kaydı: {len(remaining)}"
                    )
                    st.rerun()

    return tarama_hazir


def manuel_vbts_durum_paneli_goster() -> None:
    """Manuel VBTS CSV kaynağının özet durumunu tekrar üretmeden gösterir."""

    csv_path_raw = os.getenv("HISSE_ROBOTU_VBTS_CSV_PATH", "").strip()

    if not csv_path_raw:
        st.info("VBTS CSV durumu: Dosya yolu tanımlı değil")
        return

    csv_path = Path(csv_path_raw)

    if not csv_path.exists():
        st.info("VBTS CSV durumu: Dosya bulunamadı")
        st.caption(f"Beklenen konum: {csv_path}")
        return

    try:
        dataset = load_dashboard_vbts_dataset()
    except DashboardManualVbtsError as exc:
        st.warning(
            "VBTS CSV durumu: Dosya doğrulanamadı. "
            "Toplu tarama VBTS uyarı modunda devam edebilir."
        )
        st.caption(str(exc))
        st.caption(f"Beklenen konum: {csv_path}")
        return

    modified_at = datetime.fromtimestamp(
        csv_path.stat().st_mtime,
        tz=timezone.utc,
    ).astimezone()

    st.caption(f"VBTS CSV dosyası: {csv_path}")
    st.caption(
        "Son güncelleme: "
        + modified_at.strftime("%Y-%m-%d %H:%M:%S")
    )
    st.caption(f"Kayıt sayısı: {len(dataset.measures)}")

def kap_vbts_durum_karti_goster() -> bool:
    """Seçilen VBTS veri kaynağının doğrulama durumunu gösterir."""

    source_name = os.getenv("HISSE_ROBOTU_VBTS_SOURCE", "").strip().lower()

    if not source_name:
        st.warning(
            "VBTS veri kaynağı seçilmedi. "
            "Toplu tarama çalışır; VBTS tedbirleri doğrulanamaz."
        )
        st.caption(
            "HISSE_ROBOTU_VBTS_SOURCE tanımlandığında tedbir bilgileri "
            "uyarı katmanı olarak gösterilir."
        )
        return False

    if source_name == "manual_csv":
        csv_path_raw = os.getenv("HISSE_ROBOTU_VBTS_CSV_PATH", "").strip()

        if not csv_path_raw:
            st.warning(
                "Manuel VBTS kaynağı seçildi ancak CSV dosyası tanımlı değil. "
                "Toplu tarama VBTS doğrulaması olmadan devam eder."
            )
            return False

        try:
            load_dashboard_vbts_dataset()
        except DashboardManualVbtsError as exc:
            st.warning(
                "Manuel VBTS kaynağı güncel/doğrulanmış değil. "
                "Toplu tarama devam eder; yeni tedbirler eksik olabilir."
            )
            st.caption(str(exc))
            return False

        st.success("Manuel VBTS uyarı katmanı aktif.")
        st.caption(
            "Doğrulanmış tedbirler hisseleri taramadan çıkarmadan "
            "uyarı olarak gösterilir."
        )
        return True

    st.warning(
        f"VBTS veri kaynağı desteklenmiyor: {source_name}. "
        "Toplu tarama VBTS doğrulaması olmadan devam eder."
    )
    return False


def temel_skor_deposu() -> FundamentalScoreJsonStore:
    return FundamentalScoreJsonStore(
        Path("backend/data/fundamental_scores.json")
    )


def kayitli_temel_skorlari_yukle() -> dict:
    try:
        return temel_skor_deposu().load_latest_scores()
    except FundamentalScoreStoreError as hata:
        st.warning(f"Kayıtlı temel skorlar okunamadı: {hata}")
        return {}




def _alsat_servisini_hazirla() -> None:
    health_url = "http://127.0.0.1:8765/health"
    try:
        with urllib.request.urlopen(health_url, timeout=1.5) as response:
            if response.status == 200:
                return
    except Exception:
        pass

    project = Path(r"D:\Projects\AL-SAT-Karar-Terminali")
    env = os.environ.copy()
    env["PYTHONPATH"] = str(project / "src")
    creationflags = 0
    if os.name == "nt":
        creationflags = (
            getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
            | getattr(subprocess, "CREATE_NO_WINDOW", 0)
        )
    subprocess.Popen(
        [
            "py",
            "-3.14",
            "-c",
            "from al_sat_karar_terminali.v1_app import serve; serve(port=8765)",
        ],
        cwd=str(project),
        env=env,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        creationflags=creationflags,
    )
    for _ in range(20):
        time.sleep(0.35)
        try:
            with urllib.request.urlopen(health_url, timeout=1.0) as response:
                if response.status == 200:
                    return
        except Exception:
            continue
    raise RuntimeError("AL-SAT servisi baslatilamadi.")


def _alsata_aday_gonder(payload: dict) -> dict:
    _alsat_servisini_hazirla()
    request = urllib.request.Request(
        "http://127.0.0.1:8765/api/external-candidate",
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json; charset=utf-8"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=5) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"AL-SAT aday aktarimi reddedildi: {detail}") from exc
    except Exception as exc:
        raise RuntimeError(f"AL-SAT aday aktarimi basarisiz: {exc}") from exc


def _alsata_adaylari_toplu_gonder(payloadlar: list[dict]) -> list[dict]:
    """Birden fazla tarama adayını mevcut AL-SAT aktarım hattına gönderir."""
    sonuclar: list[dict] = []
    for payload in payloadlar:
        sonuclar.append(_alsata_aday_gonder(payload))
    return sonuclar


def bist_toplu_tarama_sonucu_goster(
    sonuc: MarketScanResult,
    *,
    temel_skorlar: dict | None = None,
    temel_filtre_aktif: bool = False,
    minimum_temel_skor: int = 60,
    research_profiles_bundle=None,
) -> None:
    if not veri_tazeligi_kilidi_goster(sonuc.veri_tazeligi):
        return
    st.subheader(f"{sonuc.evren_adi} güncel aday taraması")
    st.caption("Genel teknik sıralama · seçili tarama profili · veri tazeliği · VBTS uyarıları · isteğe bağlı temel kalite filtresi")
    metrik_izgarasi_goster(
        (
            ("Tarama evreni", str(sonuc.evren_sembol_sayisi)),
            ("Başarılı analiz", str(sonuc.filtrelenmis.aday_sayisi + sonuc.filtrelenmis.elenen_sayisi)),
            ("Filtreyi geçen", str(sonuc.filtrelenmis.aday_sayisi)),
            ("Gösterilen aday", str(sonuc.gosterilen_aday_sayisi)),
            ("Elenen", str(sonuc.filtrelenmis.elenen_sayisi)),
            ("Veri hatası", str(sonuc.filtrelenmis.hatali_sayisi)),
        )
    )
    st.caption(
        f"Evren kaynağı: {sonuc.evren_kaynagi} · "
        f"Bileşen tarihi: {sonuc.evren_tarihi} · "
        f"Profil: {sonuc.profil.ad}"
    )
    st.info(
        "Sonuçlar kesin alım tavsiyesi değildir. Tablo, ayrıntılı güncel "
        "teknik analizde doğrulanacak araştırma adaylarını sıralar."
    )

    if sonuc.vbts_dogrulama_uyarisi:
        st.warning(sonuc.vbts_dogrulama_uyarisi)

    if sonuc.sektor_baglamlari:
        st.caption(
            "Sektör bağlamı: "
            f"{sonuc.sektor_referans_evreni or 'BIST 100'} referansı · "
            "sektör skoru teknik hisse skorunu ve aday filtresini değiştirmez."
        )
    if sonuc.sektor_baglami_uyarisi:
        st.caption(sonuc.sektor_baglami_uyarisi)

    vbts_nedenleri = sonuc.vbts_engelleme_nedenleri or {}
    if vbts_nedenleri:
        st.warning(
            f"{len(vbts_nedenleri)} hissede aktif VBTS tedbiri bulundu. "
            "Bu tedbirler teknik skoru veya sıralamayı değiştirmez."
        )
        with st.expander("VBTS tedbir uyarıları", expanded=False):
            st.dataframe(
                pd.DataFrame(
                    {
                        "Hisse": sembol.removesuffix(".IS"),
                        "VBTS tedbiri": " | ".join(nedenler),
                    }
                    for sembol, nedenler in sorted(vbts_nedenleri.items())
                ),
                width="stretch",
                hide_index=True,
            )

    # RPV1_SPRINT02_RENDER_PANEL
    if research_profiles_bundle is not None:
        render_research_profiles_panel(st, research_profiles_bundle)

    adaylar = sonuc.adaylar
    temel_filtre_sonucu = apply_optional_fundamental_filter(
        adaylar,
        symbol_getter=lambda aday: aday.sembol,
        scores=temel_skorlar or {},
        enabled=temel_filtre_aktif,
        minimum_score=minimum_temel_skor,
    )
    gorunen_semboller = {
        aday.sembol for aday in temel_filtre_sonucu.accepted
    }
    _three_all_rows = aday_tablosu_kayitlari(sonuc)

    # RANKING_JUMP_V1_BLOCK1 — observation only; no rank/score/decision mutation.
    try:
        from backend.app.analysis.ranking_memory import (
            RankObservationJsonlStore,
            observations_from_research_rows,
        )

        _ranking_as_of = str(sonuc.evren_tarihi or "").strip()
        if _ranking_as_of == "Kişisel liste":
            _ranking_as_of = datetime.now().date().isoformat()

        _ranking_memory_rows = tuple(
            {
                "Sıra": _rank,
                "Hisse": _candidate.sembol.removesuffix(".IS"),
            }
            for _rank, _candidate in enumerate(
                sonuc.filtrelenmis.adaylar,
                start=1,
            )
        )
        _rank_observations = observations_from_research_rows(
            rows=_ranking_memory_rows,
            as_of=_ranking_as_of,
            universe_source=sonuc.evren_kaynagi,
            profile_name=sonuc.profil.ad,
        )
        RankObservationJsonlStore().append_snapshot(_rank_observations)
    except Exception as _rank_history_exc:
        try:
            _rank_history_log = Path(
                r"D:\Projects\Hisse-Robotu\_discovery\ranking_memory_write_error.log"
            )
            _rank_history_log.parent.mkdir(parents=True, exist_ok=True)
            with _rank_history_log.open("a", encoding="utf-8") as _rank_history_f:
                _rank_history_f.write(
                    f"{datetime.now().isoformat()} | "
                    f"{type(_rank_history_exc).__name__}: {_rank_history_exc}\n"
                )
        except Exception:
            pass

    # THREE_SYSTEM_ACTIVE_HISSE_PUBLISH_V4
    for _three_row in _three_all_rows:
        try:
            write_scan_row_opinion(
                _three_row,
                as_of=str(sonuc.evren_tarihi),
            )
        except Exception as _three_exc:
            try:
                _three_log = Path(
                    r"D:\Projects-Sistem-Ortak-Degerlendirme\hisse_publish_error.log"
                )
                _three_log.parent.mkdir(parents=True, exist_ok=True)
                with _three_log.open("a", encoding="utf-8") as _three_f:
                    _three_f.write(
                        f"{datetime.now().isoformat()} | "
                        f"{type(_three_exc).__name__}: {_three_exc} | "
                        f"row={_three_row!r}\n"
                    )
            except Exception:
                pass

    kayitlar = [
        kayit
        for aday, kayit in zip(
            sonuc.adaylar,
            _three_all_rows,
        )
        if aday.sembol in gorunen_semboller
    ]

    for aday, kayit in zip(
        (
            aday
            for aday in sonuc.adaylar
            if aday.sembol in gorunen_semboller
        ),
        kayitlar,
    ):
        sembol = aday.sembol.removesuffix(".IS").upper()
        temel_skor = (temel_skorlar or {}).get(sembol)
        kayit["Temel skor"] = (
            temel_skor.total_score
            if temel_skor is not None
            and not temel_skor.locked
            else None
        )

    if temel_filtre_aktif:
        st.info(
            f"İsteğe bağlı temel analiz filtresi aktif: "
            f"minimum {minimum_temel_skor}/100 · "
            f"geçen {len(temel_filtre_sonucu.accepted)} · "
            f"elenen {len(temel_filtre_sonucu.rejected)} · "
            f"verisi eksik {len(temel_filtre_sonucu.missing)}."
        )

    # RANKING_JUMP_V1_UI
    st.markdown("### Sıralama Hareketi / Erken Görünürlük")
    st.caption(
        "Tüm Research sıralamasında 1S / 3S / 5S hareketi, sıçrama ivmesi ve "
        "kalıcılığı gösterir. Bu görünüm AL/SAT kararı üretmez ve ana Research "
        "sırasını değiştirmez."
    )

    try:
        from backend.app.analysis.ranking_memory import RankObservationJsonlStore
        from backend.app.analysis.ranking_movement_visibility import (
            build_ranking_movement_rows,
            ranking_movement_table_rows,
        )
        # V1 compatibility: build_rank_trajectories remains the underlying trajectory contract.

        _ranking_history = RankObservationJsonlStore().list()
        _movement_rows = build_ranking_movement_rows(_ranking_history)

        if not _movement_rows:
            st.info(
                "Sıralama hareketi için henüz yeterli tarihli ranking history yok. "
                "Yeni seans snapshot'ları biriktikçe bu alan otomatik dolacaktır."
            )
        else:
            _movement_df = pd.DataFrame(ranking_movement_table_rows(_movement_rows))
            _jump_filter = st.radio(
                "Sıralama hareketi görünümü",
                options=(
                    "Tüm sıralama",
                    "3S Erken Sıçrayanlar",
                    "Kalıcı yükseliş",
                    "Yeni Top-5'e Yaklaşanlar",
                    "İvme Kaybediyor",
                ),
                horizontal=True,
                key="ranking_jump_v1_filter",
            )

            if _jump_filter == "3S Erken Sıçrayanlar":
                _movement_df = _movement_df[pd.to_numeric(_movement_df["3S Δ"], errors="coerce") > 0]
            elif _jump_filter == "Kalıcı yükseliş":
                _movement_df = _movement_df[_movement_df["Kalıcılık"].isin(("KALICI", "DESTEKLI"))]
            elif _jump_filter == "Yeni Top-5'e Yaklaşanlar":
                _movement_df = _movement_df[pd.to_numeric(_movement_df["Top-5 uzaklık"], errors="coerce") <= 20]
            elif _jump_filter == "İvme Kaybediyor":
                _movement_df = _movement_df[_movement_df["Hareket"].astype(str).str.contains("IVME_KAYBEDIYOR", na=False)]

            st.dataframe(
                _movement_df,
                width="stretch",
                hide_index=True,
                column_config={
                    "Bugün": st.column_config.NumberColumn(format="#%d"),
                    "1S Δ": st.column_config.NumberColumn(format="%d"),
                    "3S Δ": st.column_config.NumberColumn(format="%d"),
                    "5S Δ": st.column_config.NumberColumn(format="%d"),
                    "Sıçrama ivmesi": st.column_config.NumberColumn(format="%.1f"),
                },
            )

            if any(_movement_df["Karşılaştırma"].eq("Bloklu")):
                st.warning(
                    "Bazı satırlarda Research source/profile kontratı değiştiği için "
                    "karşılaştırma yalnız bilgilendirme amaçlıdır."
                )

            st.caption(
                "Sıçrama ivmesi yeni bir skor değildir; son 1 seanslık sıra kazancının "
                "önceki iki seans ortalamasına göre hızlanmasını gösterir. 1S/3S/5S "
                "değerleri ham sıra hareketidir."
            )
    except Exception as _ranking_jump_ui_exc:
        st.warning(
            "Sıralama Hareketi görünümü şu anda hazırlanamadı. "
            f"Ana Research sıralaması etkilenmedi: {_ranking_jump_ui_exc}"
        )
    # RANKING_JUMP_V1_UI_END
    if not kayitlar:
        st.warning(
            "Seçili profil koşullarını karşılayan aday bulunamadı. "
            "Daha geniş bir evren veya daha gevşek profil denenebilir."
        )
    else:
        st.dataframe(
            pd.DataFrame(kayitlar),
            width="stretch",
            hide_index=True,
            column_config={
                "Sıra": st.column_config.NumberColumn(width="small"),
                "Hisse": st.column_config.TextColumn(width="small"),
                "Skor": st.column_config.NumberColumn(width="small"),
                "Temel skor": st.column_config.NumberColumn(
                    width="small",
                    format="%d",
                ),
                "Sektör": st.column_config.TextColumn(width="medium"),
                "Sektör skoru": st.column_config.NumberColumn(
                    width="small",
                    format="%d",
                ),
                "Sektör görünümü": st.column_config.TextColumn(
                    width="small",
                ),
                "Sektör güveni": st.column_config.TextColumn(
                    width="small",
                ),
                "Sektör bağlamı": st.column_config.TextColumn(
                    width="medium",
                ),
                "Sektör RS": st.column_config.NumberColumn(
                    width="small",
                    format="%.2f",
                ),
                "Durum": st.column_config.TextColumn(width="medium"),
                "VBTS": st.column_config.TextColumn(width="large"),
                "Son kapanış": st.column_config.NumberColumn(format="%.2f"),
                "Giriş": st.column_config.NumberColumn(format="%.2f"),
                "Stop": st.column_config.NumberColumn(format="%.2f"),
                "Hedef": st.column_config.NumberColumn(format="%.2f"),
                "Risk/Getiri": st.column_config.NumberColumn(format="1:%.2f"),
                "Hacim oranı": st.column_config.NumberColumn(format="%.2fx"),
                "RSI14": st.column_config.NumberColumn(format="%.2f"),
                "ATR (%)": st.column_config.NumberColumn(format="%.2f%%"),
            },
        )

        secili = st.selectbox(
            "Aday ayrıntısı",
            options=temel_filtre_sonucu.accepted,
            format_func=lambda aday: (
                f"{aday.sembol.removesuffix('.IS')} · "
                f"{aday.sinyal.skor}/100 · {aday.sinyal.karar}"
            ),
            key="bist_toplu_tarama_aday_ayrintisi",
        )
        secili_sembol = secili.sembol.removesuffix(".IS").upper()
        toplu_secimler = st.multiselect(
            "AL-SAT'a gönderilecek adaylar",
            options=tuple(
                aday.sembol.removesuffix(".IS").upper()
                for aday in temel_filtre_sonucu.accepted
            ),
            default=(),
            key="alsata_toplu_secimler",
            help="Seçilen adaylar AL-SAT'a aktarılır.",
        )

        if st.button(
            "Seçilenleri AL-SAT'a Gönder",
            type="secondary",
            width="stretch",
            key="alsata_toplu_gonder",
            disabled=not toplu_secimler,
        ):
            try:
                payloadlar = []
                for sembol in toplu_secimler:
                    aday = next(
                        a for a in temel_filtre_sonucu.accepted
                        if a.sembol.removesuffix(".IS").upper() == sembol
                    )
                    satir = next(
                        (row for row in kayitlar if str(row.get("Hisse", "")).upper() == sembol),
                        {},
                    )
                    payloadlar.append(
                        {
                            "symbol": sembol,
                            "source": "HISSE_ROBOTU",
                            "as_of": str(sonuc.evren_tarihi),
                            "robot_score": aday.sinyal.skor,
                            "robot_decision": satir.get("Durum"),
                            "technical_outlook": aday.sinyal.karar,
                            "rank": satir.get("Sıra"),
                        }
                    )
                _alsata_adaylari_toplu_gonder(payloadlar)
                st.success(f"{len(payloadlar)} seçili aday AL-SAT'a aktarıldı.")
            except Exception as exc:
                st.error(str(exc))

        if st.button(
            "AL-SAT'a Gönder",
            type="primary",
            key=f"alsata_gonder_{secili_sembol}",
        ):
            try:
                secili_satir = next(
                    (row for row in kayitlar if str(row.get("Hisse", "")).upper() == secili_sembol),
                    {},
                )
                aktarim = _alsata_aday_gonder({
                    "symbol": secili_sembol,
                    "source": "HISSE_ROBOTU",
                    "as_of": str(sonuc.evren_tarihi),
                    "robot_score": secili.sinyal.skor,
                    "robot_decision": secili_satir.get("Durum"),
                    "technical_outlook": secili.sinyal.karar,
                    "rank": secili_satir.get("Sıra"),
                })
                st.success(
                    f"{secili_sembol} AL-SAT'a aktarıldı. AL-SAT açılıyor."
                )
                webbrowser.open(
                    f"http://127.0.0.1:8765/?symbol={secili_sembol}",
                    new=2,
                )
            except Exception as exc:
                st.error(str(exc))

        secili_vbts = vbts_nedenleri.get(
            secili.sembol,
            vbts_nedenleri.get(secili.sembol.removesuffix(".IS"), ()),
        )
        if secili_vbts:
            st.warning("VBTS: " + " | ".join(secili_vbts))

        secili_sektor = (sonuc.sektor_baglamlari or {}).get(
            secili.sembol
        )
        if secili_sektor is not None:
            st.info(
                "Sektör bağlamı: "
                f"{secili_sektor.sector_name} · "
                f"{secili_sektor.sector_score}/100 "
                f"{secili_sektor.sector_status} · "
                f"Güven: {secili_sektor.sector_confidence} · "
                f"{secili_sektor.label}. "
                "Bu bilgi teknik skoru değiştirmez."
            )

        sol, sag = st.columns(2)
        with sol:
            aciklama_listesi_goster(
                "Olumlu gerekçeler",
                secili.sinyal.pozitif_nedenler,
                "Belirgin olumlu gerekçe yok.",
            )
        with sag:
            aciklama_listesi_goster(
                "Riskler",
                secili.sinyal.riskler,
                "Belirgin risk yok.",
            )

    if sonuc.filtrelenmis.elenenler:
        with st.expander("Elenen hisseler ve nedenleri", expanded=False):
            elenen_kayitlari = []
            for elenen in sonuc.filtrelenmis.elenenler:
                elenen_kayitlari.append(
                    {
                        "Hisse": elenen.sembol.removesuffix(".IS"),
                        "Neden": " | ".join(elenen.nedenler),
                    }
                )
            st.dataframe(
                pd.DataFrame(elenen_kayitlari),
                width="stretch",
                hide_index=True,
            )

    if sonuc.filtrelenmis.hatalar:
        with st.expander("Verisi alınamayan hisseler", expanded=False):
            st.dataframe(
                pd.DataFrame(
                    {
                        "Hisse": hata.sembol.removesuffix(".IS"),
                        "Hata": hata.hata,
                    }
                    for hata in sonuc.filtrelenmis.hatalar
                ),
                width="stretch",
                hide_index=True,
            )


def bist_toplu_tarama_formu() -> None:
    # BIST_TOPLU_TARAMA_V11_ROLE_CLARITY
    st.header("BIST Toplu Tarama — Genel Teknik Aday Havuzu")
    st.caption(
        "Seçilen evrendeki hisseleri günlük teknik skor, hacim, risk/getiri, VBTS ve isteğe bağlı temel kalite filtresiyle sıralar."
    )
    st.info(
        "Fırsat Radarı doğrulanmış haftalık/aylık profil eşleşmelerini öne çıkarır; "
        "BIST Toplu Tarama ise daha geniş, profil-seçilebilir genel teknik aday havuzu üretir. "
        "Bu ekran kesin alım tavsiyesi vermez; seçilen aday Güncel Teknik Analiz veya AL-SAT ile derinleştirilir."
    )
    bildirim = st.session_state.pop("vbts_yonetim_bildirimi", None)
    if bildirim:
        st.success(bildirim)

    vbts_operasyonel_hazir = vbts_yonetim_paneli_goster()
    vbts_kaynak_hazir = kap_vbts_durum_karti_goster()
    manuel_vbts_durum_paneli_goster()

    vbts_hazirlik_hatasi: str | None = None
    hazir_tarama_servisi: BistMarketScannerService | None = None
    try:
        hazir_tarama_servisi = build_dashboard_market_scanner(
            vbts_hard_block=False,
        )
    except DashboardMarketScannerSourceError as hata:
        vbts_hazirlik_hatasi = str(hata)

    if (
        not vbts_operasyonel_hazir
        or not vbts_kaynak_hazir
        or vbts_hazirlik_hatasi
    ):
        st.warning(
            "VBTS tam doğrulanamadı. Toplu tarama kilitlenmez; "
            "teknik sonuçlar üretilir ancak VBTS tedbir bilgileri "
            "eksik veya eski olabilir."
        )
        if vbts_hazirlik_hatasi:
            st.caption(vbts_hazirlik_hatasi)

    with st.sidebar:
        st.header("BIST toplu tarama")
        st.caption(
            "Seçilen evrendeki hisseleri günlük teknik skor, hacim ve "
            "risk/getiri koşullarıyla topluca sıralar."
        )
        with st.form("bist_toplu_tarama_formu"):
            evren = st.selectbox(
                "Tarama evreni",
                options=TARAMA_EVRENLERI,
                index=0,
            )
            ozel_liste = st.text_area(
                "Özel hisse listesi",
                value="THYAO, ASELS, TUPRS, SAHOL, KCHOL",
                height=90,
                help=(
                    "Virgül, boşluk veya yeni satırla ayırabilirsiniz. "
                    "Bu alan yalnızca Özel Liste evreninde kullanılır."
                ),
            )
            profil_etiketi = st.selectbox(
                "Tarama profili",
                options=tuple(TARAMA_PROFILLERI),
                index=1,
                help=(
                    "Dengeli profil skor, hacim ve pozitif/nötr "
                    "teknik görünümü uygular. Risk/getiri işlem hazırlığı "
                    "aşamasında ayrıca değerlendirilir."
                ),
            )
            maksimum_aday = st.slider(
                "Gösterilecek aday sayısı",
                min_value=1,
                max_value=50,
                value=15,
            )
            internetten_guncelle = st.checkbox(
                "BIST evrenini resmi kaynaktan güncelle",
                value=True,
                disabled=(evren not in ("BIST 30", "BIST 100", "BIST 500", "BIST Tüm")),
            )
            temel_filtre_aktif = st.checkbox(
                "Temel kalite filtresini kullan",
                value=False,
                help=(
                    "Varsayılan olarak kapalıdır. Açıldığında önce "
                    "kayıtlı ve güncel temel kalite skorları kullanılır."
                ),
            )
            minimum_temel_skor = st.slider(
                "Minimum temel kalite skoru",
                min_value=0,
                max_value=100,
                value=60,
                # RPV1_SPRINT02_UPLOADER_ALWAYS_AVAILABLE
                disabled=False,
            )
            temel_filtre_dosyasi = st.file_uploader(
                "Temel skorları güncellemek için bilanço dosyası",
                type=("csv", "json"),
                disabled=not temel_filtre_aktif,
                key="bist_temel_filtre_dosyasi",
                help=(
                    "İsteğe bağlıdır. Dosya yüklenmezse yerel depodaki "
                    "güncel temel kalite skorları kullanılır."
                ),
            )
            calistirildi = st.form_submit_button(
                "Toplu taramayı başlat",
                type="primary",
                width="stretch",
                disabled=hazir_tarama_servisi is None,
            )

    if not calistirildi:
        onceki_tarama = st.session_state.get("bist_toplu_tarama_son_sonuc")
        if onceki_tarama is not None:
            bist_toplu_tarama_sonucu_goster(
                onceki_tarama["sonuc"],
                temel_skorlar=onceki_tarama.get("temel_skorlar", {}),
                temel_filtre_aktif=bool(onceki_tarama.get("temel_filtre_aktif", False)),
                minimum_temel_skor=int(onceki_tarama.get("minimum_temel_skor", 60)),
            )
            st.caption("Son toplu tarama sonucu korunuyor. Yeni tarama başlatılana kadar aday listesi sıfırlanmaz.")
            return
        st.info(
            "Tarama evrenini ve profili seçip sol menüdeki "
            "‘Toplu taramayı başlat’ düğmesine basın."
        )
        st.caption(
            "BIST Tüm seçeneği yüzlerce hisse içerdiğinden diğer "
            "evrenlere göre daha uzun sürebilir."
        )
        return

    if hazir_tarama_servisi is None:
        st.error(
            "Toplu tarama servisi hazırlanamadı. "
            "Bu durum VBTS kilidi değildir; servis kurulumu kontrol edilmelidir."
        )
        return

    # RPV1_SPRINT02_INPUT_CONTEXT
    research_profile_periods = ()
    research_profile_contexts = {}
    if temel_filtre_dosyasi is not None:
        try:
            _rp_bytes = temel_filtre_dosyasi.getvalue()
            _rp_suffix = Path(temel_filtre_dosyasi.name).suffix.lower()
            research_profile_periods = (
                periods_from_csv_bytes(_rp_bytes)
                if _rp_suffix == ".csv"
                else periods_from_json_bytes(_rp_bytes)
            )
            research_profile_contexts = research_profile_contexts_from_bytes(
                _rp_bytes,
                suffix=_rp_suffix,
            )
        except (FundamentalDataError, ValueError, TypeError, UnicodeError) as hata:
            st.warning(f"Research Profiles temel verisi okunamadı: {hata}")
            research_profile_periods = ()
            research_profile_contexts = {}

    temel_skorlar: dict = {}
    if temel_filtre_aktif:
        temel_skorlar = kayitli_temel_skorlari_yukle()

        if temel_filtre_dosyasi is not None:
            try:
                temel_icerik = temel_filtre_dosyasi.getvalue()
                if (
                    Path(temel_filtre_dosyasi.name).suffix.lower()
                    == ".csv"
                ):
                    temel_donemler = periods_from_csv_bytes(
                        temel_icerik
                    )
                else:
                    temel_donemler = periods_from_json_bytes(
                        temel_icerik
                    )

                for temel_sembol in sorted(
                    {item.symbol for item in temel_donemler}
                ):
                    sembol_donemleri = [
                        item
                        for item in temel_donemler
                        if item.symbol == temel_sembol
                    ]
                    sembol_tazeligi = (
                        evaluate_fundamental_freshness(
                            sembol_donemleri
                        )
                    )
                    if sembol_tazeligi.locked:
                        continue

                    sembol_snapshot = build_fundamental_snapshot(
                        sembol_donemleri
                    )
                    skor = calculate_fundamental_quality(
                        sembol_snapshot,
                        sembol_tazeligi,
                    )
                    if skor.locked or skor.total_score is None:
                        continue

                    temel_skor_deposu().save(
                        periods=sembol_donemleri,
                        score=skor,
                    )
                    temel_skorlar[temel_sembol] = skor
            except (
                FundamentalDataError,
                FundamentalScoreStoreError,
                ValueError,
                TypeError,
                UnicodeError,
            ) as hata:
                st.error(
                    f"Temel filtre dosyası doğrulanamadı: {hata}"
                )
                return

        if not temel_skorlar:
            st.error(
                "Temel kalite filtresi için güncel kayıtlı skor "
                "bulunamadı. Temel Analiz ekranında bilanço dosyası "
                "yükleyerek skorları kaydedin."
            )
            return

    ilerleme = st.progress(0, text="Tarama hazırlanıyor...")
    durum = st.empty()

    def ilerleme_bildir(sira: int, toplam: int, sembol: str) -> None:
        oran = min(max(sira / toplam, 0.0), 1.0)
        ilerleme.progress(
            oran,
            text=f"[{sira}/{toplam}] {sembol} analiz ediliyor...",
        )
        durum.caption(f"Son işlenen hisse: {sembol}")

    try:
        istek = MarketScanRequest(
            evren=evren,
            profil_adi=TARAMA_PROFILLERI[profil_etiketi],
            maksimum_aday=int(maksimum_aday),
            ozel_semboller=ozel_sembol_metinini_ayristir(ozel_liste),
            internetten_evren_guncelle=bool(internetten_guncelle),
            sektor_baglami_aktif=True,
        )
        with st.spinner(f"{istek.evren} güncel verilerle taranıyor..."):
            tarama_servisi = hazir_tarama_servisi
            sonuc = tarama_servisi.calistir(
                istek,
                ilerleme_bildirimi=ilerleme_bildir,
            )
    except (
        ValueError,
        TypeError,
        MarketScannerError,
        DashboardMarketScannerSourceError,
    ) as hata:
        ilerleme.empty()
        durum.empty()
        st.error(str(hata))
        return

    ilerleme.progress(1.0, text="Toplu tarama tamamlandı.")
    durum.empty()
    # RPV1_SPRINT02_BUILD_BUNDLE — uses same successful scan results; no rescan.
    _rp_successful_symbols = tuple(
        item.sembol for item in tuple(getattr(sonuc, "tum_sonuclar", ()) or ())
    )
    research_profiles_bundle = build_daily_research_profiles(
        successful_symbols=_rp_successful_symbols,
        periods=research_profile_periods,
        contexts=research_profile_contexts,
        as_of=research_profile_as_of_from_scan(sonuc, fallback=date.today()),
    )

    # RPV1_SPRINT03_PROFILE_MEMORY_WRITE
    try:
        _rp_memory_write = persist_research_profile_bundle(
            research_profiles_bundle,
            universe_name=sonuc.evren_adi,
        )
        if _rp_memory_write.status == "WARMING_UP":
            st.caption(
                "Research Profile Memory: WARMING UP · "
                "forward-only ilk geçerli seans bekleniyor."
            )
        elif _rp_memory_write.status == "WRITTEN":
            st.caption(
                f"Research Profile Memory: {_rp_memory_write.appended} "
                "forward observation eklendi."
            )
    except (ValueError, TypeError, OSError) as hata:
        st.warning(
            "Research Profile Memory yazılamadı; tarama ve AL/SAT sonucu "
            f"değiştirilmedi: {hata}"
        )

    if st.button(
        "Günlük Operasyon Paneline Git",
        key="bist_toplu_tarama_gunluk_operasyon_gecis",
    ):
        st.session_state["analiz_modu"] = "Günlük Operasyon Paneli"
        st.rerun()

    st.session_state["bist_toplu_tarama_son_sonuc"] = {
        "sonuc": sonuc,
        "temel_skorlar": temel_skorlar,
        "temel_filtre_aktif": bool(temel_filtre_aktif),
        "minimum_temel_skor": int(minimum_temel_skor),
    }
    bist_toplu_tarama_sonucu_goster(
        sonuc,
        temel_skorlar=temel_skorlar,
        temel_filtre_aktif=bool(temel_filtre_aktif),
        minimum_temel_skor=int(minimum_temel_skor),
        research_profiles_bundle=research_profiles_bundle,
    )


def acik_pozisyon_sonucu_goster(sonuc: PositionMonitoringResult) -> None:
    st.subheader(f"{sonuc.sembol} açık pozisyon izleme")
    metrik_izgarasi_goster(
        (
            ("Pozisyon durumu", sonuc.durum),
            ("Önerilen eylem", sonuc.eylem),
            ("Son kapanış", para_yaz(sonuc.son_kapanis)),
            ("Açık kâr/zarar", para_yaz(sonuc.acik_kar_zarar)),
            ("Getiri", yuzde_yaz(sonuc.acik_kar_zarar_yuzde)),
            ("Gerçekleşmemiş R", f"{sonuc.r_katsayisi:.2f}R"),
            ("Dinamik stop", para_yaz(sonuc.dinamik_stop)),
            ("Stop mesafesi", f"{para_yaz(sonuc.stop_mesafesi)} · %{sonuc.stop_mesafesi_yuzde:.2f}"),
        )
    )

    st.markdown("**Stop ve kâr koruma**")
    st.dataframe(
        pd.DataFrame(
            (
                {"Alan": "İlk stop", "Değer": sonuc.ilk_stop},
                {"Alan": "Önceki stop", "Değer": sonuc.onceki_stop},
                {"Alan": "Dinamik stop", "Değer": sonuc.dinamik_stop},
                {"Alan": "Pozisyon içi zirve", "Değer": sonuc.en_yuksek_fiyat},
                {"Alan": "En yüksek kapanış", "Değer": sonuc.en_yuksek_kapanis},
            )
        ),
        width="stretch",
        hide_index=True,
    )
    st.caption(f"Dinamik stop kaynağı: {sonuc.stop_kaynagi}")

    kar_alma = (
        "Tam çıkış"
        if sonuc.hedef_2.durum == "Ulaşıldı"
        else (
            f"{sonuc.onerilen_kismi_kar_lotu} lot kısmi kâr"
            if sonuc.kismi_kar_onerisi
            else "Yok"
        )
    )
    st.markdown("**Hedef ilerlemesi**")
    st.dataframe(
        pd.DataFrame(
            (
                {
                    "Hedef": "Hedef 1",
                    "Fiyat": sonuc.hedef_1.hedef,
                    "Durum": sonuc.hedef_1.durum,
                    "Kalan (%)": round(sonuc.hedef_1.kalan_yuzde, 2),
                },
                {
                    "Hedef": "Hedef 2",
                    "Fiyat": sonuc.hedef_2.hedef,
                    "Durum": sonuc.hedef_2.durum,
                    "Kalan (%)": round(sonuc.hedef_2.kalan_yuzde, 2),
                },
            )
        ),
        width="stretch",
        hide_index=True,
    )
    st.info(f"Kâr alma değerlendirmesi: {kar_alma}")

    aciklama_listesi_goster(
        "Pozitif unsurlar",
        sonuc.pozitif_nedenler,
        "Belirgin pozitif unsur yok.",
    )
    aciklama_listesi_goster(
        "Riskler",
        sonuc.riskler,
        "Belirgin yeni risk yok.",
    )
    aciklama_listesi_goster(
        "Notlar",
        sonuc.notlar,
        "Ek not yok.",
    )

    with st.expander("İzleme kimlikleri", expanded=False):
        st.code(
            "\n".join(
                (
                    f"Veri kimliği: {sonuc.veri_kimligi}",
                    f"Teknik analiz kimliği: {sonuc.teknik_analiz_kimligi}",
                    f"İzleme kimliği: {sonuc.izleme_kimligi}",
                )
            )
        )


def acik_pozisyon_izleme_formu() -> None:
    with st.sidebar:
        st.header("Açık pozisyon ayarları")
        with st.form("acik_pozisyon_izleme_formu"):
            sembol = st.text_input(
                "Hisse sembolü",
                value="THYAO",
                help="BIST uzantısı yazılmazsa .IS otomatik eklenir.",
            )
            giris_tarihi = st.date_input(
                "Giriş tarihi",
                value=datetime.now().date().replace(day=1),
            )
            giris_fiyati = st.number_input(
                "Giriş fiyatı",
                min_value=0.01,
                value=300.0,
                step=0.25,
            )
            lot_sayisi = st.number_input(
                "Açık lot",
                min_value=1,
                value=100,
                step=1,
            )
            ilk_stop = st.number_input(
                "İlk stop",
                min_value=0.01,
                value=286.50,
                step=0.25,
            )
            hedef_1 = st.number_input(
                "Hedef 1",
                min_value=0.01,
                value=327.0,
                step=0.25,
            )
            hedef_2 = st.number_input(
                "Hedef 2",
                min_value=0.01,
                value=354.0,
                step=0.25,
            )
            mevcut_stop_kullan = st.checkbox("Yükseltilmiş mevcut stop var")
            mevcut_stop_degeri = st.number_input(
                "Mevcut stop",
                min_value=0.01,
                value=286.50,
                step=0.25,
                disabled=not mevcut_stop_kullan,
            )
            hedef_1_gerceklesti = st.checkbox(
                "Hedef 1 için daha önce kısmi kâr alındı"
            )
            calistirildi = st.form_submit_button(
                "Pozisyonu güncelle",
                type="primary",
                width="stretch",
            )

    if not calistirildi:
        st.info(
            "Açık pozisyon bilgilerini girip sol menüdeki "
            "‘Pozisyonu güncelle’ düğmesine basın."
        )
        return

    try:
        istek = OpenPositionDashboardRequest(
            sembol=sembol,
            giris_tarihi=giris_tarihi,
            giris_fiyati=float(giris_fiyati),
            lot_sayisi=int(lot_sayisi),
            ilk_stop=float(ilk_stop),
            hedef_1=float(hedef_1),
            hedef_2=float(hedef_2),
            mevcut_stop=(
                float(mevcut_stop_degeri) if mevcut_stop_kullan else None
            ),
            hedef_1_gerceklesti=bool(hedef_1_gerceklesti),
        )
        with st.spinner(f"{istek.sembol} açık pozisyonu güncelleniyor..."):
            sonuc = OpenPositionDashboardService().calistir(istek)
    except (ValueError, TypeError, LiveAnalysisDashboardError) as hata:
        st.error(str(hata))
        return

    acik_pozisyon_sonucu_goster(sonuc)

def tek_hisse_formu() -> None:
    with st.sidebar:
        st.header("Tek hisse ayarları")

        with st.form("tek_hisse_backtest_formu"):
            sembol = st.text_input(
                "Hisse sembolü",
                value="THYAO",
                help="BIST uzantısı yazılmazsa .IS otomatik eklenir.",
            )
            indirme_donemi = st.selectbox(
                "Veri dönemi",
                options=("1y", "2y", "5y", "10y", "max"),
                index=2,
            )
            islem_gunu = st.number_input(
                "En fazla işlem günü",
                min_value=100,
                max_value=10_000,
                value=1253,
                step=50,
            )
            gorunum_etiketi = st.selectbox(
                "Teknik görünüm",
                options=tuple(GORUNUM_SECENEKLERI),
                index=0,
            )
            minimum_skor = st.slider(
                "Minimum sinyal skoru",
                min_value=0,
                max_value=100,
                value=50,
            )
            elde_tutma_gunu = st.slider(
                "Elde tutma süresi (bar)",
                min_value=1,
                max_value=30,
                value=10,
            )
            baslangic_sermayesi = st.number_input(
                "Başlangıç sermayesi",
                min_value=1_000.0,
                value=100_000.0,
                step=10_000.0,
            )
            pozisyon_yuzde = st.slider(
                "Pozisyon sermayesi (%)",
                min_value=1.0,
                max_value=100.0,
                value=100.0,
                step=1.0,
            )
            maliyet_yuzde = st.number_input(
                "İşlem maliyeti (%)",
                min_value=0.0,
                max_value=9.99,
                value=0.10,
                step=0.01,
            )
            stop_yuzde = st.number_input(
                "Zarar durdur (%)",
                min_value=0.01,
                max_value=99.0,
                value=5.0,
                step=0.5,
            )
            hedef_yuzde = st.number_input(
                "Hedef (%)",
                min_value=0.01,
                max_value=99.0,
                value=10.0,
                step=0.5,
            )

            calistirildi = st.form_submit_button(
                "Backtest'i başlat",
                type="primary",
                width="stretch",
            )

    if not calistirildi:
        st.info(
            "Ayarları seçip sol menüdeki "
            "‘Backtest'i başlat’ düğmesine basın."
        )
        return

    try:
        istek = DashboardBacktestRequest(
            sembol=sembol,
            islem_gunu=int(islem_gunu),
            indirme_donemi=indirme_donemi,
            gorunum_secimi=GORUNUM_SECENEKLERI[gorunum_etiketi],
            elde_tutma_gunu=int(elde_tutma_gunu),
            minimum_skor=int(minimum_skor),
            baslangic_sermayesi=float(baslangic_sermayesi),
            pozisyon_yuzde=float(pozisyon_yuzde),
            maliyet_yuzde=float(maliyet_yuzde),
            stop_yuzde=float(stop_yuzde),
            hedef_yuzde=float(hedef_yuzde),
        )

        with st.spinner(
            f"{istek.sembol} verisi hazırlanıyor ve backtest çalışıyor..."
        ):
            sonuc = BacktestDashboardService().calistir(istek)

    except (ValueError, TypeError, BacktestServiceError) as hata:
        st.error(str(hata))
        return

    kayit = gecmise_kaydet(sonuc)
    if kayit is not None:
        st.caption("Analiz geçmişine kaydedildi.")
    tek_hisse_sonucu_goster(sonuc)


def portfoy_formu() -> None:
    with st.sidebar:
        st.header("Portföy ayarları")

        with st.form("portfoy_backtest_formu"):
            semboller = st.text_area(
                "Hisse sembolleri",
                value="THYAO, TUPRS, ASELS",
                help=(
                    "Sembolleri virgül, boşluk veya yeni satırla ayırın. "
                    "En fazla 10 hisse kullanılabilir."
                ),
                height=90,
            )
            maksimum_pozisyon = st.number_input(
                "Maksimum eş zamanlı pozisyon",
                min_value=1,
                max_value=10,
                value=3,
                step=1,
            )
            indirme_donemi = st.selectbox(
                "Veri dönemi",
                options=("1y", "2y", "5y", "10y", "max"),
                index=2,
            )
            islem_gunu = st.number_input(
                "En fazla işlem günü",
                min_value=100,
                max_value=10_000,
                value=1253,
                step=50,
            )
            gorunum_etiketi = st.selectbox(
                "Teknik görünüm",
                options=tuple(GORUNUM_SECENEKLERI),
                index=0,
            )
            minimum_skor = st.slider(
                "Minimum sinyal skoru",
                min_value=0,
                max_value=100,
                value=50,
            )
            elde_tutma_gunu = st.slider(
                "Elde tutma süresi (bar)",
                min_value=1,
                max_value=30,
                value=10,
            )
            baslangic_sermayesi = st.number_input(
                "Başlangıç sermayesi",
                min_value=1_000.0,
                value=100_000.0,
                step=10_000.0,
            )
            maliyet_yuzde = st.number_input(
                "İşlem maliyeti (%)",
                min_value=0.0,
                max_value=9.99,
                value=0.10,
                step=0.01,
            )
            stop_yuzde = st.number_input(
                "Zarar durdur (%)",
                min_value=0.01,
                max_value=99.0,
                value=5.0,
                step=0.5,
            )
            hedef_yuzde = st.number_input(
                "Hedef (%)",
                min_value=0.01,
                max_value=99.0,
                value=10.0,
                step=0.5,
            )

            calistirildi = st.form_submit_button(
                "Portföy backtest'ini başlat",
                type="primary",
                width="stretch",
            )

    if not calistirildi:
        st.info(
            "Hisseleri ve ayarları seçip sol menüdeki "
            "‘Portföy backtest'ini başlat’ düğmesine basın."
        )
        return

    try:
        istek = PortfolioDashboardRequest(
            semboller=semboller,
            islem_gunu=int(islem_gunu),
            indirme_donemi=indirme_donemi,
            gorunum_secimi=GORUNUM_SECENEKLERI[gorunum_etiketi],
            elde_tutma_gunu=int(elde_tutma_gunu),
            minimum_skor=int(minimum_skor),
            baslangic_sermayesi=float(baslangic_sermayesi),
            maliyet_yuzde=float(maliyet_yuzde),
            stop_yuzde=float(stop_yuzde),
            hedef_yuzde=float(hedef_yuzde),
            maksimum_es_zamanli_pozisyon=int(maksimum_pozisyon),
        )

        with st.spinner(
            f"{len(istek.semboller)} hisse hazırlanıyor ve "
            "portföy backtest’i çalışıyor..."
        ):
            sonuc = PortfolioDashboardService().calistir(istek)

    except (ValueError, TypeError, PortfolioDashboardError) as hata:
        st.error(str(hata))
        return

    kayit = gecmise_kaydet(sonuc)
    if kayit is not None:
        st.caption("Analiz geçmişine kaydedildi.")
    portfoy_sonucu_goster(sonuc)




def _opsiyonel_fiyat(deger: float) -> float | None:
    return float(deger) if float(deger) > 0 else None


def _islem_kaydi_etiketi(kayit: TradeRecord) -> str:
    return (
        f"{kayit.exit_date.isoformat()} · {kayit.symbol.removesuffix('.IS')} · "
        f"{para_yaz(kayit.net_pnl)} · {kayit.record_id}"
    )


def _kayip_ozeti_goster(
    sonuc: LossAnalysisResult,
    kayitlar: tuple[TradeRecord, ...],
    depo: TradeJournalStore,
) -> None:
    ozet = sonuc.summary
    kar_faktoru = "—" if ozet.profit_factor is None else f"{ozet.profit_factor:.2f}"
    metrik_izgarasi_goster(
        (
            ("Toplam işlem", str(ozet.trade_count)),
            ("Kazanan / Kaybeden", f"{ozet.winning_count} / {ozet.losing_count}"),
            ("Net K/Z", para_yaz(ozet.net_pnl)),
            ("Başarı oranı", yuzde_yaz(ozet.win_rate_pct)),
            ("Kâr faktörü", kar_faktoru),
            ("İşlem başına beklenti", para_yaz(ozet.expectancy)),
            ("Azami düşüş", para_yaz(ozet.max_drawdown)),
            ("Azami düşüş %", yuzde_yaz(ozet.max_drawdown_pct)),
            ("En uzun zarar serisi", str(ozet.max_consecutive_losses)),
        )
    )
    st.caption(
        f"Güvenlik değerlendirme tarihi: {sonuc.evaluation_date.isoformat()} · "
        f"Günlük net sonuç: {para_yaz(sonuc.safety_context.daily_net_pnl)} · "
        f"Haftalık net sonuç: {para_yaz(sonuc.safety_context.weekly_net_pnl)} · "
        f"Güncel ardışık zarar: {sonuc.safety_context.consecutive_losses}"
    )

    if sonuc.causes:
        st.subheader("Kayıp nedenleri — davranış ve risk teşhisi")
        st.caption("Geç giriş, kaybedene ekleme, aşırı yükselmiş giriş, stop/RR ve risk sınırı ihlalleri bu bölümde teşhis edilir.")
        st.info(
            "Neden dağılımı, günlükte kayıtlı stop/hedef ve kullanıcı işaretlerine "
            "dayanır. Bir zararın birden fazla nedeni olabilir; zarar tutarı nedenler "
            "arasında eşit paylaştırılarak yalnızca teşhis amacıyla gösterilir."
        )
        st.dataframe(
            pd.DataFrame(cause_table(sonuc)),
            width="stretch",
            hide_index=True,
        )
        st.subheader("Zarar eden işlemler")
        st.dataframe(
            pd.DataFrame(diagnostic_table(sonuc)),
            width="stretch",
            hide_index=True,
        )
    else:
        st.success("Seçilen kayıtlarda zarar eden tamamlanmış işlem bulunmuyor.")

    st.subheader("İşlem günlüğü")
    st.dataframe(
        pd.DataFrame(journal_table(kayitlar)),
        width="stretch",
        hide_index=True,
    )

    if kayitlar:
        with st.expander("Yanlış kaydı sil", expanded=False):
            secenekler = {_islem_kaydi_etiketi(item): item.record_id for item in kayitlar}
            secilen = st.selectbox("Silinecek kayıt", options=tuple(secenekler))
            if st.button("Seçilen kaydı sil", type="secondary", width="stretch"):
                try:
                    if depo.delete(secenekler[secilen]):
                        st.session_state["islem_gunlugu_bildirimi"] = "İşlem kaydı silindi."
                        st.rerun()
                except TradeJournalError as hata:
                    st.error(str(hata))


def _islem_kaydi_ekle(depo: TradeJournalStore) -> None:
    st.subheader("Tamamlanmış işlem ekle")
    st.caption("Kayıt: hesap türü · giriş/çıkış · lot · sermaye · stop/hedef · masraf · sinyal sınıfı · davranış etiketleri · notlar")
    st.caption(
        "Buraya yalnızca gerçekleşmiş değerleri girin. Stop ve hedef kullanılmadıysa "
        "ilgili alana 0 yazın. Gerçek ve deneme hesapları ayrı tutulur."
    )
    with st.form("islem_kaydi_ekle_formu"):
        sol, orta, sag = st.columns(3)
        with sol:
            hesap = st.selectbox("Hesap türü", options=HESAP_TURLERI)
            sembol = st.text_input("Hisse sembolü", value="THYAO")
            giris_tarihi = st.date_input(
                "Giriş tarihi",
                value=datetime.now().date() - timedelta(days=7),
                key="gunluk_giris_tarihi",
            )
            cikis_tarihi = st.date_input(
                "Çıkış tarihi",
                value=datetime.now().date(),
                key="gunluk_cikis_tarihi",
            )
        with orta:
            giris_fiyati = st.number_input(
                "Giriş fiyatı", min_value=0.01, value=100.0, step=0.25
            )
            cikis_fiyati = st.number_input(
                "Çıkış fiyatı", min_value=0.01, value=100.0, step=0.25
            )
            lot = st.number_input("Lot", min_value=1, value=100, step=1)
            sermaye = st.number_input(
                "İşlem anındaki sermaye",
                min_value=1_000.0,
                value=100_000.0,
                step=10_000.0,
            )
        with sag:
            stop = st.number_input(
                "Planlanan stop (0 = yok)", min_value=0.0, value=0.0, step=0.25
            )
            hedef = st.number_input(
                "Planlanan hedef (0 = yok)", min_value=0.0, value=0.0, step=0.25
            )
            masraf = st.number_input(
                "Toplam komisyon/masraf", min_value=0.0, value=0.0, step=1.0
            )
            sinyal = st.text_input("Sinyal sınıfı", value="")

        gec_giris = st.checkbox("Girişin geç yapıldığını düşünüyorum")
        kaybedene_ekleme = st.checkbox("Kaybeden pozisyona ekleme yapıldı")
        asiri_yukselmis = st.checkbox("Aşırı yükselmiş bölgede giriş yapıldı")
        notlar = st.text_area("Notlar", value="", height=80)
        kaydet = st.form_submit_button(
            "İşlemi günlüğe kaydet", type="primary", width="stretch"
        )

    if not kaydet:
        return
    try:
        kayit = TradeRecord(
            account_type=hesap,
            symbol=sembol,
            entry_date=giris_tarihi,
            exit_date=cikis_tarihi,
            entry_price=float(giris_fiyati),
            exit_price=float(cikis_fiyati),
            quantity=int(lot),
            capital_at_entry=float(sermaye),
            stop_loss=_opsiyonel_fiyat(float(stop)),
            target_price=_opsiyonel_fiyat(float(hedef)),
            fees=float(masraf),
            signal_class=sinyal.strip(),
            late_entry=bool(gec_giris),
            averaging_down=bool(kaybedene_ekleme),
            overextended_entry=bool(asiri_yukselmis),
            notes=notlar.strip(),
        )
        depo.save(kayit)
        st.session_state["islem_gunlugu_bildirimi"] = (
            f"{kayit.symbol.removesuffix('.IS')} işlemi günlüğe kaydedildi."
        )
        st.rerun()
    except (ValueError, TypeError, TradeJournalError) as hata:
        st.error(str(hata))


def _islem_csv_araclari(
    depo: TradeJournalStore,
    kayitlar: tuple[TradeRecord, ...],
) -> None:
    st.subheader("CSV içe ve dışa aktarma")
    st.caption(f"Yerel günlük dosyası: {depo.file_path}")
    sol, sag = st.columns(2)
    with sol:
        st.download_button(
            "CSV şablonunu indir",
            data=csv_template_bytes(),
            file_name="Hisse-Robotu-Islem-Gunlugu-Sablonu.csv",
            mime="text/csv",
            width="stretch",
        )
    with sag:
        st.download_button(
            "Mevcut günlüğü CSV olarak indir",
            data=records_to_csv_bytes(kayitlar),
            file_name="Hisse-Robotu-Islem-Gunlugu.csv",
            mime="text/csv",
            width="stretch",
        )

    yuklenen = st.file_uploader(
        "İşlem günlüğü CSV dosyası",
        type=("csv",),
        help="Şablondaki sütun adlarını koruyun. Ondalık ayırıcı nokta veya virgül olabilir.",
    )
    if yuklenen is not None and st.button(
        "CSV kayıtlarını günlüğe ekle", type="primary", width="stretch"
    ):
        try:
            yeni_kayitlar = records_from_csv_bytes(yuklenen.getvalue())
            eklenen = depo.save_many(yeni_kayitlar)
            st.session_state["islem_gunlugu_bildirimi"] = (
                f"CSV dosyasından {eklenen} işlem kaydı eklendi."
            )
            st.rerun()
        except (ValueError, TypeError, TradeJournalError) as hata:
            st.error(str(hata))


def _guvenlik_karari_goster(karar: SafetyDecision) -> None:
    if karar.allowed:
        st.success(
            "İşlem güvenlik kurallarını geçiyor. Bu sonuç kazanç garantisi veya "
            "alım önerisi değildir; yalnızca tanımlı risk sınırlarının aşılmadığını gösterir."
        )
    else:
        st.error("Yeni işlem güvenlik kilidi tarafından engellendi.")
        st.caption("Engel kaldırılmadan işlem güvenlik kontrolünden geçmiş sayılmaz.")

    metrik_izgarasi_goster(
        (
            ("Güvenlik durumu", karar.status),
            ("Pozisyon tutarı", para_yaz(karar.position_amount)),
            ("Pozisyon / sermaye", yuzde_yaz(karar.position_pct)),
            (
                "Planlanan risk",
                "—" if karar.risk_amount is None else para_yaz(karar.risk_amount),
            ),
            (
                "Risk / sermaye",
                "—" if karar.risk_pct is None else yuzde_yaz(karar.risk_pct),
            ),
            (
                "Risk/Getiri",
                "—" if karar.reward_risk is None else f"1:{karar.reward_risk:.2f}",
            ),
            ("Günlük zarar oranı", yuzde_yaz(karar.daily_loss_pct)),
            ("Haftalık zarar oranı", yuzde_yaz(karar.weekly_loss_pct)),
        )
    )
    aciklama_listesi_goster(
        "İşlemi engelleyen nedenler",
        karar.blocking_reasons,
        "Engelleyen kural yok.",
    )
    aciklama_listesi_goster(
        "Uyarılar",
        karar.warnings,
        "Ek uyarı yok.",
    )


def _yeni_islem_on_kontrolu(
    sonuc: LossAnalysisResult,
    politika: SafetyPolicy,
) -> None:
    st.subheader("Yeni işlem ön kontrolü — Güvenlik Kilidi")
    st.caption("Kontrol: pozisyon/sermaye · işlem başına risk · minimum risk/getiri · günlük/haftalık zarar · ardışık zarar · davranış blokları")
    st.warning(
        "Bu ekran emir göndermez. Yalnızca stop, hedef, pozisyon büyüklüğü ve "
        "işlem günlüğündeki günlük/haftalık kayıp sınırlarını kontrol eder."
    )
    with st.form("yeni_islem_guvenlik_formu"):
        sol, sag = st.columns(2)
        with sol:
            sembol = st.text_input("Yeni işlem sembolü", value="THYAO")
            sermaye = st.number_input(
                "Güncel sermaye", min_value=1_000.0, value=100_000.0, step=10_000.0
            )
            giris = st.number_input(
                "Planlanan giriş", min_value=0.01, value=100.0, step=0.25
            )
            lot = st.number_input("Planlanan lot", min_value=1, value=100, step=1)
        with sag:
            stop = st.number_input(
                "Stop-loss (0 = yok)", min_value=0.0, value=95.0, step=0.25
            )
            hedef = st.number_input(
                "Hedef fiyat (0 = yok)", min_value=0.0, value=110.0, step=0.25
            )
            kaybedene_ekleme = st.checkbox("Bu işlem kaybeden pozisyona ekleme")
            asiri_yukselmis = st.checkbox("Hisse aşırı yükselmiş bölgede")
        kontrol = st.form_submit_button(
            "Güvenlik kontrolünü çalıştır", type="primary", width="stretch"
        )

    if not kontrol:
        return
    try:
        teklif = TradeProposal(
            symbol=sembol,
            capital=float(sermaye),
            entry_price=float(giris),
            quantity=int(lot),
            stop_loss=_opsiyonel_fiyat(float(stop)),
            target_price=_opsiyonel_fiyat(float(hedef)),
            averaging_down=bool(kaybedene_ekleme),
            overextended_entry=bool(asiri_yukselmis),
        )
        karar = evaluate_trade_safety(
            teklif,
            context=sonuc.safety_context,
            policy=politika,
        )
        _guvenlik_karari_goster(karar)
    except (ValueError, TypeError) as hata:
        st.error(str(hata))


def islem_kayip_analizi_formu() -> None:
    depo = TradeJournalStore()
    with st.sidebar:
        st.header("Kayıp analizi ve güvenlik")
        hesap_filtresi = st.selectbox(
            "Analiz edilecek hesap",
            options=(GERCEK_HESAP, DENEME_HESABI, "Tümü"),
            index=0,
        )
        degerlendirme_tarihi = st.date_input(
            "Güvenlik değerlendirme tarihi",
            value=datetime.now().date(),
            key="kayip_degerlendirme_tarihi",
        )
        st.markdown("**Güvenlik sınırları**")
        azami_risk = st.number_input(
            "İşlem başına azami risk (%)",
            min_value=0.10,
            max_value=10.0,
            value=1.0,
            step=0.10,
            key="kayip_azami_risk",
        )
        minimum_rr = st.number_input(
            "Minimum risk/getiri",
            min_value=0.50,
            max_value=10.0,
            value=2.0,
            step=0.25,
        )
        azami_pozisyon = st.number_input(
            "Azami pozisyon / sermaye (%)",
            min_value=1.0,
            max_value=100.0,
            value=30.0,
            step=1.0,
        )
        gunluk_limit = st.number_input(
            "Günlük zarar kilidi (%)",
            min_value=0.50,
            max_value=20.0,
            value=2.0,
            step=0.50,
        )
        haftalik_limit = st.number_input(
            "Haftalık zarar kilidi (%)",
            min_value=1.0,
            max_value=50.0,
            value=4.0,
            step=0.50,
        )
        azami_seri = st.number_input(
            "Azami ardışık zarar",
            min_value=1,
            max_value=20,
            value=3,
            step=1,
        )

    bildirim = st.session_state.pop("islem_gunlugu_bildirimi", None)
    if bildirim:
        st.success(bildirim)

    try:
        tum_kayitlar = depo.list_records()
    except TradeJournalError as hata:
        st.error(str(hata))
        return

    kayitlar = tuple(
        item
        for item in tum_kayitlar
        if hesap_filtresi == "Tümü" or item.account_type == hesap_filtresi
    )
    try:
        politika = SafetyPolicy(
            max_risk_per_trade_pct=float(azami_risk),
            min_reward_risk=float(minimum_rr),
            max_position_pct=float(azami_pozisyon),
            daily_loss_limit_pct=float(gunluk_limit),
            weekly_loss_limit_pct=float(haftalik_limit),
            max_consecutive_losses=int(azami_seri),
        )
        sonuc = analyze_trade_losses(
            kayitlar,
            policy=politika,
            evaluation_date=degerlendirme_tarihi,
        )
    except (ValueError, TypeError) as hata:
        st.error(str(hata))
        return

    # ISLEM_GUNLUGU_V11_ROLE_CLARITY
    # KAYIP_GUVENLIK_V11_ROLE_CLARITY
    st.header("İşlem Kayıp Analizi ve Güvenlik Kilidi")
    st.caption(
        "Tamamlanmış işlem günlüğünü teşhis verisi olarak kullanır; zarar nedenlerini, "
        "günlük/haftalık kayıp bağlamını ve yeni işlem öncesi risk kurallarını tek güvenlik akışında toplar."
    )
    st.info(
        "İşlem Günlüğü kayıt deposudur; Kayıp Analizi geçmiş zararların nedenlerini açıklar; "
        "Güvenlik Kilidi ise yeni işlem teklifini tanımlı risk sınırlarına göre izin/verme kararıyla kontrol eder. "
        "Bu kontrol kazanç garantisi veya alım önerisi değildir."
    )
    st.caption(
        "İşlem Günlüğü ayrı bir canlı pozisyon motoru değildir; tamamlanmış gerçek/deneme işlemlerini "
        "kalıcı olarak saklar ve kayıp analizi, güvenlik kilidi ve performans incelemelerine kanıt sağlar."
    )
    st.info(
        "Gölge Portföy açık/kapalı kağıt pozisyonları yönetir; Haftalık Performans Raporu dönemsel gölge performansını özetler; "
        "bu ekran ise tamamlanmış işlem kayıtları, planlanan risk/getiri, gerçekleşen R, davranış etiketleri ve notları üzerinden kayıp/güvenlik analizi yapar."
    )
    st.info(
        "Analiz yalnızca günlüğe girilen tamamlanmış işlemleri kullanır. Eksik veya "
        "yanlış kayıtlar sonucu değiştirir. Sistem zararları geri kazanmayı veya gelecek "
        "işlemlerde kârı garanti etmez."
    )
    st.markdown("#### İşlem günlüğü ve güvenlik akışı")
    ozet_tab, ekle_tab, csv_tab, kontrol_tab = st.tabs(
        ("Kayıp özeti", "İşlem ekle", "CSV aktarımı", "Yeni işlem ön kontrolü")
    )
    with ozet_tab:
        if not kayitlar:
            st.warning(
                f"{hesap_filtresi} hesabında analiz edilecek tamamlanmış işlem yok. "
                "İşlem ekle veya CSV aktarımı sekmesini kullanın."
            )
        else:
            _kayip_ozeti_goster(sonuc, kayitlar, depo)
    with ekle_tab:
        _islem_kaydi_ekle(depo)
    with csv_tab:
        _islem_csv_araclari(depo, tum_kayitlar)
    with kontrol_tab:
        _yeni_islem_on_kontrolu(sonuc, politika)


def piyasa_rejimi_formu() -> None:
    """XU100, XU030 ve XUTUM için günlük/haftalık piyasa rejimini gösterir."""
    with st.sidebar:
        st.subheader("Piyasa rejimi")
        st.caption(
            "Endeksler için günlük ve haftalık veri zorunludur. "
            "Saatlik veri bulunamazsa analiz durmaz."
        )
        baslat = st.button("Piyasa rejimini analiz et", type="primary")

    st.header("Piyasa Rejimi ve Endeks Analizi")
    st.info(
        "Bu panel kısa vadeli hisse taramasından önce piyasa ortamını "
        "Pozitif, Seçici veya Riskli olarak sınıflandırır. Endeks için "
        "lot, giriş, stop veya hedef üretmez."
    )
    if not baslat:
        st.caption(
            "XU100, XU030 ve XUTUM analizini başlatmak için "
            "sol menüdeki düğmeye basın."
        )
        return

    with st.spinner("Endeks verileri ve piyasa rejimi hesaplanıyor..."):
        try:
            sonuc = MarketRegimeDashboardService().calistir()
        except MarketRegimeDashboardError as hata:
            st.error(str(hata))
            return

    ana = sonuc.ana_rejim
    rejim_baglami = piyasa_rejimi_baglami_olustur(sonuc)
    st.session_state[PIYASA_REJIMI_BAGLAMI_KEY] = (
        rejim_baglami.as_dict()
    )
    if rejim_baglami.gecerli:
        st.session_state["aktif_piyasa_rejimi"] = ana.rejim
    else:
        st.session_state.pop("aktif_piyasa_rejimi", None)
        st.session_state.pop(MOMENTUM_DISCOVERY_RESULT_KEY, None)
        st.session_state.pop(MOMENTUM_DISCOVERY_SIGNATURE_KEY, None)

    if sonuc.eksik_endeksler:
        st.warning(
            "Yardımcı endeks verisi alınamadı: "
            + ", ".join(sonuc.eksik_endeksler)
            + ". BIST 100 ana rejimi kullanılabilir; güven düzeyi "
            "eksik veriyi yansıtır."
        )

    metrik_izgarasi_goster(
        (
            ("BIST 100 rejimi", ana.rejim),
            ("Toplam skor", f"{ana.toplam_skor}/100"),
            ("Güven düzeyi", ana.guven_duzeyi),
            ("Son veri tarihi", tarih_saat_yaz(ana.analiz_tarihi)),
            ("Veri kaynağı", ana.veri_kaynagi),
            ("Kaynak zinciri", " → ".join(ana.kaynak_sirasi)),
            ("Yeniden deneme", str(ana.yeniden_deneme_sayisi)),
            (
                "İndirme süresi",
                f"{ana.toplam_indirme_suresi_saniye:.2f} sn",
            ),
        )
    )

    if rejim_baglami.gecerli:
        st.success(
            "Bu rejim bağlamı Momentum Keşif ekranına güvenli biçimde "
            "aktarılabilir."
        )
    else:
        st.error(
            "Bu rejim Momentum Keşif'e aktarılmadı: "
            + rejim_baglami.gecersizlik_nedeni
        )

    if ana.rejim == REJIM_POZITIF:
        st.success(
            "Kısa vadeli işlem ortamı pozitif; yine de yalnızca detay "
            "teyit alan hisseler değerlendirilmelidir."
        )
    elif ana.rejim == REJIM_SECICI:
        st.warning(
            "Kısa vadeli işlem ortamı seçici; güçlü trend, hacim ve "
            "kırılım teyidi olmayan hisseler elenmelidir."
        )
    else:
        st.error(
            "Kısa vadeli işlem ortamı riskli; yeni pozisyonlar için "
            "korumacı yaklaşım gerekir."
        )

    tablo = [
        {
            "Endeks": f"{item.sembol} · {item.ad}",
            "Kaynak": item.yahoo_sembolu,
            "Veri durumu": (
                "Güncel" if not item.veri_tazeligi.kilitli else "Kilitli"
            ),
            "Skor": item.toplam_skor,
            "Rejim": item.rejim,
            "Güven": item.guven_duzeyi,
            "Günlük": item.gunluk_yon,
            "Haftalık": item.haftalik_yon,
            "Saatlik": (
                item.saatlik_yon
                if item.saatlik_kullanilabilir
                else "Veri yok — analiz sürdü"
            ),
            "Veri tarihi": tarih_saat_yaz(item.analiz_tarihi),
        }
        for item in sonuc.sonuclar
    ]
    st.dataframe(pd.DataFrame(tablo), width="stretch", hide_index=True)

    secili = st.selectbox(
        "Endeks ayrıntısı",
        options=[item.sembol for item in sonuc.sonuclar],
        format_func=lambda kod: next(
            f"{x.sembol} · {x.ad}"
            for x in sonuc.sonuclar
            if x.sembol == kod
        ),
    )
    item = next(x for x in sonuc.sonuclar if x.sembol == secili)

    bilesenler = (
        item.trend,
        item.momentum,
        item.hacim,
        item.kirilim,
        item.genislik,
    )
    for baslangic in range(0, len(bilesenler), 2):
        sutunlar = st.columns(2)
        for sutun, bilesen in zip(
            sutunlar,
            bilesenler[baslangic : baslangic + 2],
        ):
            sutun.metric(
                bilesen.ad,
                f"{bilesen.skor}/{bilesen.maksimum_skor}",
                bilesen.durum,
            )

    veri_durumu = (
        "Güncel" if not item.veri_tazeligi.kilitli else "Kilitli"
    )
    st.markdown("### Veri güvenliği")
    st.caption(
        f"Kaynak: {item.yahoo_sembolu} · "
        f"Son veri: {tarih_saat_yaz(item.analiz_tarihi)} · "
        f"Durum: {veri_durumu} · "
        f"Güven: {item.guven_duzeyi}"
    )
    if item.veri_tazeligi.kilitli:
        st.error(item.veri_tazeligi.aciklama)
    else:
        st.success(item.veri_tazeligi.aciklama)

    with st.expander("Olumlu gerekçeler", expanded=True):
        if item.pozitif_nedenler:
            for metin in item.pozitif_nedenler:
                st.markdown(f"- {metin}")
        else:
            st.write("Belirgin olumlu gerekçe yok.")

    with st.expander("Riskler ve eksik teyitler", expanded=True):
        if item.riskler:
            for metin in item.riskler:
                st.markdown(f"- {metin}")
        else:
            st.write("Belirgin risk kaydı yok.")


def _temel_deger_yaz(deger: object) -> str:
    if deger is None:
        return "Hesaplanamadı"
    try:
        return f"{float(deger):,.2f}"
    except (TypeError, ValueError):
        return str(deger)


def _temel_yuzde_yaz(deger: object) -> str:
    if deger is None:
        return "Hesaplanamadı"
    return f"%{float(deger):,.2f}"


def _buyume_tablosu(snapshot) -> pd.DataFrame:
    satirlar: list[dict[str, object]] = []

    for baslik, buyume in (
        ("Önceki çeyrek", snapshot.quarter_growth),
        ("Geçen yıl aynı dönem", snapshot.annual_growth),
    ):
        if buyume is None:
            continue
        satirlar.extend(
            (
                {
                    "Karşılaştırma": baslik,
                    "Gösterge": "Hasılat",
                    "Değişim (%)": buyume.revenue_growth,
                },
                {
                    "Karşılaştırma": baslik,
                    "Gösterge": "FAVÖK",
                    "Değişim (%)": buyume.ebitda_growth,
                },
                {
                    "Karşılaştırma": baslik,
                    "Gösterge": "Net kâr",
                    "Değişim (%)": buyume.net_income_growth,
                },
                {
                    "Karşılaştırma": baslik,
                    "Gösterge": "Özsermaye",
                    "Değişim (%)": buyume.equity_growth,
                },
                {
                    "Karşılaştırma": baslik,
                    "Gösterge": "Faaliyet nakit akışı",
                    "Değişim (%)": (
                        buyume.operating_cash_flow_growth
                    ),
                },
            )
        )

    return pd.DataFrame(satirlar)


def _donem_grafigi(periods) -> pd.DataFrame:
    satirlar = []
    for item in sorted(periods, key=lambda value: value.period_end):
        satirlar.append(
            {
                "Dönem": item.period_key,
                "Hasılat": float(item.revenue),
                "FAVÖK": float(item.ebitda),
                "Net kâr": float(item.net_income),
                "Özsermaye": float(item.total_equity),
            }
        )

    if not satirlar:
        return pd.DataFrame()

    return pd.DataFrame(satirlar).set_index("Dönem")


def temel_analiz_formu() -> None:
    # TEMEL_ANALIZ_V11_ROLE_CLARITY
    st.header("Temel Analiz — Finansal Sağlık ve Kalite İncelemesi")
    st.caption(
        "Şirketin bilanço kalitesi, büyüme, kârlılık, borçluluk, likidite ve nakit akışı "
        "görünümünü dönemsel ve sektör bağlamında inceler."
    )
    st.info(
        "Bu ekran teknik giriş zamanlaması veya AL/SAT kararı üretmez. "
        "Fırsat Radarı aday bulur; Güncel Teknik Analiz teknik teyidi derinleştirir; "
        "Temel Analiz ise finansal kalite ve sürdürülebilirliği değerlendirir."
    )
    st.caption(
        "Okuma sırası: Veri tazeliği → Temel kalite skoru → Finansal oranlar → "
        "Sektör karşılaştırması → Skor geçmişi → Rapor ve arşiv."
    )
    st.header("Temel Analiz ve Bilanço")
    st.caption(
        "Şirket finansallarını dönemsel olarak karşılaştırır. "
        "Bu ekran teknik taramaya zorunlu filtre uygulamaz."
    )

    ayar_deposu = FundamentalSettingsJsonStore()
    try:
        temel_ayarlar = ayar_deposu.load()
    except FundamentalSettingsError as hata:
        st.warning(
            f"Temel analiz ayarları okunamadı: {hata}"
        )
        temel_ayarlar = FundamentalAnalysisSettings()

    with st.expander(
        "Temel analiz ayarları",
        expanded=False,
    ):
        st.caption(
            "Bu ayarlar yalnızca temel analiz, sektör "
            "karşılaştırması ve temel rapor arşivini etkiler."
        )
        ayar_sol, ayar_orta, ayar_sag = st.columns(3)
        with ayar_sol:
            guclu_esigi = st.number_input(
                "Güçlü alt sınırı",
                min_value=0,
                max_value=100,
                value=temel_ayarlar.strong_threshold,
                step=1,
                key="temel_ayar_guclu",
            )
            dengeli_esigi = st.number_input(
                "Dengeli alt sınırı",
                min_value=0,
                max_value=100,
                value=temel_ayarlar.balanced_threshold,
                step=1,
                key="temel_ayar_dengeli",
            )
            izlenmeli_esigi = st.number_input(
                "İzlenmeli alt sınırı",
                min_value=0,
                max_value=100,
                value=temel_ayarlar.watch_threshold,
                step=1,
                key="temel_ayar_izlenmeli",
            )
        with ayar_orta:
            asgari_sektor_sirketi = st.number_input(
                "Sektör için asgari şirket",
                min_value=2,
                max_value=50,
                value=temel_ayarlar.minimum_sector_company_count,
                step=1,
                key="temel_ayar_asgari_sektor",
            )
            sektor_degisim_esigi = st.number_input(
                "Sektör değişim eşiği",
                min_value=0.1,
                max_value=25.0,
                value=float(
                    temel_ayarlar.sector_change_threshold
                ),
                step=0.5,
                key="temel_ayar_sektor_degisim",
            )
        with ayar_sag:
            skor_gecmis_yasi = st.number_input(
                "Skor geçmişi azami gün",
                min_value=30,
                max_value=3650,
                value=(
                    temel_ayarlar
                    .score_history_maximum_age_days
                ),
                step=30,
                key="temel_ayar_skor_yasi",
            )
            rapor_arsiv_yasi = st.number_input(
                "Rapor arşivi azami gün",
                min_value=30,
                max_value=3650,
                value=(
                    temel_ayarlar
                    .report_archive_maximum_age_days
                ),
                step=30,
                key="temel_ayar_rapor_yasi",
            )

        siralama_etiketleri = {
            "Dönem · yeni → eski": "period_desc",
            "Dönem · eski → yeni": "period_asc",
            "Oluşturulma · yeni → eski": "created_desc",
            "Oluşturulma · eski → yeni": "created_asc",
            "Temel skor · yüksek → düşük": "score_desc",
            "Temel skor · düşük → yüksek": "score_asc",
        }
        mevcut_siralama_etiketi = next(
            (
                label
                for label, value in siralama_etiketleri.items()
                if value == temel_ayarlar.default_archive_sort
            ),
            "Dönem · yeni → eski",
        )
        varsayilan_arsiv_siralama = st.selectbox(
            "Varsayılan arşiv sıralaması",
            options=tuple(siralama_etiketleri),
            index=tuple(siralama_etiketleri).index(
                mevcut_siralama_etiketi
            ),
            key="temel_ayar_arsiv_siralama",
        )

        kaydet_sol, sifirla_sag = st.columns(2)
        with kaydet_sol:
            ayarlari_kaydet = st.button(
                "Temel analiz ayarlarını kaydet",
                key="temel_ayar_kaydet",
                width="stretch",
            )
        with sifirla_sag:
            varsayilana_don = st.button(
                "Varsayılan ayarlara dön",
                key="temel_ayar_sifirla",
                width="stretch",
            )

        if ayarlari_kaydet:
            try:
                temel_ayarlar = ayar_deposu.save(
                    FundamentalAnalysisSettings(
                        strong_threshold=int(guclu_esigi),
                        balanced_threshold=int(dengeli_esigi),
                        watch_threshold=int(izlenmeli_esigi),
                        minimum_sector_company_count=int(
                            asgari_sektor_sirketi
                        ),
                        sector_change_threshold=float(
                            sektor_degisim_esigi
                        ),
                        score_history_maximum_age_days=int(
                            skor_gecmis_yasi
                        ),
                        report_archive_maximum_age_days=int(
                            rapor_arsiv_yasi
                        ),
                        default_archive_sort=siralama_etiketleri[
                            varsayilan_arsiv_siralama
                        ],
                    )
                )
            except FundamentalSettingsError as hata:
                st.error(
                    f"Temel analiz ayarları kaydedilemedi: {hata}"
                )
            else:
                st.success("Temel analiz ayarları kaydedildi.")

        if varsayilana_don:
            temel_ayarlar = ayar_deposu.reset()
            st.success(
                "Temel analiz ayarları varsayılan değerlere "
                "döndürüldü."
            )

    kap_api_durumu = validate_kap_api_configuration(
        load_kap_api_configuration()
    )

    st.subheader("KAP API erişim durumu")
    metrik_izgarasi_goster(
        (
            (
                "Erişim modu",
                kap_api_durumu.configuration.mode.value,
            ),
            (
                "API adresi",
                (
                    kap_api_durumu.configuration.base_url
                    or "Tanımlı değil"
                ),
            ),
            (
                "İstemci",
                kap_api_durumu.configuration.masked_client_id,
            ),
            (
                "Canlı güncelleme",
                (
                    "Hazır"
                    if not kap_api_durumu.locked
                    else "Kilitli"
                ),
            ),
        )
    )

    if kap_api_durumu.locked:
        st.warning(kap_api_durumu.explanation)
        if kap_api_durumu.missing_fields:
            st.caption(
                "Eksik yapılandırma: "
                + ", ".join(kap_api_durumu.missing_fields)
            )
    else:
        st.success(kap_api_durumu.explanation)

    st.caption(
        "API anahtarı ve istemci bilgileri ekranda gösterilmez "
        "ve proje dosyalarına kaydedilmez."
    )
    st.info(
        "Canlı KAP veri çekme bu aşamada devre dışıdır. "
        "Manuel CSV/JSON bilanço yükleme yolu aktiftir."
    )

    yuklenen = st.file_uploader(
        "Bilanço dosyası",
        type=("csv", "json"),
        accept_multiple_files=False,
        key="temel_analiz_dosyasi",
        help=(
            "Sprint-54 bilanço şemasına uygun CSV veya JSON "
            "dosyası yükleyin."
        ),
    )

    if yuklenen is None:
        st.info(
            "Analiz için CSV veya JSON bilanço dosyası yükleyin. "
            "Örnek dosya: backend/data/fundamental_sample.csv"
        )
        return

    try:
        uzanti = Path(yuklenen.name).suffix.lower()
        icerik = yuklenen.getvalue()

        if uzanti == ".csv":
            donemler = periods_from_csv_bytes(icerik)
        elif uzanti == ".json":
            donemler = periods_from_json_bytes(icerik)
        else:
            raise FundamentalDataError(
                "Bilanço dosyası CSV veya JSON olmalıdır."
            )
    except (
        FundamentalDataError,
        ValueError,
        TypeError,
        UnicodeError,
    ) as hata:
        st.error(f"Bilanço dosyası doğrulanamadı: {hata}")
        return

    semboller = sorted({item.symbol for item in donemler})
    sembol = st.selectbox(
        "Şirket",
        options=semboller,
        key="temel_analiz_sembol",
    )
    sirket_donemleri = [
        item for item in donemler if item.symbol == sembol
    ]

    tazelik = evaluate_fundamental_freshness(sirket_donemleri)
    if tazelik.locked:
        st.error(tazelik.explanation)
    else:
        st.success(tazelik.explanation)

    metrik_izgarasi_goster(
        (
            ("Finansal dönem", str(len(sirket_donemleri))),
            (
                "Son dönem",
                (
                    tarih_saat_yaz(tazelik.latest_period_end)
                    if tazelik.latest_period_end is not None
                    else "Yok"
                ),
            ),
            ("Tazelik durumu", tazelik.status),
            (
                "Veri yaşı",
                (
                    f"{tazelik.age_days} gün"
                    if tazelik.age_days is not None
                    else "Bilinmiyor"
                ),
            ),
        )
    )

    if tazelik.locked:
        st.warning(
            "Tazelik kilidi nedeniyle temel oranlar ve büyüme "
            "değerlendirmesi üretilmedi."
        )
        return

    try:
        snapshot = build_fundamental_snapshot(
            sirket_donemleri,
            source_metadata={
                "filename": yuklenen.name,
                "record_count": str(len(sirket_donemleri)),
            },
        )
    except (ValueError, TypeError) as hata:
        st.error(f"Temel analiz özeti üretilemedi: {hata}")
        return

    latest = snapshot.latest
    ratios = snapshot.ratios
    kalite = calculate_fundamental_quality(snapshot, tazelik)
    rapor_skor_degisimi = "Önceki dönem verisi yok"
    rapor_sektor_oranlari: tuple[tuple[str, str, str, str], ...] = ()
    rapor_sektor_siralamasi = "Sektör sıralaması üretilemedi"
    rapor_sektor_gucu = "Sektör güç haritası üretilemedi"

    st.subheader("Temel kalite skoru")
    if kalite.locked or kalite.total_score is None:
        st.warning(kalite.explanation)
    else:
        try:
            skor_kayit_sonucu = temel_skor_deposu().save(
                periods=sirket_donemleri,
                score=kalite,
            )
            st.caption(
                "Temel skor yerel depoya kaydedildi · "
                f"eklenen {skor_kayit_sonucu.inserted} · "
                f"güncellenen {skor_kayit_sonucu.updated} · "
                f"değişmeyen {skor_kayit_sonucu.unchanged}."
            )
        except (
            FundamentalScoreStoreError,
            ValueError,
        ) as hata:
            st.warning(f"Temel skor kaydedilemedi: {hata}")

        metrik_izgarasi_goster(
            (
                ("Toplam kalite skoru", f"{kalite.total_score}/100"),
                ("Kalite sınıfı", kalite.grade),
                (
                    "Kârlılık",
                    f"{kalite.profitability.score}/"
                    f"{kalite.profitability.maximum_score}",
                ),
                (
                    "Büyüme",
                    f"{kalite.growth.score}/"
                    f"{kalite.growth.maximum_score}",
                ),
                (
                    "Borçluluk",
                    f"{kalite.leverage.score}/"
                    f"{kalite.leverage.maximum_score}",
                ),
                (
                    "Likidite",
                    f"{kalite.liquidity.score}/"
                    f"{kalite.liquidity.maximum_score}",
                ),
                (
                    "Nakit akışı",
                    f"{kalite.cash_flow.score}/"
                    f"{kalite.cash_flow.maximum_score}",
                ),
            )
        )
        st.caption(kalite.explanation)

    st.subheader("Temel skor geçmişi")
    try:
        skor_gecmisi = temel_skor_deposu().load_history(
            latest.symbol,
            maximum_age_days=(
                temel_ayarlar.score_history_maximum_age_days
            ),
        )
    except FundamentalScoreStoreError as hata:
        st.warning(f"Temel skor geçmişi okunamadı: {hata}")
        skor_gecmisi = ()

    if not skor_gecmisi:
        st.info(
            "Bu şirket için kayıtlı temel skor geçmişi bulunmuyor."
        )
    else:
        gecmis_tablosu = pd.DataFrame(
            history_rows(skor_gecmisi)
        )
        st.dataframe(
            gecmis_tablosu,
            width="stretch",
            hide_index=True,
        )

        skor_grafigi = gecmis_tablosu.set_index("Dönem")[
            [
                "Toplam skor",
                "Kârlılık",
                "Büyüme",
                "Borçluluk",
                "Likidite",
                "Nakit akışı",
            ]
        ]
        st.line_chart(
            skor_grafigi,
            width="stretch",
        )

        son_degisiklik = latest_score_change(skor_gecmisi)
        if son_degisiklik is None:
            st.caption(
                "Skor değişimi için en az iki kayıtlı dönem gerekir."
            )
        else:
            degisim_yonu = (
                "arttı"
                if son_degisiklik.total_change > 0
                else "azaldı"
                if son_degisiklik.total_change < 0
                else "değişmedi"
            )
            rapor_skor_degisimi = (
                f"{son_degisiklik.previous_period} → "
                f"{son_degisiklik.current_period}: "
                f"{son_degisiklik.total_change:+d} puan"
            )
            st.info(
                f"Toplam temel skor "
                f"{son_degisiklik.previous_period} → "
                f"{son_degisiklik.current_period} döneminde "
                f"{abs(son_degisiklik.total_change)} puan "
                f"{degisim_yonu}."
            )
            if son_degisiklik.improving_components:
                st.caption(
                    "Güçlenen bileşenler: "
                    + ", ".join(
                        son_degisiklik.improving_components
                    )
                )
            if son_degisiklik.weakening_components:
                st.caption(
                    "Zayıflayan bileşenler: "
                    + ", ".join(
                        son_degisiklik.weakening_components
                    )
                )

    st.subheader("Şirket bazlı temel skor karşılaştırması")
    try:
        karsilastirilabilir_skorlar = (
            temel_skor_deposu().load_comparable_latest()
        )
    except FundamentalScoreStoreError as hata:
        st.warning(
            f"Şirket karşılaştırması okunamadı: {hata}"
        )
        karsilastirilabilir_skorlar = ()

    if len(karsilastirilabilir_skorlar) < 2:
        st.info(
            "Aynı güncel döneme ait en az iki şirket skoru "
            "bulunduğunda karşılaştırma tablosu gösterilir."
        )
    else:
        st.dataframe(
            pd.DataFrame(
                comparison_rows(karsilastirilabilir_skorlar)
            ),
            width="stretch",
            hide_index=True,
        )
        st.caption(
            "Şirket karşılaştırması yalnızca aynı güncel bilanço "
            "dönemindeki kayıtları kullanır ve alım/satım sinyali "
            "üretmez."
        )

    st.subheader("Finansal oran ve sektör referansı")
    st.caption(
        "Sektör karşılaştırması yalnızca yüklenen bilanço "
        "verileri ile kullanıcı tarafından sağlanan sektör "
        "referansını kullanır."
    )

    sektor_dosyasi = st.file_uploader(
        "Sektör referans dosyası",
        type=("csv",),
        accept_multiple_files=False,
        key="temel_analiz_sektor_referansi",
        help=(
            "Zorunlu sütunlar: symbol, sector. "
            "F/K ve PD/DD için isteğe bağlı market_cap "
            "sütunu kullanılabilir."
        ),
    )

    if sektor_dosyasi is None:
        st.info(
            "Sektör medyanı karşılaştırması için CSV referans "
            "dosyası yükleyin. Sektör veya piyasa değeri "
            "tahmin edilmez."
        )
    else:
        try:
            sektor_referanslari = references_from_csv_bytes(
                sektor_dosyasi.getvalue()
            )
            oran_referanslari = (
                build_company_ratio_references(
                    donemler,
                    sektor_referanslari,
                )
            )
            sektor_karsilastirmasi = (
                compare_company_to_sector(
                    oran_referanslari,
                    latest.symbol,
                )
            )
        except (
            SectorReferenceError,
            ValueError,
            TypeError,
            UnicodeError,
        ) as hata:
            st.warning(
                f"Sektör karşılaştırması üretilemedi: {hata}"
            )
        else:
            rapor_sektor_oranlari = tuple(
                (
                    str(row["Finansal oran"]),
                    str(row["Şirket"]),
                    str(row["Sektör medyanı"]),
                    str(row["Konum"]),
                )
                for row in sector_comparison_rows(
                    sektor_karsilastirmasi
                )
            )
            metrik_izgarasi_goster(
                (
                    (
                        "Şirket",
                        sektor_karsilastirmasi.symbol,
                    ),
                    (
                        "Sektör",
                        sektor_karsilastirmasi.sector,
                    ),
                    (
                        "Karşılaştırma dönemi",
                        sektor_karsilastirmasi.period_key,
                    ),
                    (
                        "Aynı dönem şirket sayısı",
                        str(sektor_karsilastirmasi.peer_count),
                    ),
                )
            )
            st.dataframe(
                pd.DataFrame(
                    sector_comparison_rows(
                        sektor_karsilastirmasi
                    )
                ),
                width="stretch",
                hide_index=True,
                column_config={
                    "Şirket": st.column_config.NumberColumn(
                        "Şirket",
                        format="%.2f",
                    ),
                    "Sektör medyanı": (
                        st.column_config.NumberColumn(
                            "Sektör medyanı",
                            format="%.2f",
                        )
                    ),
                },
            )
            st.caption(
                "F/K ve PD/DD yalnızca market_cap sağlandığında "
                "hesaplanır. Oran konumu tek başına olumlu veya "
                "olumsuz kabul edilmez ve alım/satım sinyali "
                "üretmez."
            )

            st.subheader(
                "Sektör bazlı temel skor sıralaması"
            )
            st.caption(
                "Sıralama yalnızca aynı güncel bilanço "
                "dönemindeki kayıtlı ve kilitsiz temel skorları "
                "kullanır."
            )

            siralama_sektoru = st.selectbox(
                "Sıralanacak sektör",
                options=sorted(
                    {
                        reference.sector
                        for reference in (
                            sektor_referanslari.values()
                        )
                    }
                ),
                index=(
                    sorted(
                        {
                            reference.sector
                            for reference in (
                                sektor_referanslari.values()
                            )
                        }
                    ).index(
                        sektor_karsilastirmasi.sector
                    )
                    if sektor_karsilastirmasi.sector
                    in {
                        reference.sector
                        for reference in (
                            sektor_referanslari.values()
                        )
                    }
                    else 0
                ),
                key="temel_skor_sektor_siralamasi",
            )

            try:
                sektor_skor_siralamasi = (
                    build_sector_score_ranking(
                        karsilastirilabilir_skorlar,
                        sektor_referanslari,
                        siralama_sektoru,
                        minimum_peer_count=(
                            temel_ayarlar
                            .minimum_sector_company_count
                        ),
                        strong_threshold=(
                            temel_ayarlar.strong_threshold
                        ),
                        balanced_threshold=(
                            temel_ayarlar.balanced_threshold
                        ),
                        watch_threshold=(
                            temel_ayarlar.watch_threshold
                        ),
                    )
                )
            except SectorScoreRankingError as hata:
                st.info(
                    f"Sektör temel skor sıralaması "
                    f"oluşturulamadı: {hata}"
                )
            else:
                siralama_kaydi = next(
                    (
                        item
                        for item in sektor_skor_siralamasi.items
                        if item.symbol == latest.symbol
                    ),
                    None,
                )
                if siralama_kaydi is not None:
                    rapor_sektor_siralamasi = (
                        f"{siralama_kaydi.rank}/"
                        f"{sektor_skor_siralamasi.peer_count} · "
                        f"{siralama_kaydi.quality_class} · "
                        f"{siralama_kaydi.relative_position}"
                    )
                metrik_izgarasi_goster(
                    (
                        (
                            "Sektör",
                            sektor_skor_siralamasi.sector,
                        ),
                        (
                            "Dönem",
                            sektor_skor_siralamasi.period_key,
                        ),
                        (
                            "Şirket sayısı",
                            str(
                                sektor_skor_siralamasi.peer_count
                            ),
                        ),
                        (
                            "Sektör medyanı",
                            f"{sektor_skor_siralamasi.sector_median:.1f}",
                        ),
                    )
                )
                st.dataframe(
                    pd.DataFrame(
                        sector_score_ranking_rows(
                            sektor_skor_siralamasi
                        )
                    ),
                    width="stretch",
                    hide_index=True,
                )
                st.caption(
                    "Güçlü, Dengeli, İzlenmeli ve Zayıf "
                    "sınıfları temel kalite skorunu özetler. "
                    "Bu sıralama tek başına alım/satım sinyali "
                    "üretmez."
                )

            st.subheader("Sektör güç haritası")
            st.caption(
                "Güç haritası aynı güncel bilanço dönemindeki "
                "sektör medyanlarını ve önceki dönem değişimini "
                "karşılaştırır."
            )
            try:
                tum_gecerli_skorlar = (
                    temel_skor_deposu().load_all_valid_scores()
                )
                sektor_guc_haritasi = build_sector_strength_map(
                    tum_gecerli_skorlar,
                    sektor_referanslari,
                    minimum_company_count=(
                        temel_ayarlar
                        .minimum_sector_company_count
                    ),
                    strong_threshold=(
                        temel_ayarlar.strong_threshold
                    ),
                    balanced_threshold=(
                        temel_ayarlar.balanced_threshold
                    ),
                    watch_threshold=(
                        temel_ayarlar.watch_threshold
                    ),
                    change_threshold=(
                        temel_ayarlar.sector_change_threshold
                    ),
                )
            except (
                FundamentalScoreStoreError,
                SectorStrengthMapError,
            ) as hata:
                st.info(
                    f"Sektör güç haritası oluşturulamadı: {hata}"
                )
            else:
                sektor_adi = sektor_karsilastirmasi.sector
                guc_kaydi = next(
                    (
                        item
                        for item in sektor_guc_haritasi.items
                        if item.sector == sektor_adi
                    ),
                    None,
                )
                if guc_kaydi is not None:
                    rapor_sektor_gucu = (
                        f"{guc_kaydi.rank}/"
                        f"{sektor_guc_haritasi.sector_count} · "
                        f"medyan {guc_kaydi.median_score:.1f} · "
                        f"{guc_kaydi.direction}"
                    )
                metrik_izgarasi_goster(
                    (
                        (
                            "Güncel dönem",
                            sektor_guc_haritasi.current_period_key,
                        ),
                        (
                            "Önceki dönem",
                            sektor_guc_haritasi.previous_period_key
                            or "Yok",
                        ),
                        (
                            "Karşılaştırılan sektör",
                            str(sektor_guc_haritasi.sector_count),
                        ),
                        (
                            "Asgari şirket sayısı",
                            "3",
                        ),
                    )
                )
                st.dataframe(
                    pd.DataFrame(
                        sector_strength_rows(
                            sektor_guc_haritasi
                        )
                    ),
                    width="stretch",
                    hide_index=True,
                )
                st.bar_chart(
                    pd.DataFrame(
                        sector_strength_rows(
                            sektor_guc_haritasi
                        )
                    ).set_index("Sektör")[
                        ["Medyan skor", "Ortalama skor"]
                    ],
                    width="stretch",
                )
                st.caption(
                    "Güçleniyor, Yatay ve Zayıflıyor ifadeleri "
                    "dönemsel temel skor değişimini gösterir. "
                    "Sektör güç haritası tek başına alım/satım "
                    "sinyali üretmez."
                )

    st.subheader(f"{latest.symbol} · {latest.period_key}")
    st.caption(
        f"Dönem sonu: {tarih_saat_yaz(latest.period_end)} · "
        f"Para birimi: {latest.currency} · "
        f"Kaynak: {latest.source}"
    )

    metrik_izgarasi_goster(
        (
            ("Hasılat", _temel_deger_yaz(latest.revenue)),
            ("FAVÖK", _temel_deger_yaz(latest.ebitda)),
            ("Net kâr", _temel_deger_yaz(latest.net_income)),
            ("Özsermaye", _temel_deger_yaz(latest.total_equity)),
        )
    )

    st.subheader("Kârlılık ve finansal yapı")
    oran_tablosu = pd.DataFrame(
        (
            {
                "Gösterge": "Brüt kâr marjı",
                "Değer": _temel_yuzde_yaz(ratios.gross_margin),
            },
            {
                "Gösterge": "Faaliyet kâr marjı",
                "Değer": _temel_yuzde_yaz(
                    ratios.operating_margin
                ),
            },
            {
                "Gösterge": "FAVÖK marjı",
                "Değer": _temel_yuzde_yaz(ratios.ebitda_margin),
            },
            {
                "Gösterge": "Net kâr marjı",
                "Değer": _temel_yuzde_yaz(ratios.net_margin),
            },
            {
                "Gösterge": "ROE",
                "Değer": _temel_yuzde_yaz(ratios.roe),
            },
            {
                "Gösterge": "ROA",
                "Değer": _temel_yuzde_yaz(ratios.roa),
            },
            {
                "Gösterge": "Cari oran",
                "Değer": _temel_deger_yaz(ratios.current_ratio),
            },
            {
                "Gösterge": "Borç / özsermaye",
                "Değer": _temel_deger_yaz(
                    ratios.debt_to_equity
                ),
            },
            {
                "Gösterge": "Net borç",
                "Değer": _temel_deger_yaz(ratios.net_debt),
            },
            {
                "Gösterge": "Net borç / FAVÖK",
                "Değer": _temel_deger_yaz(
                    ratios.net_debt_to_ebitda
                ),
            },
            {
                "Gösterge": "Serbest nakit akışı",
                "Değer": _temel_deger_yaz(
                    ratios.free_cash_flow
                ),
            },
            {
                "Gösterge": "Serbest nakit akışı marjı",
                "Değer": _temel_yuzde_yaz(
                    ratios.free_cash_flow_margin
                ),
            },
        )
    )
    st.dataframe(
        oran_tablosu,
        width="stretch",
        hide_index=True,
    )

    grafik = _donem_grafigi(sirket_donemleri)
    if not grafik.empty:
        st.subheader("Dönemsel gelişim")
        st.line_chart(grafik, width="stretch")

    buyume = _buyume_tablosu(snapshot)
    st.subheader("Dönem karşılaştırmaları")
    if buyume.empty:
        st.info(
            "Önceki çeyrek veya geçen yıl aynı dönem verisi "
            "bulunmadığı için büyüme karşılaştırması üretilemedi."
        )
    else:
        st.dataframe(
            buyume,
            width="stretch",
            hide_index=True,
            column_config={
                "Değişim (%)": st.column_config.NumberColumn(
                    "Değişim (%)",
                    format="%.2f",
                )
            },
        )

    st.subheader("Finansal kalite uyarıları")
    if snapshot.quality_flags:
        for uyari in snapshot.quality_flags:
            st.warning(uyari)
    else:
        st.success(
            "Tanımlı temel analiz kurallarına göre belirgin "
            "finansal kalite uyarısı bulunmadı."
        )

    st.subheader("Temel analiz özet raporu")
    st.caption(
        "Rapor güncel temel kalite skorunu, finansal oranları, "
        "dönemsel değişimi ve varsa sektör karşılaştırmalarını "
        "bir araya getirir."
    )
    try:
        temel_rapor = FundamentalReport(
            symbol=latest.symbol,
            period_key=latest.period_key,
            period_end=latest.period_end,
            currency=latest.currency,
            source=latest.source,
            freshness_status=tazelik.status,
            age_days=tazelik.age_days,
            total_score=kalite.total_score,
            grade=kalite.grade,
            component_scores=(
                ("Kârlılık", kalite.profitability.score, kalite.profitability.maximum_score),
                ("Büyüme", kalite.growth.score, kalite.growth.maximum_score),
                ("Borçluluk", kalite.leverage.score, kalite.leverage.maximum_score),
                ("Likidite", kalite.liquidity.score, kalite.liquidity.maximum_score),
                ("Nakit akışı", kalite.cash_flow.score, kalite.cash_flow.maximum_score),
            ),
            score_change=rapor_skor_degisimi,
            ratio_rows=tuple(
                (str(row["Gösterge"]), str(row["Değer"]))
                for row in oran_tablosu.to_dict("records")
            ),
            sector_ratio_rows=rapor_sektor_oranlari,
            sector_ranking=rapor_sektor_siralamasi,
            sector_strength=rapor_sektor_gucu,
            quality_flags=tuple(snapshot.quality_flags),
            generated_at=datetime.now(timezone.utc),
        )
        rapor_csv = fundamental_report_csv_bytes(temel_rapor)
        rapor_pdf = fundamental_report_pdf_bytes(temel_rapor)
        csv_adi, pdf_adi = fundamental_report_file_names(temel_rapor)
    except (FundamentalReportError, ValueError, TypeError) as hata:
        st.warning(f"Temel analiz raporu üretilemedi: {hata}")
    else:
        rapor_sutunlari = st.columns(2)
        with rapor_sutunlari[0]:
            st.download_button(
                "Temel analiz CSV indir",
                data=rapor_csv,
                file_name=csv_adi,
                mime="text/csv",
                key="temel_analiz_csv_indir",
                width="stretch",
            )
        with rapor_sutunlari[1]:
            st.download_button(
                "Temel analiz PDF indir",
                data=rapor_pdf,
                file_name=pdf_adi,
                mime="application/pdf",
                key="temel_analiz_pdf_indir",
                width="stretch",
            )
        st.caption(
            "Eksik sektör verileri raporda açıkça belirtilir. "
            "Rapor yatırım danışmanlığı veya alım/satım tavsiyesi "
            "değildir."
        )

        st.subheader("Temel analiz rapor arşivi")
        try:
            rapor_arsivi = FundamentalReportJsonArchive()
            arsiv_kayit_sonucu = rapor_arsivi.save(temel_rapor)
            arsiv_raporlari = rapor_arsivi.list_symbol(
                temel_rapor.symbol
            )
        except FundamentalReportArchiveError as hata:
            st.warning(
                f"Temel analiz rapor arşivi kullanılamadı: {hata}"
            )
        else:
            st.caption(
                "Temel rapor yerel arşive işlendi · "
                f"eklenen {arsiv_kayit_sonucu.inserted} · "
                f"değişmeyen {arsiv_kayit_sonucu.unchanged}."
            )

            st.subheader("Arşiv arama ve filtreleme")
            try:
                tum_arsiv_raporlari = rapor_arsivi.list_all(
                    maximum_age_days=(
                        temel_ayarlar
                        .report_archive_maximum_age_days
                    )
                )
            except FundamentalReportArchiveError as hata:
                st.warning(
                    f"Arşiv kayıtları okunamadı: {hata}"
                )
                tum_arsiv_raporlari = ()

            filtre_sol, filtre_orta, filtre_sag = st.columns(3)
            with filtre_sol:
                arsiv_sembol_arama = st.text_input(
                    "Şirket sembolü",
                    value=temel_rapor.symbol,
                    key="temel_arsiv_sembol_arama",
                )
                arsiv_baslangic = st.date_input(
                    "Dönem başlangıcı",
                    value=None,
                    key="temel_arsiv_donem_baslangic",
                )
            with filtre_orta:
                arsiv_bitis = st.date_input(
                    "Dönem bitişi",
                    value=None,
                    key="temel_arsiv_donem_bitis",
                )
                arsiv_skor_araligi = st.slider(
                    "Temel skor aralığı",
                    min_value=0,
                    max_value=100,
                    value=(0, 100),
                    key="temel_arsiv_skor_araligi",
                )
            with filtre_sag:
                arsiv_siralama_secenekleri = (
                    "Dönem · yeni → eski",
                    "Dönem · eski → yeni",
                    "Oluşturulma · yeni → eski",
                    "Oluşturulma · eski → yeni",
                    "Temel skor · yüksek → düşük",
                    "Temel skor · düşük → yüksek",
                )
                varsayilan_siralama_esleme = {
                    "period_desc": "Dönem · yeni → eski",
                    "period_asc": "Dönem · eski → yeni",
                    "created_desc": (
                        "Oluşturulma · yeni → eski"
                    ),
                    "created_asc": (
                        "Oluşturulma · eski → yeni"
                    ),
                    "score_desc": (
                        "Temel skor · yüksek → düşük"
                    ),
                    "score_asc": (
                        "Temel skor · düşük → yüksek"
                    ),
                }
                varsayilan_siralama_etiketi = (
                    varsayilan_siralama_esleme[
                        temel_ayarlar.default_archive_sort
                    ]
                )
                arsiv_siralama = st.selectbox(
                    "Sıralama",
                    options=arsiv_siralama_secenekleri,
                    index=arsiv_siralama_secenekleri.index(
                        varsayilan_siralama_etiketi
                    ),
                    key="temel_arsiv_siralama",
                )

            kalite_secenekleri = sorted(
                {
                    item.report.grade
                    for item in tum_arsiv_raporlari
                }
            )
            kaynak_secenekleri = sorted(
                {
                    item.report.source
                    for item in tum_arsiv_raporlari
                }
            )
            tazelik_secenekleri = sorted(
                {
                    item.report.freshness_status
                    for item in tum_arsiv_raporlari
                }
            )

            ek_filtre_sol, ek_filtre_orta, ek_filtre_sag = (
                st.columns(3)
            )
            with ek_filtre_sol:
                secili_kalite_siniflari = st.multiselect(
                    "Kalite sınıfı",
                    options=kalite_secenekleri,
                    key="temel_arsiv_kalite",
                )
            with ek_filtre_orta:
                secili_kaynaklar = st.multiselect(
                    "Veri kaynağı",
                    options=kaynak_secenekleri,
                    key="temel_arsiv_kaynak",
                )
            with ek_filtre_sag:
                secili_tazelikler = st.multiselect(
                    "Tazelik durumu",
                    options=tazelik_secenekleri,
                    key="temel_arsiv_tazelik",
                )

            siralama_esleme = {
                "Dönem · yeni → eski": "period_desc",
                "Dönem · eski → yeni": "period_asc",
                "Oluşturulma · yeni → eski": "created_desc",
                "Oluşturulma · eski → yeni": "created_asc",
                "Temel skor · yüksek → düşük": "score_desc",
                "Temel skor · düşük → yüksek": "score_asc",
            }

            try:
                filtrelenmis_arsiv_raporlari = (
                    search_archived_reports(
                        tum_arsiv_raporlari,
                        FundamentalReportArchiveFilter(
                            symbol_query=arsiv_sembol_arama,
                            period_start=arsiv_baslangic,
                            period_end=arsiv_bitis,
                            minimum_score=arsiv_skor_araligi[0],
                            maximum_score=arsiv_skor_araligi[1],
                            grades=tuple(
                                secili_kalite_siniflari
                            ),
                            sources=tuple(secili_kaynaklar),
                            freshness_statuses=tuple(
                                secili_tazelikler
                            ),
                            sort_by=siralama_esleme[
                                arsiv_siralama
                            ],
                        ),
                    )
                )
            except FundamentalReportArchiveError as hata:
                st.warning(
                    f"Arşiv filtresi uygulanamadı: {hata}"
                )
                filtrelenmis_arsiv_raporlari = ()

            st.caption(
                f"Filtrelenen rapor sayısı: "
                f"{len(filtrelenmis_arsiv_raporlari)}"
            )
            st.dataframe(
                pd.DataFrame(
                    report_archive_rows(
                        filtrelenmis_arsiv_raporlari
                    )
                ),
                width="stretch",
                hide_index=True,
            )

            if filtrelenmis_arsiv_raporlari:
                arsiv_csv = archived_reports_csv_bytes(
                    filtrelenmis_arsiv_raporlari
                )
                rapor_secim_haritasi = {
                    (
                        f"{item.symbol} · {item.period_key} · "
                        f"{item.report_id}"
                    ): item
                    for item in filtrelenmis_arsiv_raporlari
                }
                toplu_pdf_secimleri = st.multiselect(
                    "Toplu PDF raporları",
                    options=list(rapor_secim_haritasi),
                    default=list(rapor_secim_haritasi)[:10],
                    key="temel_arsiv_toplu_pdf_secimleri",
                )

                disari_sol, disari_sag = st.columns(2)
                with disari_sol:
                    st.download_button(
                        "Filtrelenmiş arşivi CSV indir",
                        data=arsiv_csv,
                        file_name=(
                            "temel_analiz_rapor_arsivi.csv"
                        ),
                        mime="text/csv",
                        key="temel_arsiv_csv_indir",
                        width="stretch",
                    )
                with disari_sag:
                    secili_toplu_raporlar = tuple(
                        rapor_secim_haritasi[label]
                        for label in toplu_pdf_secimleri
                    )
                    if secili_toplu_raporlar:
                        arsiv_pdf = archived_reports_pdf_bytes(
                            secili_toplu_raporlar
                        )
                        st.download_button(
                            "Seçilen raporları PDF indir",
                            data=arsiv_pdf,
                            file_name=(
                                "temel_analiz_rapor_arsivi.pdf"
                            ),
                            mime="application/pdf",
                            key="temel_arsiv_pdf_indir",
                            width="stretch",
                        )
                    else:
                        st.info(
                            "Toplu PDF için en az bir rapor "
                            "seçilmelidir."
                        )

                st.caption(
                    "Arama, filtreleme ve dışa aktarım yalnızca "
                    "arşiv kayıtlarını düzenler; alım/satım "
                    "tavsiyesi üretmez."
                )
            else:
                st.info(
                    "Seçilen filtrelere uygun arşiv raporu "
                    "bulunamadı."
                )

            st.subheader("Şirket rapor geçmişi")
            st.dataframe(
                pd.DataFrame(
                    report_archive_rows(arsiv_raporlari)
                ),
                width="stretch",
                hide_index=True,
            )

            if len(arsiv_raporlari) < 2:
                st.info(
                    "Geçmiş rapor karşılaştırması için aynı "
                    "şirkete ait en az iki uyumlu rapor gerekir."
                )
            else:
                rapor_secimleri = {
                    (
                        f"{item.period_key} · "
                        f"{tarih_saat_yaz(item.period_end)} · "
                        f"{item.report_id}"
                    ): item
                    for item in arsiv_raporlari
                }
                secim_etiketleri = list(rapor_secimleri)

                onceki_etiket = st.selectbox(
                    "Önceki temel rapor",
                    options=secim_etiketleri,
                    index=min(1, len(secim_etiketleri) - 1),
                    key="temel_rapor_arsiv_onceki",
                )
                guncel_etiket = st.selectbox(
                    "Güncel temel rapor",
                    options=secim_etiketleri,
                    index=0,
                    key="temel_rapor_arsiv_guncel",
                )

                try:
                    rapor_karsilastirmasi = (
                        compare_archived_reports(
                            rapor_secimleri[onceki_etiket],
                            rapor_secimleri[guncel_etiket],
                        )
                    )
                except FundamentalReportArchiveError as hata:
                    st.info(
                        f"Rapor karşılaştırması yapılamadı: {hata}"
                    )
                else:
                    st.dataframe(
                        pd.DataFrame(
                            report_comparison_rows(
                                rapor_karsilastirmasi
                            )
                        ),
                        width="stretch",
                        hide_index=True,
                    )
                    st.caption(
                        "Arşiv karşılaştırması toplam ve alt "
                        "skorları, finansal oranları, sektör "
                        "konumunu, kaynak ve tazelik bilgisini "
                        "korur. Alım/satım tavsiyesi üretmez."
                    )



def sinyal_sonuclari_formu() -> None:
    st.subheader("Sinyal Sonuçları — İleri Performans ve Kalibrasyon Kanıtı")
    st.caption(
        "Kaydedilmiş sinyallerin sonraki 5/10/20 işlem günü performansını izler; "
        "bekleyen ve tamamlanan ufukları, başarı özetini ve kalibrasyon kanıtını birleştirir."
    )
    st.info(
        "Kesim tarihinden sonraki fiyatlar yalnızca performans ölçümü için kullanılır; "
        "aday veya sinyal üretiminde kullanılmaz. Bu ekran yeni sinyal veya AL/SAT kararı üretmez."
    )

    store = SignalOutcomeJsonStore()
    (
        automatic_tab,
        input_tab,
        archive_tab,
        contribution_tab,
        walk_forward_tab,
    ) = st.tabs(
        (
            "Otomatik kayıt ve güncelleme",
            "Yeni sonuç ölçümü",
            "Sonuç arşivi",
            "Gösterge katkısı",
            "Walk-forward doğrulama",
        )
    )

    with automatic_tab:
        st.markdown("#### Bekleyen ve tamamlanan sonuç ufukları")
        st.info(
            "Aynı sembol ve sinyal tarihi için ikinci kayıt oluşturulmaz. "
            "5/10/20 günlük sonuçlar yeni fiyat verisi geldikçe güncellenir. "
            "Henüz yeterli işlem günü oluşmamış ufuklar bekleyen olarak kalır."
        )

        auto_left, auto_right = st.columns(2)
        with auto_left:
            auto_symbol = st.text_input(
                "Otomatik kayıt sembolü",
                value="THYAO",
                key="auto_signal_symbol",
            )
            auto_signal_date = st.date_input(
                "Otomatik kayıt sinyal tarihi",
                value=date.today(),
                key="auto_signal_date",
            )
            auto_reference_price = st.number_input(
                "Otomatik kayıt referans fiyatı",
                min_value=0.01,
                value=100.0,
                step=0.01,
                key="auto_signal_reference",
            )
            auto_class = st.selectbox(
                "Otomatik kayıt karar sınıfı",
                options=(
                    "İzlemeye Değer",
                    "Temkinli İzle",
                    "Uygun Değil",
                ),
                key="auto_signal_class",
            )
            auto_quality = st.slider(
                "Otomatik kayıt kalite skoru",
                min_value=0,
                max_value=100,
                value=60,
                key="auto_signal_quality",
            )

        with auto_right:
            auto_daily = st.selectbox(
                "Otomatik kayıt günlük yön",
                options=("Pozitif", "Nötr", "Negatif"),
                key="auto_signal_daily",
            )
            auto_weekly = st.selectbox(
                "Otomatik kayıt haftalık yön",
                options=("Pozitif", "Nötr", "Negatif"),
                key="auto_signal_weekly",
            )
            auto_regime = st.text_input(
                "Otomatik kayıt piyasa rejimi",
                value="",
                key="auto_signal_regime",
            )
            auto_sector = st.text_input(
                "Otomatik kayıt sektör",
                value="",
                key="auto_signal_sector",
            )
            auto_momentum = st.selectbox(
                "Otomatik kayıt momentum",
                options=("", "Pozitif", "Nötr", "Negatif"),
                key="auto_signal_momentum",
            )

        auto_level1, auto_level2, auto_level3 = st.columns(3)
        with auto_level1:
            auto_stop = st.number_input(
                "Otomatik kayıt stop-loss",
                min_value=0.0,
                value=0.0,
                step=0.01,
                key="auto_signal_stop",
            )
        with auto_level2:
            auto_target1 = st.number_input(
                "Otomatik kayıt hedef 1",
                min_value=0.0,
                value=0.0,
                step=0.01,
                key="auto_signal_target1",
            )
        with auto_level3:
            auto_target2 = st.number_input(
                "Otomatik kayıt hedef 2",
                min_value=0.0,
                value=0.0,
                step=0.01,
                key="auto_signal_target2",
            )

        save_col, update_col = st.columns(2)
        with save_col:
            save_clicked = st.button(
                "Sinyali otomatik kaydet",
                type="primary",
                key="auto_signal_save",
                width="stretch",
            )
        with update_col:
            update_clicked = st.button(
                "Tüm sonuçları güncelle",
                key="auto_signal_update_all",
                width="stretch",
            )

        if save_clicked:
            try:
                result = automatic_record_from_values(
                    symbol=auto_symbol,
                    signal_date=auto_signal_date,
                    reference_price=float(auto_reference_price),
                    decision_class=auto_class,
                    quality_score=int(auto_quality),
                    daily_direction=auto_daily,
                    weekly_direction=auto_weekly,
                    market_regime=auto_regime,
                    sector=auto_sector,
                    momentum_state=auto_momentum,
                    stop_loss=auto_stop or None,
                    target_1=auto_target1 or None,
                    target_2=auto_target2 or None,
                    store=store,
                )
            except (
                AutomaticSignalTrackingError,
                SignalOutcomeError,
                ValueError,
                TypeError,
                OSError,
            ) as error:
                st.error(str(error))
            else:
                if result.created:
                    st.success(
                        f"Yeni sinyal kaydedildi: {result.path_name}"
                    )
                elif result.updated:
                    st.success(
                        f"Mevcut sinyal sonucu güncellendi: "
                        f"{result.path_name}"
                    )
                else:
                    st.info(
                        "Aynı sembol ve tarih için kayıt zaten var; "
                        "yeni tamamlanmış ölçüm bulunmadı."
                    )
                st.dataframe(
                    pd.DataFrame(outcome_rows((result.outcome,))),
                    width="stretch",
                    hide_index=True,
                )

        if update_clicked:
            with st.spinner("Kayıtlı sinyal sonuçları güncelleniyor..."):
                summary = update_all_signal_outcomes(store=store)

            metrik_izgarasi_goster(
                (
                    ("Toplam kayıt", str(summary.total_records)),
                    ("Güncellenen", str(summary.updated_records)),
                    ("Değişmeyen", str(summary.unchanged_records)),
                    ("Hata", str(summary.failed_records)),
                    ("Bekleyen ufuk", str(summary.pending_horizons)),
                    ("Tamamlanan ufuk", str(summary.completed_horizons)),
                )
            )
            if summary.errors:
                st.warning("\n".join(summary.errors))
            elif summary.total_records == 0:
                st.info("Güncellenecek sinyal kaydı yok.")
            else:
                st.success("Otomatik sonuç güncellemesi tamamlandı.")


    with input_tab:
        st.info(
            "CSV dosyasında tarih indeksi ile Close, High ve Low "
            "sütunları bulunmalıdır."
        )
        left, right = st.columns(2)
        with left:
            symbol = st.text_input(
                "Sembol",
                value="THYAO",
                key="signal_outcome_symbol",
            )
            signal_date = st.date_input(
                "Sinyal tarihi",
                value=date.today() - timedelta(days=30),
                key="signal_outcome_date",
            )
            reference_price = st.number_input(
                "Referans fiyat",
                min_value=0.01,
                value=100.0,
                step=0.01,
                key="signal_outcome_reference",
            )
            decision_class = st.selectbox(
                "Karar sınıfı",
                options=(
                    "İzlemeye Değer",
                    "Temkinli İzle",
                    "Uygun Değil",
                ),
                key="signal_outcome_class",
            )
            quality_score = st.slider(
                "Kalite skoru",
                min_value=0,
                max_value=100,
                value=60,
                key="signal_outcome_quality",
            )
        with right:
            daily_direction = st.selectbox(
                "Günlük yön",
                options=("Pozitif", "Nötr", "Negatif"),
                key="signal_outcome_daily",
            )
            weekly_direction = st.selectbox(
                "Haftalık yön",
                options=("Pozitif", "Nötr", "Negatif"),
                key="signal_outcome_weekly",
            )
            divergence_type = st.text_input(
                "Uyumsuzluk türü",
                value="",
                key="signal_outcome_divergence",
            )
            market_regime = st.text_input(
                "Piyasa rejimi",
                value="",
                key="signal_outcome_regime",
            )
            sector = st.text_input(
                "Sektör",
                value="",
                key="signal_outcome_sector",
            )
            momentum_state = st.selectbox(
                "Momentum",
                options=("", "Pozitif", "Nötr", "Negatif"),
                key="signal_outcome_momentum",
            )
            volume_choice = st.selectbox(
                "Hacim teyidi",
                options=("Bilinmiyor", "Var", "Yok"),
                key="signal_outcome_volume",
            )

        level1, level2, level3 = st.columns(3)
        with level1:
            stop_loss = st.number_input(
                "Stop-loss (0 = yok)",
                min_value=0.0,
                value=0.0,
                step=0.01,
                key="signal_outcome_stop",
            )
        with level2:
            target_1 = st.number_input(
                "Hedef 1 (0 = yok)",
                min_value=0.0,
                value=0.0,
                step=0.01,
                key="signal_outcome_target1",
            )
        with level3:
            target_2 = st.number_input(
                "Hedef 2 (0 = yok)",
                min_value=0.0,
                value=0.0,
                step=0.01,
                key="signal_outcome_target2",
            )

        metric1, metric2 = st.columns(2)
        with metric1:
            atr_percent = st.number_input(
                "ATR yüzdesi (0 = bilinmiyor)",
                min_value=0.0,
                value=0.0,
                step=0.1,
                key="signal_outcome_atr",
            )
        with metric2:
            risk_reward_ratio = st.number_input(
                "Risk/getiri oranı (0 = bilinmiyor)",
                min_value=0.0,
                value=0.0,
                step=0.1,
                key="signal_outcome_rr",
            )

        uploaded = st.file_uploader(
            "Fiyat CSV dosyası",
            type=("csv",),
            key="signal_outcome_csv",
        )

        if st.button(
            "Sonucu hesapla ve kaydet",
            type="primary",
            key="signal_outcome_calculate",
        ):
            if uploaded is None:
                st.error("Fiyat CSV dosyası seçilmelidir.")
            else:
                try:
                    price_frame = pd.read_csv(
                        uploaded,
                        index_col=0,
                        parse_dates=True,
                    )
                    snapshot = SignalSnapshot(
                        symbol=symbol,
                        signal_date=signal_date,
                        reference_price=float(reference_price),
                        decision_class=decision_class,
                        quality_score=int(quality_score),
                        daily_direction=daily_direction,
                        weekly_direction=weekly_direction,
                        divergence_type=divergence_type,
                        market_regime=market_regime,
                        sector=sector,
                        momentum_state=momentum_state,
                        volume_confirmation=(
                            None
                            if volume_choice == "Bilinmiyor"
                            else volume_choice == "Var"
                        ),
                        atr_percent=atr_percent or None,
                        risk_reward_ratio=risk_reward_ratio or None,
                        stop_loss=stop_loss or None,
                        target_1=target_1 or None,
                        target_2=target_2 or None,
                    )
                    outcome = evaluate_signal(snapshot, price_frame)
                    path = store.save(outcome)
                except (
                    SignalOutcomeError,
                    ValueError,
                    TypeError,
                    OSError,
                ) as error:
                    st.error(str(error))
                else:
                    st.success(
                        f"Sonuç kaydedildi: {path.name}"
                    )
                    st.dataframe(
                        pd.DataFrame(outcome_rows((outcome,))),
                        width="stretch",
                        hide_index=True,
                    )

    with archive_tab:
        st.markdown("#### 5/10/20 işlem günü sonuç arşivi")
        outcomes = store.list()
        if not outcomes:
            st.info("Henüz kaydedilmiş sinyal sonucu yok.")
        else:
            summary_rows = [
                success_summary(outcomes, horizon=horizon)
                for horizon in HORIZONS
            ]
            st.dataframe(
                pd.DataFrame(summary_rows),
                width="stretch",
                hide_index=True,
            )

            rows = outcome_rows(outcomes)
            st.dataframe(
                pd.DataFrame(rows),
                width="stretch",
                hide_index=True,
            )
            st.download_button(
                "Sonuçları CSV indir",
                data=outcomes_to_csv(outcomes),
                file_name="sinyal_sonuclari.csv",
                mime="text/csv",
                key="signal_outcome_download",
                width="stretch",
            )
            st.warning(
                "Başarı oranı tek başına yeterli değildir. Getiri, MFE, "
                "MAE, hedef/stop davranışı ve örnek sayısı birlikte "
                "değerlendirilmelidir."
            )



    with contribution_tab:
        st.markdown("#### Kalibrasyon için gösterge katkı kanıtı")
        outcomes = store.list()
        st.caption(
            "Analiz yalnızca tamamlanmış 5/10/20 işlem günü sonuçlarını "
            "kullanır. Küçük örneklemde kesin katkı sonucu üretmez."
        )
        if not outcomes:
            st.info("Katkı analizi için kayıtlı sinyal sonucu yok.")
        else:
            control1, control2 = st.columns(2)
            with control1:
                selected_horizon = st.selectbox(
                    "Ölçüm ufku",
                    options=HORIZONS,
                    format_func=lambda value: f"{value} işlem günü",
                    key="indicator_contribution_horizon",
                )
            with control2:
                minimum_group_size = st.number_input(
                    "Her grup için minimum örnek",
                    min_value=2,
                    max_value=100,
                    value=5,
                    step=1,
                    key="indicator_contribution_minimum",
                )

            contributions = analyze_indicator_contributions(
                outcomes,
                horizon=int(selected_horizon),
                minimum_group_size=int(minimum_group_size),
            )
            contribution_frame = pd.DataFrame(
                contribution_rows(contributions)
            )
            st.dataframe(
                contribution_frame,
                width="stretch",
                hide_index=True,
            )

            enough_count = sum(
                item.confidence != "Yetersiz örnek"
                for item in contributions
            )
            supportive_count = sum(
                item.confidence == "Destekleyici"
                for item in contributions
            )
            weakening_count = sum(
                item.confidence == "Zayıflatıcı"
                for item in contributions
            )
            metrik_izgarasi_goster(
                (
                    ("Ölçülebilir gösterge", str(enough_count)),
                    ("Destekleyici", str(supportive_count)),
                    ("Zayıflatıcı", str(weakening_count)),
                    (
                        "Yetersiz örnek",
                        str(len(contributions) - enough_count),
                    ),
                )
            )

            redundancy = analyze_redundancy(
                outcomes,
                minimum_sample_size=max(
                    10,
                    int(minimum_group_size) * 2,
                ),
            )
            st.markdown("#### Tekrarlayan gösterge adayları")
            if redundancy:
                st.dataframe(
                    pd.DataFrame(redundancy_rows(redundancy)),
                    width="stretch",
                    hide_index=True,
                )
            else:
                st.info(
                    "Yeterli örnekle doğrulanmış yüksek benzerlikte "
                    "gösterge çifti bulunmadı."
                )

            st.download_button(
                "Gösterge katkı raporunu CSV indir",
                data=contribution_to_csv(contributions),
                file_name=(
                    f"gosterge_katki_{selected_horizon}_gun.csv"
                ),
                mime="text/csv",
                key="indicator_contribution_download",
                width="stretch",
            )
            st.warning(
                "Katkı farkı nedensellik kanıtı değildir. Sonuçlar piyasa "
                "rejimi, sektör, örnek sayısı ve dönem değişimiyle birlikte "
                "yorumlanmalıdır."
            )



    with walk_forward_tab:
        st.markdown("#### Zamansal doğrulama — walk-forward")
        outcomes = store.list()
        st.caption(
            "Kayıtlar sinyal tarihine göre sıralanır. Eğitim dönemi yalnızca "
            "geçmiş kayıtları, doğrulama dönemi ise daha sonraki kayıtları kullanır."
        )
        if not outcomes:
            st.info("Walk-forward doğrulama için kayıtlı sinyal sonucu yok.")
        else:
            control1, control2, control3 = st.columns(3)
            with control1:
                walk_horizon = st.selectbox(
                    "Walk-forward ölçüm ufku",
                    options=HORIZONS,
                    format_func=lambda value: f"{value} işlem günü",
                    key="walk_forward_horizon",
                )
                training_size = st.number_input(
                    "Eğitim penceresi",
                    min_value=10,
                    max_value=1000,
                    value=40,
                    step=5,
                    key="walk_forward_training",
                )
            with control2:
                validation_size = st.number_input(
                    "Doğrulama penceresi",
                    min_value=5,
                    max_value=500,
                    value=15,
                    step=5,
                    key="walk_forward_validation",
                )
                step_size = st.number_input(
                    "Yürüme adımı",
                    min_value=1,
                    max_value=500,
                    value=15,
                    step=1,
                    key="walk_forward_step",
                )
            with control3:
                minimum_training_samples = st.number_input(
                    "Minimum eğitim örneği",
                    min_value=2,
                    max_value=500,
                    value=8,
                    step=1,
                    key="walk_forward_min_training",
                )
                minimum_validation_samples = st.number_input(
                    "Minimum doğrulama örneği",
                    min_value=2,
                    max_value=500,
                    value=4,
                    step=1,
                    key="walk_forward_min_validation",
                )

            if st.button(
                "Walk-forward doğrulamayı çalıştır",
                type="primary",
                key="walk_forward_run",
                width="stretch",
            ):
                try:
                    walk_result = run_walk_forward_calibration(
                        outcomes,
                        horizon=int(walk_horizon),
                        training_size=int(training_size),
                        validation_size=int(validation_size),
                        step_size=int(step_size),
                        minimum_training_samples=int(
                            minimum_training_samples
                        ),
                        minimum_validation_samples=int(
                            minimum_validation_samples
                        ),
                    )
                except WalkForwardCalibrationError as error:
                    st.error(str(error))
                else:
                    accepted_windows = sum(
                        item.accepted for item in walk_result.windows
                    )
                    metrik_izgarasi_goster(
                        (
                            ("Pencere", str(len(walk_result.windows))),
                            (
                                "Kabul edilen",
                                str(accepted_windows),
                            ),
                            (
                                "Kararlı parametre bölgesi",
                                str(len(walk_result.recommended)),
                            ),
                            (
                                "Ölçüm ufku",
                                f"{walk_result.horizon} gün",
                            ),
                        )
                    )

                    st.markdown("#### Walk-forward pencereleri")
                    st.dataframe(
                        pd.DataFrame(window_rows(walk_result)),
                        width="stretch",
                        hide_index=True,
                    )

                    st.markdown("#### Parametre kararlılığı")
                    st.dataframe(
                        pd.DataFrame(aggregate_rows(walk_result)),
                        width="stretch",
                        hide_index=True,
                    )

                    st.download_button(
                        "Kalibrasyon sonuçlarını CSV indir",
                        data=calibration_to_csv(walk_result),
                        file_name=(
                            f"walk_forward_{walk_result.horizon}_gun.csv"
                        ),
                        mime="text/csv",
                        key="walk_forward_download",
                        width="stretch",
                    )
                    st.warning(walk_result.warning)



def gecikmeli_veri_pilotu_formu() -> None:
    st.subheader("Gün İçi Veri Kalitesi")
    st.caption(
        "Gecikmeli Veri Pilotu · yfinance gün içi verisi yalnızca veri kalitesi, "
        "gecikme ve eksik bar ölçümü için kullanılır. "
        "Gün içi gecikmeli veri kesin işlem sinyali değildir. "
        "Ön izleme — işlem sinyali değildir."
    )
    st.info(
        "Bu ekran aday seçmez ve alım/satım kararı üretmez. "
        "Amaç, gün içi verinin ne kadar güncel ve kullanılabilir olduğunu göstermektir."
    )

    control1, control2, control3 = st.columns(3)
    with control1:
        symbol = st.text_input(
            "Pilot sembol",
            value="THYAO",
            key="delayed_pilot_symbol",
        )
    with control2:
        refresh_minutes = st.selectbox(
            "Yenileme aralığı",
            options=(1, 2, 5, 10, 15),
            index=2,
            format_func=lambda value: f"{value} dakika",
            key="delayed_pilot_refresh",
        )
    with control3:
        automatic = st.toggle(
            "Otomatik yenileme",
            value=False,
            key="delayed_pilot_auto",
        )

    config = DelayedDataPilotConfig(
        refresh_interval_minutes=int(refresh_minutes),
    )
    store = DelayedDataPilotStore()

    def render_delayed_snapshot() -> None:
        try:
            snapshot = fetch_delayed_snapshot(
                symbol,
                config=config,
            )
            store.append(snapshot)
        except DelayedDataPilotError as error:
            st.error(str(error))
            return

        metrik_izgarasi_goster(
            (
                ("Durum", snapshot.status),
                ("Son fiyat", f"{snapshot.last_price:.2f}"),
                (
                    "Ölçülen gecikme",
                    f"{snapshot.measured_delay_minutes:.1f} dk",
                ),
                (
                    "Beklenen gecikme",
                    f"{snapshot.expected_delay_minutes} dk",
                ),
                (
                    "Eksik bar",
                    str(snapshot.missing_bar_count),
                ),
                (
                    "Güvenlik kilidi",
                    "AKTİF" if snapshot.locked else "Kapalı",
                ),
            )
        )

        st.dataframe(
            pd.DataFrame(
                (
                    {
                        "Sembol": snapshot.symbol,
                        "Borsa zamanı": snapshot.exchange_time,
                        "Sisteme alınma zamanı": snapshot.received_time,
                        "Gün içi açılış": snapshot.day_open,
                        "Gün içi yüksek": snapshot.day_high,
                        "Gün içi düşük": snapshot.day_low,
                        "Kümülatif hacim": snapshot.cumulative_volume,
                        "Son bar hacmi": snapshot.latest_bar_volume,
                        "Fiyat değişimi (%)": (
                            snapshot.price_change_percent
                        ),
                    },
                )
            ),
            width="stretch",
            hide_index=True,
        )

        if snapshot.locked:
            st.error(
                "Veri eski veya eksik olduğu için analiz güvenlik "
                "kilidi aktiftir."
            )
        elif snapshot.preview_only:
            st.warning(
                "Gün içi ön izleme: Veri gecikmelidir ve kesin "
                "alım/satım kararı için kullanılmamalıdır."
            )
        else:
            st.success(
                "Günlük bar tamamlanmış veri olarak işaretlendi."
            )

    if automatic:
        @st.fragment(
            run_every=timedelta(minutes=int(refresh_minutes))
        )
        def delayed_auto_fragment() -> None:
            render_delayed_snapshot()

        delayed_auto_fragment()
    elif st.button(
        "Gecikmeli veriyi şimdi güncelle",
        type="primary",
        key="delayed_pilot_refresh_now",
        width="stretch",
    ):
        render_delayed_snapshot()

    records = store.list()
    st.markdown("#### Veri kalitesi ölçüm geçmişi")
    if not records:
        st.info("Henüz kaydedilmiş pilot ölçümü yok.")
    else:
        latest_records = records[-500:]
        st.dataframe(
            pd.DataFrame(pilot_rows(latest_records)),
            width="stretch",
            hide_index=True,
        )
        st.download_button(
            "Pilot ölçümlerini CSV indir",
            data=pilot_to_csv(records),
            file_name="gecikmeli_veri_pilotu.csv",
            mime="text/csv",
            key="delayed_pilot_csv",
            width="stretch",
        )
        st.caption(
            "Pilot kayıtları: "
            "~/.hisse_robotu/gecikmeli_veri_pilotu/"
            "pilot_olcumleri.jsonl"
        )




def gunluk_operasyon_paneli_formu() -> None:
    st.subheader("Günlük Operasyon Paneli — Sistem ve Görev Özeti")
    st.caption(
        "Gün içi veri kalitesi, bekleyen/tamamlanan sinyal sonuçları, "
        "gölge/gerçek işlem kayıtları ve günlük görevler tek ekranda özetlenir."
    )
    st.info(
        "Bu panel yeni teknik skor, işlem sinyali veya AL/SAT kararı üretmez. "
        "Mevcut tarama, Early Visibility, teknik teyit ve risk kanıtlarından üretilmiş "
        "günlük Top-5 ile AL / BEKLE / İŞLEM YOK closeout sonucunu tek ekranda gösterir."
    )

    pilot_store = DelayedDataPilotStore()
    signal_store = SignalOutcomeJsonStore()
    trade_store = TradeJournalStore()

    try:
        trade_records = trade_store.list_records()
    except TradeJournalError as error:
        trade_records = ()
        st.warning(f"İşlem günlüğü okunamadı: {error}")

    shadow_store = ShadowPortfolioStore()
    try:
        shadow_positions = shadow_store.list()
    except ShadowPortfolioError as error:
        shadow_positions = ()
        st.warning(f"Gölge portföy okunamadı: {error}")

    summary = build_daily_operation_summary(
        pilot_records=pilot_store.list(),
        signal_outcomes=signal_store.list(),
        trade_records=trade_records,
        shadow_positions=shadow_positions,
    )

    # DAILY_BUY_DECISION_AUTOMATION_BRIDGE_V1
    st.markdown("#### Otomatik Karar Koşusu")
    st.caption(
        "Windows görevleri kurulduğunda sistem hafta içi 18:20'de seans sonu, "
        "09:00'da sabah yeniden değerlendirme koşusunu panel açık olmasa da çalıştırır."
    )
    try:
        _scheduler_store = ScheduledRunJsonStore()
        st.dataframe(
            pd.DataFrame(scheduler_health_rows(_scheduler_store)),
            width="stretch",
            hide_index=True,
        )
        _recovery_cols = st.columns(2)
        with _recovery_cols[0]:
            if st.button("18:20 koşusunu yeniden çalıştır", key="retry_evening_daily_buy_decision"):
                with st.spinner("Seans sonu karar koşusu yeniden çalıştırılıyor..."):
                    _retry_evening = retry_failed_or_missing_run("EVENING", store=_scheduler_store)
                if _retry_evening.status in {"SUCCESS", "SKIPPED"}:
                    st.success(_retry_evening.detail)
                else:
                    st.error(_retry_evening.detail)
                st.rerun()
        with _recovery_cols[1]:
            if st.button("09:00 koşusunu yeniden çalıştır", key="retry_morning_daily_buy_decision"):
                with st.spinner("Sabah karar koşusu yeniden çalıştırılıyor..."):
                    _retry_morning = retry_failed_or_missing_run("MORNING", store=_scheduler_store)
                if _retry_morning.status in {"SUCCESS", "SKIPPED"}:
                    st.success(_retry_morning.detail)
                else:
                    st.error(_retry_morning.detail)
                st.rerun()
        st.caption(
            "Yeniden çalıştırma yalnız başarısız/eksik koşuyu kurtarır; aynı gün başarılı faz varsa duplicate üretmez."
        )

        # SCHEDULED_RUN_AUDIT_HISTORY_V1
        with st.expander("Otomasyon Koşu Geçmişi / Audit", expanded=False):
            _audit_store = ScheduledRunAuditJsonStore()
            _audit_rows = scheduler_audit_rows(_audit_store, limit=50)
            if _audit_rows:
                st.dataframe(
                    pd.DataFrame(_audit_rows),
                    width="stretch",
                    hide_index=True,
                )
            else:
                st.caption("Henüz arşivlenmiş otomasyon koşusu yok.")

            st.markdown("**EOD → 09:00 günlük zincir denetimi**")
            _chain_rows = scheduler_daily_chain_rows(_scheduler_store, limit_days=14)
            if _chain_rows:
                st.dataframe(
                    pd.DataFrame(_chain_rows),
                    width="stretch",
                    hide_index=True,
                )
            else:
                st.caption("Henüz günlük EOD / 09:00 zincir kaydı yok.")
    except (OSError, ValueError, TypeError) as _scheduler_status_error:
        st.caption(f"Otomatik koşu durumu okunamadı: {_scheduler_status_error}")

    # OPERATIONAL_CLOSEOUT_V1
    st.markdown("#### Operasyonel Kapanış — Günlük Karar Zinciri")
    st.caption(
        "18:20 EOD ve 09:00 Morning koşularını scheduler durumu, audit kaydı ve "
        "karar çıktı arşivi üzerinden birlikte doğrular. Yeni skor veya karar üretmez."
    )
    try:
        _operational_closeout = build_operational_closeout()
        if _operational_closeout.status == "COMPLETE":
            st.success(_operational_closeout.headline)
        elif _operational_closeout.status == "WAITING":
            st.info(_operational_closeout.headline)
        else:
            st.warning(_operational_closeout.headline)
        st.dataframe(
            pd.DataFrame(operational_closeout_rows(_operational_closeout)),
            width="stretch",
            hide_index=True,
        )
        if _operational_closeout.missing_links:
            st.caption("Eksik halkalar: " + " · ".join(_operational_closeout.missing_links))
    except (OSError, ValueError, TypeError) as _operational_closeout_error:
        st.caption(f"Operasyonel kapanış doğrulanamadı: {_operational_closeout_error}")
    # OPERATIONAL_CLOSEOUT_V1_END

    # V1_OPERATIONS_01C_MORNING_CANDIDATE_UI
    # DAILY_10_TRAJECTORY_V1
    st.markdown("#### Bugünün 10 Araştırma Adayı")
    st.caption(
        "İlk 5 mevcut operasyon/karar adayını aynen korur. Ek 5 araştırma adayı, "
        "22–80 Research bandında 5S → 3S → 1S → bugün sırası sürekli iyileşen "
        "sağlıklı sıra göçlerinden seçilir. Erken 5 yeni teknik skor, işlem sinyali "
        "veya AL/SAT kararı üretmez."
    )
    # Legacy V1 Operations wiring contract intentionally preserved.
    st.markdown("#### Bugünün 5 Adayı")
    st.caption(
        "Seans sonu ve sabah karar koşusu, mevcut BIST tarama sırasını Early Visibility "
        "ve operasyon bağlamıyla birleştirir. Veri eskiliği listeyi bloke etmez."
    )

    _morning_scan_state = st.session_state.get("bist_toplu_tarama_son_sonuc")
    _auto_scan_error = None
    if _morning_scan_state is None and resolve_daily_buy_decision_phase() is not None:
        try:
            _auto_scan_service = build_dashboard_market_scanner(vbts_hard_block=False)
            _auto_scan_request = MarketScanRequest(
                evren="BIST 100",
                profil_adi=TARAMA_PROFILLERI["Dengeli"],
                maksimum_aday=15,
                ozel_semboller=(),
                internetten_evren_guncelle=True,
                sektor_baglami_aktif=True,
            )
            with st.spinner("Günlük karar listesi için BIST 100 otomatik taranıyor..."):
                _auto_scan_result = _auto_scan_service.calistir(_auto_scan_request)
            _morning_scan_state = {
                "sonuc": _auto_scan_result,
                "temel_skorlar": {},
                "temel_filtre_aktif": False,
                "minimum_temel_skor": 60,
            }
            st.session_state["bist_toplu_tarama_son_sonuc"] = _morning_scan_state
        except (
            ValueError,
            TypeError,
            MarketScannerError,
            DashboardMarketScannerSourceError,
        ) as _auto_scan_exception:
            _auto_scan_error = str(_auto_scan_exception)

    if _morning_scan_state is None:
        st.warning(
            "Otomatik günlük tarama henüz sonuç üretmedi. Son kayıtlı akşam/sabah "
            "snapshot'ı varsa aşağıdaki karar geçmişinde korunur; manuel tarama zorunlu değildir."
        )
        if _auto_scan_error:
            st.caption(f"Otomatik tarama detayı: {_auto_scan_error}")
    else:
        try:
            _morning_visibility_contexts = build_current_visibility_context()
        except Exception as _morning_visibility_error:
            _morning_visibility_contexts = ()
            st.caption(
                "Early Visibility geçmişi şu anda okunamadı; adaylar mevcut "
                "tarama sırasıyla gösterilecek. "
                f"Detay: {_morning_visibility_error}"
            )

        _morning_snapshot = build_morning_operation_snapshot(
            operation_summary=summary,
            scan_result=_morning_scan_state["sonuc"],
            visibility_contexts=_morning_visibility_contexts,
            limit=5,
        )

        if not _morning_snapshot.candidates:
            st.info(
                "Güncel taramada sabah aday kartına taşınacak hisse bulunamadı."
            )
        else:
            st.success(
                f"{_morning_snapshot.candidate_count} ana operasyon adayı hazır."
            )
            st.markdown("##### Ana 5 — mevcut operasyon adayları")
            st.dataframe(
                pd.DataFrame(
                    morning_candidate_rows(_morning_snapshot.candidates)
                ),
                width="stretch",
                hide_index=True,
            )

            # DAILY_10_TRAJECTORY_V1_EARLY_FIVE
            st.markdown("##### Erken 5 — sağlıklı sıra göçü")
            st.caption(
                "Sıralama: önce 3S sıra kazancı, sonra 5S kalıcılık, sonra 1S devam "
                "ve son olarak bugünkü Research sırası. Composite skor yoktur."
            )
            try:
                from backend.app.analysis.daily_early_trajectory import (
                    build_daily_early_trajectory_candidates,
                    daily_early_trajectory_rows,
                )
                from backend.app.analysis.ranking_memory import (
                    RankObservationJsonlStore,
                )
                from backend.app.analysis.ranking_trajectory import (
                    build_rank_trajectories,
                )

                _daily10_rank_history = RankObservationJsonlStore().list()
                _daily10_trajectories = build_rank_trajectories(
                    _daily10_rank_history
                )
                _daily10_primary_symbols = tuple(
                    item.symbol for item in _morning_snapshot.candidates
                )
                _daily10_early_candidates = (
                    build_daily_early_trajectory_candidates(
                        _daily10_trajectories,
                        primary_symbols=_daily10_primary_symbols,
                        limit=5,
                        rank_min=22,
                        rank_max=80,
                    )
                )
                if _daily10_early_candidates:
                    st.dataframe(
                        pd.DataFrame(
                            daily_early_trajectory_rows(
                                _daily10_early_candidates,
                                start_priority=6,
                            )
                        ),
                        width="stretch",
                        hide_index=True,
                    )
                else:
                    st.info(
                        "Bugün 5S → 3S → 1S → bugün boyunca sürekli iyileşen, "
                        "22–80 bandında ve karşılaştırılabilir ek erken aday yok. "
                        "Liste düşük kaliteli adayla zorla 10'a tamamlanmadı."
                    )
            except (OSError, ValueError, TypeError) as _daily10_trajectory_error:
                st.warning(
                    "Erken 5 sıra yolu hazırlanamadı; Ana 5 ve mevcut AL/SAT "
                    "karar zinciri değişmeden çalışmaya devam ediyor. "
                    f"Detay: {_daily10_trajectory_error}"
                )
            # DAILY_10_TRAJECTORY_V1_EARLY_FIVE_END
            # V1_OPERATIONS_01D_DECISION_CARDS
            st.markdown("##### Aday karar kartları")
            for _candidate_card in _morning_snapshot.candidates:
                _candidate_title = (
                    f"#{_candidate_card.rank} {_candidate_card.symbol} — "
                    f"{_candidate_card.operational_status}"
                )
                with st.expander(_candidate_title, expanded=False):
                    _c1, _c2, _c3, _c4 = st.columns(4)
                    _c1.metric("Teknik skor", _candidate_card.technical_score)
                    _c2.metric(
                        "Araştırma önceliği",
                        _candidate_card.research_priority,
                    )
                    _c3.metric(
                        "Hacim oranı",
                        f"{_candidate_card.volume_ratio:.2f}",
                    )
                    _c4.metric(
                        "Risk/Getiri",
                        f"{_candidate_card.risk_reward:.2f}",
                    )

                    st.write(
                        f"**Teknik görünüm:** "
                        f"{_candidate_card.technical_view}"
                    )
                    st.write(
                        f"**Erken görünürlük:** "
                        f"{_candidate_card.visibility_state or '-'}"
                    )
                    st.write(
                        f"**Aday kaynağı:** {_candidate_card.selection_source} · "
                        f"{_candidate_card.selection_reason}"
                    )
                    st.write(
                        f"**Sıçrama kalite kapısı:** {_candidate_card.jump_quality} · "
                        f"{_candidate_card.jump_quality_reason}"
                    )
                    st.write(
                        f"**Giriş hazırlığı:** {_candidate_card.entry_readiness} · "
                        f"{_candidate_card.entry_readiness_reason}"
                    )
                    st.write(
                        f"**Sıra değişimi:** "
                        f"{_candidate_card.rank_change if _candidate_card.rank_change is not None else '-'}"
                    )

                    st.markdown("**Neden burada?**")
                    if _candidate_card.positive_reasons:
                        for _reason in _candidate_card.positive_reasons:
                            st.write(f"• {_reason}")
                    else:
                        st.write("• Ek pozitif neden yok.")

                    st.markdown("**Riskler**")
                    if _candidate_card.risks:
                        for _risk in _candidate_card.risks:
                            st.write(f"• {_risk}")
                    else:
                        st.write("• Kayıtlı ek risk yok.")

                    if _candidate_card.data_blocked:
                        st.warning(
                            "Bu adayın veri bağlamı doğrulama gerektiriyor."
                        )

            # DAILY_BUY_DECISION_CLOSEOUT_V1
            _final_buy_decisions = build_daily_buy_decisions(
                _morning_snapshot.candidates
            )
            st.markdown("##### Nihai günlük karar")
            st.dataframe(
                pd.DataFrame(daily_buy_decision_rows(_final_buy_decisions)),
                width="stretch",
                hide_index=True,
            )
            _buy_symbols = [
                item.symbol for item in _final_buy_decisions
                if item.decision == "AL"
            ]
            if _buy_symbols:
                st.success("AL: " + ", ".join(_buy_symbols))
            else:
                st.info("Bugünkü Top-5 içinde AL koşullarını tamamlayan aday yok.")

            # HIGH_CONVICTION_BUY_GATE_V1
            st.markdown("##### High-Conviction Buy Gate")
            st.caption(
                "Mevcut AL / BEKLE / İŞLEM YOK kararını değiştirmez ve yeni birleşik güven skoru üretmez. "
                "Yalnız mevcut teknik, hacim, risk/getiri, zamanlama, giriş, veri ve outcome kanıtlarının "
                "tamamını zorunlu kapılar halinde değerlendirir. Geçmiş outcome kanıtı yeterli değilse "
                "bir AL adayı Yüksek Güvenli AL olarak etiketlenmez."
            )
            try:
                _high_conviction_outcomes = BuyDecisionOutcomeJsonStore().load()
                _high_conviction_calibration = build_buy_decision_calibration(
                    _high_conviction_outcomes
                )
            except (OSError, ValueError, TypeError, json.JSONDecodeError):
                _high_conviction_calibration = ()

            _high_conviction_decisions = build_high_conviction_buy_gate(
                _morning_snapshot.candidates,
                _final_buy_decisions,
                calibration_slices=_high_conviction_calibration,
            )
            st.dataframe(
                pd.DataFrame(high_conviction_rows(_high_conviction_decisions)),
                width="stretch",
                hide_index=True,
            )
            _high_conviction_symbols = [
                item.symbol
                for item in _high_conviction_decisions
                if item.conviction == HIGH_CONVICTION_BUY
            ]
            _normal_conviction_symbols = [
                item.symbol
                for item in _high_conviction_decisions
                if item.conviction == NORMAL_CONVICTION_BUY
            ]
            if _high_conviction_symbols:
                st.success(
                    "Yüksek Güvenli AL: " + ", ".join(_high_conviction_symbols)
                )
            elif _normal_conviction_symbols:
                st.info(
                    "Bugün Yüksek Güvenli AL yok. Normal güvenli AL: "
                    + ", ".join(_normal_conviction_symbols)
                )
            else:
                st.info("Bugün yüksek güvenli veya normal güvenli AL adayı yok.")
            # HIGH_CONVICTION_BUY_GATE_V1_END

            # RANKING_MOVEMENT_WIDE_DAILY_PANEL_V1
            with st.expander("Sıralama Hareketi — Geniş Evren", expanded=False):
                st.caption(
                    "Toplu taramaya giren tüm tarihli hisselerin 1S / 3S / 5S sıra "
                    "hareketini gösterir. 'Sıçrama görünürlüğü' ayrı bir AL/SAT skoru "
                    "değildir; hangi hissenin neden erken araştırma havuzunda görünür "
                    "olduğunu açıklar."
                )
                try:
                    from backend.app.analysis.ranking_memory import RankObservationJsonlStore
                    from backend.app.analysis.ranking_movement_visibility import (
                        build_ranking_movement_rows,
                        ranking_movement_table_rows,
                    )

                    _daily_rank_history = RankObservationJsonlStore().list()
                    _daily_movement_rows = build_ranking_movement_rows(_daily_rank_history)
                    if not _daily_movement_rows:
                        st.info(
                            "Geniş evren sıra hareketi için henüz yeterli tarihli "
                            "ranking snapshot'ı yok."
                        )
                    else:
                        _daily_movement_df = pd.DataFrame(
                            ranking_movement_table_rows(_daily_movement_rows)
                        )
                        _daily_movement_filter = st.radio(
                            "Geniş evren filtresi",
                            options=(
                                "Tümü",
                                "Sıçrama adayları",
                                "Kalıcı / destekli",
                                "Top-5'e yaklaşanlar",
                            ),
                            horizontal=True,
                            key="daily_ranking_movement_wide_filter",
                        )
                        if _daily_movement_filter == "Sıçrama adayları":
                            _daily_movement_df = _daily_movement_df[
                                _daily_movement_df["Sıçrama görünürlüğü"].eq("ADAY")
                            ]
                        elif _daily_movement_filter == "Kalıcı / destekli":
                            _daily_movement_df = _daily_movement_df[
                                _daily_movement_df["Kalıcılık"].isin(("KALICI", "DESTEKLI"))
                            ]
                        elif _daily_movement_filter == "Top-5'e yaklaşanlar":
                            _daily_movement_df = _daily_movement_df[
                                pd.to_numeric(
                                    _daily_movement_df["Top-5 uzaklık"],
                                    errors="coerce",
                                ) <= 20
                            ]

                        st.dataframe(
                            _daily_movement_df,
                            width="stretch",
                            hide_index=True,
                            column_config={
                                "Bugün": st.column_config.NumberColumn(format="#%d"),
                                "1S Δ": st.column_config.NumberColumn(format="%d"),
                                "3S Δ": st.column_config.NumberColumn(format="%d"),
                                "5S Δ": st.column_config.NumberColumn(format="%d"),
                                "Sıçrama ivmesi": st.column_config.NumberColumn(format="%.1f"),
                            },
                        )
                        st.caption(
                            f"Gösterilen: {len(_daily_movement_df)} / "
                            f"{len(_daily_movement_rows)} hisse. "
                            "Neden? sütunu ham sıra hareketi, hızlanma ve kalıcılığı "
                            "açıklanabilir biçimde gösterir."
                        )
                except Exception as _daily_ranking_movement_error:
                    st.warning(
                        "Geniş evren sıralama hareketi hazırlanamadı; Top-5 karar "
                        "zinciri çalışmaya devam eder. Detay: "
                        f"{_daily_ranking_movement_error}"
                    )
            # RANKING_MOVEMENT_WIDE_DAILY_PANEL_V1_END

            # DUAL_RUN_DAILY_BUY_DECISION_V1
            _decision_phase = resolve_daily_buy_decision_phase()
            _decision_store = DailyBuyDecisionJsonStore()
            if _decision_phase is not None:
                try:
                    _decision_snapshot = build_daily_buy_decision_snapshot(
                        _morning_snapshot.candidates,
                        phase=_decision_phase,
                        decisions=_final_buy_decisions,
                    )
                    _decision_store.save(_decision_snapshot)
                    DecisionOutputArchiveJsonStore().save_snapshot(_decision_snapshot)
                except (OSError, ValueError, TypeError) as _decision_store_error:
                    st.caption(
                        "Akşam/sabah karar snapshot'ı kaydedilemedi: "
                        f"{_decision_store_error}"
                    )

            try:
                _decision_snapshots = _decision_store.load()
            except (OSError, ValueError, TypeError):
                _decision_snapshots = {}

            _evening_snapshot = _decision_snapshots.get("EVENING")
            _morning_decision_snapshot = _decision_snapshots.get("MORNING")
            _decision_changes = compare_evening_morning(
                _evening_snapshot,
                _morning_decision_snapshot,
            )
            if _evening_snapshot is not None:
                st.caption(
                    "Seans sonu liste: "
                    f"{_evening_snapshot.created_at} · "
                    f"{len(_evening_snapshot.candidates)} aday"
                )
            if _morning_decision_snapshot is not None:
                st.caption(
                    "Sabah yeniden değerlendirme: "
                    f"{_morning_decision_snapshot.created_at} · "
                    f"{len(_morning_decision_snapshot.candidates)} aday"
                )
            if _decision_changes:
                st.markdown("##### Akşam → Sabah karar değişimi")
                st.caption(
                    "Karar değişim nedeni; teknik görünüm/skor, hacim, risk-getiri, "
                    "giriş hazırlığı, sıçrama kalite kapısı, sıra hareketi ve veri "
                    "durumundaki akşam→sabah farklardan deterministik olarak türetilir."
                )
                st.dataframe(
                    pd.DataFrame(daily_buy_decision_change_rows(_decision_changes)),
                    width="stretch",
                    hide_index=True,
                )

            # EOD_MORNING_BOARD_DELTA_SUMMARY_V1
            _board_delta_summary = build_eod_morning_board_delta(
                _evening_snapshot,
                _morning_decision_snapshot,
            )
            if _board_delta_summary is not None:
                st.markdown("##### Akşam → 09:00 Aksiyon Farkı — Tek Bakış")
                st.caption(
                    "Seans sonu ön aksiyon listesi ile 09:00 nihai karar yapısını read-only "
                    "özetler; yeni skor, sinyal veya karar üretmez."
                )
                metrik_izgarasi_goster(
                    (
                        ("Akşam AL", str(_board_delta_summary.evening_buy)),
                        ("09:00 AL", str(_board_delta_summary.morning_buy)),
                        ("Güçlenen", str(_board_delta_summary.upgrades)),
                        ("Zayıflayan", str(_board_delta_summary.downgrades)),
                        ("Yeni / Çıkan", f"{_board_delta_summary.added} / {_board_delta_summary.removed}"),
                        ("Değişmeyen", str(_board_delta_summary.unchanged)),
                    )
                )
                st.info(_board_delta_summary.headline)
                _board_delta_rows = eod_morning_board_delta_rows(_board_delta_summary)
                if _board_delta_rows:
                    st.dataframe(
                        pd.DataFrame(_board_delta_rows),
                        width="stretch",
                        hide_index=True,
                    )
                else:
                    st.caption("Akşam ve 09:00 arasında karar veya Top-5 üyeliği değişmedi.")
            # EOD_MORNING_BOARD_DELTA_SUMMARY_V1_END

            # DECISION_OUTPUT_ARCHIVE_DAILY_COMPARE_V1
            try:
                _decision_archive_store = DecisionOutputArchiveJsonStore()
                _decision_archive_records = _decision_archive_store.load()
                with st.expander("Karar Çıktı Arşivi / Günler Arası Karşılaştırma", expanded=False):
                    st.caption(
                        "EOD ve 09:00 Top-5 karar board'ları günlük olarak saklanır. "
                        "Bu görünüm geçmiş kararları yeniden açar ve günler arasındaki "
                        "Top-5 / AL / sıra / karar değişimini read-only karşılaştırır."
                    )
                    _archive_rows = decision_output_archive_rows(
                        _decision_archive_records, limit=30
                    )
                    if _archive_rows:
                        st.dataframe(
                            pd.DataFrame(_archive_rows),
                            width="stretch",
                            hide_index=True,
                        )

                        _archive_dates = tuple(sorted(
                            {item.run_date for item in _decision_archive_records},
                            reverse=True,
                        ))
                        _selected_archive_date = st.selectbox(
                            "Geçmiş karar günü",
                            options=_archive_dates,
                            key="daily_decision_archive_selected_date",
                        )
                        _selected_date_records = _decision_archive_store.by_date(
                            _selected_archive_date
                        )
                        for _archive_record in _selected_date_records:
                            st.markdown(
                                f"**{_archive_record.run_date} · {_archive_record.phase}**"
                            )
                            st.dataframe(
                                pd.DataFrame(decision_output_board_rows(_archive_record)),
                                width="stretch",
                                hide_index=True,
                            )

                        st.markdown("**Son iki 09:00 günü karşılaştırması**")
                        _daily_archive_delta = latest_daily_compare(
                            _decision_archive_records, phase="MORNING"
                        )
                        if _daily_archive_delta is not None:
                            st.dataframe(
                                pd.DataFrame(
                                    daily_decision_archive_delta_rows(_daily_archive_delta)
                                ),
                                width="stretch",
                                hide_index=True,
                            )
                        else:
                            st.caption(
                                "Günler arası 09:00 karşılaştırması için en az iki günlük arşiv gerekir."
                            )

                        st.markdown("**Karar çıktısı ↔ otomasyon audit eşleşmesi**")
                        try:
                            _decision_archive_audit = ScheduledRunAuditJsonStore().load()
                            st.dataframe(
                                pd.DataFrame(
                                    decision_output_audit_rows(
                                        _decision_archive_records,
                                        _decision_archive_audit,
                                        limit=30,
                                    )
                                ),
                                width="stretch",
                                hide_index=True,
                            )
                        except (OSError, ValueError, TypeError) as _archive_audit_error:
                            st.caption(
                                f"Karar arşivi audit eşleşmesi okunamadı: {_archive_audit_error}"
                            )
                    else:
                        st.caption("Henüz arşivlenmiş günlük karar çıktısı yok.")
            except (OSError, ValueError, TypeError) as _decision_archive_error:
                st.caption(f"Karar çıktı arşivi okunamadı: {_decision_archive_error}")
            # DECISION_OUTPUT_ARCHIVE_DAILY_COMPARE_V1_END

            # EOD_FINAL_ACTION_BOARD_V1
            if _decision_phase == "EVENING":
                _eod_final_actions = build_eod_final_actions(
                    _morning_snapshot.candidates,
                    _final_buy_decisions,
                )
                st.markdown("##### Seans Sonu — Ertesi Gün Ön Aksiyon Listesi")
                st.caption(
                    "Kapanış verisiyle ertesi gün için ilk aksiyon listesi hazırlanır. "
                    "AL adayları önce gösterilir; Top-5'in orijinal sırası, aday kaynağı, "
                    "giriş hazırlığı ve kalite kanıtları değiştirilmez. Sabah 09:00 "
                    "yeniden değerlendirmesi bu listenin yerine geçebilir."
                )
                st.dataframe(
                    pd.DataFrame(eod_final_action_rows(_eod_final_actions)),
                    width="stretch",
                    hide_index=True,
                )
                _eod_buy_actions = [
                    item.symbol for item in _eod_final_actions
                    if item.decision == "AL"
                ]
                if _eod_buy_actions:
                    st.success("Seans sonu ertesi gün AL adayları: " + ", ".join(_eod_buy_actions))
                else:
                    st.info("Seans sonu listesinde ertesi gün için AL koşullarını tamamlayan aday yok.")
            # EOD_FINAL_ACTION_BOARD_V1_END

            # MORNING_FINAL_ACTION_BOARD_V1
            if _decision_phase == "MORNING":
                _morning_final_actions = build_morning_final_actions(
                    _morning_snapshot.candidates,
                    _final_buy_decisions,
                )
                st.markdown("##### 09:00 Nihai Aksiyon Listesi")
                st.caption(
                    "Sabah yeniden değerlendirmesinden sonra AL adayları önce gösterilir; "
                    "Top-5'in orijinal sırası, aday kaynağı, giriş hazırlığı ve kalite "
                    "kanıtları değiştirilmez. Bu görünüm yeni skor veya yeni karar üretmez."
                )
                st.dataframe(
                    pd.DataFrame(morning_final_action_rows(_morning_final_actions)),
                    width="stretch",
                    hide_index=True,
                )
                _morning_buy_actions = [
                    item.symbol for item in _morning_final_actions
                    if item.decision == "AL"
                ]
                if _morning_buy_actions:
                    st.success("09:00 AL adayları: " + ", ".join(_morning_buy_actions))
                else:
                    st.info("09:00 listesinde AL koşullarını tamamlayan aday yok.")
            # MORNING_FINAL_ACTION_BOARD_V1_END

            _decision_replacements = compare_evening_morning_replacements(
                _evening_snapshot,
                _morning_decision_snapshot,
            )
            if _decision_replacements:
                st.markdown("##### Sabah Top-5 yer değişimleri")
                st.caption(
                    "Akşam listesinden çıkan ve sabah listesine giren adaylar eşleştirilir. "
                    "Yer değişimi bağlamı karar, giriş hazırlığı, sıçrama kalite kapısı "
                    "ve aday kaynağını gösterir; nedensellik iddiası değildir."
                )
                st.dataframe(
                    pd.DataFrame(
                        daily_buy_decision_replacement_rows(_decision_replacements)
                    ),
                    width="stretch",
                    hide_index=True,
                )

            # DAILY_BUY_DECISION_OUTCOME_TRACKING_V1
            _outcome_store = BuyDecisionOutcomeJsonStore()
            try:
                _outcome_records = _outcome_store.load()
                if _decision_phase == "MORNING":
                    _outcome_records = register_buy_decisions(
                        _outcome_records,
                        _final_buy_decisions,
                        phase="MORNING",
                    )
                _current_prices = {
                    card.symbol: card.reference_price
                    for card in _morning_snapshot.candidates
                    if card.reference_price is not None
                }
                if _current_prices:
                    _outcome_records = apply_session_prices(
                        _outcome_records,
                        _current_prices,
                    )
                _outcome_store.save(_outcome_records)
            except (OSError, ValueError, TypeError, json.JSONDecodeError) as _outcome_error:
                st.caption(f"AL karar performans takibi güncellenemedi: {_outcome_error}")
                _outcome_records = ()

            if _outcome_records:
                st.markdown("##### AL karar isabet takibi")
                st.dataframe(
                    pd.DataFrame(buy_decision_hit_summary(_outcome_records)),
                    width="stretch",
                    hide_index=True,
                )
                with st.expander("AL karar geçmişi ve 1/3/5 seans sonuçları", expanded=False):
                    st.dataframe(
                        pd.DataFrame(buy_decision_outcome_rows(_outcome_records)),
                        width="stretch",
                        hide_index=True,
                    )
                _calibration_slices = build_buy_decision_calibration(_outcome_records)
                if _calibration_slices:
                    with st.expander("Karar kalibrasyonu / outcome feedback", expanded=False):
                        st.caption(
                            "Bu görünüm yalnız mevcut AL kararlarının performansını kırılımlarda ölçer; "
                            "karar eşiklerini otomatik değiştirmez. En az 10 örnek olmadan kalibrasyon "
                            "önerisi üretmez."
                        )
                        st.dataframe(
                            pd.DataFrame(buy_decision_calibration_rows(_calibration_slices)),
                            width="stretch",
                            hide_index=True,
                        )

                _daily_reviews = build_daily_decision_reviews(_outcome_records)
                if _daily_reviews:
                    with st.expander("Günlük karar kalite raporu", expanded=False):
                        st.caption(
                            "Başarı/başarısızlık nedenleri nedensellik iddiası değildir; karar anında "
                            "mevcut olan teknik, hacim, risk/getiri, sıralama ve görünürlük kanıtlarını "
                            "sonraki 1/3/5 seans sonuçlarıyla birlikte gösterir."
                        )
                        st.dataframe(
                            pd.DataFrame(daily_decision_review_summary(_daily_reviews)),
                            width="stretch",
                            hide_index=True,
                        )
                        st.dataframe(
                            pd.DataFrame(daily_decision_review_rows(_daily_reviews)),
                            width="stretch",
                            hide_index=True,
                        )

                if _calibration_slices:
                    _threshold_recommendations = build_threshold_recommendations(
                        _calibration_slices
                    )
                    if _threshold_recommendations:
                        with st.expander("Threshold recommendation / read-only", expanded=False):
                            st.caption(
                                "Bu görünüm yalnız outcome kanıtından eşik inceleme önerisi üretir. "
                                "Karar eşiklerini değiştirmez; herhangi bir değişiklik manuel inceleme "
                                "ve ayrı onay gerektirir."
                            )
                            st.dataframe(
                                pd.DataFrame(
                                    threshold_recommendation_rows(
                                        _threshold_recommendations
                                    )
                                ),
                                width="stretch",
                                hide_index=True,
                            )

                            # RECOMMENDATION_GOVERNANCE_MANUAL_APPROVAL_V1
                            _governance_store = RecommendationGovernanceJsonStore()
                            try:
                                _governance_records = sync_governance_records(
                                    _governance_store.load(),
                                    _threshold_recommendations,
                                )
                                _governance_store.save(_governance_records)
                            except (OSError, ValueError, TypeError, json.JSONDecodeError) as _governance_error:
                                st.caption(f"Öneri governance kaydı güncellenemedi: {_governance_error}")
                                _governance_records = ()

                            if _governance_records:
                                st.markdown("###### Recommendation governance / manual approval")
                                st.caption(
                                    "Onay veya ret yalnız governance kaydını değiştirir; AL/BEKLE/İŞLEM YOK "
                                    "eşikleri ve karar kuralları otomatik olarak değişmez."
                                )
                                st.dataframe(
                                    pd.DataFrame(governance_rows(_governance_records)),
                                    width="stretch",
                                    hide_index=True,
                                )
                                _pending_governance = tuple(
                                    item for item in _governance_records if item.status == "BEKLİYOR"
                                )
                                if _pending_governance:
                                    _governance_id = st.selectbox(
                                        "İncelenecek eşik önerisi",
                                        options=tuple(item.recommendation_id for item in _pending_governance),
                                        format_func=lambda value: next(
                                            f"{item.dimension} · {item.horizon} · {item.recommendation}"
                                            for item in _pending_governance
                                            if item.recommendation_id == value
                                        ),
                                        key="daily_buy_decision_governance_review_id",
                                    )
                                    _gov_cols = st.columns(2)
                                    if _gov_cols[0].button(
                                        "Governance önerisini onayla",
                                        key="daily_buy_decision_governance_approve",
                                        width="stretch",
                                    ):
                                        _governance_records = review_governance_record(
                                            _governance_records,
                                            _governance_id,
                                            GOVERNANCE_APPROVED,
                                        )
                                        _governance_store.save(_governance_records)
                                        st.success("Öneri governance kaydında ONAYLANDI. Karar eşikleri değiştirilmedi.")
                                    if _gov_cols[1].button(
                                        "Governance önerisini reddet",
                                        key="daily_buy_decision_governance_reject",
                                        width="stretch",
                                    ):
                                        _governance_records = review_governance_record(
                                            _governance_records,
                                            _governance_id,
                                            GOVERNANCE_REJECTED,
                                        )
                                        _governance_store.save(_governance_records)
                                        st.info("Öneri governance kaydında REDDEDİLDİ. Karar eşikleri değiştirilmedi.")

            st.caption(
                "Aday sırası mevcut BIST Toplu Tarama sonucundan gelir. "
                "Early Visibility yalnız araştırma bağlamı ekler; teknik skoru "
                "ve mevcut sıralamayı değiştirmez. Seans sonu ve sabah çalışma "
                "pencerelerinde liste snapshot'ı saklanır ve değişimler karşılaştırılır."
            )

    # V11_TRACK1_OBSERVABILITY_UI
    st.markdown("#### Operasyon Sağlığı — Tek Bakış")
    st.caption(
        "Mevcut Günlük Operasyon kanıtını tek yerde özetler; yeni teknik skor, sinyal, "
        "AL/SAT kararı veya ayrı veri deposu üretmez."
    )
    st.dataframe(
        pd.DataFrame(observability_rows(summary)),
        width="stretch",
        hide_index=True,
    )


    st.markdown("#### Operasyon özeti")
    metrik_izgarasi_goster(
        (
            ("Veri durumu", summary.delayed_data_status),
            (
                "Ölçülen gecikme",
                "—"
                if summary.delayed_data_age_minutes is None
                else f"{summary.delayed_data_age_minutes:.1f} dk",
            ),
            (
                "Bekleyen sonuç",
                str(summary.pending_signal_horizons),
            ),
            (
                "Tamamlanan sonuç",
                str(summary.completed_signal_horizons),
            ),
            (
                "Sinyal kaydı",
                str(summary.signal_record_count),
            ),
            (
                "Gölge işlem",
                str(summary.shadow_trade_count),
            ),
            (
                "Gerçek işlem",
                str(summary.real_trade_count),
            ),
            (
                "Güvenlik kilidi",
                "Aktif" if summary.delayed_data_locked else "Kapalı",
            ),
        )
    )

    _gunluk_ai_karar_destegi_goster()
    _ai_gecmis_egilim_goster()

    st.markdown("#### Öncelikli operasyon uyarıları")
    st.caption("Kritik uyarılar bu bölümde öncelik sırasıyla gösterilir.")
    if summary.alerts:
        st.dataframe(
            pd.DataFrame(alert_rows(summary.alerts)),
            width="stretch",
            hide_index=True,
        )
    else:
        st.success("Kritik operasyon uyarısı yok.")

    st.markdown("#### Bugünkü görevler ve hedef modül")
    if summary.delayed_data_locked:
        st.warning(
            "Yeni analiz / yeni işlem görevleri veri güvenlik kilidi nedeniyle bloklu. "
            "Görevler bilgi amaçlı listelenir; Açık Pozisyon İzleme kullanılabilir."
        )
    else:
        st.caption("Bugünkü yapılacak işlemler bu bölümde hedef modüllerle birlikte listelenir.")
    st.dataframe(
        pd.DataFrame(task_rows(summary.tasks)),
        width="stretch",
        hide_index=True,
    )

    st.markdown("#### Modül yönlendirmesi")
    st.info(
        "Veri sorunu → Gecikmeli Veri Pilotu · tarama ihtiyacı → BIST Toplu Tarama / "
        "Fırsat Radarı · tek-hisse teyidi → Güncel Teknik Analiz · "
        "sonuç takibi → Sinyal Sonuçları · işlem takibi → Gölge Portföy."
    )

    if st.button(
        "Operasyon panelini yenile",
        key="daily_operation_refresh",
        width="stretch",
    ):
        st.rerun()



def _gunluk_ai_karar_destegi_goster() -> None:
    """Arşivlenmiş AI değerlendirmesini günlük operasyonda gösterir."""

    st.markdown("#### Günlük AI karar desteği")
    # AI_ANALIZ_ASISTANI_V11_ROLE_CLARITY
    st.caption(
        "AI Analiz Asistanı bağımsız bir AL/SAT motoru değildir; piyasa bağlamını özetler, "
        "risk/olumlu faktörleri ve değişimleri açıklanabilir biçimde sunar."
    )
    st.caption(
        "Bu bölüm yeni AI çağrısı yapmaz; Seans Öncesi Bağlam ekranında "
        "arşivlenmiş son değerlendirmeyi gösterir. Teknik skorları ve "
        "AL/SAT kararlarını değiştirmez."
    )

    data_root = Path(__file__).resolve().parent / "data"
    context = load_daily_ai_operation_context(data_root)

    if not context.available:
        st.info(
            "Henüz arşivlenmiş AI piyasa değerlendirmesi yok. "
            "Seans Öncesi Bağlam ekranında günlük raporları değerlendirin."
        )
        return

    if not context.current_day:
        st.warning(
            f"Son AI değerlendirmesi {context.review_date} tarihli. "
            "Bugünkü raporlar henüz AI ile değerlendirilmemiş olabilir."
        )

    provider = context.provider or "Bilinmiyor"
    model = context.model or "Bilinmiyor"

    metrik_izgarasi_goster(
        (
            ("AI değerlendirme tarihi", context.review_date or "—"),
            ("Değerlendirilen rapor", str(context.report_count)),
            ("AI sağlayıcı", provider),
            ("AI model", model),
        )
    )

    if context.summary:
        st.markdown("**Günlük AI özeti**")
        st.write(context.summary)

    left, right = st.columns(2)

    with left:
        st.markdown("**Olumlu faktörler**")
        if context.positive_factors:
            for item in context.positive_factors:
                st.write(f"- {item}")
        else:
            st.caption("Belirlenemedi")

    with right:
        st.markdown("**Risk faktörleri**")
        if context.risk_factors:
            for item in context.risk_factors:
                st.write(f"- {item}")
        else:
            st.caption("Belirlenemedi")

    if context.previous_date:
        with st.expander(
            f"Önceki AI değerlendirmesine göre değişim · "
            f"{context.previous_date} → {context.review_date}",
            expanded=False,
        ):
            change_found = False

            if context.added_risks:
                change_found = True
                st.markdown("**Yeni riskler**")
                for item in context.added_risks:
                    st.write(f"- {item}")

            if context.resolved_risks:
                change_found = True
                st.markdown("**Artık listelenmeyen riskler**")
                for item in context.resolved_risks:
                    st.write(f"- {item}")

            if context.added_positive_factors:
                change_found = True
                st.markdown("**Yeni olumlu faktörler**")
                for item in context.added_positive_factors:
                    st.write(f"- {item}")

            if context.removed_positive_factors:
                change_found = True
                st.markdown("**Artık listelenmeyen olumlu faktörler**")
                for item in context.removed_positive_factors:
                    st.write(f"- {item}")

            if not change_found:
                st.caption("Risk ve olumlu faktör listelerinde belirgin değişim yok.")

    if context.conflicting_points or context.watch_items:
        with st.expander("Çelişkiler ve izlenecek başlıklar", expanded=False):
            if context.conflicting_points:
                st.markdown("**Çelişkili noktalar**")
                for item in context.conflicting_points:
                    st.write(f"- {item}")

            if context.watch_items:
                st.markdown("**İzlenecek başlıklar**")
                for item in context.watch_items:
                    st.write(f"- {item}")

def _ai_gecmis_egilim_goster() -> None:
    """Son AI değerlendirmelerinin çok günlük eğilimini gösterir."""

    st.markdown("#### AI Geçmişi ve Eğilim")
    st.caption(
        "Son arşivlenmiş AI değerlendirmelerini karşılaştırır. "
        "Yeni API çağrısı yapmaz; teknik skor ve AL/SAT kararlarına veri aktarmaz."
    )

    data_root = Path(__file__).resolve().parent / "data"
    records = load_ai_evaluation_history(data_root, limit=7)

    if not records:
        st.info("Henüz AI değerlendirme geçmişi yok.")
        return

    rows = build_ai_history_view(records)
    trend = analyze_ai_history_trend(records)

    direction_labels = {
        "risk_artiyor": "Risk baskısı artıyor",
        "olumlu_gucleniyor": "Olumlu bağlam güçleniyor",
        "karisik": "Karışık / iki yönlü değişim",
        "dengeli": "Belirgin değişim yok",
        "veri_yok": "Veri yok",
        "baslangic_verisi": "Başlangıç verisi / karşılaştırma için yetersiz",
    }

    st.metric(
        "Son günlerde AI bağlam eğilimi",
        direction_labels.get(trend.get("direction"), "Belirlenemedi"),
    )

    if len(rows) >= 2:
        st.caption(
            f"Karşılaştırılan dönem: {rows[0]['date']} → {rows[-1]['date']} · "
            f"{len(rows)} günlük AI değerlendirmesi"
        )
    else:
        st.caption(
            f"Mevcut AI değerlendirmesi: {rows[-1]['date']} · "
            "Yön karşılaştırması için en az iki gün gerekir."
        )

    left, right = st.columns(2)

    with left:
        st.markdown("**Kalıcı / yeni riskler**")
        for item in trend.get("persistent_risks", []):
            st.write(f"- Kalıcı: {item}")
        for item in trend.get("new_risks", []):
            st.write(f"- Yeni: {item}")
        if not trend.get("persistent_risks") and not trend.get("new_risks"):
            st.caption("Belirgin risk eğilimi yok.")

    with right:
        st.markdown("**Kalıcı / yeni olumlu faktörler**")
        for item in trend.get("persistent_positive_factors", []):
            st.write(f"- Kalıcı: {item}")
        for item in trend.get("new_positive_factors", []):
            st.write(f"- Yeni: {item}")
        if (
            not trend.get("persistent_positive_factors")
            and not trend.get("new_positive_factors")
        ):
            st.caption("Belirgin olumlu faktör eğilimi yok.")

    if trend.get("resolved_risks") or trend.get("lost_positive_factors"):
        with st.expander("Kaybolan / çözülen başlıklar", expanded=False):
            if trend.get("resolved_risks"):
                st.markdown("**Artık listelenmeyen riskler**")
                for item in trend["resolved_risks"]:
                    st.write(f"- {item}")

            if trend.get("lost_positive_factors"):
                st.markdown("**Artık listelenmeyen olumlu faktörler**")
                for item in trend["lost_positive_factors"]:
                    st.write(f"- {item}")

    with st.expander("Son AI değerlendirmeleri", expanded=False):
        for row in reversed(rows):
            st.markdown(f"**{row['date']}**")
            if row.get("summary"):
                st.write(row["summary"])


def golge_portfoy_formu() -> None:
    st.header("Gölge Portföy — Kağıt İşlem ve Trader İzleme")
    st.caption(
        "Sinyal veya manuel girişten açılan gölge pozisyonların performansını, "
        "stop/hedef gelişimini ve aktif trader değerlendirmesini tek yerde izler."
    )
    st.info(
        "Bu ekran gerçek emir göndermez ve gerçek para kullanmaz. "
        "Pozisyonlar yalnızca sinyal kalibrasyonu ve performans ölçümü içindir."
    )

    store = ShadowPortfolioStore()
    signal_store = SignalOutcomeJsonStore()

    try:
        positions = store.list()
        signals = signal_store.list()
    except (ShadowPortfolioError, SignalOutcomeError) as error:
        st.error(str(error))
        return

    open_positions = tuple(
        item for item in positions if item.status == OPEN_STATUS
    )
    closed_positions = tuple(
        item for item in positions if item.status == CLOSED_STATUS
    )

    total_unrealized = sum(
        item.unrealized_pnl for item in open_positions
    )
    total_realized = sum(
        item.realized_pnl for item in closed_positions
    )
    metrik_izgarasi_goster(
        (
            ("Açık pozisyon", str(len(open_positions))),
            ("Kapalı pozisyon", str(len(closed_positions))),
            ("Gerçekleşmemiş K/Z", para_yaz(total_unrealized)),
            ("Gerçekleşen K/Z", para_yaz(total_realized)),
        )
    )

    portfolio_tab, trader_tab, signal_tab, manual_tab, close_tab = st.tabs(
        (
            "Portföy ve günlük",
            "Aktif Trader Yönetimi",
            "Sinyalden pozisyon aç",
            "Manuel pozisyon aç",
            "Pozisyon kapat",
        )
    )

    with portfolio_tab:
        update_col, csv_col = st.columns(2)
        with update_col:
            update_clicked = st.button(
                "Açık pozisyon fiyatlarını güncelle",
                type="primary",
                key="shadow_refresh_all",
                width="stretch",
            )
        with csv_col:
            st.download_button(
                "Gölge portföyü CSV indir",
                data=positions_to_csv(positions),
                file_name="Hisse-Robotu-Golge-Portfoy.csv",
                mime="text/csv",
                key="shadow_csv",
                width="stretch",
            )

        if update_clicked:
            with st.spinner("Gölge pozisyonlar güncelleniyor..."):
                updated, failed, errors = refresh_all_open_positions(
                    store=store
                )
            if errors:
                st.warning("\n".join(errors))
            st.success(
                f"{updated} pozisyon güncellendi · {failed} hata."
            )
            st.rerun()

        if positions:
            st.markdown("#### Açık pozisyonlar")
            if open_positions:
                st.dataframe(
                    pd.DataFrame(position_rows(open_positions)),
                    width="stretch",
                    hide_index=True,
                )
            else:
                st.info("Açık gölge pozisyon yok.")

            st.markdown("#### Kapalı pozisyonlar")
            if closed_positions:
                st.dataframe(
                    pd.DataFrame(position_rows(closed_positions)),
                    width="stretch",
                    hide_index=True,
                )
            else:
                st.info("Kapalı gölge pozisyon yok.")
        else:
            st.warning("Gölge portföyde henüz pozisyon yok.")

    with trader_tab:
        st.subheader("Aktif Gölge Portföy — Trader Yönetimi")
        st.caption(
            "Gün içi fiyat manuel girilir. Sistem gerçek emir göndermez; "
            "stop, trailing stop ve çıkış değerlendirmesi yalnız gölge pozisyonu yönetir."
        )
        st.caption(
            "Varsayılan trader politikası: 1R → başa baş · "
            "1.5R → kâr koruma · 2R → trailing stop."
        )
        if not open_positions:
            st.info("Aktif trader yönetimi için açık gölge pozisyon bulunmuyor.")
        else:
            trader_store = ActiveShadowTraderStore()
            trader_options = {
                (
                    f"{item.symbol.removesuffix('.IS')} · "
                    f"{item.entry_date} · giriş {item.entry_price:.2f} · "
                    f"son {item.current_price:.2f}"
                ): item
                for item in open_positions
            }
            trader_label = st.selectbox(
                "Yönetilecek pozisyon",
                options=tuple(trader_options),
                key="shadow_trader_position",
            )
            trader_position = trader_options[trader_label]

            try:
                trader_key = stable_position_key(trader_position)
                trader_state = trader_store.load(trader_key)
            except (ActiveShadowTraderError, ValueError, TypeError) as error:
                st.error(str(error))
                trader_state = None
                trader_key = ""

            if trader_key:
                trader_col1, trader_col2, trader_col3 = st.columns(3)
                with trader_col1:
                    # V11_TRACK2_SHADOW_PRICE_ASSIST
                    from backend.app.analysis.shadow_price_bridge import fetch_shadow_price_suggestion

                    _price_key = "shadow_trader_manual_price"
                    _price_symbol_key = "_shadow_trader_manual_price_symbol"
                    _price_prefill_key = "_shadow_trader_manual_price_prefill"
                    _price_meta_key = "_shadow_trader_delayed_price_meta"
                    _current_symbol = trader_position.symbol

                    if st.session_state.get(_price_symbol_key) != _current_symbol:
                        st.session_state.pop(_price_key, None)
                        st.session_state.pop(_price_prefill_key, None)
                        st.session_state.pop(_price_meta_key, None)
                        st.session_state[_price_symbol_key] = _current_symbol

                    if st.button(
                        "Gecikmeli fiyatı getir",
                        key="shadow_trader_fetch_delayed_price",
                        width="stretch",
                    ):
                        try:
                            _price_suggestion = fetch_shadow_price_suggestion(_current_symbol)
                        except DelayedDataPilotError as error:
                            st.error(str(error))
                        else:
                            st.session_state[_price_meta_key] = {
                                "symbol": _price_suggestion.symbol,
                                "status": _price_suggestion.status,
                                "locked": _price_suggestion.locked,
                                "preview_only": _price_suggestion.preview_only,
                                "source": _price_suggestion.source,
                                "delay": _price_suggestion.measured_delay_minutes,
                            }
                            if _price_suggestion.usable:
                                st.session_state[_price_prefill_key] = float(_price_suggestion.price)
                                st.session_state.pop(_price_key, None)
                                st.rerun()
                            else:
                                st.warning("Gecikmeli fiyat güvenlik kilidinde; manuel fiyat değiştirilmedi.")

                    _price_default = st.session_state.pop(
                        _price_prefill_key,
                        max(0.01, float(trader_position.current_price)),
                    )
                    trader_price = st.number_input(
                        "Manuel gün içi fiyat",
                        min_value=0.01,
                        value=max(0.01, float(_price_default)),
                        step=0.01,
                        key="shadow_trader_manual_price",
                    )

                    _price_meta = st.session_state.get(_price_meta_key)
                    if _price_meta and _price_meta.get("symbol") == _current_symbol:
                        st.caption(
                            "Kaynak {} · Durum {} · Gecikme {:.1f} dk".format(
                                _price_meta["source"],
                                _price_meta["status"],
                                float(_price_meta["delay"]),
                            )
                        )
                with trader_col2:
                    trader_technical = st.selectbox(
                        "Teknik görünüm",
                        options=TECH_OPTIONS,
                        index=1,
                        key="shadow_trader_technical",
                    )
                with trader_col3:
                    trader_news = st.selectbox(
                        "Haber / olay riski",
                        options=NEWS_OPTIONS,
                        index=0,
                        key="shadow_trader_news",
                    )

                max_holding_days = st.number_input(
                    "Zaman değerlendirme eşiği (gün)",
                    min_value=1,
                    max_value=20,
                    value=5,
                    step=1,
                    key="shadow_trader_time_stop_days",
                    help=(
                        "Bu süre dolduğunda pozisyon yeterli R ilerlemesi göstermediyse "
                        "otomatik kapanmaz; çıkış değerlendirmesine alınır."
                    ),
                )

                try:
                    trader_assessment = assess_shadow_position(
                        trader_position,
                        manual_price=float(trader_price),
                        state=trader_state,
                        technical_state=trader_technical,
                        news_risk=trader_news,
                        observed_on=date.today(),
                        policy=TraderPolicy(
                            max_holding_days=int(max_holding_days)
                        ),
                    )
                except (ValueError, TypeError) as error:
                    st.error(str(error))
                else:
                    metrik_izgarasi_goster(
                        (
                            (
                                "Trader kararı",
                                trader_assessment.action,
                            ),
                            (
                                "Getiri",
                                yuzde_yaz(trader_assessment.pnl_percent),
                            ),
                            (
                                "R katsayısı",
                                "—"
                                if trader_assessment.r_multiple is None
                                else f"{trader_assessment.r_multiple:.2f}R",
                            ),
                            (
                                "Önerilen aktif stop",
                                "—"
                                if trader_assessment.recommended_stop is None
                                else para_yaz(trader_assessment.recommended_stop),
                            ),
                            (
                                "Stop fazı",
                                trader_assessment.stop_phase,
                            ),
                            (
                                "Görülen en yüksek fiyat",
                                para_yaz(trader_assessment.high_water_price),
                            ),
                        )
                    )

                    if trader_state is not None:
                        st.caption(
                            "Kayıtlı aktif stop: "
                            + (
                                "—"
                                if trader_state.active_stop is None
                                else para_yaz(trader_state.active_stop)
                            )
                            + f" · Gözlem sayısı: {trader_state.observation_count}"
                        )

                    for trader_reason in trader_assessment.reasons:
                        st.write(f"- {trader_reason}")

                    apply_stop = st.checkbox(
                        "Önerilen stopu aktif stop olarak kaydet",
                        value=False,
                        key="shadow_trader_apply_stop",
                        disabled=trader_assessment.recommended_stop is None,
                    )
                    if st.button(
                        "Trader değerlendirmesini kaydet",
                        type="primary",
                        width="stretch",
                        key="shadow_trader_save_assessment",
                    ):
                        try:
                            saved_state = trader_store.record_assessment(
                                trader_assessment,
                                previous=trader_state,
                                apply_recommended_stop=bool(apply_stop),
                                observed_at=datetime.now(timezone.utc),
                            )
                        except (ActiveShadowTraderError, ValueError, TypeError) as error:
                            st.error(str(error))
                        else:
                            st.success(
                                "Trader değerlendirmesi kaydedildi. "
                                + (
                                    "Aktif stop güncellendi."
                                    if apply_stop and saved_state.active_stop is not None
                                    else "Aktif stop değiştirilmedi."
                                )
                            )
                            st.rerun()

                    if trader_assessment.action in (
                        ACTION_STOP_EXIT,
                        ACTION_EXIT_REVIEW,
                    ):
                        st.warning(
                            "Pozisyon çıkış değerlendirmesinde. Otomatik emir verilmez; "
                            "kapatma yalnız aşağıdaki kullanıcı onayıyla yapılır."
                        )
                        close_confirm = st.checkbox(
                            "Bu manuel fiyatla gölge pozisyonun kapatılmasını onaylıyorum.",
                            value=False,
                            key="shadow_trader_close_confirm",
                        )
                        if st.button(
                            "Bu fiyatla pozisyonu kapat",
                            type="primary",
                            width="stretch",
                            disabled=not close_confirm,
                            key="shadow_trader_close_now",
                        ):
                            reason_text = (
                                "Sprint-155 aktif trader · "
                                f"{trader_assessment.action} · "
                                + " | ".join(trader_assessment.reasons)
                            )
                            try:
                                trader_store.record_assessment(
                                    trader_assessment,
                                    previous=trader_state,
                                    apply_recommended_stop=bool(apply_stop),
                                    observed_at=datetime.now(timezone.utc),
                                )
                                closed = close_shadow_position(
                                    trader_position,
                                    store=store,
                                    exit_date=date.today(),
                                    exit_price=float(trader_price),
                                    close_reason=reason_text,
                                    fees=0.0,
                                )
                            except (
                                ActiveShadowTraderError,
                                ShadowPortfolioError,
                                ValueError,
                                TypeError,
                            ) as error:
                                st.error(str(error))
                            else:
                                st.success(
                                    f"{closed.symbol} gölge pozisyonu aktif trader "
                                    "kararıyla kapatıldı."
                                )
                                st.rerun()

    with signal_tab:
        if not signals:
            st.warning(
                "Gölge pozisyon açmak için önce Sinyal Sonuçları "
                "ekranında sinyal kaydı oluşturun."
            )
        else:
            signal_options = {
                (
                    f"{item.snapshot.signal_date} · "
                    f"{item.snapshot.symbol.removesuffix('.IS')} · "
                    f"{item.snapshot.decision_class} · "
                    f"{item.snapshot.quality_score}"
                ): item
                for item in signals
            }
            selected_label = st.selectbox(
                "Sinyal kaydı",
                options=tuple(signal_options),
                key="shadow_signal_select",
            )
            selected = signal_options[selected_label]
            signal_quantity = st.number_input(
                "Gölge lot",
                min_value=1,
                value=100,
                step=1,
                key="shadow_signal_quantity",
            )
            signal_capital = st.number_input(
                "Gölge sermaye",
                min_value=1000.0,
                value=100000.0,
                step=10000.0,
                key="shadow_signal_capital",
            )
            signal_reason = st.text_area(
                "İşlem gerekçesi",
                value=(
                    "Otomatik sinyal kaydı ve günlük/haftalık "
                    "karar matrisi doğrulaması."
                ),
                key="shadow_signal_reason",
            )
            if st.button(
                "Seçilen sinyalden gölge pozisyon aç",
                type="primary",
                key="shadow_open_from_signal",
                width="stretch",
            ):
                try:
                    opened = open_from_signal(
                        selected,
                        store=store,
                        quantity=int(signal_quantity),
                        capital_at_entry=float(signal_capital),
                        rationale=signal_reason,
                    )
                except ShadowPortfolioError as error:
                    st.error(str(error))
                else:
                    st.success(
                        f"{opened.symbol} gölge pozisyonu açıldı."
                    )
                    st.rerun()

    with manual_tab:
        with st.form("shadow_manual_open_form"):
            left, right = st.columns(2)
            with left:
                manual_symbol = st.text_input(
                    "Sembol",
                    value="THYAO",
                    key="shadow_manual_symbol",
                )
                manual_date = st.date_input(
                    "Giriş tarihi",
                    value=date.today(),
                    key="shadow_manual_date",
                )
                manual_price = st.number_input(
                    "Giriş fiyatı",
                    min_value=0.01,
                    value=100.0,
                    step=0.25,
                    key="shadow_manual_price",
                )
                manual_quantity = st.number_input(
                    "Lot",
                    min_value=1,
                    value=100,
                    step=1,
                    key="shadow_manual_quantity",
                )
                manual_capital = st.number_input(
                    "Sermaye",
                    min_value=1000.0,
                    value=100000.0,
                    step=10000.0,
                    key="shadow_manual_capital",
                )
            with right:
                manual_stop = st.number_input(
                    "Stop (0 = yok)",
                    min_value=0.0,
                    value=0.0,
                    step=0.25,
                    key="shadow_manual_stop",
                )
                manual_target1 = st.number_input(
                    "Hedef 1 (0 = yok)",
                    min_value=0.0,
                    value=0.0,
                    step=0.25,
                    key="shadow_manual_target1",
                )
                manual_target2 = st.number_input(
                    "Hedef 2 (0 = yok)",
                    min_value=0.0,
                    value=0.0,
                    step=0.25,
                    key="shadow_manual_target2",
                )
                manual_class = st.text_input(
                    "Sinyal sınıfı",
                    value="",
                    key="shadow_manual_class",
                )
                manual_reason = st.text_area(
                    "İşlem gerekçesi",
                    value="",
                    key="shadow_manual_reason",
                )
            manual_opened = st.form_submit_button(
                "Manuel gölge pozisyon aç",
                type="primary",
                width="stretch",
            )

        if manual_opened:
            try:
                opened = open_shadow_position(
                    store=store,
                    symbol=manual_symbol,
                    entry_date=manual_date,
                    entry_price=float(manual_price),
                    quantity=int(manual_quantity),
                    capital_at_entry=float(manual_capital),
                    stop_loss=_opsiyonel_fiyat(manual_stop),
                    target_1=_opsiyonel_fiyat(manual_target1),
                    target_2=_opsiyonel_fiyat(manual_target2),
                    signal_class=manual_class,
                    rationale=manual_reason,
                )
            except ShadowPortfolioError as error:
                st.error(str(error))
            else:
                st.success(
                    f"{opened.symbol} gölge pozisyonu açıldı."
                )
                st.rerun()

    with close_tab:
        if not open_positions:
            st.info("Kapatılacak açık gölge pozisyon yok.")
        else:
            close_options = {
                (
                    f"{item.symbol.removesuffix('.IS')} · "
                    f"{item.entry_date} · {item.entry_price:.2f}"
                ): item
                for item in open_positions
            }
            close_label = st.selectbox(
                "Kapatılacak pozisyon",
                options=tuple(close_options),
                key="shadow_close_select",
            )
            close_position = close_options[close_label]
            close_date = st.date_input(
                "Çıkış tarihi",
                value=date.today(),
                key="shadow_close_date",
            )
            close_price = st.number_input(
                "Çıkış fiyatı",
                min_value=0.01,
                value=float(close_position.current_price),
                step=0.25,
                key="shadow_close_price",
            )
            close_fees = st.number_input(
                "Masraf",
                min_value=0.0,
                value=0.0,
                step=1.0,
                key="shadow_close_fees",
            )
            close_reason = st.text_area(
                "Kapanış nedeni",
                value="",
                key="shadow_close_reason",
            )
            if st.button(
                "Gölge pozisyonu kapat",
                type="primary",
                key="shadow_close_button",
                width="stretch",
            ):
                try:
                    closed = close_shadow_position(
                        close_position,
                        store=store,
                        exit_date=close_date,
                        exit_price=float(close_price),
                        close_reason=close_reason,
                        fees=float(close_fees),
                    )
                except ShadowPortfolioError as error:
                    st.error(str(error))
                else:
                    st.success(
                        f"{closed.symbol} gölge pozisyonu kapatıldı."
                    )
                    st.rerun()




def haftalik_performans_raporu_formu() -> None:
    # HAFTALIK_PERFORMANS_V11_ROLE_CLARITY
    st.header("Haftalık Performans Raporu — Gölge İşlem Sonuç Özeti")
    st.caption(
        "Gölge Portföy kayıtlarını seçilen 7/14/21/28 günlük dönem için toplulaştırır; "
        "açılan/kapanan pozisyonlar, K/Z, getiri, MFE/MAE, hedef/stop oranları ve grup bazlı başarı karşılaştırmalarını gösterir."
    )
    st.info(
        "Bu rapor yeni sinyal, teknik skor veya AL/SAT kararı üretmez. "
        "Sinyal Sonuçları 5/10/20 günlük ileri sinyal performansını ölçerken, "
        "Haftalık Performans Raporu Gölge Portföy pozisyonlarının dönemsel işlem performansını özetler."
    )
    st.caption(
        "Not: Mevcut haftalık rapor kontratında R-multiple metriği bulunmaz; "
        "performans yüzdesel getiri, MFE/MAE, hedef/stop ve gerçekleşen/gerçekleşmemiş K/Z ile izlenir."
    )

    store = ShadowPortfolioStore()
    archive = WeeklyPerformanceArchive()

    period_end = st.date_input(
        "Rapor bitiş tarihi",
        value=date.today(),
        key="weekly_report_end",
    )
    days = st.selectbox(
        "Rapor dönemi",
        options=(7, 14, 21, 28),
        index=0,
        format_func=lambda value: f"Son {value} gün",
        key="weekly_report_days",
    )

    try:
        report = build_weekly_performance_report(
            store.list(),
            period_end=period_end,
            days=int(days),
        )
        csv_bytes = weekly_report_csv_bytes(report)
        pdf_bytes = weekly_report_pdf_bytes(report)
    except (
        ShadowPortfolioError,
        WeeklyPerformanceReportError,
        OSError,
        ValueError,
        TypeError,
    ) as error:
        st.error(str(error))
        return

    st.markdown("#### Dönem performans özeti")
    metrik_izgarasi_goster(
        (
            ("Açılan", str(report.opened_count)),
            ("Kapanan", str(report.closed_count)),
            ("Açık", str(report.open_count)),
            ("Kazanan", str(report.winning_count)),
            ("Kaybeden", str(report.losing_count)),
            ("Gerçekleşen K/Z", para_yaz(report.realized_pnl)),
            ("Gerçekleşmemiş K/Z", para_yaz(report.unrealized_pnl)),
            (
                "Ortalama getiri",
                "—"
                if report.average_return_percent is None
                else yuzde_yaz(report.average_return_percent),
            ),
        )
    )

    summary_tab, comparison_tab, detail_tab, archive_tab = st.tabs(
        (
            "Haftalık özet",
            "Başarı karşılaştırmaları",
            "İşlem ayrıntıları",
            "Rapor arşivi",
        )
    )

    with summary_tab:
        st.dataframe(
            pd.DataFrame(weekly_summary_rows(report)),
            width="stretch",
            hide_index=True,
        )
        csv_col, pdf_col, save_col = st.columns(3)
        with csv_col:
            st.download_button(
                "Haftalık CSV indir",
                data=csv_bytes,
                file_name=(
                    f"haftalik_performans_{report.period_start}_"
                    f"{report.period_end}.csv"
                ),
                mime="text/csv",
                key="weekly_report_csv",
                width="stretch",
            )
        with pdf_col:
            st.download_button(
                "Haftalık PDF indir",
                data=pdf_bytes,
                file_name=(
                    f"haftalik_performans_{report.period_start}_"
                    f"{report.period_end}.pdf"
                ),
                mime="application/pdf",
                key="weekly_report_pdf",
                width="stretch",
            )
        with save_col:
            if st.button(
                "Raporu arşivle",
                key="weekly_report_archive",
                width="stretch",
            ):
                try:
                    paths = archive.save(
                        report,
                        csv_bytes=csv_bytes,
                        pdf_bytes=pdf_bytes,
                    )
                except OSError as error:
                    st.error(f"Haftalık rapor arşivlenemedi: {error}")
                else:
                    st.success(
                        "Haftalık rapor arşivlendi: "
                        + ", ".join(path.name for path in paths)
                    )

    with comparison_tab:
        comparison_sets = (
            ("Sinyal sınıfı", report.signal_class_rows),
            ("Kalite skoru bandı", report.quality_band_rows),
            ("Günlük/haftalık yön uyumu", report.direction_rows),
            ("Piyasa rejimi", report.regime_rows),
            ("Sektör", report.sector_rows),
        )
        for title, rows in comparison_sets:
            st.markdown(f"#### {title}")
            if rows:
                st.dataframe(
                    pd.DataFrame(group_rows_for_table(rows)),
                    width="stretch",
                    hide_index=True,
                )
            else:
                st.info(f"{title} için değerlendirilebilir kayıt yok.")

    with detail_tab:
        if report.position_rows:
            columns = (
                "Durum", "Sembol", "Giriş tarihi", "Çıkış tarihi",
                "Giriş fiyatı", "Son/çıkış fiyatı", "Lot",
                "Gerçekleşen K/Z", "Gerçekleşmemiş K/Z", "Getiri (%)",
                "MFE (%)", "MAE (%)", "Sinyal sınıfı", "Kalite",
                "Rejim", "Sektör", "Kapanış nedeni",
            )
            st.dataframe(
                pd.DataFrame(report.position_rows, columns=columns),
                width="stretch",
                hide_index=True,
            )
        else:
            st.info("Seçilen dönemde raporlanacak gölge pozisyon yok.")

    with archive_tab:
        archived = archive.list()
        if not archived:
            st.info("Arşivlenmiş haftalık performans raporu yok.")
        else:
            st.dataframe(
                pd.DataFrame(
                    {
                        "Rapor": path.name,
                        "Konum": str(path.parent),
                        "Değiştirilme": datetime.fromtimestamp(
                            path.stat().st_mtime
                        ),
                    }
                    for path in archived
                ),
                width="stretch",
                hide_index=True,
            )
            st.caption(
                "Arşiv klasörü: ~/.hisse_robotu/haftalik_raporlar"
            )




def basari_karsilastirmasi_formu() -> None:
    st.header("Rejim, Sektör ve Gösterge Bazlı Başarı Karşılaştırması")
    st.caption(
        "5/10/20 günlük sonuçlar piyasa rejimi, sektör, gösterge, "
        "yön uyumu, hacim onayı ve kalite bandına göre karşılaştırılır."
    )

    store = SignalOutcomeJsonStore()
    outcomes = store.list()

    minimum_sample = st.number_input(
        "Minimum örneklem büyüklüğü",
        min_value=1,
        max_value=100,
        value=5,
        step=1,
        key="success_comparison_min_sample",
    )

    try:
        report = build_success_comparison_report(
            outcomes,
            minimum_sample_size=int(minimum_sample),
        )
    except SuccessComparisonError as error:
        st.error(str(error))
        return

    if not report.rows:
        st.warning(
            "Karşılaştırma için tamamlanmış 5/10/20 günlük sinyal "
            "sonucu bulunamadı."
        )
        return

    eligible_count = sum(
        item.sample_status == "Yeterli"
        for item in report.rows
    )
    insufficient_count = len(report.rows) - eligible_count

    metrik_izgarasi_goster(
        (
            ("Karşılaştırma satırı", str(len(report.rows))),
            ("Yeterli örneklem", str(eligible_count)),
            ("Yetersiz örneklem", str(insufficient_count)),
            ("Minimum örneklem", str(report.minimum_sample_size)),
        )
    )

    dimension_options = ("Tümü",) + tuple(
        sorted({item.dimension for item in report.rows})
    )
    selected_dimension = st.selectbox(
        "Karşılaştırma boyutu",
        options=dimension_options,
        key="success_comparison_dimension",
    )
    selected_horizon = st.selectbox(
        "Ölçüm ufku",
        options=("Tümü", 5, 10, 20),
        format_func=lambda value: (
            value if value == "Tümü" else f"{value} gün"
        ),
        key="success_comparison_horizon",
    )

    filtered = tuple(
        item
        for item in report.rows
        if (
            selected_dimension == "Tümü"
            or item.dimension == selected_dimension
        )
        and (
            selected_horizon == "Tümü"
            or item.horizon == selected_horizon
        )
    )

    st.dataframe(
        pd.DataFrame(comparison_rows(filtered)),
        width="stretch",
        hide_index=True,
    )

    strong_col, weak_col = st.columns(2)
    with strong_col:
        st.markdown("#### En güçlü gruplar")
        if report.strongest:
            st.dataframe(
                pd.DataFrame(comparison_rows(report.strongest)),
                width="stretch",
                hide_index=True,
            )
        else:
            st.info("Yeterli örnekleme sahip grup yok.")
    with weak_col:
        st.markdown("#### En zayıf gruplar")
        if report.weakest:
            st.dataframe(
                pd.DataFrame(comparison_rows(report.weakest)),
                width="stretch",
                hide_index=True,
            )
        else:
            st.info("Yeterli örnekleme sahip grup yok.")

    if insufficient_count:
        st.warning(
            f"{insufficient_count} karşılaştırma satırında örneklem "
            "yetersizdir. Bu gruplar kalibrasyon kararı için tek başına "
            "kullanılmamalıdır."
        )

    csv_col, pdf_col = st.columns(2)
    with csv_col:
        st.download_button(
            "Başarı karşılaştırmasını CSV indir",
            data=comparison_csv_bytes(report),
            file_name="Hisse-Robotu-Basari-Karsilastirmasi.csv",
            mime="text/csv",
            key="success_comparison_csv",
            width="stretch",
        )
    with pdf_col:
        try:
            pdf_data = comparison_pdf_bytes(report)
        except SuccessComparisonError as error:
            st.warning(str(error))
        else:
            st.download_button(
                "Başarı karşılaştırmasını PDF indir",
                data=pdf_data,
                file_name="Hisse-Robotu-Basari-Karsilastirmasi.pdf",
                mime="application/pdf",
                key="success_comparison_pdf",
                width="stretch",
            )




def v13_kalibrasyon_karari_formu() -> None:
    st.header("V1.3 Kalibrasyon Kararı")
    st.caption(
        "Sprint-75–80 kayıt zincirleri birlikte değerlendirilir. "
        "Karar gerçek işlem tavsiyesi değildir."
    )

    pilot_store = DelayedDataPilotStore()
    signal_store = SignalOutcomeJsonStore()
    shadow_store = ShadowPortfolioStore()

    minimum_pilot = st.number_input(
        "Minimum gecikmeli veri ölçümü",
        min_value=1,
        max_value=500,
        value=5,
        step=1,
        key="v13_minimum_pilot",
    )
    minimum_horizon = st.number_input(
        "Minimum tamamlanan 5/10/20 ufku",
        min_value=1,
        max_value=10000,
        value=15,
        step=1,
        key="v13_minimum_horizon",
    )
    minimum_closed = st.number_input(
        "Minimum kapalı gölge pozisyon",
        min_value=1,
        max_value=1000,
        value=5,
        step=1,
        key="v13_minimum_closed",
    )
    minimum_comparison = st.number_input(
        "Minimum yeterli karşılaştırma grubu",
        min_value=1,
        max_value=1000,
        value=3,
        step=1,
        key="v13_minimum_comparison",
    )

    try:
        pilots = pilot_store.list()
        outcomes = signal_store.list()
        positions = shadow_store.list()
        comparison = build_success_comparison_report(
            outcomes,
            minimum_sample_size=5,
        )
        decision = build_v13_calibration_decision(
            pilot_records=pilots,
            signal_outcomes=outcomes,
            shadow_positions=positions,
            comparison_report=comparison,
            minimum_pilot_measurements=int(minimum_pilot),
            minimum_completed_horizons=int(minimum_horizon),
            minimum_closed_positions=int(minimum_closed),
            minimum_sufficient_comparisons=int(minimum_comparison),
        )
    except (
        ShadowPortfolioError,
        SignalOutcomeError,
        SuccessComparisonError,
        ValueError,
        OSError,
    ) as error:
        st.error(str(error))
        return

    if decision.decision == DEVAM:
        st.success("V1.3 kalibrasyon kararı: Devam")
    elif decision.decision == TEMKINLI_DEVAM:
        st.warning("V1.3 kalibrasyon kararı: Temkinli Devam")
    else:
        st.error("V1.3 kalibrasyon kararı: Kalibrasyon Gerekli")

    st.dataframe(
        pd.DataFrame(decision_summary_rows(decision)),
        width="stretch",
        hide_index=True,
    )

    st.markdown("#### Kapanış kriterleri")
    st.dataframe(
        pd.DataFrame(criterion_rows(decision)),
        width="stretch",
        hide_index=True,
    )

    st.info(
        "Snapshot yalnızca hedef testler, tam regresyon ve sistem kontrolü "
        "başarılı olduktan sonra Kur-Sprint81.ps1 ile birlikte gelen "
        "Olustur-V13-Snapshot.ps1 komutuyla oluşturulmalıdır."
    )



def main() -> None:
    st.set_page_config(
        page_title="Hisse Robotu",
        page_icon="📈",
        layout="wide",
    )

    arayuz_stili_uygula()

    st.title("Hisse Robotu")
    st.caption(
        "Gerçek veri backtest paneli · "
        "Kişisel analiz amaçlıdır, yatırım tavsiyesi değildir."
    )

    with st.sidebar:
        st.link_button(
            "Teknik Grafik Terminali",
            "http://localhost:8502",
            width="stretch",
        )
        st.divider()

        akis_adimi = st.radio(
            "Kullanım akışı",
            options=KULLANIM_AKISI,
            index=0,
        )
        analiz_modu = st.selectbox(
            "Modül",
            options=AKIS_MODULLERI[akis_adimi],
            index=0,
        )

    if analiz_modu == "Tek Hisse":
        tek_hisse_formu()
    elif analiz_modu == "Fon Analiz Merkezi":
        from backend.app.funds.live_pipeline import run_live_fund_analysis
        from backend.app.ui.fund_analysis_center import render_fund_analysis_center

        render_fund_analysis_center(
            st,
            run_live_fund_analysis(),
        )
    elif analiz_modu == "Seans Öncesi Bağlam":
        # SEANS_ONCESI_BAGLAM_V11_ROLE_CLARITY
        st.markdown("## Seans Öncesi Bağlam — Günlük Piyasa Hazırlığı")
        st.caption(
            "Seans öncesinde işlenmiş günlük piyasa raporlarını ve arşivlenmiş AI değerlendirmesini "
            "tek hazırlık bağlamında inceler."
        )
        st.info(
            "Bu ekran Haber Merkezi'nin Bugünün Önemli Gelişmeleri veya Ekonomik Takvim sekmelerinin yerine geçmez; "
            "onlar haber/olay ve takvim kayıtlarını yönetir. Seans Öncesi Bağlam ise market-context raporlarını "
            "hazırlık amacıyla toplar. Yeni teknik skor, fiyat yönü, işlem sinyali veya AL/SAT kararı üretmez."
        )
        render_market_context_dashboard(
            st,
            project_root=Path(__file__).resolve().parents[1],
        )
    elif analiz_modu == "Güncel Teknik Analiz":
        guncel_teknik_analiz_formu()
        st.caption(
            "AI hisse sohbeti mevcut teknik analiz bağlamını açıklamaya yardımcı olur; "
            "teknik teyit skorunu, işlem planını veya AL/SAT kararını değiştirmez."
        )
        render_stock_ai_chat(st)
    elif analiz_modu == "Temel Analiz":
        temel_analiz_formu()
    elif analiz_modu == "Piyasa Haber, Olay ve Etki Merkezi":
        render_news_center_dashboard(st)
    elif analiz_modu == "Piyasa Rejimi":
        piyasa_rejimi_formu()
    elif analiz_modu == "BIST Günlük Piyasa":
        render_bist_daily_market()
    elif analiz_modu == "Fırsat Radarı":
        render_opportunity_radar()
    elif analiz_modu == "Momentum Keşif":
        momentum_kesif_formu()
    elif analiz_modu == "Ön Yükseliş Hazırlık":
        on_yukselis_hazirlik_formu()
    elif analiz_modu == "Ön Yükseliş Toplu Doğrulama":
        on_yukselis_toplu_dogrulama_formu()
    elif analiz_modu == "BIST Toplu Tarama":
        bist_toplu_tarama_formu()
    elif analiz_modu == "Açık Pozisyon İzleme":
        acik_pozisyon_izleme_formu()
    elif analiz_modu == "İşlem Kayıp Analizi":
        islem_kayip_analizi_formu()
    elif analiz_modu == "Sinyal Sonuçları":
        sinyal_sonuclari_formu()
    elif analiz_modu == "Gecikmeli Veri Pilotu":
        gecikmeli_veri_pilotu_formu()
    elif analiz_modu == "Günlük Operasyon Paneli":
        gunluk_operasyon_paneli_formu()
    elif analiz_modu == "Gölge Portföy":
        golge_portfoy_formu()
    elif analiz_modu == "Haftalık Performans Raporu":
        haftalik_performans_raporu_formu()
    elif analiz_modu == "Başarı Karşılaştırması":
        basari_karsilastirmasi_formu()
    elif analiz_modu == "V1.3 Kalibrasyon Kararı":
        v13_kalibrasyon_karari_formu()
    elif analiz_modu == "Aynı Veri Karşılaştırması":
        ayni_veri_karsilastirma_formu()
    elif analiz_modu == "Çoklu Hisse Portföyü":
        portfoy_formu()
    else:
        analiz_gecmisi_goster()


if __name__ == "__main__":
    main()
