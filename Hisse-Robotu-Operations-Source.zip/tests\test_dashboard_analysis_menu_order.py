import ast
from pathlib import Path


DASHBOARD = Path("backend/dashboard.py")


EXPECTED_ALPHABETICAL_ORDER = (
    "Açık Pozisyon İzleme",
    "Analiz Geçmişi",
    "Aynı Veri Karşılaştırması",
    "Başarı Karşılaştırması",
    "BIST Günlük Piyasa",
    "BIST Toplu Tarama",
    "Çoklu Hisse Portföyü",
    "Fırsat Radarı",
    "Gecikmeli Veri Pilotu",
    "Gölge Portföy",
    "Güncel Teknik Analiz",
    "Günlük Operasyon Paneli",
    "Haftalık Performans Raporu",
    "İşlem Kayıp Analizi",
    "Momentum Keşif",
    "Ön Yükseliş Hazırlık",
    "Ön Yükseliş Toplu Doğrulama",
    "Piyasa Haber, Olay ve Etki Merkezi",
    "Piyasa Rejimi",
    "Seans Öncesi Bağlam",
    "Sinyal Sonuçları",
    "Tek Hisse",
    "Temel Analiz",
    "V1.3 Kalibrasyon Kararı",
)


def _analysis_modes() -> tuple[str, ...]:
    tree = ast.parse(DASHBOARD.read_text(encoding="utf-8-sig"))
    for node in tree.body:
        if isinstance(node, ast.Assign):
            if any(
                isinstance(target, ast.Name) and target.id == "ANALIZ_MODLARI"
                for target in node.targets
            ):
                value = ast.literal_eval(node.value)
                assert isinstance(value, tuple)
                return value
    raise AssertionError("ANALIZ_MODLARI bulunamadı.")


def test_analiz_modlarinin_tamami_alfabetiktir() -> None:
    assert _analysis_modes() == EXPECTED_ALPHABETICAL_ORDER


def test_varsayilan_ekran_tek_hisse_olarak_korunur() -> None:
    source = DASHBOARD.read_text(encoding="utf-8-sig")
    assert 'index=ANALIZ_MODLARI.index("Tek Hisse")' in source