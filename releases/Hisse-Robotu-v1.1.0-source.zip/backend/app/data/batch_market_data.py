from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Iterable

import pandas as pd
import yfinance as yf

from .market_data import MarketDataError, fiyat_verisini_duzelt


class BatchMarketDataError(Exception):
    """Toplu piyasa verisi indirme işlemi bütünüyle başarısız olduğunda kullanılır."""


@dataclass(frozen=True)
class BatchMarketDataFailure:
    """Tek bir sembol için alınamayan piyasa verisini temsil eder."""

    sembol: str
    hata: str


@dataclass(frozen=True)
class BatchMarketDataResult:
    """Toplu indirme sonucundaki başarılı veriler ve sembol bazlı hatalar."""

    veriler: dict[str, pd.DataFrame]
    hatalar: tuple[BatchMarketDataFailure, ...]


Downloader = Callable[..., pd.DataFrame]


def toplu_fiyat_verisi_getir(
    semboller: Iterable[str],
    islem_gunu: int = 160,
    indirme_donemi: str = "1y",
    parca_boyutu: int = 40,
    indirici: Downloader = yf.download,
) -> BatchMarketDataResult:
    """
    Birden fazla sembolün günlük OHLCV verisini yfinance üzerinden parça parça indirir.

    Tek tek HTTP çağrısı yerine toplu indirme kullanılması, BIST 100/500/Tüm gibi
    geniş evrenlerin taranmasını belirgin biçimde hızlandırır. Bir sembolün hatası
    diğer sembollerin analizini durdurmaz.
    """
    temiz_semboller = _sembolleri_hazirla(semboller)

    if not temiz_semboller:
        raise ValueError("Toplu veri için en az bir hisse sembolü gereklidir.")
    if islem_gunu < 1:
        raise ValueError("İşlem günü sayısı en az 1 olmalıdır.")
    if parca_boyutu < 1:
        raise ValueError("Parça boyutu en az 1 olmalıdır.")

    veriler: dict[str, pd.DataFrame] = {}
    hatalar: list[BatchMarketDataFailure] = []

    for baslangic in range(0, len(temiz_semboller), parca_boyutu):
        parca = temiz_semboller[baslangic : baslangic + parca_boyutu]

        try:
            ham_veri = indirici(
                tickers=parca,
                period=indirme_donemi,
                interval="1d",
                auto_adjust=True,
                progress=False,
                threads=True,
                timeout=45,
                group_by="ticker",
            )
        except Exception as hata:  # yfinance farklı ağ istisnaları üretebilir.
            mesaj = f"Toplu veri indirme hatası: {hata}"
            hatalar.extend(
                BatchMarketDataFailure(sembol=sembol, hata=mesaj)
                for sembol in parca
            )
            continue

        if ham_veri is None or ham_veri.empty:
            hatalar.extend(
                BatchMarketDataFailure(
                    sembol=sembol,
                    hata="Piyasa verisi bulunamadı.",
                )
                for sembol in parca
            )
            continue

        for sembol in parca:
            try:
                sembol_verisi = _sembol_verisini_ayir(
                    ham_veri=ham_veri,
                    sembol=sembol,
                    parca_uzunlugu=len(parca),
                )
                temiz_veri = fiyat_verisini_duzelt(
                    sembol_verisi,
                    yalnizca_tamamlanmis_gunler=True,
                )

                if len(temiz_veri) < islem_gunu:
                    raise MarketDataError(
                        f"Yalnızca {len(temiz_veri)} tamamlanmış işlem günü "
                        f"bulundu. İstenen: {islem_gunu}"
                    )

                veriler[sembol] = temiz_veri.tail(islem_gunu).copy()

            except (KeyError, ValueError, MarketDataError) as hata:
                hatalar.append(
                    BatchMarketDataFailure(
                        sembol=sembol,
                        hata=str(hata),
                    )
                )

    if not veriler and hatalar:
        # Ayrıntılar sonuçta korunur; bu istisna yalnızca bütünüyle başarısız
        # indirmeyi üst katmanda açıkça göstermek için kullanılır.
        return BatchMarketDataResult(veriler={}, hatalar=tuple(hatalar))

    return BatchMarketDataResult(veriler=veriler, hatalar=tuple(hatalar))


def _sembolleri_hazirla(semboller: Iterable[str]) -> list[str]:
    sonuc: list[str] = []
    gorulenler: set[str] = set()

    for ham in semboller:
        sembol = str(ham).strip().upper()
        if not sembol:
            continue
        if "." not in sembol:
            sembol = f"{sembol}.IS"
        if sembol in gorulenler:
            continue
        gorulenler.add(sembol)
        sonuc.append(sembol)

    return sonuc


def _sembol_verisini_ayir(
    ham_veri: pd.DataFrame,
    sembol: str,
    parca_uzunlugu: int,
) -> pd.DataFrame:
    """yfinance'ın iki farklı MultiIndex düzeninden sembol verisini ayırır."""
    if not isinstance(ham_veri.columns, pd.MultiIndex):
        if parca_uzunlugu == 1:
            return ham_veri.copy()
        raise MarketDataError(f"{sembol} sütunları toplu veride bulunamadı.")

    ilk_seviye = set(map(str, ham_veri.columns.get_level_values(0)))
    ikinci_seviye = set(map(str, ham_veri.columns.get_level_values(1)))

    if sembol in ilk_seviye:
        return ham_veri[sembol].copy()

    if sembol in ikinci_seviye:
        return ham_veri.xs(sembol, axis=1, level=1).copy()

    raise MarketDataError(f"{sembol} için toplu piyasa verisi bulunamadı.")
