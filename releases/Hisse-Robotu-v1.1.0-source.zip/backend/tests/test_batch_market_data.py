from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from backend.app.data.batch_market_data import toplu_fiyat_verisi_getir


def coklu_veri(semboller: list[str], satir: int = 200) -> pd.DataFrame:
    tarihler = pd.date_range("2025-01-01", periods=satir, freq="B")
    sutunlar = pd.MultiIndex.from_product(
        [semboller, ["Open", "High", "Low", "Close", "Volume"]]
    )
    veri = pd.DataFrame(index=tarihler, columns=sutunlar, dtype=float)

    for sira, sembol in enumerate(semboller, start=1):
        taban = np.linspace(100 + sira, 150 + sira, satir)
        veri[(sembol, "Open")] = taban
        veri[(sembol, "High")] = taban + 2
        veri[(sembol, "Low")] = taban - 2
        veri[(sembol, "Close")] = taban + 0.5
        veri[(sembol, "Volume")] = 1_000_000 + sira

    return veri


def test_toplu_veri_indirir_normalize_eder_ve_tekrari_siler() -> None:
    cagrilar: list[list[str]] = []

    def indirici(**kwargs: object) -> pd.DataFrame:
        semboller = list(kwargs["tickers"])  # type: ignore[arg-type]
        cagrilar.append(semboller)
        return coklu_veri(semboller)

    sonuc = toplu_fiyat_verisi_getir(
        ["THYAO", "ASELS.IS", "THYAO"],
        islem_gunu=160,
        parca_boyutu=10,
        indirici=indirici,
    )

    assert cagrilar == [["THYAO.IS", "ASELS.IS"]]
    assert tuple(sonuc.veriler) == ("THYAO.IS", "ASELS.IS")
    assert len(sonuc.veriler["THYAO.IS"]) == 160
    assert list(sonuc.veriler["THYAO.IS"].columns) == [
        "Open",
        "High",
        "Low",
        "Close",
        "Volume",
    ]
    assert sonuc.hatalar == ()


def test_toplu_veride_eksik_sembol_hata_olarak_korunur() -> None:
    def indirici(**_kwargs: object) -> pd.DataFrame:
        return coklu_veri(["THYAO.IS"])

    sonuc = toplu_fiyat_verisi_getir(
        ["THYAO", "YOK"],
        islem_gunu=160,
        indirici=indirici,
    )

    assert tuple(sonuc.veriler) == ("THYAO.IS",)
    assert sonuc.hatalar[0].sembol == "YOK.IS"
    assert "bulunamadı" in sonuc.hatalar[0].hata


def test_gecersiz_parca_boyutu_reddedilir() -> None:
    with pytest.raises(ValueError, match="Parça boyutu"):
        toplu_fiyat_verisi_getir(["THYAO"], parca_boyutu=0)
