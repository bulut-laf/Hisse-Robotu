ZIP'i D:\Projects\Hisse-Robotu klasörüne ayıklayın.

Tek komut:
.\Sprint-42-VBTS-Dugmesini-Duzelt-ve-Test-Et.ps1
