from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, time, timedelta
from typing import Iterable, Mapping
from zoneinfo import ZoneInfo

import pandas as pd

ISTANBUL = ZoneInfo("Europe/Istanbul")
GUNCEL = "Güncel"
BEKLEMEDE = "Kapanış verisi bekleniyor"
ESKI = "Eski veri"
GELECEK = "Gelecek tarihli veri"
VERI_YOK = "Veri yok"


@dataclass(frozen=True)
class DataFreshnessPolicy:
    saat_dilimi: str = "Europe/Istanbul"
    seans_kapanisi: time = time(18, 10)
    saglayici_bekleme_dakikasi: int = 20
    kapali_tarihler: tuple[date, ...] = ()

    def __post_init__(self) -> None:
        if self.saglayici_bekleme_dakikasi < 0:
            raise ValueError("Sağlayıcı bekleme süresi negatif olamaz.")
        ZoneInfo(self.saat_dilimi)

    @property
    def zaman_bolgesi(self) -> ZoneInfo:
        return ZoneInfo(self.saat_dilimi)


@dataclass(frozen=True)
class DataFreshnessResult:
    durum: str
    son_veri_tarihi: date | None
    beklenen_tarih: date
    is_gunu_gecikmesi: int
    kilitli: bool
    aciklama: str
    kilit_asamasi: str = "günlük veri doğrulaması"
    sonraki_kontrol_zamani: datetime | None = None

    @property
    def guncel(self) -> bool:
        return self.durum in (GUNCEL, BEKLEMEDE) and not self.kilitli


@dataclass(frozen=True)
class BatchDataFreshnessResult:
    durum: str
    beklenen_tarih: date
    en_eski_tarih: date | None
    en_yeni_tarih: date | None
    toplam_sembol: int
    guncel_sembol: int
    eski_sembol: int
    veri_yok_sembol: int
    kilitli: bool
    aciklama: str
    kilit_asamasi: str = "toplu veri doğrulaması"
    sonraki_kontrol_zamani: datetime | None = None


def beklenen_son_tamamlanmis_islem_gunu(
    simdi: datetime | None = None,
    politika: DataFreshnessPolicy = DataFreshnessPolicy(),
) -> date:
    an = _yerel_zaman(simdi, politika)
    bugun = an.date()
    kapanis_esigi = datetime.combine(
        bugun, politika.seans_kapanisi, tzinfo=politika.zaman_bolgesi
    ) + timedelta(minutes=politika.saglayici_bekleme_dakikasi)

    if _is_gunu_mu(bugun, politika) and an >= kapanis_esigi:
        return bugun
    return _onceki_is_gunu(bugun, politika)



def sonraki_tazelik_kontrol_zamani(
    *,
    simdi: datetime | None = None,
    politika: DataFreshnessPolicy = DataFreshnessPolicy(),
) -> datetime:
    """Kullanıcıya önerilecek en erken anlamlı yeniden kontrol zamanını üretir."""

    an = _yerel_zaman(simdi, politika)
    bugun = an.date()
    bugun_esigi = datetime.combine(
        bugun,
        politika.seans_kapanisi,
        tzinfo=politika.zaman_bolgesi,
    ) + timedelta(minutes=politika.saglayici_bekleme_dakikasi)

    if _is_gunu_mu(bugun, politika) and an < bugun_esigi:
        return bugun_esigi

    aday = bugun + timedelta(days=1)
    while not _is_gunu_mu(aday, politika):
        aday += timedelta(days=1)
    return datetime.combine(
        aday,
        politika.seans_kapanisi,
        tzinfo=politika.zaman_bolgesi,
    ) + timedelta(minutes=politika.saglayici_bekleme_dakikasi)


def gunluk_veri_tazeligini_degerlendir(
    veri: pd.DataFrame,
    *,
    simdi: datetime | None = None,
    politika: DataFreshnessPolicy = DataFreshnessPolicy(),
) -> DataFreshnessResult:
    beklenen = beklenen_son_tamamlanmis_islem_gunu(simdi, politika)
    if veri is None or veri.empty:
        return DataFreshnessResult(
            durum=VERI_YOK,
            son_veri_tarihi=None,
            beklenen_tarih=beklenen,
            is_gunu_gecikmesi=0,
            kilitli=True,
            aciklama="Günlük fiyat verisi bulunamadı; analiz güvenlik nedeniyle durduruldu.",
            kilit_asamasi="günlük veri indirme",
            sonraki_kontrol_zamani=sonraki_tazelik_kontrol_zamani(
                simdi=simdi,
                politika=politika,
            ),
        )

    son = pd.Timestamp(veri.index[-1]).date()
    if son > beklenen:
        return DataFreshnessResult(
            durum=GELECEK,
            son_veri_tarihi=son,
            beklenen_tarih=beklenen,
            is_gunu_gecikmesi=0,
            kilitli=True,
            aciklama=(
                f"Son günlük bar {son}; beklenen tamamlanmış işlem günü {beklenen}. "
                "Gelecek veya tamamlanmamış bar analize karışmış olabilir."
            ),
            kilit_asamasi="tamamlanmış bar doğrulaması",
            sonraki_kontrol_zamani=sonraki_tazelik_kontrol_zamani(
                simdi=simdi,
                politika=politika,
            ),
        )

    gecikme = _is_gunu_mesafesi(son, beklenen, politika)
    if gecikme > 0:
        return DataFreshnessResult(
            durum=ESKI,
            son_veri_tarihi=son,
            beklenen_tarih=beklenen,
            is_gunu_gecikmesi=gecikme,
            kilitli=True,
            aciklama=(
                f"Son günlük bar {son}; beklenen {beklenen}. Veri {gecikme} işlem günü geride. "
                "Momentum, teknik analiz ve işlem planı kullanılmamalıdır."
            ),
            kilit_asamasi="sağlayıcı günlük bar tazeliği",
            sonraki_kontrol_zamani=sonraki_tazelik_kontrol_zamani(
                simdi=simdi,
                politika=politika,
            ),
        )

    an = _yerel_zaman(simdi, politika)
    bugun = an.date()
    if son == beklenen and beklenen != bugun and _is_gunu_mu(bugun, politika):
        durum = BEKLEMEDE
        aciklama = (
            f"Son tamamlanmış günlük bar {son}. Bugünkü seans henüz kapanmadığı veya "
            "sağlayıcıya düşmediği için bu tarih beklenen değerdir."
        )
    else:
        durum = GUNCEL
        aciklama = f"Son günlük bar {son}; beklenen tamamlanmış işlem günüyle eşleşiyor."

    return DataFreshnessResult(
        durum=durum,
        son_veri_tarihi=son,
        beklenen_tarih=beklenen,
        is_gunu_gecikmesi=0,
        kilitli=False,
        aciklama=aciklama,
        kilit_asamasi="doğrulandı",
        sonraki_kontrol_zamani=None,
    )


def toplu_veri_tazeligini_degerlendir(
    veriler: Mapping[str, pd.DataFrame],
    *,
    simdi: datetime | None = None,
    politika: DataFreshnessPolicy = DataFreshnessPolicy(),
) -> BatchDataFreshnessResult:
    beklenen = beklenen_son_tamamlanmis_islem_gunu(simdi, politika)
    tarihler: list[date] = []
    guncel = 0
    eski = 0
    veri_yok = 0
    for veri in veriler.values():
        sonuc = gunluk_veri_tazeligini_degerlendir(
            veri, simdi=simdi, politika=politika
        )
        if sonuc.son_veri_tarihi is not None:
            tarihler.append(sonuc.son_veri_tarihi)
        if sonuc.durum == VERI_YOK:
            veri_yok += 1
        elif sonuc.kilitli:
            eski += 1
        else:
            guncel += 1

    toplam = len(veriler)
    kilitli = toplam == 0 or eski > 0 or veri_yok > 0
    if toplam == 0:
        durum = VERI_YOK
        aciklama = "Toplu taramada doğrulanabilir günlük veri yok."
    elif kilitli:
        durum = ESKI
        aciklama = (
            f"{toplam} sembolün {eski} tanesinde eski/uyumsuz, {veri_yok} tanesinde boş veri var. "
            "Tarama güvenlik nedeniyle durdurulmalıdır."
        )
    else:
        durum = GUNCEL
        aciklama = (
            f"{toplam} sembolün tamamı beklenen {beklenen} tamamlanmış işlem gününe ait."
        )

    return BatchDataFreshnessResult(
        durum=durum,
        beklenen_tarih=beklenen,
        en_eski_tarih=min(tarihler) if tarihler else None,
        en_yeni_tarih=max(tarihler) if tarihler else None,
        toplam_sembol=toplam,
        guncel_sembol=guncel,
        eski_sembol=eski,
        veri_yok_sembol=veri_yok,
        kilitli=kilitli,
        aciklama=aciklama,
        kilit_asamasi=(
            "referans/toplu günlük veri tazeliği"
            if kilitli
            else "doğrulandı"
        ),
        sonraki_kontrol_zamani=(
            sonraki_tazelik_kontrol_zamani(
                simdi=simdi,
                politika=politika,
            )
            if kilitli
            else None
        ),
    )


def _yerel_zaman(
    simdi: datetime | None,
    politika: DataFreshnessPolicy,
) -> datetime:
    if simdi is None:
        return datetime.now(politika.zaman_bolgesi)
    if simdi.tzinfo is None:
        return simdi.replace(tzinfo=politika.zaman_bolgesi)
    return simdi.astimezone(politika.zaman_bolgesi)


def _is_gunu_mu(gun: date, politika: DataFreshnessPolicy) -> bool:
    return gun.weekday() < 5 and gun not in set(politika.kapali_tarihler)


def _onceki_is_gunu(gun: date, politika: DataFreshnessPolicy) -> date:
    aday = gun - timedelta(days=1)
    while not _is_gunu_mu(aday, politika):
        aday -= timedelta(days=1)
    return aday


def _is_gunu_mesafesi(
    baslangic: date,
    bitis: date,
    politika: DataFreshnessPolicy,
) -> int:
    if baslangic >= bitis:
        return 0
    sayi = 0
    aday = baslangic + timedelta(days=1)
    while aday <= bitis:
        if _is_gunu_mu(aday, politika):
            sayi += 1
        aday += timedelta(days=1)
    return sayi
