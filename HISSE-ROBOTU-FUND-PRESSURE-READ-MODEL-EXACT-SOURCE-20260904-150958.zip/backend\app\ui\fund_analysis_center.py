from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from decimal import Decimal
from typing import Any, Iterable, Mapping

from backend.app.funds.analysis_engine import FundAnalysisResult
from backend.app.funds.kap_portfolio_auto_ingestion import (
    auto_ingest_kap_portfolio_reports,
)
from backend.app.funds.kap_portfolio_ingestion import (
    KapFundPortfolioError,
    ingest_kap_portfolio_pdf_upload,
    ingest_kap_portfolio_report_url,
)
from backend.app.funds.portfolio_tracking import (
    FundPortfolioChangeSet,
    FundPortfolioSnapshot,
    FundPortfolioSnapshotJsonStore,
    PortfolioPositionChange,
    PortfolioSnapshotStoreError,
    PositionChangeKind,
    StockFundActivity,
    aggregate_stock_fund_activity,
    compare_portfolio_snapshots,
)
from backend.app.funds.pressure_risk import StockFundPressureInput, StockFundPressureProfile


@dataclass(frozen=True, slots=True)
class FundPortfolioTrackingReadModel:
    latest_by_fund: Mapping[str, FundPortfolioSnapshot]
    changes_by_fund: Mapping[str, FundPortfolioChangeSet]
    stock_activity: tuple[StockFundActivity, ...]


def fund_analysis_rows(results: Iterable[FundAnalysisResult]) -> tuple[dict[str, object], ...]:
    return tuple({
        "Fon": item.canonical_fund_id, "Kategori": item.category_id or "EŞLEŞMEMŞ",
        "Sınıf": item.classification.value, "Durum": item.class_label,
        "Pozitif": ", ".join(item.positive_families) or "-",
        "Nötr": ", ".join(item.neutral_families) or "-",
        "Dikkat": ", ".join(item.caution_families) or "-",
        "Eksik": ", ".join(item.unavailable_families) or "-",
        "Gerekçe": item.eligibility_reason,
    } for item in sorted(results, key=lambda x: (x.classification.value, x.canonical_fund_id)))


def _decimal_display(value: Decimal | None, *, digits: int = 2) -> float | None:
    if value is None:
        return None
    return round(float(value), digits)


def _percent_display(value: Decimal | None) -> float | None:
    if value is None:
        return None
    return _decimal_display(value * Decimal("100"))


def _latest_series_by_fund(
    snapshots: Iterable[FundPortfolioSnapshot],
) -> tuple[dict[str, FundPortfolioSnapshot], dict[str, FundPortfolioChangeSet]]:
    grouped: dict[str, list[FundPortfolioSnapshot]] = {}
    for snapshot in snapshots:
        grouped.setdefault(snapshot.canonical_fund_id, []).append(snapshot)

    latest_by_fund: dict[str, FundPortfolioSnapshot] = {}
    changes_by_fund: dict[str, FundPortfolioChangeSet] = {}
    for fund_id, candidates in grouped.items():
        latest = max(
            candidates,
            key=lambda item: (item.portfolio_date, item.publication_date, item.ingested_at, item.provider),
        )
        latest_by_fund[fund_id] = latest
        same_provider = sorted(
            (item for item in candidates if item.provider == latest.provider),
            key=lambda item: (item.portfolio_date, item.publication_date, item.ingested_at),
        )
        if len(same_provider) >= 2:
            changes_by_fund[fund_id] = compare_portfolio_snapshots(
                same_provider[-2],
                same_provider[-1],
            )
    return latest_by_fund, changes_by_fund


def build_fund_portfolio_tracking_read_model(
    store: FundPortfolioSnapshotJsonStore,
) -> FundPortfolioTrackingReadModel:
    snapshots = store.list_snapshots()
    latest_by_fund, changes_by_fund = _latest_series_by_fund(snapshots)
    return FundPortfolioTrackingReadModel(
        latest_by_fund=latest_by_fund,
        changes_by_fund=changes_by_fund,
        stock_activity=aggregate_stock_fund_activity(changes_by_fund.values()),
    )


def current_portfolio_rows(snapshot: FundPortfolioSnapshot) -> tuple[dict[str, object], ...]:
    positions = sorted(
        snapshot.positions,
        key=lambda item: (
            item.portfolio_weight is None,
            -(item.portfolio_weight or Decimal("0")),
            item.asset_type,
            item.symbol,
        ),
    )
    return tuple(
        {
            "Sembol": item.symbol,
            "Varlık Türü": item.asset_type,
            "Varlık": item.asset_name or "-",
            "Adet": _decimal_display(item.shares_held, digits=4),
            "Piyasa Değeri": _decimal_display(item.market_value),
            "Portföy %": _percent_display(item.portfolio_weight),
        }
        for item in positions
    )


def portfolio_change_rows(change_set: FundPortfolioChangeSet) -> tuple[dict[str, object], ...]:
    labels = {
        PositionChangeKind.NEW_ENTRY: "Yeni giriş",
        PositionChangeKind.INCREASED: "Artırıldı",
        PositionChangeKind.REDUCED: "Azaltıldı",
        PositionChangeKind.FULL_EXIT: "Tam çıkış",
        PositionChangeKind.UNCHANGED: "Değişmedi",
        PositionChangeKind.UNKNOWN: "Belirsiz",
    }
    return tuple(
        {
            "Hisse": item.symbol,
            "Durum": labels[item.kind],
            "Güven": item.confidence.value,
            "Önceki Adet": _decimal_display(item.previous_shares, digits=4),
            "Güncel Adet": _decimal_display(item.current_shares, digits=4),
            "Adet Değişimi": _decimal_display(item.share_change, digits=4),
            "Önceki %": _percent_display(item.previous_weight),
            "Güncel %": _percent_display(item.current_weight),
            "Ağırlık Δ pp": _decimal_display(item.weight_change_percentage_points),
            "Kanıt": item.reason,
        }
        for item in change_set.changes
    )


def stock_fund_activity_rows(items: Iterable[StockFundActivity]) -> tuple[dict[str, object], ...]:
    return tuple(
        {
            "Hisse": item.symbol,
            "Fon": item.current_fund_count,
            "Karşılaştırılabilir": item.comparable_fund_count,
            "Yeni": item.new_fund_count,
            "Tam Çıkış": item.exited_fund_count,
            "Artıran": item.increasing_fund_count,
            "Azaltan": item.decreasing_fund_count,
            "Belirsiz": item.unknown_fund_count,
            "Birikim Breadth %": _percent_display(item.accumulation_breadth),
            "Dağıtım Breadth %": _percent_display(item.distribution_breadth),
        }
        for item in items
    )


def fund_pressure_rows(
    profiles: Mapping[str, StockFundPressureProfile],
    inputs: Mapping[str, StockFundPressureInput] | None = None,
) -> tuple[dict[str, object], ...]:
    inputs = inputs or {}
    rows: list[dict[str, object]] = []
    for symbol, profile in sorted(profiles.items()):
        raw = inputs.get(symbol)
        rows.append({
            "Hisse": symbol,
            "Fon/FDO %": None if raw is None else _percent_display(raw.ownership.fund_free_float_ratio),
            "Likidasyon Normal (gün)": None if raw is None else _decimal_display(raw.liquidity.liquidation_days_normal),
            "Likidasyon Agresif (gün)": None if raw is None else _decimal_display(raw.liquidity.liquidation_days_aggressive),
            "Likidasyon Stres (gün)": None if raw is None else _decimal_display(raw.liquidity.liquidation_days_stress),
            "Fon Yoğunluğu": _decimal_display(profile.fund_concentration_risk.score),
            "Çıkış Zorluğu": _decimal_display(profile.exit_difficulty_risk.score),
            "Aktif Satış Baskısı": _decimal_display(profile.active_selling_pressure.score),
            "Veri Kalitesi": profile.data_quality_state.value,
            "Trade Authority": profile.automatic_trade_authority,
        })
    return tuple(rows)


def _render_portfolio_tracking(
    st: Any,
    store: FundPortfolioSnapshotJsonStore,
    pressure_profiles: Mapping[str, StockFundPressureProfile],
    pressure_inputs: Mapping[str, StockFundPressureInput],
    *,
    fund_codes: Iterable[str] = (),
) -> None:
    known_codes = {
        str(code or "").strip().upper()
        for code in fund_codes
        if str(code or "").strip()
    }
    try:
        for snapshot in store.list_snapshots():
            if snapshot.canonical_fund_id.startswith("fund:tefas:"):
                known_codes.add(snapshot.canonical_fund_id.rsplit(":", 1)[-1].strip().upper())
    except PortfolioSnapshotStoreError:
        pass

    if hasattr(st, "button"):
        st.markdown("#### Otomatik KAP Portföy Güncelleme")
        st.caption(
            "Fon Analiz Merkezi açılışta ağ çağrısı yapmaz. Bu düğme, bilinen fon kodları için "
            "resmî KAP bildirim listesini tarar; Portföy Dağılım Raporu bildirimini, ekini ve "
            "snapshot içe aktarımını otomatik yürütür. Manuel PDF yalnız fallback olarak kalır."
        )
        if known_codes:
            st.caption(f"Otomatik tarama evreni: {len(known_codes)} fon kodu.")
        else:
            st.caption("Otomatik tarama için önce TEFAS fon evreni veya kayıtlı bir fon snapshot'ı gerekir.")

        if st.button(
            "Yeni KAP Portföy Raporlarını Otomatik Tara",
            key="fund_portfolio_kap_auto_ingest_button",
            disabled=not known_codes,
        ):
            try:
                summary = auto_ingest_kap_portfolio_reports(
                    store=store,
                    fund_codes=tuple(sorted(known_codes)),
                    network_enabled=True,
                )
            except (KapFundPortfolioError, PortfolioSnapshotStoreError, ValueError) as exc:
                st.error(f"Otomatik KAP portföy güncellemesi çalışmadı: {exc}")
            else:
                if hasattr(st, "success"):
                    st.success(
                        "Otomatik KAP taraması tamamlandı · "
                        f"bulunan={summary.discovered} · "
                        f"yeni={summary.inserted} · "
                        f"zaten kayıtlı={summary.unchanged} · "
                        f"hata={len(summary.failures)}."
                    )
                if summary.failures and hasattr(st, "warning"):
                    preview = " | ".join(
                        f"{item.notification_id}: {item.error}"
                        for item in summary.failures[:5]
                    )
                    st.warning(f"İçe alınamayan KAP bildirimleri: {preview}")

    if hasattr(st, "text_input") and hasattr(st, "button"):
        st.markdown("#### KAP Portföy Raporu İçeri Aktar")
        st.caption(
            "Tekil resmî KAP Portföy Dağılım Raporu bildirim URL\'siyle manuel tetikleme yoludur. "
            "Ağ çağrısı yalnız bu düğmeye açıkça basıldığında yapılır."
        )
        kap_url = st.text_input(
            "KAP bildirim URL\'si",
            key="fund_portfolio_kap_detail_url",
            placeholder="https://www.kap.org.tr/tr/Bildirim/1234567",
        )
        if st.button(
            "KAP Portföy Snapshot\'ını İçeri Aktar",
            key="fund_portfolio_kap_ingest_button",
            disabled=not str(kap_url or "").strip(),
        ):
            try:
                ingestion = ingest_kap_portfolio_report_url(
                    str(kap_url).strip(),
                    store=store,
                    network_enabled=True,
                )
            except (KapFundPortfolioError, PortfolioSnapshotStoreError, ValueError) as exc:
                st.error(f"KAP fon portföyü içeri alınamadı: {exc}")
            else:
                status = "eklendi" if ingestion.store_result.inserted else "zaten kayıtlı"
                if hasattr(st, "success"):
                    st.success(
                        f"{ingestion.snapshot.canonical_fund_id} · "
                        f"{ingestion.snapshot.portfolio_date.isoformat()} snapshot {status}."
                    )

    if (
        hasattr(st, "file_uploader")
        and hasattr(st, "number_input")
        and hasattr(st, "date_input")
        and hasattr(st, "text_input")
        and hasattr(st, "button")
    ):
        st.markdown("##### Alternatif: KAP Portföy PDF Dosyası Yükle")
        st.caption(
            "Gerçek 'Portföy Dağılım Raporu' PDF eki gerekir. KAP bildirim sayfasının "
            "PDF çıktısı veya ekran görüntüsü portföy tablosu içermediği için yeterli değildir. "
            "Rapor dönemi ve KAP yayın tarihi kullanıcı tarafından açıkça doğrulanır."
        )
        uploaded_pdf = st.file_uploader(
            "Portföy dağılım PDF'si",
            type=["pdf"],
            key="fund_portfolio_kap_manual_pdf",
        )
        current_year = date.today().year
        report_year = int(st.number_input(
            "Rapor yılı",
            min_value=2000,
            max_value=2100,
            value=current_year,
            step=1,
            key="fund_portfolio_kap_manual_year",
        ))
        report_month = int(st.number_input(
            "Rapor ayı",
            min_value=1,
            max_value=12,
            value=max(1, date.today().month - 1),
            step=1,
            key="fund_portfolio_kap_manual_month",
        ))
        publication_date = st.date_input(
            "KAP yayın tarihi",
            value=date.today(),
            key="fund_portfolio_kap_manual_publication_date",
        )
        notification_id = st.text_input(
            "KAP bildirim numarası (opsiyonel)",
            key="fund_portfolio_kap_manual_notification_id",
            placeholder="1646130",
        )
        source_reference = st.text_input(
            "Kaynak referansı (opsiyonel)",
            key="fund_portfolio_kap_manual_source_reference",
            placeholder="KAP/Fintables/kurucu site URL veya kısa kaynak notu",
        )
        if st.button(
            "PDF'den Portföy Snapshot'ını İçeri Aktar",
            key="fund_portfolio_kap_manual_ingest_button",
            disabled=uploaded_pdf is None,
        ):
            try:
                ingestion = ingest_kap_portfolio_pdf_upload(
                    uploaded_pdf.getvalue(),
                    filename=getattr(uploaded_pdf, "name", "portfolio.pdf"),
                    report_year=report_year,
                    report_month=report_month,
                    publication_date=publication_date,
                    notification_id=str(notification_id or "").strip() or None,
                    source_reference=str(source_reference or "").strip() or None,
                    store=store,
                )
            except (KapFundPortfolioError, PortfolioSnapshotStoreError, ValueError) as exc:
                st.error(f"KAP PDF portföyü içeri alınamadı: {exc}")
            else:
                status = "eklendi" if ingestion.store_result.inserted else "zaten kayıtlı"
                if hasattr(st, "success"):
                    st.success(
                        f"{ingestion.snapshot.canonical_fund_id} · "
                        f"{ingestion.snapshot.portfolio_date.isoformat()} snapshot {status}. "
                        "İçe aktarım modu: MANUAL_PDF."
                    )

    try:
        model = build_fund_portfolio_tracking_read_model(store)
    except PortfolioSnapshotStoreError:
        st.error("Fon portföy snapshot deposu okunamadı; mevcut fon analiz sonuçları korunuyor.")
        return

    st.divider()
    st.subheader("Fon Portföy Takibi & Baskı Riski")
    st.caption(
        "Tarihli snapshot karşılaştırmasıdır. Ağırlık değişimi tek başına doğrulanmış alım/satım sayılmaz; "
        "bu ekran otomatik AL/SAT üretmez."
    )

    if not model.latest_by_fund:
        st.info("Henüz tarihli fon portföy snapshot verisi yok.")
    else:
        fund_ids = tuple(sorted(model.latest_by_fund))
        selected_fund = st.selectbox(
            "Fon portföyü",
            options=fund_ids,
            index=0,
            key="fund_portfolio_tracking_selected_fund",
        )
        latest = model.latest_by_fund[selected_fund]
        columns = st.columns(5)
        columns[0].metric("Portföy tarihi", latest.portfolio_date.isoformat())
        columns[1].metric("Yayın tarihi", latest.publication_date.isoformat())
        columns[2].metric("Yayın gecikmesi", f"{(latest.publication_date - latest.portfolio_date).days} gün")
        columns[3].metric("Provider", latest.provider)
        columns[4].metric("Veri kalitesi", latest.data_quality_state.value)
        if latest.source_reference:
            st.caption(f"Kaynak: {latest.source_reference}")

        st.markdown("#### Güncel Portföy")
        current_rows = current_portfolio_rows(latest)
        if current_rows:
            st.dataframe(current_rows, width="stretch", hide_index=True)
        else:
            st.info("Bu snapshot içinde gösterilecek hisse pozisyonu yok.")

        st.markdown("#### Portföy Değişimleri")
        change_set = model.changes_by_fund.get(selected_fund)
        if change_set is None:
            st.info("Değişim karşılaştırması için aynı provider'dan en az iki snapshot gerekir.")
        else:
            change_counts = {kind: sum(item.kind is kind for item in change_set.changes) for kind in PositionChangeKind}
            summary_columns = st.columns(5)
            summary_columns[0].metric("Yeni giriş", change_counts[PositionChangeKind.NEW_ENTRY])
            summary_columns[1].metric("Artırılan", change_counts[PositionChangeKind.INCREASED])
            summary_columns[2].metric("Azaltılan", change_counts[PositionChangeKind.REDUCED])
            summary_columns[3].metric("Tam çıkış", change_counts[PositionChangeKind.FULL_EXIT])
            summary_columns[4].metric("Belirsiz", change_counts[PositionChangeKind.UNKNOWN])
            all_rows = portfolio_change_rows(change_set)
            selected_states = st.multiselect(
                "Değişim türü",
                options=("Yeni giriş", "Artırıldı", "Azaltıldı", "Tam çıkış", "Değişmedi", "Belirsiz"),
                default=("Yeni giriş", "Artırıldı", "Azaltıldı", "Tam çıkış", "Belirsiz"),
                key="fund_portfolio_change_filter",
            )
            filtered = [row for row in all_rows if row["Durum"] in selected_states]
            if filtered:
                st.dataframe(filtered, width="stretch", hide_index=True)
            else:
                st.info("Seçili değişim türlerinde kayıt yok.")

        st.markdown("#### Hisse Bazlı Fon Hareketleri")
        activity_rows = stock_fund_activity_rows(model.stock_activity)
        if activity_rows:
            st.dataframe(activity_rows, width="stretch", hide_index=True)
        else:
            st.info("Hisse bazlı birikim/dağıtım için karşılaştırılabilir snapshot henüz yok.")

    st.markdown("#### Fon/FDO & Baskı Riski")
    risk_rows = fund_pressure_rows(pressure_profiles, pressure_inputs)
    if risk_rows:
        st.dataframe(risk_rows, width="stretch", hide_index=True)
    else:
        st.info(
            "Risk profilini göstermek için Fon/FDO, likidite ve fiyat/hacim girdilerinin production read model'e bağlanması bekleniyor."
        )


def render_fund_analysis_center(
    st: Any,
    results: Iterable[FundAnalysisResult] = (),
    *,
    portfolio_store: FundPortfolioSnapshotJsonStore | None = None,
    pressure_profiles: Mapping[str, StockFundPressureProfile] | None = None,
    pressure_inputs: Mapping[str, StockFundPressureInput] | None = None,
) -> None:
    items = tuple(results)
    st.subheader("Fon Analiz Merkezi")
    st.caption("TEFAS/fon araştırma dikeyidir. BIST taraması çalıştırmaz; otomatik AL/SAT üretmez.")
    counts = {key: sum(item.classification.value == key for item in items) for key in "ABCDX"}
    for column, key in zip(st.columns(5), "ABCDX"):
        column.metric(key, counts[key])
    selected = st.multiselect("Fon sınıfı", options=tuple("ABCDX"), default=tuple("ABCDX"), key="fund_analysis_class_filter")
    rows = [row for row in fund_analysis_rows(items) if row["Sınıf"] in selected]
    if rows:
        st.dataframe(rows, width="stretch", hide_index=True)
    else:
        st.info("Henüz gösterilecek canonical fon analiz sonucu yok.")
    st.caption("Forward takip: 1H / 1A / 3A · outcome tuning kapalı · AL/SAT authority: NONE")

    if portfolio_store is not None or pressure_profiles:
        known_fund_codes = tuple(
            sorted({
                item.canonical_fund_id.rsplit(":", 1)[-1]
                for item in items
                if item.canonical_fund_id.startswith("fund:tefas:")
            })
        )
        _render_portfolio_tracking(
            st,
            portfolio_store if portfolio_store is not None else _EmptyPortfolioStore(),
            pressure_profiles or {},
            pressure_inputs or {},
            fund_codes=known_fund_codes,
        )


class _EmptyPortfolioStore(FundPortfolioSnapshotJsonStore):
    def __init__(self) -> None:
        pass

    def list_snapshots(self) -> tuple[FundPortfolioSnapshot, ...]:
        return ()
