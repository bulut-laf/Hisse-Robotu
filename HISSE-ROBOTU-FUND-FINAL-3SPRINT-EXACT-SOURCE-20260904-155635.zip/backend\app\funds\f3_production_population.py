from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from time import sleep

from dataclasses import dataclass
from typing import Iterable, Mapping

from . import tefas_history_population as history_population
from .f3_store_read_model import price_histories_from_store
from .normalization import normalize_fund_code
from .store import (
    FundObservationJsonStore,
    fund_observation_store,
)
from .tefas_adapter import (
    canonical_tefas_fund_id,
    fetch_tefas_universe_rows,
)
from .tefas_history_population import (
    populate_tefas_history_batch,
)


MAXIMUM_PRODUCTION_BATCH_SIZE = 50


@dataclass(frozen=True, slots=True)
class F3ProductionPopulationResult:
    selected_funds: tuple[str, ...]
    succeeded_funds: tuple[str, ...]
    failed_funds: tuple[str, ...]
    observation_count: int
    inserted: int
    updated: int
    unchanged: int
    total_records: int

    @property
    def status(self) -> str:
        if not self.selected_funds:
            return "ALREADY_COMPLETE"

        if not self.succeeded_funds:
            return "NO_PROGRESS"

        if self.failed_funds:
            return "PARTIAL"

        return "COMPLETE"


def _pick_code(
    row: Mapping[str, object],
) -> str:
    lookup = {
        str(key).casefold(): value
        for key, value in row.items()
    }

    for name in (
        "fonkod",
        "fonkodu",
        "fund_code",
        "provider_fund_id",
        "code",
    ):
        value = lookup.get(
            name.casefold()
        )

        if value not in (None, ""):
            return normalize_fund_code(
                value
            )

    raise ValueError(
        "F3_UNIVERSE_FUND_CODE_MISSING"
    )


def universe_codes(
    rows: Iterable[Mapping[str, object]],
) -> tuple[str, ...]:
    return tuple(
        sorted(
            {
                _pick_code(row)
                for row in rows
            }
        )
    )


def completed_f3_codes(
    store: FundObservationJsonStore,
) -> frozenset[str]:
    histories = price_histories_from_store(
        store
    )

    result: set[str] = set()

    for canonical_id, prices in histories.items():
        if len(prices) < 3:
            continue

        prefix = "fund:tefas:"

        if not canonical_id.startswith(
            prefix
        ):
            continue

        result.add(
            canonical_id[
                len(prefix):
            ]
        )

    return frozenset(result)


def select_next_f3_batch(
    rows: Iterable[Mapping[str, object]],
    *,
    store: FundObservationJsonStore,
    batch_size: int = MAXIMUM_PRODUCTION_BATCH_SIZE,
    excluded_fund_codes: Iterable[object] = (),
) -> tuple[str, ...]:
    if (
        batch_size < 1
        or batch_size > MAXIMUM_PRODUCTION_BATCH_SIZE
    ):
        raise ValueError(
            f"F3_PRODUCTION_BATCH_SIZE_INVALID:"
            f"{batch_size}"
        )

    completed = completed_f3_codes(
        store
    )

    excluded = frozenset(
        normalize_fund_code(code)
        for code in excluded_fund_codes
    )

    missing = tuple(
        code
        for code in universe_codes(rows)
        if (
            code not in completed
            and code not in excluded
        )
    )

    return missing[:batch_size]


def populate_next_f3_production_batch(
    *,
    batch_size: int = MAXIMUM_PRODUCTION_BATCH_SIZE,
    timeout_seconds: int = 10,
    store: FundObservationJsonStore | None = None,
    excluded_fund_codes: Iterable[object] = (),
    worker_count: int = 2,
    retry_attempts: int = 3,
    retry_backoff_seconds: float = 1.0,
) -> F3ProductionPopulationResult:
    """
    Provider-friendly bounded F3 population.

    - max 2 concurrent TEFAS history calls
    - transient reset/timeout retry only
    - data/schema errors are not retried
    - one store upsert per successful batch
    """
    if worker_count < 1 or worker_count > 2:
        raise ValueError(
            f"F3_WORKER_COUNT_INVALID:{worker_count}"
        )

    if retry_attempts < 1 or retry_attempts > 5:
        raise ValueError(
            f"F3_RETRY_ATTEMPTS_INVALID:{retry_attempts}"
        )

    if retry_backoff_seconds < 0:
        raise ValueError(
            "F3_RETRY_BACKOFF_INVALID"
        )

    target_store = (
        store
        if store is not None
        else fund_observation_store()
    )

    rows = fetch_tefas_universe_rows()

    selected = select_next_f3_batch(
        rows,
        store=target_store,
        batch_size=batch_size,
        excluded_fund_codes=excluded_fund_codes,
    )

    if not selected:
        return F3ProductionPopulationResult(
            selected_funds=(),
            succeeded_funds=(),
            failed_funds=(),
            observation_count=0,
            inserted=0,
            updated=0,
            unchanged=0,
            total_records=len(
                target_store.list_records()
            ),
        )

    stamp = datetime.now(
        timezone.utc
    )

    observations_by_code = {}
    failures_by_code = {}

    def fetch_one(code: str):
        for attempt in range(
            1,
            retry_attempts + 1,
        ):
            try:
                history_rows = (
                    history_population
                    .fetch_tefas_fund_history_rows(
                        code,
                        period=1,
                        timeout_seconds=timeout_seconds,
                    )
                )

                observations = (
                    history_population
                    .history_rows_to_observations(
                        history_rows,
                        fund_code=code,
                        fetched_at=stamp,
                        source_as_of=stamp,
                    )
                )

                return code, observations

            except (
                ConnectionResetError,
                TimeoutError,
            ):
                if attempt >= retry_attempts:
                    raise

                delay = (
                    retry_backoff_seconds
                    * (2 ** (attempt - 1))
                )

                if delay:
                    sleep(delay)

        raise RuntimeError(
            "F3_RETRY_STATE_INVALID"
        )

    with ThreadPoolExecutor(
        max_workers=min(
            worker_count,
            len(selected),
        )
    ) as executor:

        future_to_code = {
            executor.submit(
                fetch_one,
                code,
            ): code
            for code in selected
        }

        for future in as_completed(
            future_to_code
        ):
            code = future_to_code[
                future
            ]

            try:
                returned_code, observations = (
                    future.result()
                )
            except Exception as exc:
                failures_by_code[code] = (
                    f"{code}:"
                    f"{type(exc).__name__}:"
                    f"{exc}"
                )
                continue

            observations_by_code[
                returned_code
            ] = observations

    succeeded = tuple(
        code
        for code in selected
        if code in observations_by_code
    )

    failed = tuple(
        failures_by_code[code]
        for code in selected
        if code in failures_by_code
    )

    observations = tuple(
        observation
        for code in succeeded
        for observation
        in observations_by_code[code]
    )

    if observations:
        stored = target_store.upsert(
            observations
        )

        inserted = stored.inserted
        updated = stored.updated
        unchanged = stored.unchanged
        total_records = stored.total_records
    else:
        inserted = 0
        updated = 0
        unchanged = 0
        total_records = len(
            target_store.list_records()
        )

    return F3ProductionPopulationResult(
        selected_funds=selected,
        succeeded_funds=succeeded,
        failed_funds=failed,
        observation_count=len(
            observations
        ),
        inserted=inserted,
        updated=updated,
        unchanged=unchanged,
        total_records=total_records,
    )
