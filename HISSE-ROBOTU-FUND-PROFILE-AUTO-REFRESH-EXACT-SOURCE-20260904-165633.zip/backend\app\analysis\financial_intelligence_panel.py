from __future__ import annotations

from datetime import datetime
from decimal import Decimal

from ..models.investability_models import IntelligencePanelPayload, InvestabilityResult


def build_financial_intelligence_panel(
    *,
    symbol: str,
    as_of: datetime,
    financial_health_score: int | None,
    financial_health_grade: str,
    financial_risk: str,
    short_term: InvestabilityResult,
    long_term: InvestabilityResult,
    current_price: Decimal | None = None,
    bear_value: Decimal | None = None,
    base_value: Decimal | None = None,
    bull_value: Decimal | None = None,
    valuation_status: str | None = None,
    margin_of_safety_status: str | None = None,
    confidence: str = "LOW",
    extra_strengths: tuple[str, ...] = (),
    extra_risks: tuple[str, ...] = (),
    what_to_watch_next: tuple[str, ...] = (),
) -> IntelligencePanelPayload:
    upside = None
    if current_price is not None and base_value is not None and current_price > 0:
        upside = (base_value / current_price) - Decimal("1")

    strengths = tuple(dict.fromkeys((*short_term.strengths, *long_term.strengths, *extra_strengths)))
    risks = tuple(dict.fromkeys((*short_term.risks, *long_term.risks, *extra_risks)))

    return IntelligencePanelPayload(
        symbol=symbol,
        as_of=as_of,
        financial_health_score=financial_health_score,
        financial_health_grade=financial_health_grade,
        financial_risk=financial_risk,
        valuation_status=valuation_status,
        current_price=current_price,
        bear_value=bear_value,
        base_value=base_value,
        bull_value=bull_value,
        upside_downside_to_base=upside,
        margin_of_safety_status=margin_of_safety_status,
        short_term_score=short_term.score,
        short_term_label=short_term.label,
        long_term_score=long_term.score,
        long_term_label=long_term.label,
        confidence=confidence,
        strengths=strengths,
        risks=risks,
        what_to_watch_next=what_to_watch_next,
        read_only=True,
    )
