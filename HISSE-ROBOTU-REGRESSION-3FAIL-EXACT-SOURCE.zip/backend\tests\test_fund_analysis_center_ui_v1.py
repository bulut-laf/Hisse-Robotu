﻿from backend.app.funds.analysis_engine import FundAnalysisClass, FundAnalysisResult
from backend.app.ui.fund_analysis_center import fund_analysis_rows, render_fund_analysis_center


def item():
    return FundAnalysisResult("fund:tefas:AAA", "equity", FundAnalysisClass.A, "GL / NCELKL",
        ("F1", "F2", "F3", "F4"), ("F5",), (), (), "BROAD_STRENGTH", "kanıt")


class Column:
    def metric(self, *_args, **_kwargs): pass


class Stub:
    def __init__(self): self.info_messages = []; self.frames = []
    def subheader(self, *_args): pass
    def caption(self, *_args): pass
    def columns(self, count): return [Column() for _ in range(count)]
    def multiselect(self, _label, options, default, key): return default
    def dataframe(self, rows, **_kwargs): self.frames.append(rows)
    def info(self, message): self.info_messages.append(message)


def test_rows_are_research_only():
    row = fund_analysis_rows((item(),))[0]
    assert row["Sınıf"] == "A" and "AL" not in row and "SAT" not in row


def test_empty_and_populated_states():
    empty = Stub(); render_fund_analysis_center(empty, ())
    full = Stub(); render_fund_analysis_center(full, (item(),))
    assert empty.info_messages and full.frames
