﻿from __future__ import annotations

from typing import Any, Iterable

from backend.app.funds.analysis_engine import FundAnalysisResult


def fund_analysis_rows(results: Iterable[FundAnalysisResult]) -> tuple[dict[str, object], ...]:
    return tuple({
        "Fon": item.canonical_fund_id, "Kategori": item.category_id or "EŞLEŞMEMŞ",
        "Sınıf": item.classification.value, "Durum": item.class_label,
        "Pozitif": ", ".join(item.positive_families) or "-",
        "Nötr": ", ".join(item.neutral_families) or "-",
        "Dikkat": ", ".join(item.caution_families) or "-",
        "Eksik": ", ".join(item.unavailable_families) or "-",
        "Gerekçe": item.eligibility_reason,
    } for item in sorted(results, key=lambda x: (x.classification.value, x.canonical_fund_id)))


def render_fund_analysis_center(st: Any, results: Iterable[FundAnalysisResult] = ()) -> None:
    items = tuple(results)
    st.subheader("Fon Analiz Merkezi")
    st.caption("TEFAS/fon araştırma dikeyidir. BIST taraması çalıştırmaz; otomatik AL/SAT üretmez.")
    counts = {key: sum(item.classification.value == key for item in items) for key in "ABCDX"}
    for column, key in zip(st.columns(5), "ABCDX"):
        column.metric(key, counts[key])
    selected = st.multiselect("Fon sınıfı", options=tuple("ABCDX"), default=tuple("ABCDX"), key="fund_analysis_class_filter")
    rows = [row for row in fund_analysis_rows(items) if row["Sınıf"] in selected]
    if rows:
        st.dataframe(rows, width="stretch", hide_index=True)
    else:
        st.info("Henüz gösterilecek canonical fon analiz sonucu yok.")
    st.caption("Forward takip: 1H / 1A / 3A · outcome tuning kapalı · AL/SAT authority: NONE")
