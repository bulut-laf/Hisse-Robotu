TURBO-15 Market Scan Snapshot

Amaç:
Mevcut BIST günlük tarama sonucunu kalıcı snapshot olarak saklamak.

Akış:
Akşam tarama
 -> snapshot
 -> sabah açılış
 -> mevcut sonucu kullan
 -> yeni veri varsa mevcut taramayı tekrar çalıştır

Yeni skor motoru yok.
Yeni analiz zinciri yok.
