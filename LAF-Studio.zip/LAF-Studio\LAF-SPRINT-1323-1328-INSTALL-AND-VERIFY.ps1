﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$panel = Join-Path $app "src\ui\learning\A1ConnectNativeLearningPanel.tsx"

if (-not (Test-Path $panel)) {
    throw "A1ConnectNativeLearningPanel.tsx missing."
}

$utf8 = New-Object System.Text.UTF8Encoding($false)
$text = [System.IO.File]::ReadAllText(
    $panel,
    $utf8
)

$importLine =
    'import { A1ConnectGreetingComprehensionTaskPanel } from "./A1ConnectGreetingComprehensionTaskPanel";'

if (-not $text.Contains($importLine)) {
    $anchor =
        'import { A1ConnectLanguageContentPanel } from "./A1ConnectLanguageContentPanel";'

    if (-not $text.Contains($anchor)) {
        throw "A1 CONNECT task import anchor not found."
    }

    $text = $text.Replace(
        $anchor,
        $anchor +
        [Environment]::NewLine +
        $importLine
    )
}

$renderMarker =
    '<A1ConnectGreetingComprehensionTaskPanel'

if (-not $text.Contains($renderMarker)) {
    $anchor = '      <div className="a1-connect-native-gate">'

    if (-not $text.Contains($anchor)) {
        throw "A1 CONNECT task render anchor not found."
    }

    $render = @'
      {selectedLanguageCode &&
      selectedLesson?.lessonId ===
        "a1-connect-greeting-response" ? (
        <A1ConnectGreetingComprehensionTaskPanel
          languageCode={selectedLanguageCode}
        />
      ) : null}

'@

    $text = $text.Replace(
        $anchor,
        $render + $anchor
    )
}

# Update the visible gate text now that content exists and the first real task is executable.
$text = $text.Replace(
    '"Dil seçildi; içerik paketi bekleniyor"',
    '"Dil seçildi; ilk gerçek görev kullanılabilir"'
)
$text = $text.Replace(
    '"Dil İçeriği Bekleniyor"',
    '"İlk Görev Yukarıda"'
)

[System.IO.File]::WriteAllText(
    $panel,
    $text,
    $utf8
)

$task = Join-Path $app "src\core\learning\CefrA1ConnectGreetingComprehensionTask.ts"
$evaluation = Join-Path $app "src\application\learning\CefrA1ConnectGreetingComprehensionEvaluation.ts"
$completion = Join-Path $app "src\application\learning\CefrA1ConnectGreetingTaskCompletionService.ts"
$taskPanel = Join-Path $app "src\ui\learning\A1ConnectGreetingComprehensionTaskPanel.tsx"
$safety = Join-Path $app "src\core\learning\CefrA1ConnectExecutableTaskSafety.ts"

foreach ($file in @(
    $task,
    $evaluation,
    $completion,
    $taskPanel,
    $safety
)) {
    if (-not (Test-Path $file)) {
        throw "Sprint 1323-1328 source missing: $file"
    }
}

$checks = @{
    $task = @(
        '"a1-connect-evidence-greeting-comprehension"',
        'evidenceOnCorrectSubmissionOnly: true'
    )
    $evaluation = @(
        'evidenceEligible: correct',
        'masteryAssigned: false'
    )
    $completion = @(
        'if (!evaluation.evidenceEligible)',
        'recordUserEvidence({',
        'userActionConfirmed:'
    )
    $taskPanel = @(
        'Cevabı Kontrol Et',
        'Kanıt',
        'service.submit({'
    )
    $panel = @(
        'A1ConnectGreetingComprehensionTaskPanel',
        '"a1-connect-greeting-response"',
        'languageCode={selectedLanguageCode}'
    )
    $safety = @(
        'incorrectAnswerCreatesEvidence:',
        'false',
        'correctSubmissionMayCreateEvidence:',
        'true'
    )
}

foreach ($entry in $checks.GetEnumerator()) {
    foreach ($marker in $entry.Value) {
        if (-not (
            Select-String `
                -Path $entry.Key `
                -SimpleMatch `
                -Pattern $marker `
                -Quiet
        )) {
            throw "Required Sprint 1323-1328 marker missing: $marker"
        }
    }
}

Write-Host "SPRINT-1323-1328 SOURCE CHECK PASSED"

Set-Location $app

$targets = @(
    "src/core/learning/CefrA1ConnectGreetingComprehensionTask.test.ts",
    "src/application/learning/CefrA1ConnectGreetingComprehensionEvaluation.test.ts",
    "src/application/learning/CefrA1ConnectGreetingTaskCompletionService.test.ts",
    "src/core/learning/CefrA1ConnectExecutableTaskSafety.test.ts",
    "src/ui/learning/A1ConnectGreetingComprehensionTaskPanel.test.ts",
    "src/application/learning/CefrA1ConnectRuntimeEvidenceService.test.ts",
    "src/core/learning/CefrA1ConnectLanguageContentRegistry.test.ts",
    "src/application/learning/CefrA1ConnectLanguageContentView.test.ts"
)

& npx vitest run $targets
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1323-1328 target tests failed."
}

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Full regression failed."
}

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Production build failed."
}

Write-Host "SPRINT-1323-1328 VERIFICATION COMPLETE"
