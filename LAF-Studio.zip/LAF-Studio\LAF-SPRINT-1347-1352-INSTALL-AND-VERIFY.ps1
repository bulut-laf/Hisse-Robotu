﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$panel = Join-Path $app "src\ui\learning\A1ConnectNativeLearningPanel.tsx"

if (-not (Test-Path $panel)) {
    throw "A1ConnectNativeLearningPanel.tsx missing."
}

$utf8 =
    New-Object System.Text.UTF8Encoding($false)

$text =
    [System.IO.File]::ReadAllText(
        $panel,
        $utf8
    )

$importLine =
    'import { A1ConnectUnitRuntimePanel } from "./A1ConnectUnitRuntimePanel";'

if (-not $text.Contains($importLine)) {
    $anchor =
        'import { A1ConnectExtendedTaskPanel } from "./A1ConnectExtendedTaskPanel";'

    if (-not $text.Contains($anchor)) {
        throw "Unit runtime import anchor not found."
    }

    $text = $text.Replace(
        $anchor,
        $anchor +
        [Environment]::NewLine +
        $importLine
    )
}

$renderMarker =
    '<A1ConnectUnitRuntimePanel'

if (-not $text.Contains($renderMarker)) {
    $anchor =
        '      <div className="a1-connect-native-gate">'

    if (-not $text.Contains($anchor)) {
        throw "Unit runtime render anchor not found."
    }

    $render = @'
      {selectedLanguageCode ? (
        <A1ConnectUnitRuntimePanel
          languageCode={selectedLanguageCode}
        />
      ) : null}

'@

    $text = $text.Replace(
        $anchor,
        $render + $anchor
    )
}

[System.IO.File]::WriteAllText(
    $panel,
    $text,
    $utf8
)

$coverage = Join-Path $app "src\core\learning\CefrA1ConnectEvidenceCoverage.ts"
$readModel = Join-Path $app "src\application\learning\CefrA1ConnectEvidenceCoverageReadModel.ts"
$activation = Join-Path $app "src\core\learning\CefrA1ConnectGuidedRealLifeActivation.ts"
$runtimePanel = Join-Path $app "src\ui\learning\A1ConnectUnitRuntimePanel.tsx"
$safety = Join-Path $app "src\core\learning\CefrA1ConnectUnitRuntimeSafety.ts"

foreach ($file in @(
    $coverage,
    $readModel,
    $activation,
    $runtimePanel,
    $safety
)) {
    if (-not (Test-Path $file)) {
        throw "Sprint 1347-1352 source missing: $file"
    }
}

$checks = @{
    $coverage = @(
        'totalImmediateEvidenceCount: 6',
        'progressOnly: true',
        'masteryInferred: false'
    )
    $activation = @(
        'guidedRehearsalOnly: true',
        'activationCreatesEvidence: false',
        'progressionTriggered: false'
    )
    $runtimePanel = @(
        'Durumu Yenile',
        'Delayed Retrieval · Bekliyor',
        'Provayı Başlat'
    )
    $panel = @(
        'A1ConnectUnitRuntimePanel',
        'languageCode={selectedLanguageCode}'
    )
    $safety = @(
        'evidenceCoverageEqualsMastery:',
        'false',
        'activationCreatesEvidence: false'
    )
}

foreach ($entry in $checks.GetEnumerator()) {
    foreach ($marker in $entry.Value) {
        if (-not (
            Select-String `
                -Path $entry.Key `
                -SimpleMatch `
                -Pattern $marker `
                -Quiet
        )) {
            throw "Required Sprint 1347-1352 marker missing: $marker"
        }
    }
}

Write-Host "SPRINT-1347-1352 SOURCE CHECK PASSED"

Set-Location $app

$targets = @(
    "src/core/learning/CefrA1ConnectEvidenceCoverage.test.ts",
    "src/application/learning/CefrA1ConnectEvidenceCoverageReadModel.test.ts",
    "src/core/learning/CefrA1ConnectGuidedRealLifeActivation.test.ts",
    "src/core/learning/CefrA1ConnectUnitRuntimeSafety.test.ts",
    "src/ui/learning/A1ConnectUnitRuntimePanel.test.ts",
    "src/core/learning/CefrA1ConnectDelayedRetrievalCandidate.test.ts",
    "src/core/learning/CefrA1ConnectDelayedRetrievalTimingBoundary.test.ts",
    "src/application/learning/CefrA1ConnectRuntimeEvidenceService.test.ts"
)

& npx vitest run $targets
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1347-1352 target tests failed."
}

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Full regression failed."
}

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Production build failed."
}

Write-Host "SPRINT-1347-1352 VERIFICATION COMPLETE"
