﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

$state = Join-Path $app "src\core\learning\CefrA1ConnectSessionState.ts"
$repo = Join-Path $app "src\application\learning\CefrA1ConnectSessionStateRepository.ts"
$next = Join-Path $app "src\core\learning\CefrA1ConnectAdvisoryNextStep.ts"
$continuity = Join-Path $app "src\ui\learning\A1ConnectContinuityPanel.tsx"
$panel = Join-Path $app "src\ui\learning\A1ConnectNativeLearningPanel.tsx"

foreach ($file in @(
    $state,
    $repo,
    $next,
    $continuity,
    $panel
)) {
    if (-not (Test-Path $file)) {
        throw "Sprint 1353-1358 Rev1 source missing: $file"
    }
}

$checks = @{
    $state = @(
        'learningDecisionClaimed: false',
        'masteryClaimed: false',
        'cefrLevelClaimed: false'
    )
    $repo = @(
        'laf.cefr.a1-connect.session.v1',
        'saveSelection('
    )
    $next = @(
        'advisoryOnly: true',
        'automaticLessonSelection: false',
        'automaticProgression: false'
    )
    $continuity = @(
        'Seçimi Hatırla',
        'SIRADAKİ ÖNERİ',
        'otomatik seçilmez',
        'otomatik yapılmaz'
    )
    $panel = @(
        'A1ConnectContinuityPanel',
        'selectedLanguageCode={selectedLanguageCode}'
    )
}

foreach ($entry in $checks.GetEnumerator()) {
    foreach ($marker in $entry.Value) {
        if (-not (
            Select-String `
                -Path $entry.Key `
                -SimpleMatch `
                -Pattern $marker `
                -Quiet
        )) {
            throw "Required Sprint 1353-1358 Rev1 marker missing: $marker"
        }
    }
}

Write-Host "SPRINT-1353-1358 REV1 SOURCE CHECK PASSED"

Set-Location $app

$targets = @(
    "src/core/learning/CefrA1ConnectSessionState.test.ts",
    "src/application/learning/CefrA1ConnectSessionStateRepository.test.ts",
    "src/core/learning/CefrA1ConnectAdvisoryNextStep.test.ts",
    "src/core/learning/CefrA1ConnectContinuitySafety.test.ts",
    "src/ui/learning/A1ConnectContinuityPanel.test.ts",
    "src/core/learning/CefrA1ConnectEvidenceCoverage.test.ts",
    "src/application/learning/CefrA1ConnectEvidenceCoverageReadModel.test.ts",
    "src/core/learning/CefrA1ConnectUnitRuntimeSafety.test.ts"
)

& npx vitest run $targets
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1353-1358 Rev1 target tests failed."
}

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Full regression failed."
}

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Production build failed."
}

Write-Host "SPRINT-1353-1358 REV1 VERIFICATION COMPLETE"
