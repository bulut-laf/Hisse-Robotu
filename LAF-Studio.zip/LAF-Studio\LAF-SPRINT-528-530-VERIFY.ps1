$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

Set-Location $app

Write-Host "=== Sprint 528-530 Target Tests ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceSubstantiation.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceSubstantiationCoordination.test.ts" `
  "src/core/learning/CefrEvidenceSubstantiationAwareCefrIntelligencePlatform.test.ts"

if ($LASTEXITCODE -ne 0) {
  throw "Sprint 528-530 target tests failed."
}

Write-Host "=== Full Regression ==="
npm run test

if ($LASTEXITCODE -ne 0) {
  throw "Full regression failed."
}

Write-Host "=== Production Build ==="
npm run build

if ($LASTEXITCODE -ne 0) {
  throw "Production build failed."
}

Write-Host "SPRINT-528-530 VERIFICATION COMPLETE"
