import type {
  TranslationLanguageCode,
} from "../../core/translation/TranslationDraft";

export interface TranslationGrammarTeacherGuideRequest {
  sourceLanguage: TranslationLanguageCode;
  focusTerm: string;
  contextSentence: string;
  pattern: string;
  functionText: string;
  explanation: string;
}

export interface TranslationGrammarTeacherGuideExample {
  sourceText: string;
  targetText: string;
}

export interface TranslationGrammarTeacherGuide {
  simpleExplanation: string;
  whyHere: string;
  examples: TranslationGrammarTeacherGuideExample[];
  commonMistake: string;
}

export type TranslationGrammarTeacherGuideIssueCode =
  | "invalid-response"
  | "missing-simple-explanation"
  | "missing-why-here"
  | "invalid-examples"
  | "missing-common-mistake";

export interface TranslationGrammarTeacherGuideIssue {
  code: TranslationGrammarTeacherGuideIssueCode;
}

export type TranslationGrammarTeacherGuidePreparation =
  | {
      status: "ready";
      guide: TranslationGrammarTeacherGuide;
      issues: [];
    }
  | {
      status: "blocked";
      guide?: never;
      issues: TranslationGrammarTeacherGuideIssue[];
    };

const isRecord = (
  value: unknown,
): value is Record<string, unknown> =>
  typeof value === "object" &&
  value !== null &&
  !Array.isArray(value);

const prepareExample = (
  value: unknown,
): TranslationGrammarTeacherGuideExample | undefined => {
  if (!isRecord(value)) {
    return undefined;
  }

  const sourceText =
    typeof value.sourceText === "string"
      ? value.sourceText.trim()
      : "";
  const targetText =
    typeof value.targetText === "string"
      ? value.targetText.trim()
      : "";

  if (!sourceText || !targetText) {
    return undefined;
  }

  return {
    sourceText,
    targetText,
  };
};

export function prepareTranslationGrammarTeacherGuide(
  value: unknown,
): TranslationGrammarTeacherGuidePreparation {
  if (!isRecord(value)) {
    return {
      status: "blocked",
      issues: [
        {
          code: "invalid-response",
        },
      ],
    };
  }

  const simpleExplanation =
    typeof value.simpleExplanation === "string"
      ? value.simpleExplanation.trim()
      : "";
  const whyHere =
    typeof value.whyHere === "string"
      ? value.whyHere.trim()
      : "";
  const commonMistake =
    typeof value.commonMistake === "string"
      ? value.commonMistake.trim()
      : "";
  const examples =
    Array.isArray(value.examples)
      ? value.examples
          .map(prepareExample)
          .filter(
            (
              item,
            ): item is TranslationGrammarTeacherGuideExample =>
              item !== undefined,
          )
          .slice(0, 3)
      : [];

  const issues: TranslationGrammarTeacherGuideIssue[] =
    [];

  if (!simpleExplanation) {
    issues.push({
      code: "missing-simple-explanation",
    });
  }

  if (!whyHere) {
    issues.push({
      code: "missing-why-here",
    });
  }

  if (examples.length === 0) {
    issues.push({
      code: "invalid-examples",
    });
  }

  if (!commonMistake) {
    issues.push({
      code: "missing-common-mistake",
    });
  }

  if (issues.length > 0) {
    return {
      status: "blocked",
      issues,
    };
  }

  return {
    status: "ready",
    issues: [],
    guide: {
      simpleExplanation,
      whyHere,
      examples,
      commonMistake,
    },
  };
}
