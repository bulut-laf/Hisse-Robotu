﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$src = Join-Path $app "src"
$out = Join-Path $root "LAF_UI_INTEGRATION_DISCOVERY.txt"

if (-not (Test-Path $src)) {
    throw "Source root not found: $src"
}

$report = New-Object System.Collections.Generic.List[string]

function Add-Line {
    param([string]$Text)
    if ($null -eq $Text) {
        $Text = ""
    }
    [void]$report.Add($Text)
}

function Add-Section {
    param([string]$Title)
    Add-Line ""
    Add-Line ("=" * 80)
    Add-Line $Title
    Add-Line ("=" * 80)
}

function Relative-Path {
    param([string]$FullPath)

    $prefix = $root + "\"
    if ($FullPath.StartsWith($prefix)) {
        return $FullPath.Substring($prefix.Length)
    }

    return $FullPath
}

function Preview-File {
    param(
        [string]$Path,
        [int]$MaxLines
    )

    if (-not (Test-Path $Path)) {
        return
    }

    Add-Line ""
    Add-Line ("FILE: " + (Relative-Path $Path))
    Add-Line ("-" * 80)

    $content = @(Get-Content -Path $Path -ErrorAction Stop)
    $limit = [Math]::Min($content.Count, $MaxLines)

    for ($i = 0; $i -lt $limit; $i++) {
        Add-Line ("{0,4}: {1}" -f ($i + 1), $content[$i])
    }

    if ($content.Count -gt $MaxLines) {
        Add-Line ("... truncated; total lines: " + $content.Count)
    }
}

function Search-Patterns {
    param(
        [string]$Title,
        [string[]]$Patterns,
        [int]$Limit
    )

    Add-Section $Title

    $sourceFiles = @(
        Get-ChildItem -Path $src -Recurse -File -ErrorAction SilentlyContinue |
        Where-Object {
            $_.Extension -eq ".ts" -or
            $_.Extension -eq ".tsx" -or
            $_.Extension -eq ".js" -or
            $_.Extension -eq ".jsx" -or
            $_.Extension -eq ".css"
        }
    )

    $items = New-Object System.Collections.Generic.List[object]

    foreach ($file in $sourceFiles) {
        foreach ($pattern in $Patterns) {
            $hits = @(
                Select-String -Path $file.FullName -Pattern $pattern -SimpleMatch -ErrorAction SilentlyContinue
            )

            foreach ($hit in $hits) {
                $obj = New-Object PSObject
                Add-Member -InputObject $obj -MemberType NoteProperty -Name File -Value (Relative-Path $hit.Path)
                Add-Member -InputObject $obj -MemberType NoteProperty -Name Line -Value $hit.LineNumber
                Add-Member -InputObject $obj -MemberType NoteProperty -Name Pattern -Value $pattern
                Add-Member -InputObject $obj -MemberType NoteProperty -Name Text -Value $hit.Line.Trim()
                [void]$items.Add($obj)
            }
        }
    }

    $matches = @(
        $items |
        Sort-Object File, Line, Pattern -Unique |
        Select-Object -First $Limit
    )

    if ($matches.Count -eq 0) {
        Add-Line "(no matches)"
    }
    else {
        foreach ($m in $matches) {
            Add-Line ("{0}:{1} [{2}] {3}" -f $m.File, $m.Line, $m.Pattern, $m.Text)
        }
    }
}

Add-Line "LAF STUDIO - REAL UI ROUTER INTEGRATION DISCOVERY"
Add-Line ("Generated: " + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
Add-Line ("Project: " + $root)
Add-Line "READ ONLY - project source files are not modified."

Add-Section "1. PACKAGE AND BUILD CONFIG"
Preview-File -Path (Join-Path $app "package.json") -MaxLines 180
Preview-File -Path (Join-Path $app "vite.config.ts") -MaxLines 120
Preview-File -Path (Join-Path $app "vite.config.js") -MaxLines 120
Preview-File -Path (Join-Path $app "tsconfig.json") -MaxLines 120

Add-Section "2. TOP LEVEL SRC FILES"
$top = @(
    Get-ChildItem -Path $src -File -ErrorAction SilentlyContinue |
    Sort-Object Name
)

if ($top.Count -eq 0) {
    Add-Line "(no top level src files found)"
}
else {
    foreach ($file in $top) {
        Add-Line (Relative-Path $file.FullName)
    }
}

Add-Section "3. APP ROUTER ENTRY CANDIDATES"
$names = @(
    "App.tsx",
    "App.ts",
    "main.tsx",
    "main.ts",
    "index.tsx",
    "index.ts",
    "router.tsx",
    "router.ts",
    "routes.tsx",
    "routes.ts",
    "Router.tsx",
    "Routes.tsx"
)

$candidates = @()
foreach ($name in $names) {
    $candidates += @(
        Get-ChildItem -Path $src -Recurse -File -Filter $name -ErrorAction SilentlyContinue
    )
}

$candidates = @($candidates | Sort-Object FullName -Unique)

if ($candidates.Count -eq 0) {
    Add-Line "(no conventional app or router files found)"
}
else {
    foreach ($file in $candidates) {
        Preview-File -Path $file.FullName -MaxLines 180
    }
}

$routerPatterns = @(
    "react-router",
    "BrowserRouter",
    "HashRouter",
    "MemoryRouter",
    "Routes",
    "Route",
    "useNavigate",
    "navigate(",
    "router.push",
    "router.replace",
    "location.pathname",
    "window.location"
)
Search-Patterns -Title "4. ROUTER AND NAVIGATION SIGNALS" -Patterns $routerPatterns -Limit 180

$learningPatterns = @(
    "Learning Focus",
    "Daily Learning",
    "Learning Path",
    "Continue Learning",
    "CEFR",
    "Language Orbit",
    "Sticky Learning Journey"
)
Search-Patterns -Title "5. LEARNING HOME AND CEFR SIGNALS" -Patterns $learningPatterns -Limit 180

$studioPatterns = @(
    "grammar-lab",
    "reading-studio",
    "listening-studio",
    "writing-studio",
    "speaking-pronunciation-studio",
    "dialogue-role-play-studio",
    "vocabulary-memory-studio",
    "translation-studio",
    "interpreting-studio",
    "Grammar Lab",
    "Reading Studio",
    "Listening Studio",
    "Writing Studio",
    "Translation Studio"
)
Search-Patterns -Title "6. STUDIO SIGNALS" -Patterns $studioPatterns -Limit 220

$statePatterns = @(
    "createContext",
    "useContext",
    "useReducer",
    "useState",
    "zustand",
    "redux",
    "localStorage",
    "sessionStorage",
    "service",
    "repository",
    "store"
)
Search-Patterns -Title "7. STATE SERVICE STORE SIGNALS" -Patterns $statePatterns -Limit 180

$facadePatterns = @(
    "CefrGuidanceApplicationFacade",
    "cefrGuidanceApplicationFacade",
    "CefrIntegratedGuidancePlatform",
    "CefrApplicationGuidance"
)
Search-Patterns -Title "8. GUIDANCE FACADE REFERENCES" -Patterns $facadePatterns -Limit 160

Add-Section "9. LIKELY UI TSX FILES"
$ui = @(
    Get-ChildItem -Path $src -Recurse -File -Filter *.tsx -ErrorAction SilentlyContinue |
    Where-Object {
        $_.FullName -match "component|page|screen|view|dashboard|home|learning|studio|cefr"
    } |
    Sort-Object FullName |
    Select-Object -First 120
)

if ($ui.Count -eq 0) {
    Add-Line "(no likely UI files found)"
}
else {
    foreach ($file in $ui) {
        Add-Line ((Relative-Path $file.FullName) + " (" + $file.Length + " bytes)")
    }
}

Add-Section "10. UI AND APP TEST FILES"
$tests = @(
    Get-ChildItem -Path $src -Recurse -File -ErrorAction SilentlyContinue |
    Where-Object {
        ($_.Name -like "*.test.ts" -or $_.Name -like "*.test.tsx") -and
        $_.FullName -match "component|page|screen|view|dashboard|home|learning|studio|cefr|App"
    } |
    Sort-Object FullName |
    Select-Object -First 120
)

if ($tests.Count -eq 0) {
    Add-Line "(no matching test files found)"
}
else {
    foreach ($file in $tests) {
        Add-Line (Relative-Path $file.FullName)
    }
}

Add-Section "11. NEXT INTEGRATION INPUT"
Add-Line "Need exact application entry or router file."
Add-Line "Need exact Learning Home or CEFR insertion point."
Add-Line "Need exact Studio route identifiers."
Add-Line "Need current navigation mechanism."
Add-Line "Need current state or service pattern."
Add-Line "Need nearby UI test convention."

$report | Set-Content -Path $out -Encoding UTF8

Write-Host ""
Write-Host "LAF UI INTEGRATION DISCOVERY REV2 COMPLETE"
Write-Host "Report:"
Write-Host $out
Write-Host ""
Get-Content -Path $out
