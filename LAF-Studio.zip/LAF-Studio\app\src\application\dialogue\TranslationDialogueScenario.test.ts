import {
  describe,
  expect,
  it,
} from "vitest";

import {
  getTranslationDialogueScenario,
  getTranslationDialogueScenarios,
  isTranslationDialogueReplyReady,
  normalizeTranslationDialogueReply,
} from "./TranslationDialogueScenario";

describe(
  "TranslationDialogueScenario",
  () => {
    it("provides three Hungarian scenarios", () => {
      expect(
        getTranslationDialogueScenarios(
          "hu",
        ),
      ).toHaveLength(3);
    });

    it("provides three Turkish scenarios", () => {
      expect(
        getTranslationDialogueScenarios(
          "tr",
        ),
      ).toHaveLength(3);
    });

    it("provides three guided prompts per scenario", () => {
      expect(
        getTranslationDialogueScenario(
          "hu",
          "cafe",
        ).prompts,
      ).toHaveLength(3);
    });

    it("uses Hungarian partner text in Hungarian mode", () => {
      expect(
        getTranslationDialogueScenario(
          "hu",
          "introduction",
        ).prompts[0]?.partnerText,
      ).toContain("Szia");
    });

    it("uses Turkish partner text in Turkish mode", () => {
      expect(
        getTranslationDialogueScenario(
          "tr",
          "directions",
        ).prompts[0]?.partnerText,
      ).toContain("Merhaba");
    });

    it("normalizes repeated whitespace", () => {
      expect(
        normalizeTranslationDialogueReply(
          "  Jó   napot!  ",
        ),
      ).toBe("Jó napot!");
    });

    it("accepts a non-empty learner reply", () => {
      expect(
        isTranslationDialogueReplyReady(
          "Kérek egy kávét.",
        ),
      ).toBe(true);
    });

    it("rejects blank learner replies", () => {
      expect(
        isTranslationDialogueReplyReady(
          "   ",
        ),
      ).toBe(false);
    });
  },
);
