﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$core = Join-Path $app "src\core\learning"
$application = Join-Path $app "src\application\learning"

$utf8 =
    New-Object System.Text.UTF8Encoding($false)

function Read-Utf8([string]$path) {
    return [System.IO.File]::ReadAllText(
        $path,
        $utf8
    )
}

function Write-Utf8(
    [string]$path,
    [string]$text
) {
    [System.IO.File]::WriteAllText(
        $path,
        $text,
        $utf8
    )
}

# ============================================================
# REV1 REPAIR 1
# Complete A1 DESCRIBE registration using the already-existing
# A1 NAVIGATE invocation as the seam. Do not assume an exact
# "return createCefrRuntimeSliceRegistry([" formatting shape.
# ============================================================

$productionRegistryPath =
    Join-Path $core "CefrProductionRuntimeSliceRegistry.ts"

if (-not (Test-Path $productionRegistryPath)) {
    throw "CefrProductionRuntimeSliceRegistry.ts missing."
}

$productionRegistry =
    Read-Utf8 $productionRegistryPath

# Import may already have been inserted by the first installer
# before it stopped. Add it only when genuinely absent.
if (-not $productionRegistry.Contains(
    "createLafA1DescribeRuntimeSliceDefinition"
)) {
    $describeImport =
        'import {' +
        [Environment]::NewLine +
        '  createLafA1DescribeRuntimeSliceDefinition,' +
        [Environment]::NewLine +
        '} from "./CefrA1DescribeRuntimeSliceDefinition";' +
        [Environment]::NewLine

    $productionRegistry =
        $describeImport +
        $productionRegistry
}

$describeInvocation =
    "createLafA1DescribeRuntimeSliceDefinition()"

if (-not $productionRegistry.Contains(
    $describeInvocation
)) {
    $navigatePattern =
        '(?m)^(?<indent>[ \t]*)createLafA1NavigateRuntimeSliceDefinition\(\)(?<comma>,?)[ \t]*$'

    $navigateMatches =
        [regex]::Matches(
            $productionRegistry,
            $navigatePattern
        )

    if ($navigateMatches.Count -ne 1) {
        throw "Expected exactly one A1 NAVIGATE runtime invocation seam; found $($navigateMatches.Count)."
    }

    $match =
        $navigateMatches[0]

    $indent =
        $match.Groups["indent"].Value

    $navigateLine =
        $match.Value.TrimEnd()

    if (-not $navigateLine.EndsWith(",")) {
        $navigateLine =
            $navigateLine + ","
    }

    $replacement =
        $indent +
        $navigateLine.TrimStart() +
        [Environment]::NewLine +
        $indent +
        "createLafA1DescribeRuntimeSliceDefinition(),"

    $productionRegistry =
        $productionRegistry.Remove(
            $match.Index,
            $match.Length
        ).Insert(
            $match.Index,
            $replacement
        )
}

Write-Utf8 `
    $productionRegistryPath `
    $productionRegistry

# ============================================================
# REV1 REPAIR 2
# Expand the production delayed-retrieval audit authority from
# CONNECT + NAVIGATE to CONNECT + NAVIGATE + DESCRIBE.
# ============================================================

$auditPath =
    Join-Path $core "CefrProductionRuntimeEvidenceEligibilityAudit.ts"

if (-not (Test-Path $auditPath)) {
    throw "CefrProductionRuntimeEvidenceEligibilityAudit.ts missing."
}

$audit =
    Read-Utf8 $auditPath

$describeDelayedId =
    '"a1-describe-evidence-delayed-retrieval"'

if (-not $audit.Contains(
    $describeDelayedId
)) {
    $navigateDelayedLine =
        '"a1-navigate-evidence-delayed-retrieval",'

    $navigateDelayedPos =
        $audit.IndexOf(
            $navigateDelayedLine
        )

    if ($navigateDelayedPos -lt 0) {
        throw "A1 NAVIGATE delayed-retrieval audit anchor missing."
    }

    $lineStart =
        $audit.LastIndexOf(
            [Environment]::NewLine,
            $navigateDelayedPos
        )

    if ($lineStart -lt 0) {
        $lineStart = -1
    }

    $indentStart =
        $lineStart + 1

    $indentLength =
        $navigateDelayedPos -
        $indentStart

    $indent =
        $audit.Substring(
            $indentStart,
            $indentLength
        )

    $insertAt =
        $navigateDelayedPos +
        $navigateDelayedLine.Length

    $audit =
        $audit.Insert(
            $insertAt,
            [Environment]::NewLine +
            $indent +
            $describeDelayedId +
            ","
        )
}

Write-Utf8 $auditPath $audit

# ============================================================
# REV1 REPAIR 3
# Update only stale exact-cardinality tests caused by adding the
# third approved production runtime slice.
# ============================================================

$platformTestPath =
    Join-Path $application "CefrProductionRuntimePlatform.test.ts"

if (-not (Test-Path $platformTestPath)) {
    throw "CefrProductionRuntimePlatform.test.ts missing."
}

$platformTest =
    Read-Utf8 $platformTestPath

if ($platformTest.Contains(
    "registeredSliceCount: 2"
)) {
    $count =
        [regex]::Matches(
            $platformTest,
            [regex]::Escape(
                "registeredSliceCount: 2"
            )
        ).Count

    if ($count -ne 1) {
        throw "Unexpected registeredSliceCount: 2 occurrence count in platform test: $count"
    }

    $platformTest =
        $platformTest.Replace(
            "registeredSliceCount: 2",
            "registeredSliceCount: 3"
        )
}

if (-not $platformTest.Contains(
    "registeredSliceCount: 3"
)) {
    throw "Production platform test was not updated to three slices."
}

Write-Utf8 `
    $platformTestPath `
    $platformTest

$auditTestPath =
    Join-Path $core "CefrProductionRuntimeEvidenceEligibilityAudit.test.ts"

if (-not (Test-Path $auditTestPath)) {
    throw "CefrProductionRuntimeEvidenceEligibilityAudit.test.ts missing."
}

$auditTest =
    Read-Utf8 $auditTestPath

if ($auditTest.Contains(
    "registeredSliceCount: 2"
)) {
    $auditTest =
        $auditTest.Replace(
            "registeredSliceCount: 2",
            "registeredSliceCount: 3"
        )
}

if ($auditTest.Contains(
    "executableEvidenceDefinitionCount:" +
    [Environment]::NewLine +
    "          12"
)) {
    $auditTest =
        $auditTest.Replace(
            "executableEvidenceDefinitionCount:" +
            [Environment]::NewLine +
            "          12",
            "executableEvidenceDefinitionCount:" +
            [Environment]::NewLine +
            "          18"
        )
}
elseif ($auditTest.Contains(
    "executableEvidenceDefinitionCount: 12"
)) {
    $auditTest =
        $auditTest.Replace(
            "executableEvidenceDefinitionCount: 12",
            "executableEvidenceDefinitionCount: 18"
        )
}

if (-not $auditTest.Contains(
    $describeDelayedId
)) {
    $navigateDelayedLine =
        '          "a1-navigate-evidence-delayed-retrieval",'

    $navigateDelayedPos =
        $auditTest.IndexOf(
            $navigateDelayedLine
        )

    if ($navigateDelayedPos -lt 0) {
        throw "Audit test delayed-retrieval array anchor missing."
    }

    $insertAt =
        $navigateDelayedPos +
        $navigateDelayedLine.Length

    $auditTest =
        $auditTest.Insert(
            $insertAt,
            [Environment]::NewLine +
            '          "a1-describe-evidence-delayed-retrieval",'
        )
}

$lengthPattern =
    '(LAF_POLICY_GATED_DELAYED_RETRIEVAL_EVIDENCE_IDS,\s*\)\.toHaveLength\()2(\);)'

if (
    [regex]::IsMatch(
        $auditTest,
        $lengthPattern
    )
) {
    $auditTest =
        [regex]::Replace(
            $auditTest,
            $lengthPattern,
            '${1}3${2}',
            1
        )
}

if (-not $auditTest.Contains(
    "registeredSliceCount: 3"
)) {
    throw "Audit test registered slice count did not resolve to three."
}

if (-not $auditTest.Contains(
    $describeDelayedId
)) {
    throw "Audit test missing A1 DESCRIBE delayed-retrieval identity."
}

Write-Utf8 $auditTestPath $auditTest

# ============================================================
# Source validation before target tests.
# ============================================================

$checks = @(
    @(
      $productionRegistryPath,
      "createLafA1DescribeRuntimeSliceDefinition"
    ),
    @(
      $productionRegistryPath,
      "createLafA1DescribeRuntimeSliceDefinition()"
    ),
    @(
      $auditPath,
      $describeDelayedId
    ),
    @(
      (Join-Path $core "CefrA1DescribeCurriculum.ts"),
      '"a1-describe-basic-familiar-world"'
    ),
    @(
      (Join-Path $core "CefrA1DescribeEvidenceDefinition.ts"),
      '"a1-describe-evidence-delayed-retrieval"'
    ),
    @(
      (Join-Path $core "CefrA1DescribeEvidenceDefinition.ts"),
      "runtimeWriteEnabled: false"
    ),
    @(
      (Join-Path $core "CefrA1DescribeRuntimeEvidenceCatalog.ts"),
      "LAF_A1_DESCRIBE_EXECUTABLE_RUNTIME_EVIDENCE_DEFINITIONS"
    ),
    @(
      (Join-Path $core "CefrA1DescribeImplementationSafety.ts"),
      '"description-production"'
    ),
    @(
      (Join-Path $core "CefrAuthoritativeCurriculumRegistry.ts"),
      '"curriculum-map-a1-describe-v1"'
    )
)

foreach ($check in $checks) {
    if (-not (
        Select-String `
            -Path $check[0] `
            -SimpleMatch `
            -Pattern $check[1] `
            -Quiet
    )) {
        throw "Sprint 1497-1505 Rev1 source marker missing: $($check[1])"
    }
}

$runtimeCatalogPath =
    Join-Path $core "CefrA1DescribeRuntimeEvidenceCatalog.ts"

$runtimeCatalog =
    Read-Utf8 $runtimeCatalogPath

if ($runtimeCatalog.Contains(
    '"a1-describe-evidence-delayed-retrieval"'
)) {
    throw "A1 DESCRIBE delayed retrieval leaked into executable runtime catalog."
}

$describeSafety =
    Read-Utf8 (
        Join-Path $core "CefrA1DescribeImplementationSafety.ts"
    )

if ($describeSafety.Contains(
    '"narrative-sequencing"'
)) {
    throw "A1 DESCRIBE safety source unexpectedly includes narrative-sequencing."
}

Write-Host "SPRINT-1497-1505 REV1 SOURCE CHECK PASSED"

Set-Location $app

# ============================================================
# No target checkpoint passed in the original attempt.
# Run the complete intended 3-checkpoint verification.
# ============================================================

Write-Host ""
Write-Host "CHECKPOINT 1/3 — Sprint 1497-1499 authoritative curriculum + experience identities"

& npx vitest run @(
    "src/core/learning/CefrA1DescribeCurriculum.test.ts",
    "src/core/learning/CefrA1DescribePracticeDefinition.test.ts",
    "src/core/learning/CefrA1DescribeInteractionDefinition.test.ts",
    "src/core/learning/CefrA1DescribeEvidenceDefinition.test.ts",
    "src/core/learning/CefrA1DescribeActivationDefinition.test.ts",
    "src/core/learning/CefrA1DescribeLearningExperienceCatalog.test.ts",
    "src/core/learning/CefrA1DescribeImplementationSafety.test.ts"
)

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1497-1499 Rev1 target checkpoint failed."
}

Write-Host "SPRINT-1497-1499 REV1 TARGET CHECKPOINT PASSED"

Write-Host ""
Write-Host "CHECKPOINT 2/3 — Sprint 1500-1502 authoritative registry + runtime evidence/provenance"

& npx vitest run @(
    "src/core/learning/CefrA1DescribeAuthoritativeCatalog.test.ts",
    "src/core/learning/CefrA1DescribeCurriculumRegistry.test.ts",
    "src/core/learning/CefrA1DescribeRuntimeEvidenceCatalog.test.ts",
    "src/core/learning/CefrAuthoritativeCurriculumCatalog.test.ts",
    "src/core/learning/CefrAuthoritativeCurriculumRegistry.test.ts",
    "src/core/learning/CefrAuthoritativeCapabilityRegistry.test.ts"
)

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1500-1502 Rev1 target checkpoint failed."
}

Write-Host "SPRINT-1500-1502 REV1 TARGET CHECKPOINT PASSED"

Write-Host ""
Write-Host "CHECKPOINT 3/3 — Sprint 1503-1505 existing generic production runtime activation"

& npx vitest run @(
    "src/core/learning/CefrA1DescribeRuntimeSliceDefinition.test.ts",
    "src/core/learning/CefrProductionRuntimeSliceRegistry.test.ts",
    "src/core/learning/CefrProductionRuntimeRegistryEnforcement.test.ts",
    "src/core/learning/CefrProductionRuntimeEvidenceEligibilityAudit.test.ts",
    "src/application/learning/CefrProductionRuntimeDelayedRetrievalVisibility.test.ts",
    "src/application/learning/CefrA1DescribeProductionRuntime.test.ts",
    "src/application/learning/CefrProductionRuntimePlatform.test.ts"
)

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1503-1505 Rev1 target checkpoint failed."
}

Write-Host "SPRINT-1503-1505 REV1 TARGET CHECKPOINT PASSED"

Write-Host ""
Write-Host "FINAL 9-SPRINT BLOCK REGRESSION — one full run only"

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1497-1505 Rev1 final full regression failed."
}

Write-Host ""
Write-Host "FINAL PRODUCTION BUILD"

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1497-1505 Rev1 production build failed."
}

Write-Host ""
Write-Host "SPRINT-1497-1505 REV1 VERIFICATION COMPLETE"
