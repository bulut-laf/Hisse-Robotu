import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrPersonalLanguageProfileState,
  type CefrPersonalLanguageProfileState,
} from "../../core/learning/CefrPersonalLanguageProfileState";
import type {
  CefrGuidanceRuntimeProfileRepository,
} from "./CefrGuidanceRuntimeProfileRepository";
import {
  CefrA1ConnectRuntimeEvidenceService,
  createCefrA1ConnectRuntimeEvidenceId,
} from "./CefrA1ConnectRuntimeEvidenceService";

class MemoryRepository
  implements CefrGuidanceRuntimeProfileRepository {
  private state:
    CefrPersonalLanguageProfileState =
      createCefrPersonalLanguageProfileState(
        [],
        [],
      );

  private persisted = false;

  load(): CefrPersonalLanguageProfileState {
    return this.state;
  }

  save(
    state: CefrPersonalLanguageProfileState,
  ): void {
    this.state = state;
    this.persisted = true;
  }

  hasPersistedProfile(): boolean {
    return this.persisted;
  }

  clear(): void {
    this.state =
      createCefrPersonalLanguageProfileState(
        [],
        [],
      );
    this.persisted = false;
  }
}

describe(
  "CefrA1ConnectRuntimeEvidenceService",
  () => {
    it("persists approved real user evidence and writes observational social-exchange capability evidence", () => {
      const repository =
        new MemoryRepository();

      const service =
        new CefrA1ConnectRuntimeEvidenceService(
          repository,
        );

      const result =
        service.recordUserEvidence({
          evidenceDefinitionId:
            "a1-connect-evidence-greeting-response",
          eventId: "event-001",
          occurredAt:
            new Date(
              "2026-08-11T15:00:00.000Z",
            ),
          userActionConfirmed: true,
        });

      expect(result).toMatchObject({
        sourceLearningItemId:
          "a1-connect-greeting-response",
        evidenceDefinitionId:
          "a1-connect-evidence-greeting-response",
        capabilityObservationWritten: true,
        resolvedCapabilityReferences: [
          "social-exchange",
        ],
        masteryAssigned: false,
        competencySuccessAssigned: false,
        cefrLevelAssigned: false,
        progressionPerformed: false,
        automaticStudioLaunchPerformed: false,
      });

      expect(result.evidence).toMatchObject({
        evidenceAdded: true,
        duplicateIgnored: false,
      });

      const state = repository.load();

      expect(
        state.profileSnapshot
          .evidenceAggregation.evidence,
      ).toHaveLength(1);

      expect(
        state.capabilityObservationRegistry
          .observations,
      ).toEqual([
        {
          capabilityReference:
            "social-exchange",
          evidenceId:
            "a1-connect-runtime-evidence:a1-connect-evidence-greeting-response:event-001",
          source: "learning-studio",
          observationalOnly: true,
        },
      ]);
    });

    it("is exact-event duplicate safe across both evidence and capability observation persistence", () => {
      const repository =
        new MemoryRepository();

      const service =
        new CefrA1ConnectRuntimeEvidenceService(
          repository,
        );

      const input = {
        evidenceDefinitionId:
          "a1-connect-evidence-self-introduction",
        eventId: "event-duplicate",
        occurredAt:
          new Date(
            "2026-08-11T15:05:00.000Z",
          ),
        userActionConfirmed: true as const,
      };

      const first =
        service.recordUserEvidence(input);
      const second =
        service.recordUserEvidence(input);

      expect(first.evidence.evidenceAdded).toBe(
        true,
      );

      expect(
        first.capabilityObservationWritten,
      ).toBe(true);

      expect(
        second.evidence.duplicateIgnored,
      ).toBe(true);

      expect(
        second.capabilityObservationWritten,
      ).toBe(false);

      expect(
        second.observation
          .duplicateObservationCount,
      ).toBe(1);

      expect(
        repository.load()
          .profileSnapshot
          .evidenceAggregation.evidence,
      ).toHaveLength(1);

      expect(
        repository.load()
          .capabilityObservationRegistry
          .observations,
      ).toHaveLength(1);
    });

    it("rejects unknown evidence definitions before persistence", () => {
      const repository =
        new MemoryRepository();

      const service =
        new CefrA1ConnectRuntimeEvidenceService(
          repository,
        );

      expect(() =>
        service.recordUserEvidence({
          evidenceDefinitionId:
            "a1-connect-evidence-not-approved",
          eventId: "event-unknown",
          occurredAt:
            new Date(
              "2026-08-11T15:10:00.000Z",
            ),
          userActionConfirmed: true,
        }),
      ).toThrow(
        "Unknown authoritative A1 CONNECT evidence definition",
      );

      expect(
        repository.hasPersistedProfile(),
      ).toBe(false);
    });

    it("rejects missing event identity before persistence", () => {
      const repository =
        new MemoryRepository();

      const service =
        new CefrA1ConnectRuntimeEvidenceService(
          repository,
        );

      expect(() =>
        service.recordUserEvidence({
          evidenceDefinitionId:
            "a1-connect-evidence-personal-answer",
          eventId: " ",
          occurredAt:
            new Date(
              "2026-08-11T15:15:00.000Z",
            ),
          userActionConfirmed: true,
        }),
      ).toThrow(
        "eventId is required",
      );

      expect(
        repository.hasPersistedProfile(),
      ).toBe(false);
    });

    it("creates stable duplicate-safe runtime evidence identity", () => {
      expect(
        createCefrA1ConnectRuntimeEvidenceId(
          "a1-connect-evidence-delayed-retrieval",
          "attempt-7",
        ),
      ).toBe(
        "a1-connect-runtime-evidence:a1-connect-evidence-delayed-retrieval:attempt-7",
      );
    });
  },
);
