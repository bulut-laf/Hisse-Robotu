﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app  = Join-Path $root "app"
$src  = Join-Path $app "src"
$out  = Join-Path $root "LAF_CURRICULUM_CONTENT_DISCOVERY.txt"

if (-not (Test-Path $src)) {
    throw "Source root not found: $src"
}

$report = New-Object System.Collections.Generic.List[string]

function Add-Line {
    param([string]$Text)
    if ($null -eq $Text) { $Text = "" }
    [void]$report.Add($Text)
}

function Add-Section {
    param([string]$Title)
    Add-Line ""
    Add-Line ("=" * 96)
    Add-Line $Title
    Add-Line ("=" * 96)
}

function Rel {
    param([string]$Path)
    $prefix = $root + "\"
    if ($Path.StartsWith($prefix)) {
        return $Path.Substring($prefix.Length)
    }
    return $Path
}

function Add-File {
    param(
        [string]$Relative,
        [int]$Limit = 500
    )

    $file = Join-Path $src $Relative
    Add-Section ("FILE: app\src\" + $Relative)

    if (-not (Test-Path $file)) {
        Add-Line "(file not found)"
        return
    }

    $lines = @(Get-Content -Path $file)
    $count = [Math]::Min($lines.Count, $Limit)

    for ($i = 0; $i -lt $count; $i++) {
        Add-Line ("{0,4}: {1}" -f ($i + 1), $lines[$i])
    }

    if ($lines.Count -gt $Limit) {
        Add-Line ("... truncated; total lines: " + $lines.Count)
    }
}

$files = @(
    Get-ChildItem -Path $src -Recurse -File |
    Where-Object {
        $_.Extension -eq ".ts" -or
        $_.Extension -eq ".tsx"
    }
)

Add-Line "LAF STUDIO - CURRICULUM CONTENT DISCOVERY"
Add-Line ("Generated: " + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
Add-Line "READ ONLY - no project source files are modified."
Add-Line "Stable technical baseline expected: Sprint 1286."

Add-Section "1. CANDIDATE LESSON / UNIT / CURRICULUM PRODUCTION FILES"

$candidates = @(
    $files |
    Where-Object {
        -not (
            $_.Name.EndsWith(".test.ts") -or
            $_.Name.EndsWith(".test.tsx")
        ) -and (
            $_.Name -match "Lesson|Unit|Curriculum|LearningPath|Catalog|Module"
        )
    } |
    Sort-Object FullName
)

foreach ($file in ($candidates | Select-Object -First 180)) {
    Add-Line (Rel $file.FullName)
}

Add-Section "2. PRODUCTION lessonId / unitId / lessons / units / getLessonById OCCURRENCES"

$patterns = @(
    "lessonId",
    "unitId",
    "readonly lessons",
    "readonly units",
    "getLessonById",
    "getNextLessonById",
    "LESSONS",
    "UNITS"
)

foreach ($pattern in $patterns) {
    Add-Line ""
    Add-Line ("PATTERN: " + $pattern)

    $matches = New-Object System.Collections.Generic.List[object]

    foreach ($file in $files) {
        if (
            $file.Name.EndsWith(".test.ts") -or
            $file.Name.EndsWith(".test.tsx")
        ) {
            continue
        }

        $hits = @(
            Select-String `
                -Path $file.FullName `
                -SimpleMatch `
                -Pattern $pattern `
                -ErrorAction SilentlyContinue
        )

        foreach ($hit in $hits) {
            [void]$matches.Add(
                [PSCustomObject]@{
                    File = Rel $hit.Path
                    Line = $hit.LineNumber
                    Text = $hit.Line.Trim()
                }
            )
        }
    }

    if ($matches.Count -eq 0) {
        Add-Line "(no matches)"
    } else {
        foreach ($m in (
            $matches |
            Sort-Object File, Line |
            Select-Object -First 220
        )) {
            Add-Line (
                "{0}:{1}: {2}" -f
                $m.File,
                $m.Line,
                $m.Text
            )
        }
    }
}

Add-Section "3. EXACT CORE CURRICULUM CONTRACT FILES"

Add-File "core\learning\CefrLearningLesson.ts" 600
Add-File "core\learning\CefrLearningLessonCatalog.ts" 600
Add-File "core\learning\CefrLearningUnit.ts" 600
Add-File "core\learning\CefrLearningUnitCatalog.ts" 600
Add-File "core\learning\CefrLearningPath.ts" 800
Add-File "core\learning\CefrAuthoritativeCurriculumRegistry.ts" 500
Add-File "core\learning\CefrCurriculumCompetencyMapping.ts" 500
Add-File "core\learning\CefrCurriculumCompetencyRegistry.ts" 500

Add-Section "4. REAL APP LESSON DATA CANDIDATES"

$lessonDataCandidates = @(
    $files |
    Where-Object {
        -not (
            $_.Name.EndsWith(".test.ts") -or
            $_.Name.EndsWith(".test.tsx")
        ) -and (
            $_.FullName -match "\\features\\lessons\\" -or
            $_.FullName -match "\\data\\" -or
            $_.FullName -match "\\content\\"
        )
    } |
    Sort-Object FullName
)

foreach ($file in ($lessonDataCandidates | Select-Object -First 120)) {
    Add-Line ""
    Add-Line ("FILE: " + (Rel $file.FullName))

    $hits = @(
        Select-String `
            -Path $file.FullName `
            -Pattern 'id\s*:|title\s*:|lessonId|unitId|level|cefr|module|skill' `
            -ErrorAction SilentlyContinue
    )

    if ($hits.Count -eq 0) {
        Add-Line "(no identity/title/level-like matches)"
        continue
    }

    foreach ($hit in ($hits | Select-Object -First 120)) {
        Add-Line (
            "{0}: {1}" -f
            $hit.LineNumber,
            $hit.Line.Trim()
        )
    }
}

Add-Section "5. PRODUCTION LESSON ID STRING LITERALS"

$idPatterns = @(
    'id\s*:\s*["''][^"'']+["'']',
    'lessonId\s*:\s*["''][^"'']+["'']'
)

$literalMatches = New-Object System.Collections.Generic.List[object]

foreach ($file in $files) {
    if (
        $file.Name.EndsWith(".test.ts") -or
        $file.Name.EndsWith(".test.tsx")
    ) {
        continue
    }

    $lines = @(Get-Content -Path $file.FullName)

    for ($i = 0; $i -lt $lines.Count; $i++) {
        foreach ($pattern in $idPatterns) {
            if ($lines[$i] -match $pattern) {
                [void]$literalMatches.Add(
                    [PSCustomObject]@{
                        File = Rel $file.FullName
                        Line = $i + 1
                        Text = $lines[$i].Trim()
                    }
                )
            }
        }
    }
}

foreach ($m in (
    $literalMatches |
    Sort-Object File, Line |
    Select-Object -First 400
)) {
    Add-Line (
        "{0}:{1}: {2}" -f
        $m.File,
        $m.Line,
        $m.Text
    )
}

Add-Section "6. CURRENT AUTHORITATIVE CURRICULUM MAPPING STATUS"

$registryFile = Join-Path $src "core\learning\CefrAuthoritativeCurriculumRegistry.ts"

if (Test-Path $registryFile) {
    $lines = @(Get-Content -Path $registryFile)
    for ($i = 0; $i -lt $lines.Count; $i++) {
        Add-Line ("{0,4}: {1}" -f ($i + 1), $lines[$i])
    }
} else {
    Add-Line "(authoritative curriculum registry not found)"
}

Add-Section "7. IMPLEMENTATION DECISION INPUT"

Add-Line "Need exact production learning-item identities that should own curriculum mappings."
Add-Line "Need exact real lesson/unit catalog rows and available metadata."
Add-Line "Need Design Studio-approved Learning Item -> Competency Outcome content before production mappings are populated."
Add-Line "Do not infer competency outcomes from lesson titles, Studio names, routes, skill labels, or CEFR-looking text."
Add-Line "Existing approved cardinality remains: minimum 1, normal maximum 2, exceptional maximum 3 with explicit approval."
Add-Line "Capability taxonomy and 36 Competency Outcome -> Capability mappings are already authoritative as of Sprint 1286."
Add-Line "No mastery, competency success, CEFR-level assignment, or automatic progression."

$report | Set-Content -Path $out -Encoding UTF8

Write-Host ""
Write-Host "LAF CURRICULUM CONTENT DISCOVERY COMPLETE"
Write-Host "Report:"
Write-Host $out
