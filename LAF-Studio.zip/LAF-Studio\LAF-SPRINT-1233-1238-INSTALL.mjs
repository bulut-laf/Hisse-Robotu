import fs from "node:fs";
import path from "node:path";

const root = "D:\\Projects\\LAF-Studio";
const file = path.join(
  root,
  "app",
  "src",
  "ui",
  "writing",
  "WritingStudioPanel.tsx",
);

if (!fs.existsSync(file)) {
  throw new Error(
    `WritingStudioPanel.tsx not found: ${file}`,
  );
}

function eolOf(source) {
  return source.includes("\r\n") ? "\r\n" : "\n";
}

function count(source, needle) {
  return source.split(needle).length - 1;
}

function findMatchingBrace(source, openIndex) {
  let depth = 0;
  let quote = null;
  let escaped = false;
  let lineComment = false;
  let blockComment = false;

  for (let i = openIndex; i < source.length; i++) {
    const char = source[i];
    const next = source[i + 1];

    if (lineComment) {
      if (char === "\n") {
        lineComment = false;
      }
      continue;
    }

    if (blockComment) {
      if (char === "*" && next === "/") {
        blockComment = false;
        i++;
      }
      continue;
    }

    if (quote !== null) {
      if (escaped) {
        escaped = false;
        continue;
      }

      if (char === "\\") {
        escaped = true;
        continue;
      }

      if (char === quote) {
        quote = null;
      }
      continue;
    }

    if (
      char === '"' ||
      char === "'" ||
      char === "`"
    ) {
      quote = char;
      continue;
    }

    if (char === "/" && next === "/") {
      lineComment = true;
      i++;
      continue;
    }

    if (char === "/" && next === "*") {
      blockComment = true;
      i++;
      continue;
    }

    if (char === "{") {
      depth++;
      continue;
    }

    if (char === "}") {
      depth--;

      if (depth === 0) {
        return i;
      }
    }
  }

  return -1;
}

function findCompleteSessionRange(source) {
  const marker =
    "const completeSession = () => {";
  const markerIndex =
    source.indexOf(marker);

  if (markerIndex < 0) {
    throw new Error(
      "Writing completeSession handler not found.",
    );
  }

  const openIndex =
    source.indexOf("{", markerIndex);
  const closeIndex =
    findMatchingBrace(source, openIndex);

  if (closeIndex < 0) {
    throw new Error(
      "Writing completeSession closing brace not found.",
    );
  }

  return {
    markerIndex,
    openIndex,
    closeIndex,
    body:
      source.slice(
        openIndex + 1,
        closeIndex,
      ),
  };
}

let source =
  fs.readFileSync(file, "utf8");
const eol = eolOf(source);

const serviceImport =
  'import { CefrGuidanceRuntimeProfileService } from "../../application/learning/CefrGuidanceRuntimeProfileService";';
const evidenceImport =
  'import { createCefrWritingStudioCompletionEvidenceInput } from "../../application/learning/CefrWritingStudioCompletionEvidence";';
const repositoryImport =
  'import { LocalStorageCefrGuidanceProfileRepository } from "../storage/LocalStorageCefrGuidanceProfileRepository";';

const missingImports = [
  serviceImport,
  evidenceImport,
  repositoryImport,
].filter(item => !source.includes(item));

if (missingImports.length > 0) {
  source =
    missingImports.join(eol) +
    eol +
    source;
}

let range =
  findCompleteSessionRange(source);

if (
  !range.body.includes(
    "createCefrWritingStudioCompletionEvidenceInput(",
  )
) {
  const resetNeedle =
    "    resetWritingSession();";
  const resetIndex =
    range.body.indexOf(resetNeedle);

  if (resetIndex < 0) {
    throw new Error(
      "Writing completeSession reset marker not found.",
    );
  }

  const evidenceBlock =
    "    const cefrCompletionAt = new Date();" +
    eol +
    "    new CefrGuidanceRuntimeProfileService(" +
    eol +
    "      new LocalStorageCefrGuidanceProfileRepository()," +
    eol +
    "    ).recordLearningStudioEvidence(" +
    eol +
    "      createCefrWritingStudioCompletionEvidenceInput(" +
    eol +
    "        taskId," +
    eol +
    "        cefrCompletionAt," +
    eol +
    "      )," +
    eol +
    "    );" +
    eol;

  const nextBody =
    range.body.slice(0, resetIndex) +
    evidenceBlock +
    range.body.slice(resetIndex);

  source =
    source.slice(0, range.openIndex + 1) +
    nextBody +
    source.slice(range.closeIndex);

  range =
    findCompleteSessionRange(source);
}

const summaryIndex =
  range.body.indexOf(
    "createTranslationWritingSessionSummary(",
  );
const evidenceIndex =
  range.body.indexOf(
    "createCefrWritingStudioCompletionEvidenceInput(",
  );
const resetIndex =
  range.body.indexOf(
    "resetWritingSession();",
  );

if (
  summaryIndex < 0 ||
  evidenceIndex < 0 ||
  resetIndex < 0
) {
  throw new Error(
    "Writing completion order validation markers are missing.",
  );
}

if (
  !(
    summaryIndex <
    evidenceIndex &&
    evidenceIndex <
    resetIndex
  )
) {
  throw new Error(
    "Writing completion order invalid: summary -> evidence -> reset required.",
  );
}

const validation = {
  serviceImport:
    count(source, serviceImport),
  evidenceImport:
    count(source, evidenceImport),
  repositoryImport:
    count(source, repositoryImport),
  evidenceCall:
    count(
      range.body,
      "createCefrWritingStudioCompletionEvidenceInput(",
    ),
  taskIdentity:
    count(
      range.body,
      "        taskId,",
    ),
  persistenceWrite:
    count(
      range.body,
      ").recordLearningStudioEvidence(",
    ),
};

for (const [name, value] of Object.entries(
  validation,
)) {
  if (value !== 1) {
    throw new Error(
      `Writing completion validation failed: ${name}=${value}`,
    );
  }
}

fs.writeFileSync(
  file,
  source,
  "utf8",
);

console.log(
  "SPRINT-1233-1238 INSTALL COMPLETE",
);
console.log(
  "Writing completion evidence binding installed between summary commit and session reset.",
);
