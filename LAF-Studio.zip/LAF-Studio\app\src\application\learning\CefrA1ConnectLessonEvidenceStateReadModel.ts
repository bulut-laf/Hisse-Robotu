import {
  createCefrA1ConnectLessonEvidenceState,
  type CefrA1ConnectLessonEvidenceState,
} from "../../core/learning/CefrA1ConnectLessonEvidenceState";
import type {
  CefrA1ConnectLessonScopedCoverageReadModel,
} from "./CefrA1ConnectLessonScopedCoverageReadModel";

export interface CefrA1ConnectLessonEvidenceStateReadModel {
  readonly lessonId: string;
  readonly evidenceState:
    CefrA1ConnectLessonEvidenceState;
  readonly currentLessonContextOnly: true;
  readonly recommendsAutomaticAdvance: false;
  readonly selectsNextLesson: false;
}

export function createCefrA1ConnectLessonEvidenceStateReadModel(
  coverage:
    CefrA1ConnectLessonScopedCoverageReadModel,
): CefrA1ConnectLessonEvidenceStateReadModel {
  return {
    lessonId: coverage.lessonId,
    evidenceState:
      createCefrA1ConnectLessonEvidenceState({
        observedImmediateEvidenceCount:
          coverage.observedEvidenceCount,
        totalImmediateEvidenceCount:
          coverage.totalEvidenceCount,
        delayedRetrievalPending:
          coverage.delayedRetrievalPending,
      }),
    currentLessonContextOnly: true,
    recommendsAutomaticAdvance: false,
    selectsNextLesson: false,
  };
}
