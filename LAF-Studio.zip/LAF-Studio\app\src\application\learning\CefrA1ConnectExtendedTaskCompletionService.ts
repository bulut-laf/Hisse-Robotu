import type {
  LafLearningLanguageCode,
} from "../../core/language/LafLanguageProfile";
import {
  createCefrA1ConnectPersonalAnswerTask,
  createCefrA1ConnectPersonalQuestionTask,
  createCefrA1ConnectReciprocalExchangeTask,
  type CefrA1ConnectExtendedTaskKind,
} from "../../core/learning/CefrA1ConnectExtendedExecutableTasks";
import {
  CefrA1ConnectEvidenceProvenanceCoordinator,
} from "./CefrA1ConnectEvidenceProvenanceCoordinator";
import {
  CefrA1ConnectLanguageEvidenceProvenanceRepository,
} from "./CefrA1ConnectLanguageEvidenceProvenanceRepository";
import type {
  CefrGuidanceRuntimeProfileRepository,
} from "./CefrGuidanceRuntimeProfileRepository";
import {
  CefrA1ConnectRuntimeEvidenceService,
  type CefrA1ConnectRuntimeEvidenceResult,
} from "./CefrA1ConnectRuntimeEvidenceService";
import {
  evaluateCefrA1ConnectExtendedChoiceTask,
  type CefrA1ConnectExtendedTaskEvaluation,
} from "./CefrA1ConnectExtendedTaskEvaluation";

export interface CefrA1ConnectExtendedTaskSubmissionInput {
  readonly taskKind:
    CefrA1ConnectExtendedTaskKind;
  readonly languageCode:
    LafLearningLanguageCode;
  readonly submittedAnswer: string;
  readonly eventId: string;
  readonly occurredAt: Date;
  readonly userActionConfirmed: true;
}

export interface CefrA1ConnectExtendedTaskSubmissionResult {
  readonly evaluation:
    CefrA1ConnectExtendedTaskEvaluation;
  readonly evidence:
    CefrA1ConnectRuntimeEvidenceResult | null;
  readonly evidencePersisted: boolean;
  readonly capabilityObservationWritten:
    boolean;
  readonly masteryAssigned: false;
  readonly competencySuccessAssigned: false;
  readonly cefrLevelAssigned: false;
  readonly progressionPerformed: false;
}

function createTask(
  taskKind: CefrA1ConnectExtendedTaskKind,
  languageCode: LafLearningLanguageCode,
) {
  if (taskKind === "personal-answer") {
    return createCefrA1ConnectPersonalAnswerTask(
      languageCode,
    );
  }

  if (taskKind === "personal-question") {
    return createCefrA1ConnectPersonalQuestionTask(
      languageCode,
    );
  }

  return createCefrA1ConnectReciprocalExchangeTask(
    languageCode,
  );
}

export class CefrA1ConnectExtendedTaskCompletionService {
  private readonly evidenceService:
    CefrA1ConnectRuntimeEvidenceService;

  private readonly provenanceCoordinator:
    CefrA1ConnectEvidenceProvenanceCoordinator;

  constructor(
    repository:
      CefrGuidanceRuntimeProfileRepository,
    provenanceCoordinatorOrRepository:
      | CefrA1ConnectEvidenceProvenanceCoordinator
      | CefrA1ConnectLanguageEvidenceProvenanceRepository =
        new CefrA1ConnectEvidenceProvenanceCoordinator(),
  ) {
    this.evidenceService =
      new CefrA1ConnectRuntimeEvidenceService(
        repository,
      );

    this.provenanceCoordinator =
      "recordPersistedEvidenceLanguage" in
      provenanceCoordinatorOrRepository
        ? provenanceCoordinatorOrRepository
        : new CefrA1ConnectEvidenceProvenanceCoordinator(
            provenanceCoordinatorOrRepository,
          );
  }

  submit(
    input:
      CefrA1ConnectExtendedTaskSubmissionInput,
  ): CefrA1ConnectExtendedTaskSubmissionResult {
    const task =
      createTask(
        input.taskKind,
        input.languageCode,
      );

    const evaluation =
      evaluateCefrA1ConnectExtendedChoiceTask(
        task,
        input.submittedAnswer,
      );

    if (!evaluation.evidenceEligible) {
      return {
        evaluation,
        evidence: null,
        evidencePersisted: false,
        capabilityObservationWritten: false,
        masteryAssigned: false,
        competencySuccessAssigned: false,
        cefrLevelAssigned: false,
        progressionPerformed: false,
      };
    }

    const evidence =
      this.evidenceService.recordUserEvidence({
        evidenceDefinitionId:
          task.evidenceDefinitionId,
        eventId: input.eventId,
        occurredAt: input.occurredAt,
        userActionConfirmed:
          input.userActionConfirmed,
      });

    this.provenanceCoordinator.recordPersistedEvidenceLanguage({
      evidenceId:
        evidence.runtimeEvidenceId,
      languageCode:
        input.languageCode,
      observedAt:
        input.occurredAt,
    });

    return {
      evaluation,
      evidence,
      evidencePersisted:
        evidence.evidence.evidenceAdded,
      capabilityObservationWritten:
        evidence.capabilityObservationWritten,
      masteryAssigned: false,
      competencySuccessAssigned: false,
      cefrLevelAssigned: false,
      progressionPerformed: false,
    };
  }
}
