﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

$required = @(
    "src\core\learning\CefrA1NavigateExecutableTaskDefinition.ts",
    "src\core\learning\CefrA1NavigateExecutableTaskDefinition.test.ts",
    "src\core\learning\CefrA1NavigateExecutableTaskSafety.ts",
    "src\core\learning\CefrA1NavigateExecutableTaskSafety.test.ts",
    "src\core\learning\CefrA1NavigateLanguageRealizationRegistry.ts",
    "src\core\learning\CefrA1NavigateLanguageRealizationRegistry.test.ts",
    "src\application\learning\CefrA1NavigateExecutableTaskService.ts",
    "src\application\learning\CefrA1NavigateExecutableTaskService.test.ts",
    "src\application\learning\CefrA1NavigateTargetLanguageSelectionModel.test.ts"
)

foreach ($relative in $required) {
    $path = Join-Path $app $relative

    if (-not (Test-Path $path)) {
        throw "Sprint 1464-1466 required file missing: $relative"
    }
}

$checks = @(
    @(
      "src\core\learning\CefrA1NavigateExecutableTaskDefinition.ts",
      '"a1-navigate-task-need-comprehension"'
    ),
    @(
      "src\core\learning\CefrA1NavigateExecutableTaskDefinition.ts",
      '"a1-navigate-evidence-information-question"'
    ),
    @(
      "src\application\learning\CefrA1NavigateExecutableTaskService.ts",
      'if (!input.userActionConfirmed)'
    ),
    @(
      "src\application\learning\CefrA1NavigateExecutableTaskService.ts",
      'if (!correct)'
    ),
    @(
      "src\application\learning\CefrA1NavigateExecutableTaskService.ts",
      'this.platform.recordUserEvidence('
    ),
    @(
      "src\core\learning\CefrA1NavigateLanguageRealizationRegistry.ts",
      '"first-executable-task-set-v1"'
    ),
    @(
      "src\core\learning\CefrA1NavigateExecutableTaskSafety.ts",
      'delayedRetrievalTaskAvailable:'
    )
)

foreach ($check in $checks) {
    $path = Join-Path $app $check[0]

    if (-not (
        Select-String `
            -Path $path `
            -SimpleMatch `
            -Pattern $check[1] `
            -Quiet
    )) {
        throw "Sprint 1464-1466 source marker missing: $($check[1])"
    }
}

Write-Host "SPRINT-1464-1466 SOURCE CHECK PASSED"

Set-Location $app

Write-Host ""
Write-Host "CHECKPOINT 3/3 — Sprint 1464-1466 target tests"

& npx vitest run @(
    "src/core/learning/CefrA1NavigateExecutableTaskDefinition.test.ts",
    "src/core/learning/CefrA1NavigateExecutableTaskSafety.test.ts",
    "src/core/learning/CefrA1NavigateLanguageRealizationRegistry.test.ts",
    "src/application/learning/CefrA1NavigateExecutableTaskService.test.ts",
    "src/application/learning/CefrA1NavigateTargetLanguageSelectionModel.test.ts",
    "src/core/learning/CefrA1NavigateRuntimeSliceDefinition.test.ts",
    "src/core/learning/CefrProductionRuntimeRegistryEnforcement.test.ts",
    "src/application/learning/CefrA1NavigateProductionRuntime.test.ts"
)

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1464-1466 target checkpoint failed."
}

Write-Host "SPRINT-1464-1466 TARGET CHECKPOINT PASSED"

Write-Host ""
Write-Host "FINAL 9-SPRINT BLOCK REGRESSION — one full run only"

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1458-1466 final full regression failed."
}

Write-Host ""
Write-Host "FINAL PRODUCTION BUILD"

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1458-1466 production build failed."
}

Write-Host ""
Write-Host "SPRINT-1458-1466 VERIFICATION COMPLETE"
