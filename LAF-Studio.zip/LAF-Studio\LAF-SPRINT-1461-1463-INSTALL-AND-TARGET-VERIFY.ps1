﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

$required = @(
    "src\core\learning\CefrA1NavigateLanguageContentRegistry.ts",
    "src\core\learning\CefrA1NavigateLanguageContentRegistry.test.ts",
    "src\core\learning\CefrA1NavigateLanguageContentSafety.ts",
    "src\core\learning\CefrA1NavigateLanguageContentSafety.test.ts",
    "src\core\learning\CefrA1NavigateLanguageRealizationRegistry.ts",
    "src\core\learning\CefrA1NavigateLanguageRealizationRegistry.test.ts",
    "src\application\learning\CefrA1NavigateLanguageContentView.ts",
    "src\application\learning\CefrA1NavigateLanguageContentView.test.ts",
    "src\application\learning\CefrA1NavigateTargetLanguageSelectionModel.test.ts"
)

foreach ($relative in $required) {
    $path = Join-Path $app $relative

    if (-not (Test-Path $path)) {
        throw "Sprint 1461-1463 required file missing: $relative"
    }
}

$checks = @(
    @(
      "src\core\learning\CefrA1NavigateLanguageContentRegistry.ts",
      '"a1-navigate-language-content-v1"'
    ),
    @(
      "src\core\learning\CefrA1NavigateLanguageContentRegistry.ts",
      '"Мне нужна помощь."'
    ),
    @(
      "src\core\learning\CefrA1NavigateLanguageRealizationRegistry.ts",
      'languageContentBound: true'
    ),
    @(
      "src\core\learning\CefrA1NavigateLanguageRealizationRegistry.ts",
      '"content-realized-v1"'
    ),
    @(
      "src\core\learning\CefrA1NavigateLanguageContentSafety.ts",
      'delayedRetrievalRuntimeEnabled:'
    ),
    @(
      "src\application\learning\CefrA1NavigateLanguageContentView.ts",
      'evidenceCaptureAvailable: false'
    )
)

foreach ($check in $checks) {
    $path = Join-Path $app $check[0]

    if (-not (
        Select-String `
            -Path $path `
            -SimpleMatch `
            -Pattern $check[1] `
            -Quiet
    )) {
        throw "Sprint 1461-1463 source marker missing: $($check[1])"
    }
}

Write-Host "SPRINT-1461-1463 SOURCE CHECK PASSED"

Set-Location $app

Write-Host ""
Write-Host "CHECKPOINT 2/3 — Sprint 1461-1463 target tests only"

& npx vitest run @(
    "src/core/learning/CefrA1NavigateLanguageContentRegistry.test.ts",
    "src/core/learning/CefrA1NavigateLanguageContentSafety.test.ts",
    "src/core/learning/CefrA1NavigateLanguageRealizationRegistry.test.ts",
    "src/core/learning/CefrA1NavigateLanguageRealizationBoundary.test.ts",
    "src/application/learning/CefrA1NavigateLanguageContentView.test.ts",
    "src/application/learning/CefrA1NavigateTargetLanguageSelectionModel.test.ts",
    "src/core/learning/CefrProductionRuntimeRegistryEnforcement.test.ts"
)

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1461-1463 target checkpoint failed."
}

Write-Host ""
Write-Host "SPRINT-1461-1463 TARGET CHECKPOINT COMPLETE"
Write-Host "No full regression/build in this 3-sprint checkpoint by design."
Write-Host "Stable production checkpoint remains Sprint 1457 until the 9-sprint block closes."
