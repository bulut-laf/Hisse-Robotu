$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 966-971 Rev1 Target Verification ==="
npx vitest run `
  "src/core/learning/CefrRecommendationContext.test.ts" `
  "src/core/learning/CefrSafeRecommendationOrchestration.test.ts" `
  "src/core/learning/CefrAdaptiveGuidancePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 966-971 Rev1 target verification failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-966-971 REV1 VERIFICATION COMPLETE"
