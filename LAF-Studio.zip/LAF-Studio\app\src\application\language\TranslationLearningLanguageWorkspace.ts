import {
  getLafLanguageProfile,
  LAF_LANGUAGE_PROFILES,
  type LafLanguageProfile,
  type LafLearningLanguageCode,
} from "../../core/language/LafLanguageProfile";

export interface TranslationLearningLanguageWorkspace {
  language: LafLearningLanguageCode;
  profile: LafLanguageProfile;
  sampleText: string;
  hasInputAssist: boolean;
}

const SAMPLE_TEXTS: Record<
  LafLearningLanguageCode,
  string
> = {
  hu:
    "Jó napot! Magyarul tanulok.",
  tr:
    "Merhaba! Türkçe öğreniyorum.",
  de:
    "Guten Tag! Ich lerne Deutsch.",
  it:
    "Buongiorno! Sto imparando l'italiano.",
  en:
    "Hello! I am learning English.",
  es:
    "¡Buenos días! Estoy aprendiendo español.",
  ru:
    "Здравствуйте! Я изучаю русский язык.",
};


export interface TranslationTargetLanguageOption {
  code: LafLearningLanguageCode;
  label: string;
  nativeLabel: string;
  displayLabel: string;
}

export interface TranslationTargetLanguageSelectorView {
  caption: "Hedef Dil";
  currentCode: LafLearningLanguageCode;
  currentLabel: string;
  options: readonly TranslationTargetLanguageOption[];
}

export function createTranslationTargetLanguageSelectorView(
  language: LafLearningLanguageCode,
): TranslationTargetLanguageSelectorView {
  const current = getLafLanguageProfile(language);

  return {
    caption: "Hedef Dil",
    currentCode: language,
    currentLabel: `${current.label} • ${current.nativeLabel}`,
    options: LAF_LANGUAGE_PROFILES.map(profile => ({
      code: profile.code,
      label: profile.label,
      nativeLabel: profile.nativeLabel,
      displayLabel: `${profile.label} • ${profile.nativeLabel}`,
    })),
  };
}

export function getTranslationLearningLanguageOptions(): readonly LafLanguageProfile[] {
  return LAF_LANGUAGE_PROFILES;
}

export function createTranslationLearningLanguageWorkspace(
  language: LafLearningLanguageCode,
): TranslationLearningLanguageWorkspace {
  const profile =
    getLafLanguageProfile(language);

  return {
    language,
    profile,
    sampleText:
      SAMPLE_TEXTS[language],
    hasInputAssist:
      profile.specialCharacters.length >
        0 ||
      Boolean(
        profile.keyboardRows?.length,
      ),
  };
}
