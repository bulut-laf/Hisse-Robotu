﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$core = Join-Path $app "src\core\learning"
$payload = Join-Path $root "_repair_payload"

$auditPath =
    Join-Path $core "CefrProductionRuntimeEvidenceEligibilityAudit.ts"
$auditTestPath =
    Join-Path $core "CefrProductionRuntimeEvidenceEligibilityAudit.test.ts"

$payloadAudit =
    Join-Path $payload "CefrProductionRuntimeEvidenceEligibilityAudit.ts"
$payloadAuditTest =
    Join-Path $payload "CefrProductionRuntimeEvidenceEligibilityAudit.test.ts"

foreach ($path in @(
    $auditPath,
    $auditTestPath,
    $payloadAudit,
    $payloadAuditTest
)) {
    if (-not (Test-Path $path)) {
        throw "Rev5 required file missing: $path"
    }
}

$timestamp =
    Get-Date -Format "yyyyMMdd-HHmmss"

$backupDir =
    Join-Path $root (
        "_sprint_backups\Sprint1497-1505-Rev5-" +
        $timestamp
    )

New-Item `
    -ItemType Directory `
    -Path $backupDir `
    -Force |
    Out-Null

Copy-Item `
    -LiteralPath $auditPath `
    -Destination (
        Join-Path $backupDir "CefrProductionRuntimeEvidenceEligibilityAudit.ts"
    ) `
    -Force

Copy-Item `
    -LiteralPath $auditTestPath `
    -Destination (
        Join-Path $backupDir "CefrProductionRuntimeEvidenceEligibilityAudit.test.ts"
    ) `
    -Force

# Replace only the corrupted audit source and its exact authority test.
Copy-Item `
    -LiteralPath $payloadAudit `
    -Destination $auditPath `
    -Force

Copy-Item `
    -LiteralPath $payloadAuditTest `
    -Destination $auditTestPath `
    -Force

$source =
    [System.IO.File]::ReadAllText($auditPath)

$requiredMarkers = @(
    'import type {',
    'LAF_POLICY_GATED_DELAYED_RETRIEVAL_EVIDENCE_IDS',
    '"a1-connect-evidence-delayed-retrieval"',
    '"a1-navigate-evidence-delayed-retrieval"',
    '"a1-describe-evidence-delayed-retrieval"',
    'auditCefrProductionRuntimeEvidenceEligibility',
    'assertCefrProductionRuntimeEvidenceEligibility'
)

foreach ($marker in $requiredMarkers) {
    if (-not $source.Contains($marker)) {
        throw "Rev5 clean audit source marker missing: $marker"
    }
}

$describeCount =
    [regex]::Matches(
        $source,
        [regex]::Escape(
            "a1-describe-evidence-delayed-retrieval"
        )
    ).Count

if ($describeCount -ne 1) {
    throw "Rev5 expected exactly one DESCRIBE delayed-retrieval authority; found $describeCount."
}

Write-Host "SPRINT-1497-1505 REV5 CLEAN AUDIT RESTORE APPLIED"
Write-Host "Backup: $backupDir"

Set-Location $app

Write-Host ""
Write-Host "REV5 PARSE PROBE — clean production eligibility audit"

& npx vitest run `
    "src/core/learning/CefrProductionRuntimeEvidenceEligibilityAudit.test.ts"

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1503-1505 Rev5 audit parse/authority probe failed."
}

Write-Host "REV5 AUDIT PARSE/AUTHORITY PROBE PASSED"

Write-Host ""
Write-Host "CHECKPOINT 3/3 — Sprint 1503-1505 Rev5 production runtime integration"

& npx vitest run @(
    "src/core/learning/CefrA1DescribeRuntimeSliceDefinition.test.ts",
    "src/core/learning/CefrProductionRuntimeSliceRegistry.test.ts",
    "src/core/learning/CefrProductionRuntimeRegistryEnforcement.test.ts",
    "src/core/learning/CefrProductionRuntimeEvidenceEligibilityAudit.test.ts",
    "src/application/learning/CefrProductionRuntimeDelayedRetrievalVisibility.test.ts",
    "src/application/learning/CefrA1DescribeProductionRuntime.test.ts",
    "src/application/learning/CefrProductionRuntimePlatform.test.ts"
)

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1503-1505 Rev5 target checkpoint failed."
}

Write-Host "SPRINT-1503-1505 REV5 TARGET CHECKPOINT PASSED"

Write-Host ""
Write-Host "FINAL 9-SPRINT BLOCK REGRESSION — one full run only"

& npm run test

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1497-1505 Rev5 final full regression failed."
}

Write-Host ""
Write-Host "FINAL PRODUCTION BUILD"

& npm run build

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1497-1505 Rev5 production build failed."
}

Write-Host ""
Write-Host "SPRINT-1497-1505 REV5 VERIFICATION COMPLETE"
