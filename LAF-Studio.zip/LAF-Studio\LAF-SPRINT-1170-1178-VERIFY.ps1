$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 1170-1172 Target Tests: Session Start Acknowledgement ==="
npx vitest run `
  "src/core/learning/CefrGuidanceSessionStartResult.test.ts" `
  "src/core/learning/CefrGuidanceSessionStartAcknowledgement.test.ts" `
  "src/core/learning/CefrGuidanceActiveSessionContext.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1170-1172 target tests failed." }

Write-Host "=== Sprint 1173-1175 Target Tests: Runtime Observation ==="
npx vitest run `
  "src/core/learning/CefrGuidanceSessionRuntimeObservation.test.ts" `
  "src/core/learning/CefrGuidanceSessionRuntimeSnapshot.test.ts" `
  "src/core/learning/CefrGuidanceSessionRuntimeBoundary.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1173-1175 target tests failed." }

Write-Host "=== Sprint 1176-1178 Target Tests: Session Completion Handoff ==="
npx vitest run `
  "src/core/learning/CefrGuidanceSessionCompletionResult.test.ts" `
  "src/core/learning/CefrGuidanceSessionCompletionAcknowledgement.test.ts" `
  "src/core/learning/CefrGuidanceApplicationSessionCycle.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1176-1178 target tests failed." }

Write-Host "=== Combined Sprint 1170-1178 New Tests ==="
npx vitest run `
  "src/core/learning/CefrGuidanceSessionStartResult.test.ts" `
  "src/core/learning/CefrGuidanceSessionStartAcknowledgement.test.ts" `
  "src/core/learning/CefrGuidanceActiveSessionContext.test.ts" `
  "src/core/learning/CefrGuidanceSessionRuntimeObservation.test.ts" `
  "src/core/learning/CefrGuidanceSessionRuntimeSnapshot.test.ts" `
  "src/core/learning/CefrGuidanceSessionRuntimeBoundary.test.ts" `
  "src/core/learning/CefrGuidanceSessionCompletionResult.test.ts" `
  "src/core/learning/CefrGuidanceSessionCompletionAcknowledgement.test.ts" `
  "src/core/learning/CefrGuidanceApplicationSessionCycle.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1170-1178 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-1170-1178 VERIFICATION COMPLETE"
