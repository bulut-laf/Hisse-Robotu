﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$report = Join-Path $root "SPRINT-1503-1505-REV2-DIAGNOSTIC.txt"

if (-not (Test-Path $app)) {
    throw "LAF Studio app klasoru bulunamadi: $app"
}

$tests = @(
    "src/core/learning/CefrA1DescribeRuntimeSliceDefinition.test.ts",
    "src/core/learning/CefrProductionRuntimeSliceRegistry.test.ts",
    "src/core/learning/CefrProductionRuntimeRegistryEnforcement.test.ts",
    "src/core/learning/CefrProductionRuntimeEvidenceEligibilityAudit.test.ts",
    "src/application/learning/CefrProductionRuntimeDelayedRetrievalVisibility.test.ts",
    "src/application/learning/CefrA1DescribeProductionRuntime.test.ts",
    "src/application/learning/CefrProductionRuntimePlatform.test.ts"
)

foreach ($test in $tests) {
    $full = Join-Path $app $test
    if (-not (Test-Path $full)) {
        throw "Checkpoint 3 test dosyasi bulunamadi: $test"
    }
}

if (Test-Path $report) {
    Remove-Item $report -Force
}

$header = @"
LAF STUDIO
SPRINT-1503-1505 REV2 DIAGNOSTIC
Generated: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")
Mode: READ ONLY
Previous checkpoints: 1497-1499 PASSED / 1500-1502 PASSED
Scope: Sprint 1503-1505 target tests only
No source mutation
No full regression
No production build

"@

[System.IO.File]::WriteAllText(
    $report,
    $header,
    (New-Object System.Text.UTF8Encoding($false))
)

Set-Location $app

$failed = New-Object System.Collections.Generic.List[string]
$passed = New-Object System.Collections.Generic.List[string]

foreach ($test in $tests) {
    $separator = @"

================================================================================
TEST: $test
================================================================================
"@
    Add-Content -LiteralPath $report -Value $separator -Encoding UTF8

    Write-Host ""
    Write-Host "============================================================"
    Write-Host "DIAGNOSTIC TEST: $test"
    Write-Host "============================================================"

    $temp = Join-Path $env:TEMP ("laf-vitest-" + [Guid]::NewGuid().ToString("N") + ".txt")

    try {
        & npx vitest run $test --reporter=verbose 2>&1 |
            Tee-Object -FilePath $temp

        $exitCode = $LASTEXITCODE

        if (Test-Path $temp) {
            Get-Content -LiteralPath $temp |
                Add-Content -LiteralPath $report -Encoding UTF8
        }

        Add-Content -LiteralPath $report `
            -Value "`nEXIT_CODE=$exitCode`n" `
            -Encoding UTF8

        if ($exitCode -eq 0) {
            $passed.Add($test)
            Write-Host "PASS: $test"
        }
        else {
            $failed.Add($test)
            Write-Host "FAIL: $test"
        }
    }
    finally {
        if (Test-Path $temp) {
            Remove-Item $temp -Force -ErrorAction SilentlyContinue
        }
    }
}

$summary = @"

================================================================================
SUMMARY
================================================================================
PASSED=$($passed.Count)
FAILED=$($failed.Count)

PASSED TESTS:
$($passed -join [Environment]::NewLine)

FAILED TESTS:
$($failed -join [Environment]::NewLine)

REPORT:
$report
"@

Add-Content -LiteralPath $report -Value $summary -Encoding UTF8

Write-Host ""
Write-Host "============================================================"
Write-Host "SPRINT-1503-1505 REV2 DIAGNOSTIC COMPLETE"
Write-Host "Passed: $($passed.Count)"
Write-Host "Failed: $($failed.Count)"
Write-Host "Report: $report"
Write-Host "============================================================"

if ($failed.Count -gt 0) {
    Write-Host ""
    Write-Host "FAILED TESTS:"
    foreach ($item in $failed) {
        Write-Host " - $item"
    }

    throw "Sprint 1503-1505 Rev2 diagnostic found $($failed.Count) failing test file(s)."
}

Write-Host ""
Write-Host "All checkpoint-3 tests passed individually. If the grouped checkpoint still fails, the issue is in grouped execution or verifier orchestration."
