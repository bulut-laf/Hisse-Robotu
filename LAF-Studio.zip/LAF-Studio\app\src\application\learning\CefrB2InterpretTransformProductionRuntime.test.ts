import {describe,expect,it} from "vitest";
import {
 createCefrPersonalLanguageProfileState,
 type CefrPersonalLanguageProfileState
} from "../../core/learning/CefrPersonalLanguageProfileState";
import type {CefrLanguageEvidenceStorageLike} from "./CefrAuthoritativeLanguageEvidenceProvenanceRepository";
import type {CefrGuidanceRuntimeProfileRepository} from "./CefrGuidanceRuntimeProfileRepository";
import {CefrProductionRuntimePlatform} from "./CefrProductionRuntimePlatform";

class R implements CefrGuidanceRuntimeProfileRepository {
 private s:CefrPersonalLanguageProfileState=createCefrPersonalLanguageProfileState([],[]);
 load(){return this.s}
 save(s:CefrPersonalLanguageProfileState){this.s=s}
 hasPersistedProfile(){return false}
 clear(){}
}
class S implements CefrLanguageEvidenceStorageLike {
 private m=new Map<string,string>();
 getItem(k:string){return this.m.get(k)??null}
 setItem(k:string,v:string){this.m.set(k,v)}
 removeItem(k:string){this.m.delete(k)}
}

describe("B2 INTERPRET & TRANSFORM production runtime",()=>{
 it("resolves discovered authoritative capability mapping observationally",()=>{
  const r=new R();
  const p=new CefrProductionRuntimePlatform(r,new S());
  const result=p.recordUserEvidence(
   "b2-interpret-transform",
   {
    evidenceDefinitionId:"b2-interpret-transform-evidence-purposeful-complete-relay",
    eventId:"b2-interpret-transform-runtime-001",
    occurredAt:new Date("2026-08-15T19:00:00.000Z"),
    languageCode:"hu",
    userActionConfirmed:true
   }
  );
  expect(result).toMatchObject({
   evidencePersisted:true,
   masteryAssigned:false,
   competencySuccessAssigned:false,
   cefrLevelAssigned:false,
   progressionPerformed:false
  });
  expect(result.runtime.resolvedCapabilityReferences).toEqual([
   "summarization-reformulation",
   "information-synthesis",
   "meaning-context-adaptation"
  ]);
  expect(
   r.load().capabilityObservationRegistry.observations
    .map(x=>x.capabilityReference)
  ).toEqual([
   "summarization-reformulation",
   "information-synthesis",
   "meaning-context-adaptation"
  ]);
 });
 it("rejects delayed retrieval until separate policy exists",()=>{
  const p=new CefrProductionRuntimePlatform(new R(),new S());
  expect(()=>p.recordUserEvidence(
   "b2-interpret-transform",
   {
    evidenceDefinitionId:"b2-interpret-transform-evidence-delayed-retrieval",
    eventId:"b2-interpret-transform-delayed",
    occurredAt:new Date("2026-08-15T19:05:00.000Z"),
    languageCode:"hu",
    userActionConfirmed:true
   }
  )).toThrow("Unknown authoritative CEFR evidence definition");
 });
});
