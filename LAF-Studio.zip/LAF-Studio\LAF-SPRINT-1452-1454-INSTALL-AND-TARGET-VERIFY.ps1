﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

$required = @(
    "src\core\learning\CefrProductionRuntimeEvidenceEligibilityAudit.ts",
    "src\core\learning\CefrProductionRuntimeEvidenceEligibilityAudit.test.ts",
    "src\core\learning\CefrProductionRuntimeEvidenceEligibilitySafety.ts",
    "src\core\learning\CefrProductionRuntimeEvidenceEligibilitySafety.test.ts",
    "src\core\learning\CefrProductionRuntimeSliceRegistryEligibility.test.ts",
    "src\application\learning\CefrProductionRuntimeDelayedRetrievalVisibility.test.ts"
)

foreach ($relative in $required) {
    $path = Join-Path $app $relative

    if (-not (Test-Path $path)) {
        throw "Sprint 1452-1454 required file missing: $relative"
    }
}

$sourceChecks = @(
    @(
      "src\core\learning\CefrProductionRuntimeEvidenceEligibilityAudit.ts",
      '"a1-connect-evidence-delayed-retrieval"'
    ),
    @(
      "src\core\learning\CefrProductionRuntimeEvidenceEligibilityAudit.ts",
      '"a1-navigate-evidence-delayed-retrieval"'
    ),
    @(
      "src\core\learning\CefrProductionRuntimeEvidenceEligibilitySafety.ts",
      'timingThresholdMayBeInvented:'
    ),
    @(
      "src\application\learning\CefrProductionRuntimeDelayedRetrievalVisibility.test.ts",
      'read.coverage'
    )
)

foreach ($check in $sourceChecks) {
    $path = Join-Path $app $check[0]

    if (-not (
        Select-String `
            -Path $path `
            -SimpleMatch `
            -Pattern $check[1] `
            -Quiet
    )) {
        throw "Sprint 1452-1454 source marker missing: $($check[1])"
    }
}

Write-Host "SPRINT-1452-1454 SOURCE CHECK PASSED"

Set-Location $app

Write-Host ""
Write-Host "CHECKPOINT 2/3 — Sprint 1452-1454 target tests only"

& npx vitest run @(
    "src/core/learning/CefrProductionRuntimeEvidenceEligibilityAudit.test.ts",
    "src/core/learning/CefrProductionRuntimeEvidenceEligibilitySafety.test.ts",
    "src/core/learning/CefrProductionRuntimeSliceRegistryEligibility.test.ts",
    "src/application/learning/CefrProductionRuntimeDelayedRetrievalVisibility.test.ts",
    "src/core/learning/CefrProductionRuntimeSliceRegistry.test.ts",
    "src/application/learning/CefrRuntimeAssemblyFactory.test.ts",
    "src/application/learning/CefrA1ConnectDelayedRetrievalGenericRuntime.test.ts",
    "src/application/learning/CefrA1NavigateProductionRuntime.test.ts"
)

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1452-1454 target checkpoint failed."
}

Write-Host ""
Write-Host "SPRINT-1452-1454 TARGET CHECKPOINT COMPLETE"
Write-Host "No full regression/build in this 3-sprint checkpoint by design."
Write-Host "Stable production checkpoint remains Sprint 1448 until the 9-sprint block closes."
