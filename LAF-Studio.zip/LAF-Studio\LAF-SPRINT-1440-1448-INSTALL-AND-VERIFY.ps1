﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$core = Join-Path $app "src\core\learning"

$utf8 = New-Object System.Text.UTF8Encoding($false)

function Read-Utf8([string]$path) {
    return [System.IO.File]::ReadAllText($path, $utf8)
}

function Write-Utf8(
    [string]$path,
    [string]$text
) {
    [System.IO.File]::WriteAllText($path, $text, $utf8)
}

# -------------------------------------------------------------------
# Patch authoritative curriculum catalog: add approved A1 NAVIGATE Unit
# and four lessons without rewriting existing A1 CONNECT content.
# -------------------------------------------------------------------
$catalogPath = Join-Path $core "CefrAuthoritativeCurriculumCatalog.ts"
if (-not (Test-Path $catalogPath)) {
    throw "CefrAuthoritativeCurriculumCatalog.ts missing."
}

$catalog = Read-Utf8 $catalogPath

if (-not $catalog.Contains(
    'from "./CefrA1NavigateCurriculum";'
)) {
    $exportAnchor =
        'export const LAF_A1_CONNECT_FIRST_SOCIAL_ENCOUNTER_UNIT:'

    if (-not $catalog.Contains($exportAnchor)) {
        throw "Authoritative curriculum catalog export anchor missing."
    }

    $navigateImport = @'
import {
  LAF_A1_NAVIGATE_IMMEDIATE_EVERYDAY_NEEDS_LESSONS,
  LAF_A1_NAVIGATE_IMMEDIATE_EVERYDAY_NEEDS_UNIT,
} from "./CefrA1NavigateCurriculum";

'@

    $catalog = $catalog.Replace(
        $exportAnchor,
        $navigateImport + $exportAnchor
    )
}

if (-not $catalog.Contains(
    'LAF_A1_NAVIGATE_IMMEDIATE_EVERYDAY_NEEDS_UNIT,'
)) {
    $unitAnchor =
        '  LAF_A1_CONNECT_FIRST_SOCIAL_ENCOUNTER_UNIT,'

    if (-not $catalog.Contains($unitAnchor)) {
        throw "Authoritative unit array anchor missing."
    }

    $catalog = $catalog.Replace(
        $unitAnchor,
        $unitAnchor +
        [Environment]::NewLine +
        '  LAF_A1_NAVIGATE_IMMEDIATE_EVERYDAY_NEEDS_UNIT,'
    )
}

if (-not $catalog.Contains(
    '...LAF_A1_NAVIGATE_IMMEDIATE_EVERYDAY_NEEDS_LESSONS,'
)) {
    $lessonAnchor =
        '  ...LAF_A1_CONNECT_FIRST_SOCIAL_ENCOUNTER_LESSONS,'

    if (-not $catalog.Contains($lessonAnchor)) {
        throw "Authoritative lesson array anchor missing."
    }

    $catalog = $catalog.Replace(
        $lessonAnchor,
        $lessonAnchor +
        [Environment]::NewLine +
        '  ...LAF_A1_NAVIGATE_IMMEDIATE_EVERYDAY_NEEDS_LESSONS,'
    )
}

Write-Utf8 $catalogPath $catalog

# -------------------------------------------------------------------
# Patch authoritative Learning Item -> Competency mappings.
# -------------------------------------------------------------------
$registryPath = Join-Path $core "CefrAuthoritativeCurriculumRegistry.ts"
if (-not (Test-Path $registryPath)) {
    throw "CefrAuthoritativeCurriculumRegistry.ts missing."
}

$registry = Read-Utf8 $registryPath

if (-not $registry.Contains(
    '"curriculum-map-a1-navigate-v1"'
)) {
    $mappingStart =
        $registry.IndexOf(
            'export const LAF_CEFR_CURRICULUM_COMPETENCY_MAPPINGS:'
        )

    if ($mappingStart -lt 0) {
        throw "Curriculum mapping array start missing."
    }

    $mappingEnd =
        $registry.IndexOf(
            '];',
            $mappingStart
        )

    if ($mappingEnd -lt 0) {
        throw "Curriculum mapping array end missing."
    }

    $navigateMappings = @'
  {
    learningItemId:
      "a1-navigate-express-immediate-need",
    learningItemType: "lesson",
    competencyOutcomeIds: [
      "navigate-a1",
    ],
    mappingAuthority:
      "unit-lesson-curriculum-definition",
    mappingVersion:
      "curriculum-map-a1-navigate-v1",
    authoritative: true,
  },
  {
    learningItemId:
      "a1-navigate-ask-essential-information",
    learningItemType: "lesson",
    competencyOutcomeIds: [
      "navigate-a1",
    ],
    mappingAuthority:
      "unit-lesson-curriculum-definition",
    mappingVersion:
      "curriculum-map-a1-navigate-v1",
    authoritative: true,
  },
  {
    learningItemId:
      "a1-navigate-understand-practical-answer",
    learningItemType: "lesson",
    competencyOutcomeIds: [
      "navigate-a1",
    ],
    mappingAuthority:
      "unit-lesson-curriculum-definition",
    mappingVersion:
      "curriculum-map-a1-navigate-v1",
    authoritative: true,
  },
  {
    learningItemId:
      "a1-navigate-complete-need-exchange",
    learningItemType: "lesson",
    competencyOutcomeIds: [
      "navigate-a1",
    ],
    mappingAuthority:
      "unit-lesson-curriculum-definition",
    mappingVersion:
      "curriculum-map-a1-navigate-v1",
    authoritative: true,
  },

'@

    $registry =
        $registry.Insert(
            $mappingEnd,
            $navigateMappings
        )
}

Write-Utf8 $registryPath $registry

# -------------------------------------------------------------------
# Patch production runtime slice registry: register A1 NAVIGATE.
# -------------------------------------------------------------------
$productionRegistryPath =
    Join-Path $core "CefrProductionRuntimeSliceRegistry.ts"

if (-not (Test-Path $productionRegistryPath)) {
    throw "CefrProductionRuntimeSliceRegistry.ts missing."
}

$productionRegistry =
    Read-Utf8 $productionRegistryPath

if (-not $productionRegistry.Contains(
    'createLafA1NavigateRuntimeSliceDefinition'
)) {
    $connectImportAnchor =
        'import {' +
        [Environment]::NewLine +
        '  createLafA1ConnectRuntimeSliceDefinition,' +
        [Environment]::NewLine +
        '} from "./CefrA1ConnectRuntimeSliceDefinition";'

    if (-not $productionRegistry.Contains(
        $connectImportAnchor
    )) {
        $connectImportAnchor =
            'from "./CefrA1ConnectRuntimeSliceDefinition";'

        $pos =
            $productionRegistry.IndexOf(
                $connectImportAnchor
            )

        if ($pos -lt 0) {
            throw "A1 CONNECT production runtime import anchor missing."
        }

        $insertPos =
            $pos +
            $connectImportAnchor.Length

        $navigateImport =
            [Environment]::NewLine +
            'import {' +
            [Environment]::NewLine +
            '  createLafA1NavigateRuntimeSliceDefinition,' +
            [Environment]::NewLine +
            '} from "./CefrA1NavigateRuntimeSliceDefinition";'

        $productionRegistry =
            $productionRegistry.Insert(
                $insertPos,
                $navigateImport
            )
    }
    else {
        $navigateImport =
            $connectImportAnchor +
            [Environment]::NewLine +
            'import {' +
            [Environment]::NewLine +
            '  createLafA1NavigateRuntimeSliceDefinition,' +
            [Environment]::NewLine +
            '} from "./CefrA1NavigateRuntimeSliceDefinition";'

        $productionRegistry =
            $productionRegistry.Replace(
                $connectImportAnchor,
                $navigateImport
            )
    }
}

if (-not $productionRegistry.Contains(
    '    createLafA1NavigateRuntimeSliceDefinition(),'
)) {
    $sliceAnchor =
        '    createLafA1ConnectRuntimeSliceDefinition(),'

    if (-not $productionRegistry.Contains(
        $sliceAnchor
    )) {
        throw "Production runtime slice array anchor missing."
    }

    $productionRegistry =
        $productionRegistry.Replace(
            $sliceAnchor,
            $sliceAnchor +
            [Environment]::NewLine +
            '    createLafA1NavigateRuntimeSliceDefinition(),'
        )
}

Write-Utf8 $productionRegistryPath $productionRegistry

# -------------------------------------------------------------------
# Source checks before tests.
# -------------------------------------------------------------------
$sourceChecks = @(
    @(
      (Join-Path $core "CefrA1NavigateCurriculum.ts"),
      '"a1-navigate-immediate-everyday-needs"'
    ),
    @(
      (Join-Path $core "CefrA1NavigateEvidenceDefinition.ts"),
      '"a1-navigate-evidence-delayed-retrieval"'
    ),
    @(
      (Join-Path $core "CefrA1NavigateEvidenceDefinition.ts"),
      'runtimeWriteEnabled: false'
    ),
    @(
      $catalogPath,
      'LAF_A1_NAVIGATE_IMMEDIATE_EVERYDAY_NEEDS_UNIT,'
    ),
    @(
      $registryPath,
      '"curriculum-map-a1-navigate-v1"'
    ),
    @(
      $productionRegistryPath,
      'createLafA1NavigateRuntimeSliceDefinition(),'
    ),
    @(
      (Join-Path $core "CefrA1NavigateImplementationSafety.ts"),
      'automaticTransactionCompletionAllowed:'
    )
)

foreach ($pair in $sourceChecks) {
    if (-not (
        Select-String `
            -Path $pair[0] `
            -SimpleMatch `
            -Pattern $pair[1] `
            -Quiet
    )) {
        throw "Sprint 1440-1448 source marker missing: $($pair[1])"
    }
}

Write-Host "SPRINT-1440-1448 SOURCE CHECK PASSED"

Set-Location $app

# -------------------------------------------------------------------
# 3 x 3-sprint target checkpoints.
# Only one full regression + build at the end.
# -------------------------------------------------------------------
Write-Host ""
Write-Host "CHECKPOINT 1/3 — Sprint 1440-1442 authoritative curriculum content"

& npx vitest run @(
    "src/core/learning/CefrA1NavigateCurriculum.test.ts",
    "src/core/learning/CefrA1NavigateEvidenceDefinition.test.ts",
    "src/core/learning/CefrA1NavigateLearningExperienceCatalog.test.ts",
    "src/core/learning/CefrA1NavigateImplementationSafety.test.ts"
)

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1440-1442 target checkpoint failed."
}

Write-Host "SPRINT-1440-1442 TARGET CHECKPOINT PASSED"

Write-Host ""
Write-Host "CHECKPOINT 2/3 — Sprint 1443-1445 curriculum/capability authority activation"

& npx vitest run @(
    "src/core/learning/CefrA1NavigateRuntimeEvidenceCatalog.test.ts",
    "src/core/learning/CefrAuthoritativeCurriculumRegistry.test.ts",
    "src/core/learning/CefrAuthoritativeCapabilityRegistry.test.ts",
    "src/application/learning/CefrCurriculumCapabilityObservationWriter.test.ts"
)

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1443-1445 target checkpoint failed."
}

Write-Host "SPRINT-1443-1445 TARGET CHECKPOINT PASSED"

Write-Host ""
Write-Host "CHECKPOINT 3/3 — Sprint 1446-1448 production runtime activation"

& npx vitest run @(
    "src/core/learning/CefrA1NavigateRuntimeSliceDefinition.test.ts",
    "src/core/learning/CefrProductionRuntimeSliceRegistry.test.ts",
    "src/application/learning/CefrProductionRuntimePlatform.test.ts",
    "src/application/learning/CefrA1NavigateProductionRuntime.test.ts"
)

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1446-1448 target checkpoint failed."
}

Write-Host "SPRINT-1446-1448 TARGET CHECKPOINT PASSED"

Write-Host ""
Write-Host "FINAL BLOCK REGRESSION — one full run only"

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1440-1448 final full regression failed."
}

Write-Host ""
Write-Host "FINAL PRODUCTION BUILD"

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1440-1448 production build failed."
}

Write-Host ""
Write-Host "SPRINT-1440-1448 VERIFICATION COMPLETE"
