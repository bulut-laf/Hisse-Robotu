import { describe, expect, it } from "vitest";
import { createCefrActivationProgressFeedbackView } from "./CefrActivationProgressFeedbackView";

describe("CefrActivationProgressFeedbackView", () => {
  it("reuses the existing not-started / in-progress / complete repository vocabulary", () => {
    expect(createCefrActivationProgressFeedbackView({activationStarted:false,activationCompleted:false,existingAuthoritativeEvidenceObserved:false})).toMatchObject({status:"not-started",statusLabel:"Başlamadı",completionLabel:null});
    expect(createCefrActivationProgressFeedbackView({activationStarted:true,activationCompleted:false,existingAuthoritativeEvidenceObserved:false})).toMatchObject({status:"in-progress",statusLabel:"Devam Ediyor",completionLabel:null});
    expect(createCefrActivationProgressFeedbackView({activationStarted:true,activationCompleted:true,existingAuthoritativeEvidenceObserved:false})).toMatchObject({status:"complete",statusLabel:"Tamamlandı",completionLabel:"Gerçek hayat çalışması tamamlandı."});
  });

  it("keeps completion, observed evidence and mastery/CEFR language separate", () => {
    const result=createCefrActivationProgressFeedbackView({activationStarted:true,activationCompleted:true,existingAuthoritativeEvidenceObserved:false});
    expect(result).toMatchObject({observedLabel:"Bu activation completion yeni competency evidence üretmedi.",masteryLabel:null,safetyLabel:"Tamamlanma mastery veya CEFR doğrulaması değildir.",evidenceCreatedByActivation:false,masteryInferred:false,cefrLevelInferred:false,progressionPerformed:false,automaticStudioLaunchPerformed:false});
  });
});
