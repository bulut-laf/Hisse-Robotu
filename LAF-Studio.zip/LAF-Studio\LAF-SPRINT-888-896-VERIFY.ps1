$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 888-890 Target Tests: Custodial Operationalization ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialOperationalization.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialOperationalizationCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialOperationalizationAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 888-890 target tests failed." }

Write-Host "=== Sprint 891-893 Target Tests: Custodial Execution ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialExecution.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialExecutionCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialExecutionAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 891-893 target tests failed." }

Write-Host "=== Sprint 894-896 Target Tests: Custodial Delivery ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialDelivery.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialDeliveryCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialDeliveryAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 894-896 target tests failed." }

Write-Host "=== Combined Sprint 888-896 New Tests ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialOperationalization.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialOperationalizationCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialOperationalizationAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialExecution.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialExecutionCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialExecutionAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialDelivery.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialDeliveryCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialDeliveryAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 888-896 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-888-896 VERIFICATION COMPLETE"
