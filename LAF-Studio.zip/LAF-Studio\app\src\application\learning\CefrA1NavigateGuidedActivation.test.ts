import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrA1NavigateGuidedActivation,
} from "./CefrA1NavigateGuidedActivation";

describe(
  "A1 NAVIGATE guided real-life activation",
  () => {
    it("implements the approved four-contribution activation shape in the selected target language", () => {
      const result =
        createCefrA1NavigateGuidedActivation(
          "hu",
        );

      expect(result).toMatchObject({
        activationId:
          "a1-navigate-activation-immediate-everyday-need",
        languageCode: "hu",
        scenario:
          "familiar-everyday-service-or-public-setting",
        goal:
          "meet-one-immediate-practical-need",
        supportAvailable: true,
        userStartRequired: true,
        rehearsalOnly: true,
        activationEvidenceWritten: false,
        masteryGate: false,
        automaticProgressionAllowed:
          false,
        delayedRetrievalRequired: false,
      });

      expect(
        result.steps.map(
          step => step.stepId,
        ),
      ).toEqual([
        "need-or-request",
        "essential-question",
        "understand-response",
        "acknowledge-or-close",
      ]);

      expect(
        result.steps[0]?.exampleTargetText,
      ).toBe("Szeretnék egy vizet.");
    });

    it("does not turn activation rehearsal into an evidence write", () => {
      for (
        const step of
        createCefrA1NavigateGuidedActivation(
          "it",
        ).steps
      ) {
        expect(step.rehearsalOnly).toBe(
          true,
        );
      }
    });
  },
);
