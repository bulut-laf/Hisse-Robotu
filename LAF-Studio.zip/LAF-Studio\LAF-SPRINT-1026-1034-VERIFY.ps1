$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 1026-1028 Target Tests: Focus History ==="
npx vitest run `
  "src/core/learning/CefrLearningFocusHistoryEntry.test.ts" `
  "src/core/learning/CefrLearningFocusHistory.test.ts" `
  "src/core/learning/CefrLearningFocusHistorySnapshot.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1026-1028 target tests failed." }

Write-Host "=== Sprint 1029-1031 Target Tests: Repeated Observation Pattern ==="
npx vitest run `
  "src/core/learning/CefrRepeatedCapabilityObservation.test.ts" `
  "src/core/learning/CefrCapabilityObservationPatternRegistry.test.ts" `
  "src/core/learning/CefrRepeatedObservationContext.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1029-1031 target tests failed." }

Write-Host "=== Sprint 1032-1034 Target Tests: Safe Practice Priority ==="
npx vitest run `
  "src/core/learning/CefrPracticePriorityCandidate.test.ts" `
  "src/core/learning/CefrUserPracticePriorityChoice.test.ts" `
  "src/core/learning/CefrSafePracticePriorityOrchestration.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1032-1034 target tests failed." }

Write-Host "=== Combined Sprint 1026-1034 New Tests ==="
npx vitest run `
  "src/core/learning/CefrLearningFocusHistoryEntry.test.ts" `
  "src/core/learning/CefrLearningFocusHistory.test.ts" `
  "src/core/learning/CefrLearningFocusHistorySnapshot.test.ts" `
  "src/core/learning/CefrRepeatedCapabilityObservation.test.ts" `
  "src/core/learning/CefrCapabilityObservationPatternRegistry.test.ts" `
  "src/core/learning/CefrRepeatedObservationContext.test.ts" `
  "src/core/learning/CefrPracticePriorityCandidate.test.ts" `
  "src/core/learning/CefrUserPracticePriorityChoice.test.ts" `
  "src/core/learning/CefrSafePracticePriorityOrchestration.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1026-1034 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-1026-1034 VERIFICATION COMPLETE"
