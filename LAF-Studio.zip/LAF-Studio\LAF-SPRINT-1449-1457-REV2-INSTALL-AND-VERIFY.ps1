﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$slicePath =
    Join-Path $app "src\core\learning\CefrA1ConnectRuntimeSliceDefinition.ts"

$utf8 = New-Object System.Text.UTF8Encoding($false)

function Read-Utf8([string]$path) {
    return [System.IO.File]::ReadAllText($path, $utf8)
}

function Write-Utf8(
    [string]$path,
    [string]$text
) {
    [System.IO.File]::WriteAllText($path, $text, $utf8)
}

if (-not (Test-Path $slicePath)) {
    throw "CefrA1ConnectRuntimeSliceDefinition.ts missing."
}

$text = Read-Utf8 $slicePath

$newFactory =
    "createLafA1ConnectExecutableRuntimeEvidenceRegistry"

if (-not $text.Contains($newFactory)) {
    throw "New executable runtime evidence factory is not active; refusing import-only repair."
}

$oldImport = @'
import {
  createLafCefrAuthoritativeEvidenceRegistry,
} from "./CefrAuthoritativeEvidenceCatalog";
'@

$oldImportMatches =
    [regex]::Matches(
        $text,
        [regex]::Escape($oldImport)
    ).Count

if ($oldImportMatches -ne 1) {
    throw "Expected exactly one stale authoritative evidence registry import; found $oldImportMatches."
}

$text =
    $text.Replace(
        $oldImport + [Environment]::NewLine,
        ""
    )

if ($text.Contains(
    "createLafCefrAuthoritativeEvidenceRegistry"
)) {
    throw "Stale createLafCefrAuthoritativeEvidenceRegistry reference remains."
}

if (-not $text.Contains(
    "createLafA1ConnectExecutableRuntimeEvidenceRegistry()"
)) {
    throw "Executable A1 CONNECT runtime evidence registry call missing after repair."
}

Write-Utf8 $slicePath $text

Write-Host "SPRINT-1449-1457 REV2 SOURCE CHECK PASSED"

Set-Location $app

Write-Host ""
Write-Host "TARGET VERIFICATION — A1 CONNECT runtime slice"

& npx vitest run @(
    "src/core/learning/CefrA1ConnectRuntimeSliceDefinition.test.ts",
    "src/core/learning/CefrRuntimeSliceDefinition.test.ts",
    "src/application/learning/CefrA1ConnectDelayedRetrievalGenericRuntime.test.ts"
)

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1449-1457 Rev2 target verification failed."
}

Write-Host "SPRINT-1449-1457 REV2 TARGET CHECK PASSED"

Write-Host ""
Write-Host "PRODUCTION BUILD — full regression intentionally not repeated"

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1449-1457 Rev2 production build failed."
}

Write-Host ""
Write-Host "SPRINT-1449-1457 REV2 VERIFICATION COMPLETE"
