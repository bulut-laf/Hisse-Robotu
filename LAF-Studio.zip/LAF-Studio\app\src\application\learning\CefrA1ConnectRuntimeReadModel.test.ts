import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrA1ConnectRuntimeReadModel,
} from "./CefrA1ConnectRuntimeReadModel";

describe(
  "CefrA1ConnectRuntimeReadModel",
  () => {
    it("exposes the complete authoritative A1 CONNECT experience for later native /learning UI binding", () => {
      const result =
        createCefrA1ConnectRuntimeReadModel();

      expect(result.unit.id).toBe(
        "a1-connect-first-social-encounter",
      );
      expect(result.lessons).toHaveLength(4);
      expect(result.practices).toHaveLength(4);
      expect(result.interactions).toHaveLength(3);
      expect(
        result.evidenceDefinitions,
      ).toHaveLength(7);

      expect(result).toMatchObject({
        evidenceCaptureUserAuthorized: true,
        runtimeUiBindingRequired: true,
        routeCreationRequired: false,
        existingLearningRoute: "/learning",
      });
    });
  },
);
