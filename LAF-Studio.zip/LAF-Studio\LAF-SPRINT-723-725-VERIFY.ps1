$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

Set-Location $app

Write-Host "=== Sprint 723-725 Target Tests ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustody.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodyCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodyAwareCefrIntelligencePlatform.test.ts"

if ($LASTEXITCODE -ne 0) {
  throw "Sprint 723-725 target tests failed."
}

Write-Host "=== Full Regression ==="
npm run test

if ($LASTEXITCODE -ne 0) {
  throw "Full regression failed."
}

Write-Host "=== Production Build ==="
npm run build

if ($LASTEXITCODE -ne 0) {
  throw "Production build failed."
}

Write-Host "SPRINT-723-725 VERIFICATION COMPLETE"
