$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 1062-1064 Target Tests: Daily Plan Feedback ==="
npx vitest run `
  "src/core/learning/CefrDailyPlanCompletionEvidence.test.ts" `
  "src/core/learning/CefrDailyPlanCapabilityObservation.test.ts" `
  "src/core/learning/CefrDailyPlanFeedbackBundle.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1062-1064 target tests failed." }

Write-Host "=== Sprint 1065-1067 Target Tests: Profile and Observation Refresh ==="
npx vitest run `
  "src/core/learning/CefrDailyPlanProfileRefresh.test.ts" `
  "src/core/learning/CefrDailyPlanObservationRefresh.test.ts" `
  "src/core/learning/CefrDailyPlanUnifiedProfileRefresh.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1065-1067 target tests failed." }

Write-Host "=== Sprint 1068-1070 Target Tests: Next Guidance Cycle ==="
npx vitest run `
  "src/core/learning/CefrNextGuidanceCycleContext.test.ts" `
  "src/core/learning/CefrNextDailyGuidanceQueue.test.ts" `
  "src/core/learning/CefrDailyGuidanceCycleClosedLoop.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1068-1070 target tests failed." }

Write-Host "=== Combined Sprint 1062-1070 New Tests ==="
npx vitest run `
  "src/core/learning/CefrDailyPlanCompletionEvidence.test.ts" `
  "src/core/learning/CefrDailyPlanCapabilityObservation.test.ts" `
  "src/core/learning/CefrDailyPlanFeedbackBundle.test.ts" `
  "src/core/learning/CefrDailyPlanProfileRefresh.test.ts" `
  "src/core/learning/CefrDailyPlanObservationRefresh.test.ts" `
  "src/core/learning/CefrDailyPlanUnifiedProfileRefresh.test.ts" `
  "src/core/learning/CefrNextGuidanceCycleContext.test.ts" `
  "src/core/learning/CefrNextDailyGuidanceQueue.test.ts" `
  "src/core/learning/CefrDailyGuidanceCycleClosedLoop.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1062-1070 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-1062-1070 VERIFICATION COMPLETE"
