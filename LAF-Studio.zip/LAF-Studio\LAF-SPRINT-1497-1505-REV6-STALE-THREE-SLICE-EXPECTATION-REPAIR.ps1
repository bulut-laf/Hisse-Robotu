﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

$utf8 =
    New-Object System.Text.UTF8Encoding($false)

function Read-Utf8([string]$path) {
    return [System.IO.File]::ReadAllText(
        $path,
        $utf8
    )
}

function Write-Utf8(
    [string]$path,
    [string]$text
) {
    [System.IO.File]::WriteAllText(
        $path,
        $text,
        $utf8
    )
}

Set-Location $app

$testRoots = @(
    (Join-Path $app "src\core\learning"),
    (Join-Path $app "src\application\learning")
)

$productionRuntimeTests =
    foreach ($testRoot in $testRoots) {
        Get-ChildItem `
            -Path $testRoot `
            -Filter "CefrProductionRuntime*.test.ts" `
            -File `
            -ErrorAction SilentlyContinue
    }

if (-not $productionRuntimeTests) {
    throw "No CefrProductionRuntime*.test.ts files found."
}

$changed =
    New-Object System.Collections.Generic.List[string]

$backupRoot =
    Join-Path $root (
        "_sprint_backups\Sprint1497-1505-Rev6-" +
        (Get-Date -Format "yyyyMMdd-HHmmss")
    )

New-Item `
    -ItemType Directory `
    -Path $backupRoot `
    -Force |
    Out-Null

$navigateExpectedPattern =
    '(?ms)(?<block>\{\s*sliceId:\s*"a1-navigate",\s*executableEvidenceDefinitionCount:\s*6,\s*\},)'

foreach ($file in $productionRuntimeTests) {
    $text =
        Read-Utf8 $file.FullName

    if (-not $text.Contains(
        "createLafCefrProductionRuntimeSliceRegistry"
    )) {
        continue
    }

    if (-not $text.Contains(
        'sliceId: "a1-connect"'
    )) {
        continue
    }

    if (-not $text.Contains(
        'sliceId: "a1-navigate"'
    )) {
        continue
    }

    if ($text.Contains(
        'sliceId: "a1-describe"'
    )) {
        continue
    }

    $match =
        [regex]::Match(
            $text,
            $navigateExpectedPattern
        )

    if (-not $match.Success) {
        continue
    }

    $navigateBlock =
        $match.Groups["block"].Value

    $indentMatch =
        [regex]::Match(
            $navigateBlock,
            '(?m)^(?<indent>[ \t]*)\{'
        )

    $indent =
        if ($indentMatch.Success) {
            $indentMatch.Groups["indent"].Value
        }
        else {
            "        "
        }

    $innerIndent =
        $indent + "  "

    $describeBlock =
        [Environment]::NewLine +
        $indent + "{" +
        [Environment]::NewLine +
        $innerIndent + 'sliceId: "a1-describe",' +
        [Environment]::NewLine +
        $innerIndent + "executableEvidenceDefinitionCount: 6," +
        [Environment]::NewLine +
        $indent + "},"

    $newText =
        $text.Remove(
            $match.Index,
            $match.Length
        ).Insert(
            $match.Index,
            $navigateBlock +
            $describeBlock
        )

    $relative =
        $file.FullName.Substring(
            $app.Length
        ).TrimStart(
            [char[]]@("\", "/")
        )

    $backupPath =
        Join-Path $backupRoot $relative

    $backupDir =
        Split-Path $backupPath -Parent

    New-Item `
        -ItemType Directory `
        -Path $backupDir `
        -Force |
        Out-Null

    Copy-Item `
        -LiteralPath $file.FullName `
        -Destination $backupPath `
        -Force

    Write-Utf8 `
        $file.FullName `
        $newText

    $changed.Add($relative)
}

if ($changed.Count -ne 2) {
    Write-Host ""
    Write-Host "REV6 candidate files found: $($changed.Count)"
    foreach ($item in $changed) {
        Write-Host " - $item"
    }

    throw "Rev6 expected exactly 2 stale production-runtime expectation tests; found $($changed.Count). No regression/build started."
}

Write-Host ""
Write-Host "SPRINT-1497-1505 REV6 STALE EXPECTATION REPAIR"
Write-Host "Updated test files:"
foreach ($item in $changed) {
    Write-Host " - $item"
}

foreach ($relative in $changed) {
    $path =
        Join-Path $app $relative

    $text =
        Read-Utf8 $path

    foreach ($slice in @(
        'sliceId: "a1-connect"',
        'sliceId: "a1-navigate"',
        'sliceId: "a1-describe"'
    )) {
        if (-not $text.Contains($slice)) {
            throw "Rev6 expected marker missing in $relative : $slice"
        }
    }
}

Write-Host ""
Write-Host "REV6 TARGET — only repaired stale regression tests"

$targetArgs = @(
    "vitest",
    "run"
)

foreach ($relative in $changed) {
    $targetArgs += (
        $relative -replace "\\", "/"
    )
}

& npx @targetArgs

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1497-1505 Rev6 repaired target tests failed."
}

Write-Host "SPRINT-1497-1505 REV6 TARGET PASSED"

Write-Host ""
Write-Host "FINAL FULL REGRESSION"

& npm run test

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1497-1505 Rev6 final full regression failed."
}

Write-Host ""
Write-Host "FINAL PRODUCTION BUILD"

& npm run build

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1497-1505 Rev6 production build failed."
}

Write-Host ""
Write-Host "SPRINT-1497-1505 REV6 VERIFICATION COMPLETE"
Write-Host "Backup: $backupRoot"
