﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$core = Join-Path $app "src\core\learning"
$application =
    Join-Path $app "src\application\learning"
$payloadRoot =
    Join-Path $root "_sprint_payload"

$requiredBaseline = @(
    "src\core\learning\CefrA1DescribeRuntimeSliceDefinition.ts",
    "src\core\learning\CefrProductionRuntimeSliceRegistry.ts",
    "src\core\learning\CefrProductionRuntimeEvidenceEligibilityAudit.ts",
    "src\core\learning\CefrAuthoritativeCurriculumCatalog.ts",
    "src\core\learning\CefrAuthoritativeCurriculumRegistry.ts",
    "src\application\learning\CefrProductionRuntimePlatform.ts"
)

foreach ($relative in $requiredBaseline) {
    $path = Join-Path $app $relative
    if (-not (Test-Path $path)) {
        throw "Sprint 1529 stable baseline file missing: $relative"
    }
}

$utf8 =
    New-Object System.Text.UTF8Encoding($false)

function Read-Utf8([string]$path) {
    return [System.IO.File]::ReadAllText(
        $path,
        $utf8
    )
}

function Write-Utf8(
    [string]$path,
    [string]$text
) {
    [System.IO.File]::WriteAllText(
        $path,
        $text,
        $utf8
    )
}

$backupRoot =
    Join-Path $root (
        "_sprint_backups\Sprint1530-1538-" +
        (Get-Date -Format "yyyyMMdd-HHmmss")
    )

New-Item `
    -ItemType Directory `
    -Path $backupRoot `
    -Force |
    Out-Null

function Backup-IfNeeded(
    [string]$path
) {
    if (-not (Test-Path $path)) {
        return
    }

    $relative =
        $path.Substring(
            $root.Length
        ).TrimStart(
            [char[]]@("\", "/")
        )

    $backup =
        Join-Path $backupRoot $relative

    if (Test-Path $backup) {
        return
    }

    New-Item `
        -ItemType Directory `
        -Path (Split-Path $backup -Parent) `
        -Force |
        Out-Null

    Copy-Item `
        -LiteralPath $path `
        -Destination $backup `
        -Force
}

function Install-CheckpointPayload {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Checkpoint
    )

    $sourceRoot =
        Join-Path $payloadRoot $Checkpoint

    if (-not (Test-Path $sourceRoot)) {
        throw "Checkpoint payload missing: $Checkpoint"
    }

    $files =
        Get-ChildItem `
            -Path $sourceRoot `
            -Recurse `
            -File

    foreach ($file in $files) {
        $relative =
            $file.FullName.Substring(
                $sourceRoot.Length
            ).TrimStart(
                [char[]]@("\", "/")
            )

        $destination =
            Join-Path $root $relative

        New-Item `
            -ItemType Directory `
            -Path (Split-Path $destination -Parent) `
            -Force |
            Out-Null

        Backup-IfNeeded $destination

        Copy-Item `
            -LiteralPath $file.FullName `
            -Destination $destination `
            -Force
    }
}

function Patch-AuthoritativeCatalog {
    $path =
        Join-Path $core "CefrAuthoritativeCurriculumCatalog.ts"

    Backup-IfNeeded $path
    $text = Read-Utf8 $path

    # --------------------------------------------------------
    # Rev2 structural repair:
    # remove any A1 EXCHANGE import wherever a previous run
    # accidentally inserted it, then add exactly one import
    # at the file import section.
    # --------------------------------------------------------

    $exchangeImportPattern =
        '(?ms)import\s*\{\s*' +
        'LAF_A1_EXCHANGE_SIMPLE_PREFERENCES_LESSONS,\s*' +
        'LAF_A1_EXCHANGE_SIMPLE_PREFERENCES_UNIT,\s*' +
        '\}\s*from\s*"\./CefrA1ExchangeCurriculum";\s*'

    $text =
        [regex]::Replace(
            $text,
            $exchangeImportPattern,
            ""
        )

    $exchangeImport =
        'import {' +
        [Environment]::NewLine +
        '  LAF_A1_EXCHANGE_SIMPLE_PREFERENCES_LESSONS,' +
        [Environment]::NewLine +
        '  LAF_A1_EXCHANGE_SIMPLE_PREFERENCES_UNIT,' +
        [Environment]::NewLine +
        '} from "./CefrA1ExchangeCurriculum";' +
        [Environment]::NewLine

    $text =
        $exchangeImport +
        $text.TrimStart(
            [char[]]@(
                "`r",
                "`n"
            )
        )

    # --------------------------------------------------------
    # Unit registration:
    # inspect ONLY the authoritative Unit array, so the import
    # declaration cannot create a false "already registered".
    # --------------------------------------------------------

    $unitArrayStartMarker =
        'export const LAF_AUTHORITATIVE_CEFR_UNITS:'

    $unitArrayStart =
        $text.IndexOf(
            $unitArrayStartMarker
        )

    if ($unitArrayStart -lt 0) {
        throw "Authoritative Unit array start missing."
    }

    $unitArrayEnd =
        $text.IndexOf(
            '];',
            $unitArrayStart
        )

    if ($unitArrayEnd -lt 0) {
        throw "Authoritative Unit array end missing."
    }

    $unitBlock =
        $text.Substring(
            $unitArrayStart,
            $unitArrayEnd -
            $unitArrayStart
        )

    $unitUse =
        '  LAF_A1_EXCHANGE_SIMPLE_PREFERENCES_UNIT,'

    if (-not $unitBlock.Contains(
        "LAF_A1_EXCHANGE_SIMPLE_PREFERENCES_UNIT"
    )) {
        $text =
            $text.Insert(
                $unitArrayEnd,
                $unitUse +
                [Environment]::NewLine
            )
    }

    # --------------------------------------------------------
    # Lesson registration:
    # inspect ONLY the authoritative Lesson array.
    # --------------------------------------------------------

    $lessonArrayStartMarker =
        'export const LAF_AUTHORITATIVE_CEFR_LESSONS:'

    $lessonArrayStart =
        $text.IndexOf(
            $lessonArrayStartMarker
        )

    if ($lessonArrayStart -lt 0) {
        throw "Authoritative Lesson array start missing."
    }

    $lessonArrayEnd =
        $text.IndexOf(
            '];',
            $lessonArrayStart
        )

    if ($lessonArrayEnd -lt 0) {
        throw "Authoritative Lesson array end missing."
    }

    $lessonBlock =
        $text.Substring(
            $lessonArrayStart,
            $lessonArrayEnd -
            $lessonArrayStart
        )

    $lessonUse =
        '  ...LAF_A1_EXCHANGE_SIMPLE_PREFERENCES_LESSONS,'

    if (-not $lessonBlock.Contains(
        "LAF_A1_EXCHANGE_SIMPLE_PREFERENCES_LESSONS"
    )) {
        $text =
            $text.Insert(
                $lessonArrayEnd,
                $lessonUse +
                [Environment]::NewLine
            )
    }

    # --------------------------------------------------------
    # Rev2 fail-closed structural checks.
    # --------------------------------------------------------

    $importCount =
        [regex]::Matches(
            $text,
            [regex]::Escape(
                'from "./CefrA1ExchangeCurriculum";'
            )
        ).Count

    if ($importCount -ne 1) {
        throw "Expected exactly one A1 EXCHANGE curriculum import; found $importCount."
    }

    $unitArrayStart =
        $text.IndexOf(
            $unitArrayStartMarker
        )

    $unitArrayEnd =
        $text.IndexOf(
            '];',
            $unitArrayStart
        )

    $unitBlock =
        $text.Substring(
            $unitArrayStart,
            $unitArrayEnd -
            $unitArrayStart
        )

    if (-not $unitBlock.Contains(
        "LAF_A1_EXCHANGE_SIMPLE_PREFERENCES_UNIT"
    )) {
        throw "A1 EXCHANGE Unit registration missing after Rev2 repair."
    }

    if ($unitBlock.Contains(
        'from "./CefrA1ExchangeCurriculum";'
    )) {
        throw "A1 EXCHANGE import leaked into authoritative Unit array."
    }

    $lessonArrayStart =
        $text.IndexOf(
            $lessonArrayStartMarker
        )

    $lessonArrayEnd =
        $text.IndexOf(
            '];',
            $lessonArrayStart
        )

    $lessonBlock =
        $text.Substring(
            $lessonArrayStart,
            $lessonArrayEnd -
            $lessonArrayStart
        )

    if (-not $lessonBlock.Contains(
        "LAF_A1_EXCHANGE_SIMPLE_PREFERENCES_LESSONS"
    )) {
        throw "A1 EXCHANGE Lesson registration missing after Rev2 repair."
    }

    if ($lessonBlock.Contains(
        'from "./CefrA1ExchangeCurriculum";'
    )) {
        throw "A1 EXCHANGE import leaked into authoritative Lesson array."
    }

    Write-Utf8 $path $text
}
function Patch-CurriculumRegistry {
    $path =
        Join-Path $core "CefrAuthoritativeCurriculumRegistry.ts"

    Backup-IfNeeded $path
    $text = Read-Utf8 $path

    if ($text.Contains(
        '"curriculum-map-a1-exchange-v1"'
    )) {
        Write-Utf8 $path $text
        return
    }

    $start =
        $text.IndexOf(
            'export const LAF_CEFR_CURRICULUM_COMPETENCY_MAPPINGS:'
        )

    if ($start -lt 0) {
        throw "Curriculum mapping array start missing."
    }

    $end =
        $text.IndexOf(
            '];',
            $start
        )

    if ($end -lt 0) {
        throw "Curriculum mapping array end missing."
    }

    $mappings = @'
  {
    learningItemId:
      "a1-exchange-recognize-preference",
    learningItemType: "lesson",
    competencyOutcomeIds: [
      "exchange-ideas-a1",
    ],
    mappingAuthority:
      "unit-lesson-curriculum-definition",
    mappingVersion:
      "curriculum-map-a1-exchange-v1",
    authoritative: true,
  },
  {
    learningItemId:
      "a1-exchange-express-like-dislike",
    learningItemType: "lesson",
    competencyOutcomeIds: [
      "exchange-ideas-a1",
    ],
    mappingAuthority:
      "unit-lesson-curriculum-definition",
    mappingVersion:
      "curriculum-map-a1-exchange-v1",
    authoritative: true,
  },
  {
    learningItemId:
      "a1-exchange-ask-preference",
    learningItemType: "lesson",
    competencyOutcomeIds: [
      "exchange-ideas-a1",
    ],
    mappingAuthority:
      "unit-lesson-curriculum-definition",
    mappingVersion:
      "curriculum-map-a1-exchange-v1",
    authoritative: true,
  },
  {
    learningItemId:
      "a1-exchange-complete-preference-exchange",
    learningItemType: "lesson",
    competencyOutcomeIds: [
      "exchange-ideas-a1",
    ],
    mappingAuthority:
      "unit-lesson-curriculum-definition",
    mappingVersion:
      "curriculum-map-a1-exchange-v1",
    authoritative: true,
  },
  {
    learningItemId:
      "a1-exchange-interaction-state-preference",
    learningItemType: "interaction",
    competencyOutcomeIds: [
      "exchange-ideas-a1",
    ],
    mappingAuthority:
      "unit-lesson-curriculum-definition",
    mappingVersion:
      "curriculum-map-a1-exchange-v1",
    authoritative: true,
  },
  {
    learningItemId:
      "a1-exchange-interaction-ask-preference",
    learningItemType: "interaction",
    competencyOutcomeIds: [
      "exchange-ideas-a1",
    ],
    mappingAuthority:
      "unit-lesson-curriculum-definition",
    mappingVersion:
      "curriculum-map-a1-exchange-v1",
    authoritative: true,
  },
  {
    learningItemId:
      "a1-exchange-interaction-share-preferences",
    learningItemType: "interaction",
    competencyOutcomeIds: [
      "exchange-ideas-a1",
    ],
    mappingAuthority:
      "unit-lesson-curriculum-definition",
    mappingVersion:
      "curriculum-map-a1-exchange-v1",
    authoritative: true,
  },
  {
    learningItemId:
      "a1-exchange-activation-simple-preference",
    learningItemType: "activation",
    competencyOutcomeIds: [
      "exchange-ideas-a1",
    ],
    mappingAuthority:
      "unit-lesson-curriculum-definition",
    mappingVersion:
      "curriculum-map-a1-exchange-v1",
    authoritative: true,
  },

'@

    $text =
        $text.Insert(
            $end,
            $mappings
        )

    Write-Utf8 $path $text
}

function Patch-ProductionRegistry {
    $path =
        Join-Path $core "CefrProductionRuntimeSliceRegistry.ts"

    Backup-IfNeeded $path
    $text = Read-Utf8 $path

    if (-not $text.Contains(
        "createLafA1ExchangeRuntimeSliceDefinition"
    )) {
        $import =
            'import {' +
            [Environment]::NewLine +
            '  createLafA1ExchangeRuntimeSliceDefinition,' +
            [Environment]::NewLine +
            '} from "./CefrA1ExchangeRuntimeSliceDefinition";' +
            [Environment]::NewLine

        $text =
            $import +
            $text
    }

    if (-not $text.Contains(
        "createLafA1ExchangeRuntimeSliceDefinition()"
    )) {
        $pattern =
            '(?m)^(?<indent>[ \t]*)createLafA1DescribeRuntimeSliceDefinition\(\)(?<comma>,?)[ \t]*$'

        $matches =
            [regex]::Matches(
                $text,
                $pattern
            )

        if ($matches.Count -ne 1) {
            throw "Expected exactly one A1 DESCRIBE runtime invocation seam; found $($matches.Count)."
        }

        $match = $matches[0]
        $indent =
            $match.Groups["indent"].Value

        $describeLine =
            $match.Value.TrimEnd()

        if (-not $describeLine.EndsWith(",")) {
            $describeLine =
                $describeLine + ","
        }

        $replacement =
            $indent +
            $describeLine.TrimStart() +
            [Environment]::NewLine +
            $indent +
            "createLafA1ExchangeRuntimeSliceDefinition(),"

        $text =
            $text.Remove(
                $match.Index,
                $match.Length
            ).Insert(
                $match.Index,
                $replacement
            )
    }

    Write-Utf8 $path $text
}

function Patch-ProductionAudit {
    $path =
        Join-Path $core "CefrProductionRuntimeEvidenceEligibilityAudit.ts"

    Backup-IfNeeded $path
    $text = Read-Utf8 $path

    $exchangeId =
        '"a1-exchange-evidence-delayed-retrieval"'

    if (-not $text.Contains($exchangeId)) {
        $describeLine =
            '"a1-describe-evidence-delayed-retrieval",'

        $pos =
            $text.IndexOf($describeLine)

        if ($pos -lt 0) {
            throw "A1 DESCRIBE delayed-retrieval audit seam missing."
        }

        $lineStart =
            $text.LastIndexOf(
                [Environment]::NewLine,
                $pos
            )

        $indentStart =
            $lineStart + 1

        $indent =
            $text.Substring(
                $indentStart,
                $pos - $indentStart
            )

        $insertAt =
            $pos +
            $describeLine.Length

        $text =
            $text.Insert(
                $insertAt,
                [Environment]::NewLine +
                $indent +
                $exchangeId +
                ","
            )
    }

    Write-Utf8 $path $text
}

function Patch-PlatformTest {
    $path =
        Join-Path $application "CefrProductionRuntimePlatform.test.ts"

    Backup-IfNeeded $path
    $text = Read-Utf8 $path

    if ($text.Contains(
        "registeredSliceCount: 3"
    )) {
        $count =
            [regex]::Matches(
                $text,
                [regex]::Escape(
                    "registeredSliceCount: 3"
                )
            ).Count

        if ($count -ne 1) {
            throw "Unexpected registeredSliceCount: 3 occurrence count in platform test: $count"
        }

        $text =
            $text.Replace(
                "registeredSliceCount: 3",
                "registeredSliceCount: 4"
            )
    }

    if (-not $text.Contains(
        "registeredSliceCount: 4"
    )) {
        throw "Production platform test did not resolve to four slices."
    }

    Write-Utf8 $path $text
}

function Patch-AuditTest {
    $path =
        Join-Path $core "CefrProductionRuntimeEvidenceEligibilityAudit.test.ts"

    Backup-IfNeeded $path
    $text = Read-Utf8 $path

    if ($text.Contains(
        "registeredSliceCount: 3"
    )) {
        $text =
            $text.Replace(
                "registeredSliceCount: 3",
                "registeredSliceCount: 4"
            )
    }

    if ($text.Contains(
        "executableEvidenceDefinitionCount:" +
        [Environment]::NewLine +
        "          18"
    )) {
        $text =
            $text.Replace(
                "executableEvidenceDefinitionCount:" +
                [Environment]::NewLine +
                "          18",
                "executableEvidenceDefinitionCount:" +
                [Environment]::NewLine +
                "          24"
            )
    }
    elseif ($text.Contains(
        "executableEvidenceDefinitionCount: 18"
    )) {
        $text =
            $text.Replace(
                "executableEvidenceDefinitionCount: 18",
                "executableEvidenceDefinitionCount: 24"
            )
    }

    $exchangeId =
        '"a1-exchange-evidence-delayed-retrieval"'

    if (-not $text.Contains($exchangeId)) {
        $describeLine =
            '          "a1-describe-evidence-delayed-retrieval",'

        $pos =
            $text.IndexOf($describeLine)

        if ($pos -lt 0) {
            throw "Audit test A1 DESCRIBE delayed-retrieval seam missing."
        }

        $insertAt =
            $pos +
            $describeLine.Length

        $text =
            $text.Insert(
                $insertAt,
                [Environment]::NewLine +
                '          "a1-exchange-evidence-delayed-retrieval",'
            )
    }

    $lengthPattern =
        '(LAF_POLICY_GATED_DELAYED_RETRIEVAL_EVIDENCE_IDS,\s*\)\.toHaveLength\()3(\);)'

    if (
        [regex]::IsMatch(
            $text,
            $lengthPattern
        )
    ) {
        $text =
            [regex]::Replace(
                $text,
                $lengthPattern,
                '${1}4${2}',
                1
            )
    }

    if (-not $text.Contains(
        "registeredSliceCount: 4"
    )) {
        throw "Audit test registered slice count did not resolve to four."
    }

    if (-not $text.Contains(
        $exchangeId
    )) {
        throw "Audit test missing A1 EXCHANGE delayed-retrieval identity."
    }

    Write-Utf8 $path $text
}

$vitestPath =
    Join-Path $app "node_modules\.bin\vitest.cmd"

if (-not (Test-Path $vitestPath)) {
    throw "Local Vitest command missing: $vitestPath"
}

$npmPath =
    (Get-Command "npm.cmd" -ErrorAction Stop).Source

if (-not $npmPath) {
    throw "npm.cmd path could not be resolved."
}

function Run-TargetTests {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Label,

        [Parameter(Mandatory = $true)]
        [string[]]$Tests
    )

    Write-Host ""
    Write-Host "============================================================"
    Write-Host $Label
    Write-Host "============================================================"

    $vitestCommandArgs = @("run")
    $vitestCommandArgs += $Tests

    & $vitestPath @vitestCommandArgs

    if ($LASTEXITCODE -ne 0) {
        throw "$Label failed."
    }
}

Set-Location $app

# ------------------------------------------------------------
# Sprint 1530-1532
# Authoritative curriculum + experience identities.
# ------------------------------------------------------------

Install-CheckpointPayload `
    -Checkpoint "1530-1532"

Run-TargetTests `
    -Label "SPRINT-1530-1532 TARGET CHECKPOINT" `
    -Tests @(
        "src/core/learning/CefrA1ExchangeCurriculum.test.ts",
        "src/core/learning/CefrA1ExchangePracticeDefinition.test.ts",
        "src/core/learning/CefrA1ExchangeInteractionDefinition.test.ts",
        "src/core/learning/CefrA1ExchangeEvidenceDefinition.test.ts",
        "src/core/learning/CefrA1ExchangeActivationDefinition.test.ts",
        "src/core/learning/CefrA1ExchangeLearningExperienceCatalog.test.ts",
        "src/core/learning/CefrA1ExchangeImplementationSafety.test.ts"
    )

Write-Host "SPRINT-1530-1532 TARGET CHECKPOINT PASSED"

# ------------------------------------------------------------
# Sprint 1533-1535
# Authoritative catalog/registry + runtime evidence/provenance.
# ------------------------------------------------------------

Install-CheckpointPayload `
    -Checkpoint "1533-1535"

Patch-AuthoritativeCatalog

$catalogPath =
    Join-Path $core "CefrAuthoritativeCurriculumCatalog.ts"

$catalogText =
    Read-Utf8 $catalogPath

$catalogUnitStart =
    $catalogText.IndexOf(
        'export const LAF_AUTHORITATIVE_CEFR_UNITS:'
    )

$catalogUnitEnd =
    $catalogText.IndexOf(
        '];',
        $catalogUnitStart
    )

$catalogUnitBlock =
    $catalogText.Substring(
        $catalogUnitStart,
        $catalogUnitEnd -
        $catalogUnitStart
    )

if ($catalogUnitBlock.Contains(
    'from "./CefrA1ExchangeCurriculum";'
)) {
    throw "Rev2 structural verification: import remains inside Unit array."
}

if (-not $catalogUnitBlock.Contains(
    "LAF_A1_EXCHANGE_SIMPLE_PREFERENCES_UNIT"
)) {
    throw "Rev2 structural verification: A1 EXCHANGE Unit missing."
}

Patch-CurriculumRegistry

Run-TargetTests `
    -Label "SPRINT-1533-1535 TARGET CHECKPOINT" `
    -Tests @(
        "src/core/learning/CefrA1ExchangeAuthoritativeCatalog.test.ts",
        "src/core/learning/CefrA1ExchangeCurriculumRegistry.test.ts",
        "src/core/learning/CefrA1ExchangeRuntimeEvidenceCatalog.test.ts",
        "src/core/learning/CefrA1ExchangeRuntimeSliceDefinition.test.ts",
        "src/core/learning/CefrAuthoritativeCapabilityRegistry.test.ts"
    )

Write-Host "SPRINT-1533-1535 TARGET CHECKPOINT PASSED"

# ------------------------------------------------------------
# Sprint 1536-1538
# Existing generic production runtime activation.
# ------------------------------------------------------------

Install-CheckpointPayload `
    -Checkpoint "1536-1538"

Patch-ProductionRegistry
Patch-ProductionAudit
Patch-PlatformTest
Patch-AuditTest

$sourceChecks = @(
    @(
      (Join-Path $core "CefrA1ExchangeCurriculum.ts"),
      '"a1-exchange-simple-preferences"'
    ),
    @(
      (Join-Path $core "CefrA1ExchangeCurriculum.ts"),
      '"exchange-ideas-a1"'
    ),
    @(
      (Join-Path $core "CefrA1ExchangeEvidenceDefinition.ts"),
      '"a1-exchange-evidence-delayed-retrieval"'
    ),
    @(
      (Join-Path $core "CefrA1ExchangeEvidenceDefinition.ts"),
      "runtimeWriteEnabled: false"
    ),
    @(
      (Join-Path $core "CefrA1ExchangeImplementationSafety.ts"),
      '"preference-opinion-expression"'
    ),
    @(
      (Join-Path $core "CefrA1ExchangeImplementationSafety.ts"),
      "a2ReasonSupportExcluded: true"
    ),
    @(
      (Join-Path $core "CefrAuthoritativeCurriculumCatalog.ts"),
      "LAF_A1_EXCHANGE_SIMPLE_PREFERENCES_UNIT,"
    ),
    @(
      (Join-Path $core "CefrAuthoritativeCurriculumRegistry.ts"),
      '"curriculum-map-a1-exchange-v1"'
    ),
    @(
      (Join-Path $core "CefrProductionRuntimeSliceRegistry.ts"),
      "createLafA1ExchangeRuntimeSliceDefinition()"
    ),
    @(
      (Join-Path $core "CefrProductionRuntimeEvidenceEligibilityAudit.ts"),
      '"a1-exchange-evidence-delayed-retrieval"'
    )
)

foreach ($pair in $sourceChecks) {
    if (-not (
        Select-String `
            -Path $pair[0] `
            -SimpleMatch `
            -Pattern $pair[1] `
            -Quiet
    )) {
        throw "Sprint 1530-1538 source marker missing: $($pair[1])"
    }
}

$runtimeCatalog =
    Read-Utf8 (
        Join-Path $core "CefrA1ExchangeRuntimeEvidenceCatalog.ts"
    )

if ($runtimeCatalog.Contains(
    '"a1-exchange-evidence-delayed-retrieval"'
)) {
    throw "Delayed retrieval leaked into A1 EXCHANGE executable runtime catalog."
}

Run-TargetTests `
    -Label "SPRINT-1536-1538 TARGET CHECKPOINT" `
    -Tests @(
        "src/core/learning/CefrA1ExchangeRuntimeSliceDefinition.test.ts",
        "src/core/learning/CefrProductionRuntimeSliceRegistry.test.ts",
        "src/core/learning/CefrProductionRuntimeRegistryEnforcement.test.ts",
        "src/core/learning/CefrProductionRuntimeSliceRegistryEligibility.test.ts",
        "src/core/learning/CefrProductionRuntimeEvidenceEligibilityAudit.test.ts",
        "src/application/learning/CefrProductionRuntimeDelayedRetrievalVisibility.test.ts",
        "src/application/learning/CefrA1ExchangeProductionRuntime.test.ts",
        "src/application/learning/CefrProductionRuntimePlatform.test.ts",
        "src/application/learning/CefrRuntimeAssemblyFactory.test.ts"
    )

Write-Host "SPRINT-1536-1538 TARGET CHECKPOINT PASSED"

Write-Host ""
Write-Host "============================================================"
Write-Host "FINAL 9-SPRINT BLOCK REGRESSION"
Write-Host "============================================================"

& $npmPath run test

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1530-1538 final full regression failed."
}

Write-Host ""
Write-Host "============================================================"
Write-Host "FINAL PRODUCTION BUILD"
Write-Host "============================================================"

& $npmPath run build

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1530-1538 production build failed."
}

Write-Host ""
Write-Host "SPRINT-1530-1538 VERIFICATION COMPLETE"
Write-Host "Backup: $backupRoot"
