import {
  getLafA1ConnectEvidenceForLearningItem,
} from "../../core/learning/CefrA1ConnectEvidenceDefinition";
import type {
  CefrA1ConnectEvidenceCoverageItem,
} from "../../core/learning/CefrA1ConnectEvidenceCoverage";
import type {
  CefrA1ConnectLanguageScopedCoverageReadModel,
} from "./CefrA1ConnectLanguageScopedCoverageReadModel";

export interface CefrA1ConnectLessonScopedCoverageReadModel {
  readonly lessonId: string;
  readonly items:
    readonly CefrA1ConnectEvidenceCoverageItem[];
  readonly observedEvidenceCount: number;
  readonly totalEvidenceCount: number;
  readonly delayedRetrievalPending: boolean;
  readonly crossLessonEvidenceExcluded: true;
  readonly progressOnly: true;
  readonly masteryInferred: false;
  readonly cefrLevelInferred: false;
  readonly progressionTriggered: false;
}

export function createCefrA1ConnectLessonScopedCoverageReadModel(
  unitCoverage:
    CefrA1ConnectLanguageScopedCoverageReadModel,
  lessonId: string,
): CefrA1ConnectLessonScopedCoverageReadModel {
  const definitions =
    getLafA1ConnectEvidenceForLearningItem(
      lessonId,
    );

  const immediateDefinitionIds =
    new Set(
      definitions
        .filter(
          definition =>
            definition.evidenceDefinitionId !==
            "a1-connect-evidence-delayed-retrieval",
        )
        .map(
          definition =>
            definition.evidenceDefinitionId,
        ),
    );

  const items =
    unitCoverage.coverage.items.filter(
      item =>
        immediateDefinitionIds.has(
          item.evidenceDefinitionId,
        ),
    );

  return {
    lessonId,
    items,
    observedEvidenceCount:
      items.filter(item => item.present)
        .length,
    totalEvidenceCount: items.length,
    delayedRetrievalPending:
      definitions.some(
        definition =>
          definition.evidenceDefinitionId ===
          "a1-connect-evidence-delayed-retrieval",
      ),
    crossLessonEvidenceExcluded: true,
    progressOnly: true,
    masteryInferred: false,
    cefrLevelInferred: false,
    progressionTriggered: false,
  };
}
