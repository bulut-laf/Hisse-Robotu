$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 1140-1142 Target Tests: Guidance Review Presentation ==="
npx vitest run `
  "src/core/learning/CefrGuidanceReviewItem.test.ts" `
  "src/core/learning/CefrGuidanceReviewViewModel.test.ts" `
  "src/core/learning/CefrGuidanceReviewSession.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1140-1142 target tests failed." }

Write-Host "=== Sprint 1143-1145 Target Tests: Studio Selection Request ==="
npx vitest run `
  "src/core/learning/CefrGuidanceStudioSelectionOption.test.ts" `
  "src/core/learning/CefrGuidanceStudioSelectionRequest.test.ts" `
  "src/core/learning/CefrGuidanceStudioSelectionBridge.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1143-1145 target tests failed." }

Write-Host "=== Combined Sprint 1140-1145 New Tests ==="
npx vitest run `
  "src/core/learning/CefrGuidanceReviewItem.test.ts" `
  "src/core/learning/CefrGuidanceReviewViewModel.test.ts" `
  "src/core/learning/CefrGuidanceReviewSession.test.ts" `
  "src/core/learning/CefrGuidanceStudioSelectionOption.test.ts" `
  "src/core/learning/CefrGuidanceStudioSelectionRequest.test.ts" `
  "src/core/learning/CefrGuidanceStudioSelectionBridge.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1140-1145 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-1140-1145 VERIFICATION COMPLETE"
