import {
  describe,
  expect,
  it,
} from "vitest";

import {
  getTranslationLearningSupportLanguage,
} from "./TranslationLearningLanguageSupport";

describe(
  "getTranslationLearningSupportLanguage",
  () => {
    it("keeps the historical Turkish to Hungarian support direction", () => {
      expect(
        getTranslationLearningSupportLanguage(
          "tr",
        ),
      ).toBe("hu");
    });

    it.each([
      "hu",
      "de",
      "it",
      "en",
      "es",
      "ru",
    ] as const)(
      "uses Turkish as learning support language for %s",
      language => {
        expect(
          getTranslationLearningSupportLanguage(
            language,
          ),
        ).toBe("tr");
      },
    );
  },
);
