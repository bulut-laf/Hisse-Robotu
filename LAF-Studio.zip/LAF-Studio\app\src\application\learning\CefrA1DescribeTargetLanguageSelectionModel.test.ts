import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrA1DescribeTargetLanguageSelectionModel,
} from "./CefrA1DescribeTargetLanguageSelectionModel";

describe(
  "A1 DESCRIBE target-language selection executable V1",
  () => {
    it("exposes all six immediate executable tasks only after explicit target-language selection", () => {
      const empty =
        createCefrA1DescribeTargetLanguageSelectionModel(
          null,
        );

      expect(empty).toMatchObject({
        selectionRequired: true,
        selectedByUser: false,
        languageContentBound: false,
        executableTaskAvailable: false,
        evidenceCaptureAvailable: false,
        targetLanguageInferred: false,
      });

      const selected =
        createCefrA1DescribeTargetLanguageSelectionModel(
          "ru",
        );

      expect(selected).toMatchObject({
        selectedLanguageCode: "ru",
        selectionRequired: false,
        selectedByUser: true,
        languageContentBound: true,
        executableTaskAvailable: true,
        evidenceCaptureAvailable: true,
        delayedRetrievalRuntimeAvailable:
          false,
        narrativeSequencingIntroduced:
          false,
        targetLanguageInferred: false,
      });

      expect(
        selected.realization,
      ).toMatchObject({
        executableTaskCount: 6,
        evidenceCaptureRequiresCorrectUserAction:
          true,
      });
    });
  },
);
