import type { CefrLearningStudioEvidenceWriteInput } from "./CefrGuidanceRuntimeProfileService";

export type CefrEmbeddedStudioCompletionSource =
  | "reading"
  | "speaking"
  | "dialogue";

export function createCefrEmbeddedStudioCompletionEvidenceInput(
  studio: CefrEmbeddedStudioCompletionSource,
  completedAt: Date,
): CefrLearningStudioEvidenceWriteInput {
  const observedAt = completedAt.toISOString();

  return {
    evidenceId:
      `embedded-studio-completion:${studio}:${observedAt}`,
    observedAt: completedAt,
    payloadReference:
      `embedded-studio:${studio}:${observedAt}`,
  };
}
