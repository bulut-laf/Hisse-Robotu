$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 1146-1148 Target Tests: Launch Preparation ==="
npx vitest run `
  "src/core/learning/CefrGuidanceLaunchPreparation.test.ts" `
  "src/core/learning/CefrGuidanceLaunchIntent.test.ts" `
  "src/core/learning/CefrGuidanceLaunchReview.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1146-1148 target tests failed." }

Write-Host "=== Sprint 1149-1151 Target Tests: Explicit Navigation Request ==="
npx vitest run `
  "src/core/learning/CefrGuidanceNavigationRequest.test.ts" `
  "src/core/learning/CefrGuidanceNavigationGate.test.ts" `
  "src/core/learning/CefrGuidanceNavigationHandoff.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1149-1151 target tests failed." }

Write-Host "=== Combined Sprint 1146-1151 New Tests ==="
npx vitest run `
  "src/core/learning/CefrGuidanceLaunchPreparation.test.ts" `
  "src/core/learning/CefrGuidanceLaunchIntent.test.ts" `
  "src/core/learning/CefrGuidanceLaunchReview.test.ts" `
  "src/core/learning/CefrGuidanceNavigationRequest.test.ts" `
  "src/core/learning/CefrGuidanceNavigationGate.test.ts" `
  "src/core/learning/CefrGuidanceNavigationHandoff.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1146-1151 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-1146-1151 VERIFICATION COMPLETE"
