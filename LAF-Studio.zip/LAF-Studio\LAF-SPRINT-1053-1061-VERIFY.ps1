$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 1053-1055 Target Tests: Guidance Plan Routing ==="
npx vitest run `
  "src/core/learning/CefrGuidancePlanRouteAssignment.test.ts" `
  "src/core/learning/CefrGuidancePlanRouteRegistry.test.ts" `
  "src/core/learning/CefrGuidancePlanRoutingOrchestration.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1053-1055 target tests failed." }

Write-Host "=== Sprint 1056-1058 Target Tests: User-Initiated Plan Launch ==="
npx vitest run `
  "src/core/learning/CefrGuidancePlanLaunchRequest.test.ts" `
  "src/core/learning/CefrGuidancePlanLaunchGate.test.ts" `
  "src/core/learning/CefrUserInitiatedGuidancePlanLaunch.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1056-1058 target tests failed." }

Write-Host "=== Sprint 1059-1061 Target Tests: Daily Plan Completion Loop ==="
npx vitest run `
  "src/core/learning/CefrGuidancePlanOutcome.test.ts" `
  "src/core/learning/CefrGuidancePlanCompletion.test.ts" `
  "src/core/learning/CefrDailyGuidancePlanClosedLoop.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1059-1061 target tests failed." }

Write-Host "=== Combined Sprint 1053-1061 New Tests ==="
npx vitest run `
  "src/core/learning/CefrGuidancePlanRouteAssignment.test.ts" `
  "src/core/learning/CefrGuidancePlanRouteRegistry.test.ts" `
  "src/core/learning/CefrGuidancePlanRoutingOrchestration.test.ts" `
  "src/core/learning/CefrGuidancePlanLaunchRequest.test.ts" `
  "src/core/learning/CefrGuidancePlanLaunchGate.test.ts" `
  "src/core/learning/CefrUserInitiatedGuidancePlanLaunch.test.ts" `
  "src/core/learning/CefrGuidancePlanOutcome.test.ts" `
  "src/core/learning/CefrGuidancePlanCompletion.test.ts" `
  "src/core/learning/CefrDailyGuidancePlanClosedLoop.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1053-1061 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-1053-1061 VERIFICATION COMPLETE"
