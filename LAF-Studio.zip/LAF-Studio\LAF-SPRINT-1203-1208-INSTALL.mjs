import fs from "node:fs";
import path from "node:path";

const root = "D:\\Projects\\LAF-Studio";
const file = path.join(
  root,
  "app",
  "src",
  "ui",
  "pages",
  "LearningStudioPage.tsx",
);

if (!fs.existsSync(file)) {
  throw new Error(`LearningStudioPage not found: ${file}`);
}

let source = fs.readFileSync(file, "utf8");
const eol = source.includes("\r\n") ? "\r\n" : "\n";

const importLine =
  'import { LearningGuidanceEntryCard } from "../learning/LearningGuidanceEntryCard";';

if (!source.includes(importLine)) {
  const cssImport = 'import "./LearningStudioPage.css";';

  if (!source.includes(cssImport)) {
    throw new Error(
      "Safe import insertion marker not found in LearningStudioPage.tsx",
    );
  }

  source = source.replace(
    cssImport,
    `${importLine}${eol}${eol}${cssImport}`,
  );
}

if (!source.includes("<LearningGuidanceEntryCard />")) {
  const renderMarker =
    `      </header>${eol}${eol}      <section`;

  if (!source.includes(renderMarker)) {
    throw new Error(
      "Safe hero-to-queue insertion marker not found in LearningStudioPage.tsx",
    );
  }

  source = source.replace(
    renderMarker,
    `      </header>${eol}${eol}      <LearningGuidanceEntryCard />${eol}${eol}      <section`,
  );
}

const importCount = source.split(importLine).length - 1;
const renderCount =
  source.split("<LearningGuidanceEntryCard />").length - 1;

if (importCount !== 1 || renderCount !== 1) {
  throw new Error(
    `Unexpected native guidance entry counts: import=${importCount}, render=${renderCount}`,
  );
}

fs.writeFileSync(file, source, "utf8");

console.log("SPRINT-1203-1208 INSTALL COMPLETE");
console.log("LearningStudioPage native guidance entry installed.");
