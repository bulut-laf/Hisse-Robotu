﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$src = Join-Path $app "src"
$out = Join-Path $root "LAF_CAPABILITY_CONTENT_HANDOFF.txt"

$report = New-Object System.Collections.Generic.List[string]

function Add-Line {
    param([string]$Text)
    if ($null -eq $Text) { $Text = "" }
    [void]$report.Add($Text)
}

function Add-Section {
    param([string]$Title)
    Add-Line ""
    Add-Line ("=" * 96)
    Add-Line $Title
    Add-Line ("=" * 96)
}

function Add-File {
    param(
        [string]$Relative,
        [int]$Limit = 500
    )

    $file = Join-Path $src $Relative
    Add-Section ("FILE: app\src\" + $Relative)

    if (-not (Test-Path $file)) {
        Add-Line "(file not found)"
        return
    }

    $lines = @(Get-Content -Path $file)
    $count = [Math]::Min($lines.Count, $Limit)

    for ($i = 0; $i -lt $count; $i++) {
        Add-Line ("{0,4}: {1}" -f ($i + 1), $lines[$i])
    }

    if ($lines.Count -gt $Limit) {
        Add-Line ("... truncated; total lines: " + $lines.Count)
    }
}

Add-Line "LAF STUDIO - CAPABILITY TAXONOMY CONTENT HANDOFF"
Add-Line ("Generated: " + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
Add-Line "READ ONLY - no project source files are modified."

Add-File "core\learning\CefrCompetencyOutcome.ts" 700
Add-File "core\learning\CefrCompetencyOutcome.test.ts" 700
Add-File "core\learning\CefrCapabilityTaxonomy.ts" 400
Add-File "core\learning\CefrCapabilityTaxonomyRegistry.ts" 400
Add-File "core\learning\CefrCompetencyCapabilityMapping.ts" 500
Add-File "core\learning\CefrCompetencyCapabilityMappingRegistry.ts" 500
Add-File "core\learning\CefrAuthoritativeCapabilityRegistry.ts" 500
Add-File "core\learning\CefrCapabilityMappingSafety.ts" 400

Add-Section "DESIGN STUDIO CONTENT DECISIONS REQUIRED"

Add-Line "For every real production capability:"
Add-Line "- capabilityReference: immutable stable identifier"
Add-Line "- behaviorDescription: observable/reusable language behavior or sub-skill"
Add-Line ""
Add-Line "For every Competency Outcome:"
Add-Line "- competencyOutcomeId"
Add-Line "- capabilityReferences[]"
Add-Line "- normal cardinality: 1..3"
Add-Line "- above 3 requires explicit curriculum exception"
Add-Line "- mappingVersion: required"
Add-Line ""
Add-Line "Multiple Competency Outcomes may share the same capabilityReference."
Add-Line ""
Add-Line "Observation semantics stay fixed:"
Add-Line "curriculum eligibility + authoritative capability mapping + persisted real evidence"
Add-Line "-> observational-only capability observation"
Add-Line ""
Add-Line "No mastery assignment."
Add-Line "No competency success assignment."
Add-Line "No CEFR-level assignment."
Add-Line "No automatic progression."
Add-Line ""
Add-Line "Do not derive capability identities from Studio names, routes, test fixture strings, or wording heuristics."

$report | Set-Content -Path $out -Encoding UTF8

Write-Host ""
Write-Host "LAF CAPABILITY CONTENT HANDOFF EXPORT COMPLETE"
Write-Host "Report:"
Write-Host $out
