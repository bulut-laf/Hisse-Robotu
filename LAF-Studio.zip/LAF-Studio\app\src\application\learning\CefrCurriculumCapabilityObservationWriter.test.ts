import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrCapabilityTaxonomyRegistry,
} from "../../core/learning/CefrCapabilityTaxonomyRegistry";
import {
  createCefrCompetencyCapabilityMappingRegistry,
} from "../../core/learning/CefrCompetencyCapabilityMappingRegistry";
import {
  createCefrCurriculumCompetencyRegistry,
} from "../../core/learning/CefrCurriculumCompetencyRegistry";
import {
  createCefrPersonalLanguageProfileState,
  type CefrPersonalLanguageProfileState,
} from "../../core/learning/CefrPersonalLanguageProfileState";
import type {
  CefrGuidanceRuntimeProfileRepository,
} from "./CefrGuidanceRuntimeProfileRepository";
import {
  CefrCurriculumCapabilityObservationWriter,
} from "./CefrCurriculumCapabilityObservationWriter";

class MemoryRepository
implements CefrGuidanceRuntimeProfileRepository {
  private state:
    CefrPersonalLanguageProfileState;

  constructor(
    state:
      CefrPersonalLanguageProfileState,
  ) {
    this.state = state;
  }

  load(): CefrPersonalLanguageProfileState {
    return this.state;
  }

  save(
    state:
      CefrPersonalLanguageProfileState,
  ): void {
    this.state = state;
  }

  hasPersistedProfile(): boolean {
    return true;
  }

  clear(): void {
    this.state =
      createCefrPersonalLanguageProfileState(
        [],
        [],
      );
  }
}

describe(
  "CefrCurriculumCapabilityObservationWriter 1279",
  () => {
    it("persists only fully authoritative observational writes", () => {
      const evidence = {
        evidenceId: "evidence-writer-1279",
        source: "learning-studio" as const,
        observedAt:
          "2026-08-11T13:05:00.000Z",
        payloadReference:
          "lesson-writer-1279",
        masteryClaimed: false as const,
        cefrLevelClaimed: false as const,
      };

      const taxonomy =
        createCefrCapabilityTaxonomyRegistry([
          {
            capabilityReference:
              "test-capability-writer",
            behaviorDescription:
              "Observable reusable behavior.",
            reusableLanguageBehavior: true,
            productionIdentifierImmutable: true,
            authoritative: true,
          },
        ]);

      const mappings =
        createCefrCompetencyCapabilityMappingRegistry(
          [
            {
              competencyOutcomeId:
                "connect-a1",
              capabilityReferences: [
                "test-capability-writer",
              ],
              mappingAuthority:
                "dedicated-competency-capability-mapping-registry",
              mappingVersion: "v1",
              authoritative: true,
            },
          ],
          taxonomy,
        );

      const curriculum =
        createCefrCurriculumCompetencyRegistry([
          {
            learningItemId:
              "lesson-writer-1279",
            learningItemType: "lesson",
            competencyOutcomeIds: [
              "connect-a1",
            ],
            mappingAuthority:
              "curriculum-registry",
            mappingVersion: "v1",
            authoritative: true,
          },
        ]);

      const repository =
        new MemoryRepository(
          createCefrPersonalLanguageProfileState(
            [evidence],
            [],
          ),
        );

      const writer =
        new CefrCurriculumCapabilityObservationWriter(
          repository,
          curriculum,
          taxonomy,
          mappings,
        );

      expect(
        writer.write({
          learningItemType: "lesson",
          learningItemId:
            "lesson-writer-1279",
          evidenceId:
            evidence.evidenceId,
        }).capabilityObservationWritten,
      ).toBe(true);

      expect(
        repository.load()
          .capabilityObservationRegistry
          .observationCount,
      ).toBe(1);
    });
  },
);
