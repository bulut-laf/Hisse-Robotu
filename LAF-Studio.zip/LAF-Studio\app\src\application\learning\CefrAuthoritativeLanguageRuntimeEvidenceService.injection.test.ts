import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createLafA1ConnectRuntimeSliceDefinition,
} from "../../core/learning/CefrA1ConnectRuntimeSliceDefinition";
import {
  createCefrPersonalLanguageProfileState,
  type CefrPersonalLanguageProfileState,
} from "../../core/learning/CefrPersonalLanguageProfileState";
import {
  CefrAuthoritativeLanguageRuntimeEvidenceService,
} from "./CefrAuthoritativeLanguageRuntimeEvidenceService";
import {
  CefrAuthoritativeRuntimeEvidenceService,
} from "./CefrAuthoritativeRuntimeEvidenceService";
import type {
  CefrGuidanceRuntimeProfileRepository,
} from "./CefrGuidanceRuntimeProfileRepository";

class MemoryRepository
  implements CefrGuidanceRuntimeProfileRepository {
  private state:
    CefrPersonalLanguageProfileState =
      createCefrPersonalLanguageProfileState(
        [],
        [],
      );

  load(): CefrPersonalLanguageProfileState {
    return this.state;
  }

  save(
    state: CefrPersonalLanguageProfileState,
  ): void {
    this.state = state;
  }

  hasPersistedProfile(): boolean {
    return false;
  }

  clear(): void {}
}

describe(
  "CefrAuthoritativeLanguageRuntimeEvidenceService injection",
  () => {
    it("accepts a slice-configured runtime service while preserving old constructor compatibility", () => {
      const repository =
        new MemoryRepository();
      const definition =
        createLafA1ConnectRuntimeSliceDefinition();

      const runtime =
        new CefrAuthoritativeRuntimeEvidenceService(
          repository,
          definition.evidenceRegistry,
          definition.curriculumRegistry,
          definition.capabilityTaxonomyRegistry,
          definition.competencyCapabilityMappingRegistry,
        );

      const service =
        new CefrAuthoritativeLanguageRuntimeEvidenceService(
          repository,
          definition.provenanceAuthority,
          undefined,
          runtime,
        );

      expect(service).toBeDefined();
    });
  },
);
