$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 972-974 Target Tests: Studio Recommendation Consumption ==="
npx vitest run `
  "src/core/learning/CefrStudioRecommendationConsumer.test.ts" `
  "src/core/learning/CefrStudioRecommendationRegistry.test.ts" `
  "src/core/learning/CefrStudioRecommendationOrchestration.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 972-974 target tests failed." }

Write-Host "=== Sprint 975-977 Target Tests: User Guidance Presentation and Review ==="
npx vitest run `
  "src/core/learning/CefrUserGuidancePresentation.test.ts" `
  "src/core/learning/CefrUserGuidanceChoice.test.ts" `
  "src/core/learning/CefrUserGuidanceReview.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 975-977 target tests failed." }

Write-Host "=== Sprint 978-980 Target Tests: Approval and Execution Boundary ==="
npx vitest run `
  "src/core/learning/CefrGuidanceApprovalBoundary.test.ts" `
  "src/core/learning/CefrApprovedGuidanceIntent.test.ts" `
  "src/core/learning/CefrGuidanceExecutionGateway.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 978-980 target tests failed." }

Write-Host "=== Combined Sprint 972-980 New Tests ==="
npx vitest run `
  "src/core/learning/CefrStudioRecommendationConsumer.test.ts" `
  "src/core/learning/CefrStudioRecommendationRegistry.test.ts" `
  "src/core/learning/CefrStudioRecommendationOrchestration.test.ts" `
  "src/core/learning/CefrUserGuidancePresentation.test.ts" `
  "src/core/learning/CefrUserGuidanceChoice.test.ts" `
  "src/core/learning/CefrUserGuidanceReview.test.ts" `
  "src/core/learning/CefrGuidanceApprovalBoundary.test.ts" `
  "src/core/learning/CefrApprovedGuidanceIntent.test.ts" `
  "src/core/learning/CefrGuidanceExecutionGateway.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 972-980 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-972-980 VERIFICATION COMPLETE"
