import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrPersonalLanguageProfileState,
  type CefrPersonalLanguageProfileState,
} from "../../core/learning/CefrPersonalLanguageProfileState";
import type {
  CefrLanguageEvidenceStorageLike,
} from "./CefrAuthoritativeLanguageEvidenceProvenanceRepository";
import type {
  CefrGuidanceRuntimeProfileRepository,
} from "./CefrGuidanceRuntimeProfileRepository";
import {
  CefrProductionRuntimePlatform,
} from "./CefrProductionRuntimePlatform";
import {
  CefrA1NavigateSecondWaveExecutableTaskService,
} from "./CefrA1NavigateSecondWaveExecutableTaskService";

class MemoryProfileRepository
  implements CefrGuidanceRuntimeProfileRepository {
  private state:
    CefrPersonalLanguageProfileState =
      createCefrPersonalLanguageProfileState(
        [],
        [],
      );

  load(): CefrPersonalLanguageProfileState {
    return this.state;
  }

  save(
    state: CefrPersonalLanguageProfileState,
  ): void {
    this.state = state;
  }

  hasPersistedProfile(): boolean {
    return false;
  }

  clear(): void {}
}

class MemoryStorage
  implements CefrLanguageEvidenceStorageLike {
  private readonly items =
    new Map<string, string>();

  getItem(key: string): string | null {
    return this.items.get(key) ?? null;
  }

  setItem(
    key: string,
    value: string,
  ): void {
    this.items.set(key, value);
  }

  removeItem(key: string): void {
    this.items.delete(key);
  }
}

function createService() {
  const repository =
    new MemoryProfileRepository();

  return {
    repository,
    service:
      new CefrA1NavigateSecondWaveExecutableTaskService(
        new CefrProductionRuntimePlatform(
          repository,
          new MemoryStorage(),
        ),
      ),
  };
}

describe(
  "A1 NAVIGATE second-wave executable task service",
  () => {
    it("prepares listening and reading meaning-selection tasks without writing evidence", () => {
      const { service } = createService();

      const listening =
        service.getSingleTaskView(
          "a1-navigate-task-practical-answer",
          "hu",
        );
      const reading =
        service.getSingleTaskView(
          "a1-navigate-task-practical-reading",
          "de",
        );

      expect(listening).toMatchObject({
        taskKind:
          "listening-meaning-selection",
        evidenceDefinitionId:
          "a1-navigate-evidence-practical-answer",
        correctAnswerExposed: false,
        evidenceWritten: false,
      });
      expect(listening.promptPhrase.text).toBe(
        "Ott van balra.",
      );

      expect(reading).toMatchObject({
        taskKind:
          "reading-meaning-selection",
        evidenceDefinitionId:
          "a1-navigate-evidence-practical-reading",
        correctAnswerExposed: false,
        evidenceWritten: false,
      });
      expect(reading.promptPhrase.text).toBe(
        "Um zehn Uhr.",
      );
    });

    it("writes practical-answer evidence only after the correct explicit user selection", () => {
      const {
        repository,
        service,
      } = createService();

      const wrong =
        service.executeSingleSelection({
          taskId:
            "a1-navigate-task-practical-answer",
          languageCode: "hu",
          selectedPhraseId:
            "answer-price",
          eventId:
            "navigate-listening-wrong",
          occurredAt:
            new Date(
              "2026-08-12T11:00:00.000Z",
            ),
          userActionConfirmed: true,
        });

      expect(wrong).toMatchObject({
        correct: false,
        evidenceWritten: false,
        runtime: null,
      });

      const correct =
        service.executeSingleSelection({
          taskId:
            "a1-navigate-task-practical-answer",
          languageCode: "hu",
          selectedPhraseId:
            "answer-location",
          eventId:
            "navigate-listening-correct",
          occurredAt:
            new Date(
              "2026-08-12T11:01:00.000Z",
            ),
          userActionConfirmed: true,
        });

      expect(correct).toMatchObject({
        correct: true,
        evidenceWritten: true,
        masteryAssigned: false,
        cefrLevelAssigned: false,
        progressionPerformed: false,
      });

      expect(
        correct.runtime?.runtime
          .resolvedCapabilityReferences,
      ).toEqual([
        "needs-expression",
      ]);

      expect(
        repository.load()
          .profileSnapshot
          .evidenceAggregation
          .evidence,
      ).toHaveLength(1);
    });

    it("requires all three correct reciprocal steps before writing one evidence event", () => {
      const {
        repository,
        service,
      } = createService();

      const partial =
        service.executeReciprocalExchange({
          languageCode: "it",
          selectedPhraseIds: [
            "exchange-request",
            "exchange-question",
          ],
          eventId:
            "navigate-exchange-partial",
          occurredAt:
            new Date(
              "2026-08-12T11:05:00.000Z",
            ),
          userActionConfirmed: true,
        });

      expect(partial).toMatchObject({
        correctPrefix: true,
        complete: false,
        evidenceWritten: false,
        runtime: null,
      });

      const wrong =
        service.executeReciprocalExchange({
          languageCode: "it",
          selectedPhraseIds: [
            "exchange-question",
          ],
          eventId:
            "navigate-exchange-wrong",
          occurredAt:
            new Date(
              "2026-08-12T11:06:00.000Z",
            ),
          userActionConfirmed: true,
        });

      expect(wrong).toMatchObject({
        correctPrefix: false,
        complete: false,
        evidenceWritten: false,
      });

      const complete =
        service.executeReciprocalExchange({
          languageCode: "it",
          selectedPhraseIds: [
            "exchange-request",
            "exchange-question",
            "exchange-close",
          ],
          eventId:
            "navigate-exchange-complete",
          occurredAt:
            new Date(
              "2026-08-12T11:07:00.000Z",
            ),
          userActionConfirmed: true,
        });

      expect(complete).toMatchObject({
        correctPrefix: true,
        complete: true,
        evidenceWritten: true,
        automaticTransactionCompletionPerformed:
          false,
      });

      expect(
        repository.load()
          .profileSnapshot
          .evidenceAggregation
          .evidence,
      ).toHaveLength(1);
    });
  },
);
