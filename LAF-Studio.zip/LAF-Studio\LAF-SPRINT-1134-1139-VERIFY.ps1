$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 1134-1136 Target Tests: Application Read Model ==="
npx vitest run `
  "src/core/learning/CefrApplicationGuidanceReadModel.test.ts" `
  "src/core/learning/CefrApplicationGuidanceViewState.test.ts" `
  "src/core/learning/CefrGuidanceUserActionRequest.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1134-1136 target tests failed." }

Write-Host "=== Sprint 1137-1139 Target Tests: User Action Request Bridge ==="
npx vitest run `
  "src/core/learning/CefrGuidanceUserActionBridge.test.ts" `
  "src/core/learning/CefrGuidanceReviewRequestContext.test.ts" `
  "src/core/learning/CefrApplicationGuidanceInteractionBoundary.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1137-1139 target tests failed." }

Write-Host "=== Combined Sprint 1134-1139 New Tests ==="
npx vitest run `
  "src/core/learning/CefrApplicationGuidanceReadModel.test.ts" `
  "src/core/learning/CefrApplicationGuidanceViewState.test.ts" `
  "src/core/learning/CefrGuidanceUserActionRequest.test.ts" `
  "src/core/learning/CefrGuidanceUserActionBridge.test.ts" `
  "src/core/learning/CefrGuidanceReviewRequestContext.test.ts" `
  "src/core/learning/CefrApplicationGuidanceInteractionBoundary.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1134-1139 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-1134-1139 VERIFICATION COMPLETE"
