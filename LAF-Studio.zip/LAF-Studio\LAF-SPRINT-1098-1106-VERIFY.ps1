$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 1098-1100 Target Tests: Continuity History ==="
npx vitest run `
  "src/core/learning/CefrNextDayContinuityHistoryRecord.test.ts" `
  "src/core/learning/CefrNextDayContinuityHistory.test.ts" `
  "src/core/learning/CefrNextDayContinuityHistorySnapshot.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1098-1100 target tests failed." }

Write-Host "=== Sprint 1101-1103 Target Tests: Incomplete Route Recovery ==="
npx vitest run `
  "src/core/learning/CefrIncompleteNextDayGuidanceRoute.test.ts" `
  "src/core/learning/CefrIncompleteNextDayGuidanceRegistry.test.ts" `
  "src/core/learning/CefrContinuityRecoveryCandidate.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1101-1103 target tests failed." }

Write-Host "=== Sprint 1104-1106 Target Tests: Continuity Rebuild ==="
npx vitest run `
  "src/core/learning/CefrUserContinuityRecoveryChoice.test.ts" `
  "src/core/learning/CefrRecoveredContinuityPlan.test.ts" `
  "src/core/learning/CefrContinuityRecoveryOrchestration.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1104-1106 target tests failed." }

Write-Host "=== Combined Sprint 1098-1106 New Tests ==="
npx vitest run `
  "src/core/learning/CefrNextDayContinuityHistoryRecord.test.ts" `
  "src/core/learning/CefrNextDayContinuityHistory.test.ts" `
  "src/core/learning/CefrNextDayContinuityHistorySnapshot.test.ts" `
  "src/core/learning/CefrIncompleteNextDayGuidanceRoute.test.ts" `
  "src/core/learning/CefrIncompleteNextDayGuidanceRegistry.test.ts" `
  "src/core/learning/CefrContinuityRecoveryCandidate.test.ts" `
  "src/core/learning/CefrUserContinuityRecoveryChoice.test.ts" `
  "src/core/learning/CefrRecoveredContinuityPlan.test.ts" `
  "src/core/learning/CefrContinuityRecoveryOrchestration.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1098-1106 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-1098-1106 VERIFICATION COMPLETE"
