import { describe, expect, it } from "vitest";
import { createCefrPersonalLanguageProfileState } from "../../core/learning/CefrPersonalLanguageProfileState";
import type { CefrPersonalLanguageProfileEvidence } from "../../core/learning/CefrPersonalLanguageProfileEvidence";
import { createCefrGuidanceEvidenceActivityView } from "./CefrGuidanceEvidenceActivityView";

function evidence(
  evidenceId: string,
  observedAt: string,
  source:
    | "learning-studio"
    | "translation-studio"
    | "interpreting-studio" =
      "learning-studio",
): CefrPersonalLanguageProfileEvidence {
  return {
    evidenceId,
    source,
    observedAt,
    payloadReference: evidenceId,
    masteryClaimed: false,
    cefrLevelClaimed: false,
  };
}

describe("CefrGuidanceEvidenceActivityView", () => {
  const state =
    createCefrPersonalLanguageProfileState(
      [
        evidence(
          "learning-session-completion:lesson-1",
          "2026-08-11T10:00:00.000Z",
        ),
        evidence(
          "listening-practice-completion:lesson-2:2026-08-11T10:05:00.000Z",
          "2026-08-11T10:05:00.000Z",
        ),
        evidence(
          "embedded-studio-completion:reading:2026-08-11T10:10:00.000Z",
          "2026-08-11T10:10:00.000Z",
        ),
        evidence(
          "embedded-studio-completion:writing:single-sentence:2026-08-11T10:20:00.000Z",
          "2026-08-11T10:20:00.000Z",
        ),
        evidence(
          "translation-evidence-1",
          "2026-08-11T10:25:00.000Z",
          "translation-studio",
        ),
      ],
      [],
    );

  it("summarizes the complete persisted profile without assigning mastery or CEFR level", () => {
    const view =
      createCefrGuidanceEvidenceActivityView(
        state,
      );

    expect(view.totalEvidenceCount).toBe(5);
    expect(view.learningEvidenceCount).toBe(4);
    expect(view.translationEvidenceCount).toBe(1);
    expect(view.interpretingEvidenceCount).toBe(0);
    expect(view.masteryAssigned).toBe(false);
    expect(view.cefrLevelAssigned).toBe(false);
    expect(view.progressionPerformed).toBe(false);
    expect(view.readOnly).toBe(true);
  });

  it("filters by verified completion kind", () => {
    const view =
      createCefrGuidanceEvidenceActivityView(
        state,
        {
          kind: "writing",
          source: "all",
          limit: 12,
        },
      );

    expect(view.filteredEvidenceCount).toBe(1);
    expect(view.latestItems).toHaveLength(1);
    expect(view.latestItems[0].kind).toBe(
      "writing",
    );
  });

  it("filters by real evidence source", () => {
    const view =
      createCefrGuidanceEvidenceActivityView(
        state,
        {
          kind: "all",
          source: "translation-studio",
          limit: 12,
        },
      );

    expect(view.filteredEvidenceCount).toBe(1);
    expect(view.latestItems[0]).toMatchObject({
      source: "translation-studio",
      kind: "other",
    });
  });

  it("combines source and kind filters conservatively", () => {
    const view =
      createCefrGuidanceEvidenceActivityView(
        state,
        {
          kind: "reading",
          source: "translation-studio",
          limit: 12,
        },
      );

    expect(view.filteredEvidenceCount).toBe(0);
    expect(view.latestItems).toEqual([]);
  });

  it("keeps newest filtered evidence first and respects the visible limit", () => {
    const view =
      createCefrGuidanceEvidenceActivityView(
        state,
        {
          kind: "all",
          source: "learning-studio",
          limit: 2,
        },
      );

    expect(
      view.latestItems.map(item => item.kind),
    ).toEqual([
      "writing",
      "reading",
    ]);
  });
});
