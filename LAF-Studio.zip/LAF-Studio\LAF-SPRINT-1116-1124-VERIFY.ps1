$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 1116-1118 Target Tests: Recovery Evidence Return ==="
npx vitest run `
  "src/core/learning/CefrCompletedRecoveryRouteFeedback.test.ts" `
  "src/core/learning/CefrRecoveryEvidenceReturn.test.ts" `
  "src/core/learning/CefrRecoveryCapabilityObservationReturn.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1116-1118 target tests failed." }

Write-Host "=== Sprint 1119-1121 Target Tests: Recovery Profile Refresh ==="
npx vitest run `
  "src/core/learning/CefrRecoveryFeedbackBundle.test.ts" `
  "src/core/learning/CefrRecoveryProfileEvidenceRefresh.test.ts" `
  "src/core/learning/CefrRecoveryObservationRefresh.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1119-1121 target tests failed." }

Write-Host "=== Sprint 1122-1124 Target Tests: Next Guidance Re-entry ==="
npx vitest run `
  "src/core/learning/CefrRecoveryUnifiedProfileRefresh.test.ts" `
  "src/core/learning/CefrRecoveryNextGuidanceContext.test.ts" `
  "src/core/learning/CefrRecoveryGuidanceClosedLoop.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1122-1124 target tests failed." }

Write-Host "=== Combined Sprint 1116-1124 New Tests ==="
npx vitest run `
  "src/core/learning/CefrCompletedRecoveryRouteFeedback.test.ts" `
  "src/core/learning/CefrRecoveryEvidenceReturn.test.ts" `
  "src/core/learning/CefrRecoveryCapabilityObservationReturn.test.ts" `
  "src/core/learning/CefrRecoveryFeedbackBundle.test.ts" `
  "src/core/learning/CefrRecoveryProfileEvidenceRefresh.test.ts" `
  "src/core/learning/CefrRecoveryObservationRefresh.test.ts" `
  "src/core/learning/CefrRecoveryUnifiedProfileRefresh.test.ts" `
  "src/core/learning/CefrRecoveryNextGuidanceContext.test.ts" `
  "src/core/learning/CefrRecoveryGuidanceClosedLoop.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1116-1124 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-1116-1124 VERIFICATION COMPLETE"
