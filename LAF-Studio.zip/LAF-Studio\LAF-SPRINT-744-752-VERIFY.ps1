$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 744-746 Target Tests: Custodial Auditability ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialAuditability.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialAuditabilityCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialAuditabilityAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 744-746 target tests failed." }

Write-Host "=== Sprint 747-749 Target Tests: Custodial Verifiability ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialVerifiability.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialVerifiabilityCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialVerifiabilityAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 747-749 target tests failed." }

Write-Host "=== Sprint 750-752 Target Tests: Custodial Assurance ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialAssurance.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialAssuranceCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialAssuranceAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 750-752 target tests failed." }

Write-Host "=== Combined Sprint 744-752 New Tests ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialAuditability.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialAuditabilityCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialAuditabilityAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialVerifiability.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialVerifiabilityCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialVerifiabilityAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialAssurance.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialAssuranceCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialAssuranceAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 744-752 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-744-752 VERIFICATION COMPLETE"
