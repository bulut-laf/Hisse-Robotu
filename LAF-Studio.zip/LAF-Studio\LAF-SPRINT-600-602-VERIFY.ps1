$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

Set-Location $app

Write-Host "=== Sprint 600-602 Target Tests ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceConnectivity.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceConnectivityCoordination.test.ts" `
  "src/core/learning/CefrEvidenceConnectivityAwareCefrIntelligencePlatform.test.ts"

if ($LASTEXITCODE -ne 0) {
  throw "Sprint 600-602 target tests failed."
}

Write-Host "=== Full Regression ==="
npm run test

if ($LASTEXITCODE -ne 0) {
  throw "Full regression failed."
}

Write-Host "=== Production Build ==="
npm run build

if ($LASTEXITCODE -ne 0) {
  throw "Production build failed."
}

Write-Host "SPRINT-600-602 VERIFICATION COMPLETE"
