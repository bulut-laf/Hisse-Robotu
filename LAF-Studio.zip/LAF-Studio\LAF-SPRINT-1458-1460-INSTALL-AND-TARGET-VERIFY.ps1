﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

$required = @(
    "src\core\learning\CefrA1NavigateLanguageRealizationBoundary.ts",
    "src\core\learning\CefrA1NavigateLanguageRealizationBoundary.test.ts",
    "src\core\learning\CefrA1NavigateLanguageRealizationRegistry.ts",
    "src\core\learning\CefrA1NavigateLanguageRealizationRegistry.test.ts",
    "src\core\learning\CefrA1NavigateLanguageRealizationFoundationSafety.ts",
    "src\core\learning\CefrA1NavigateLanguageRealizationFoundationSafety.test.ts",
    "src\application\learning\CefrA1NavigateTargetLanguageSelectionModel.ts",
    "src\application\learning\CefrA1NavigateTargetLanguageSelectionModel.test.ts"
)

foreach ($relative in $required) {
    $path = Join-Path $app $relative

    if (-not (Test-Path $path)) {
        throw "Sprint 1458-1460 required file missing: $relative"
    }
}

$checks = @(
    @(
      "src\core\learning\CefrA1NavigateLanguageRealizationRegistry.ts",
      '"a1-navigate-immediate-everyday-needs"'
    ),
    @(
      "src\core\learning\CefrA1NavigateLanguageRealizationRegistry.ts",
      '"content-realization-pending"'
    ),
    @(
      "src\application\learning\CefrA1NavigateTargetLanguageSelectionModel.ts",
      "targetLanguageInferred: false"
    ),
    @(
      "src\core\learning\CefrA1NavigateLanguageRealizationBoundary.ts",
      "delayedRetrievalExecutableWithoutPolicy:"
    ),
    @(
      "src\core\learning\CefrA1NavigateLanguageRealizationFoundationSafety.ts",
      "currentCheckpointWritesEvidence:"
    )
)

foreach ($check in $checks) {
    $path = Join-Path $app $check[0]

    if (-not (
        Select-String `
            -Path $path `
            -SimpleMatch `
            -Pattern $check[1] `
            -Quiet
    )) {
        throw "Sprint 1458-1460 source marker missing: $($check[1])"
    }
}

Write-Host "SPRINT-1458-1460 SOURCE CHECK PASSED"

Set-Location $app

Write-Host ""
Write-Host "CHECKPOINT 1/3 — Sprint 1458-1460 target tests only"

& npx vitest run @(
    "src/core/learning/CefrA1NavigateLanguageRealizationBoundary.test.ts",
    "src/core/learning/CefrA1NavigateLanguageRealizationRegistry.test.ts",
    "src/core/learning/CefrA1NavigateLanguageRealizationFoundationSafety.test.ts",
    "src/application/learning/CefrA1NavigateTargetLanguageSelectionModel.test.ts",
    "src/core/language/LafLanguageProfile.test.ts",
    "src/core/learning/CefrA1NavigateRuntimeSliceDefinition.test.ts",
    "src/core/learning/CefrProductionRuntimeRegistryEnforcement.test.ts"
)

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1458-1460 target checkpoint failed."
}

Write-Host ""
Write-Host "SPRINT-1458-1460 TARGET CHECKPOINT COMPLETE"
Write-Host "No full regression/build in this 3-sprint checkpoint by design."
Write-Host "Stable production checkpoint remains Sprint 1457 until the 9-sprint block closes."
