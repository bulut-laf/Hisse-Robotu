import type {
  LafLearningLanguageCode,
} from "../../core/language/LafLanguageProfile";
import type {
  CefrA1ConnectLanguageEvidenceProvenance,
} from "../../core/learning/CefrA1ConnectLanguageEvidenceProvenance";

interface StorageLike {
  getItem(key: string): string | null;
  setItem(
    key: string,
    value: string,
  ): void;
  removeItem(key: string): void;
}

interface StoredEnvelope {
  readonly version: 1;
  readonly items:
    readonly CefrA1ConnectLanguageEvidenceProvenance[];
}

export const A1_CONNECT_LANGUAGE_EVIDENCE_PROVENANCE_STORAGE_KEY =
  "laf.cefr.a1-connect.language-evidence-provenance.v1";

function isProvenance(
  value: unknown,
): value is CefrA1ConnectLanguageEvidenceProvenance {
  if (
    typeof value !== "object" ||
    value === null
  ) {
    return false;
  }

  const item =
    value as Partial<CefrA1ConnectLanguageEvidenceProvenance>;

  return (
    typeof item.evidenceId === "string" &&
    typeof item.languageCode === "string" &&
    typeof item.observedAt === "string" &&
    item.source === "a1-connect-runtime" &&
    item.authoritativeLanguageProvenance ===
      true &&
    item.masteryClaimed === false &&
    item.cefrLevelClaimed === false
  );
}

export class CefrA1ConnectLanguageEvidenceProvenanceRepository {
  private readonly storage:
    StorageLike | null;

  constructor(
    storage:
      StorageLike | null =
        typeof window !== "undefined"
          ? window.localStorage
          : null,
  ) {
    this.storage = storage;
  }

  loadAll():
    readonly CefrA1ConnectLanguageEvidenceProvenance[] {
    if (!this.storage) {
      return [];
    }

    const raw =
      this.storage.getItem(
        A1_CONNECT_LANGUAGE_EVIDENCE_PROVENANCE_STORAGE_KEY,
      );

    if (!raw) {
      return [];
    }

    try {
      const parsed =
        JSON.parse(
          raw,
        ) as Partial<StoredEnvelope>;

      if (
        parsed.version !== 1 ||
        !Array.isArray(parsed.items)
      ) {
        return [];
      }

      return parsed.items.filter(
        isProvenance,
      );
    }
    catch {
      return [];
    }
  }

  save(
    provenance:
      CefrA1ConnectLanguageEvidenceProvenance,
  ):
    CefrA1ConnectLanguageEvidenceProvenance {
    const existing =
      this.loadAll().find(
        item =>
          item.evidenceId ===
          provenance.evidenceId,
      );

    if (
      existing &&
      existing.languageCode !==
        provenance.languageCode
    ) {
      throw new Error(
        `Evidence language provenance conflict: ${provenance.evidenceId}`,
      );
    }

    if (!this.storage) {
      return existing ?? provenance;
    }

    const next = existing
      ? this.loadAll()
      : [
          ...this.loadAll(),
          provenance,
        ];

    const envelope:
      StoredEnvelope = {
        version: 1,
        items: next,
      };

    this.storage.setItem(
      A1_CONNECT_LANGUAGE_EVIDENCE_PROVENANCE_STORAGE_KEY,
      JSON.stringify(envelope),
    );

    return existing ?? provenance;
  }

  findByEvidenceId(
    evidenceId: string,
  ):
    CefrA1ConnectLanguageEvidenceProvenance | null {
    return (
      this.loadAll().find(
        item =>
          item.evidenceId === evidenceId,
      ) ?? null
    );
  }

  findForLanguage(
    languageCode: LafLearningLanguageCode,
  ):
    readonly CefrA1ConnectLanguageEvidenceProvenance[] {
    return this.loadAll().filter(
      item =>
        item.languageCode === languageCode,
    );
  }

  clear(): void {
    this.storage?.removeItem(
      A1_CONNECT_LANGUAGE_EVIDENCE_PROVENANCE_STORAGE_KEY,
    );
  }
}
