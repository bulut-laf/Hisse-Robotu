import { describe, expect, it } from "vitest";
import { getTranslationDialogueScenario } from "./TranslationDialogueScenario";

describe("TranslationDialogueScenario — seven languages", () => {
  it.each([
    ["hu", "Jó napot"], ["tr", "Merhaba"], ["de", "Guten Tag"],
    ["it", "Buongiorno"], ["en", "Hello"], ["es", "¡Buenos días!"],
    ["ru", "Здравствуйте"],
  ] as const)("provides localized cafe opening for %s", (language, expected) => {
    expect(getTranslationDialogueScenario(language, "cafe").prompts[0]?.partnerText).toContain(expected);
  });
});
