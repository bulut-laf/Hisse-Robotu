$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 807-809 Target Tests: Custodial Outcome ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialOutcome.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialOutcomeCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialOutcomeAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 807-809 target tests failed." }

Write-Host "=== Sprint 810-812 Target Tests: Custodial Effect ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialEffect.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialEffectCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialEffectAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 810-812 target tests failed." }

Write-Host "=== Sprint 813-815 Target Tests: Custodial Influence ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialInfluence.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialInfluenceCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialInfluenceAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 813-815 target tests failed." }

Write-Host "=== Combined Sprint 807-815 New Tests ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialOutcome.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialOutcomeCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialOutcomeAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialEffect.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialEffectCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialEffectAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialInfluence.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialInfluenceCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialInfluenceAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 807-815 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-807-815 VERIFICATION COMPLETE"
