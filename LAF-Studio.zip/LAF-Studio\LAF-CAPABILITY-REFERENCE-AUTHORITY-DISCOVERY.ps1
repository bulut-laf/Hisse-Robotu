﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$src = Join-Path $root "app\src"
$out = Join-Path $root "LAF_CAPABILITY_REFERENCE_AUTHORITY_DISCOVERY.txt"

if (-not (Test-Path $src)) {
    throw "Source root not found: $src"
}

$report = New-Object System.Collections.Generic.List[string]

function Add-Line {
    param([string]$Text)
    if ($null -eq $Text) { $Text = "" }
    [void]$report.Add($Text)
}

function Add-Section {
    param([string]$Title)
    Add-Line ""
    Add-Line ("=" * 96)
    Add-Line $Title
    Add-Line ("=" * 96)
}

function Rel {
    param([string]$Path)
    $prefix = $root + "\"
    if ($Path.StartsWith($prefix)) {
        return $Path.Substring($prefix.Length)
    }
    return $Path
}

$files = @(
    Get-ChildItem -Path $src -Recurse -File |
    Where-Object {
        $_.Extension -eq ".ts" -or
        $_.Extension -eq ".tsx"
    }
)

Add-Line "LAF STUDIO - CAPABILITY REFERENCE AUTHORITY DISCOVERY"
Add-Line ("Generated: " + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
Add-Line "READ ONLY - no project source files are modified."

Add-Section "1. PRODUCTION FILES CONTAINING capabilityReference"

$productionMatches = New-Object System.Collections.Generic.List[object]

foreach ($file in $files) {
    if (
        $file.Name.EndsWith(".test.ts") -or
        $file.Name.EndsWith(".test.tsx")
    ) {
        continue
    }

    $hits = @(
        Select-String `
            -Path $file.FullName `
            -SimpleMatch `
            -Pattern "capabilityReference" `
            -ErrorAction SilentlyContinue
    )

    foreach ($hit in $hits) {
        [void]$productionMatches.Add(
            [PSCustomObject]@{
                File = Rel $hit.Path
                Line = $hit.LineNumber
                Text = $hit.Line.Trim()
            }
        )
    }
}

if ($productionMatches.Count -eq 0) {
    Add-Line "(no production matches)"
} else {
    foreach ($m in (
        $productionMatches |
        Sort-Object File, Line |
        Select-Object -First 500
    )) {
        Add-Line (
            "{0}:{1}: {2}" -f
            $m.File,
            $m.Line,
            $m.Text
        )
    }
}

Add-Section "2. FILES CONTAINING BOTH competencyOutcome AND capabilityReference"

$cooccurrence = @()

foreach ($file in $files) {
    $text = Get-Content -Path $file.FullName -Raw

    if (
        $text -match "competencyOutcome" -and
        $text -match "capabilityReference"
    ) {
        $cooccurrence += $file
    }
}

if ($cooccurrence.Count -eq 0) {
    Add-Line "(no files contain both concepts)"
} else {
    foreach ($file in ($cooccurrence | Sort-Object FullName)) {
        $kind =
            if (
                $file.Name.EndsWith(".test.ts") -or
                $file.Name.EndsWith(".test.tsx")
            ) {
                "TEST"
            } else {
                "PRODUCTION"
            }

        Add-Line ("[$kind] " + (Rel $file.FullName))

        $lines = @(Get-Content -Path $file.FullName)
        $hits = @(
            Select-String `
                -Path $file.FullName `
                -Pattern "competencyOutcome|capabilityReference" `
                -ErrorAction SilentlyContinue
        )

        foreach ($hit in ($hits | Select-Object -First 80)) {
            Add-Line (
                "  {0}: {1}" -f
                $hit.LineNumber,
                $hit.Line.Trim()
            )
        }
    }
}

Add-Section "3. CANDIDATE CAPABILITY REGISTRY / CATALOG / TAXONOMY FILES"

$candidates = @(
    $files |
    Where-Object {
        $_.Name -match "Capability|Competency|Outcome|Registry|Catalog|Taxonomy|Curriculum|Mapping"
    } |
    Sort-Object FullName
)

foreach ($file in ($candidates | Select-Object -First 100)) {
    $kind =
        if (
            $file.Name.EndsWith(".test.ts") -or
            $file.Name.EndsWith(".test.tsx")
        ) {
            "TEST"
        } else {
            "PRODUCTION"
        }

    Add-Line ("[$kind] " + (Rel $file.FullName))
}

Add-Section "4. STRING LITERALS USED AS capabilityReference IN PRODUCTION"

$literalPattern = 'capabilityReference\s*:\s*["'']([^"'']+)["'']'
$literals = New-Object System.Collections.Generic.List[object]

foreach ($file in $files) {
    if (
        $file.Name.EndsWith(".test.ts") -or
        $file.Name.EndsWith(".test.tsx")
    ) {
        continue
    }

    $lines = @(Get-Content -Path $file.FullName)

    for ($i = 0; $i -lt $lines.Count; $i++) {
        $matches =
            [regex]::Matches(
                $lines[$i],
                $literalPattern
            )

        foreach ($match in $matches) {
            [void]$literals.Add(
                [PSCustomObject]@{
                    Value = $match.Groups[1].Value
                    File = Rel $file.FullName
                    Line = $i + 1
                }
            )
        }
    }
}

if ($literals.Count -eq 0) {
    Add-Line "(no production literal assignments)"
} else {
    foreach ($item in (
        $literals |
        Sort-Object Value, File, Line
    )) {
        Add-Line (
            "{0} <- {1}:{2}" -f
            $item.Value,
            $item.File,
            $item.Line
        )
    }
}

Add-Section "5. KNOWN TEST-FIXTURE capabilityReference VALUES"

$testLiterals = New-Object System.Collections.Generic.List[object]

foreach ($file in $files) {
    if (
        -not (
            $file.Name.EndsWith(".test.ts") -or
            $file.Name.EndsWith(".test.tsx")
        )
    ) {
        continue
    }

    $lines = @(Get-Content -Path $file.FullName)

    for ($i = 0; $i -lt $lines.Count; $i++) {
        $matches =
            [regex]::Matches(
                $lines[$i],
                $literalPattern
            )

        foreach ($match in $matches) {
            [void]$testLiterals.Add(
                [PSCustomObject]@{
                    Value = $match.Groups[1].Value
                    File = Rel $file.FullName
                    Line = $i + 1
                }
            )
        }
    }
}

foreach ($item in (
    $testLiterals |
    Sort-Object Value, File, Line |
    Select-Object -First 300
)) {
    Add-Line (
        "{0} <- {1}:{2}" -f
        $item.Value,
        $item.File,
        $item.Line
    )
}

Add-Section "6. AUTHORITATIVE COMPETENCY OUTCOME IDS"

$outcomeFile = Join-Path $src "core\learning\CefrCompetencyOutcome.ts"

if (Test-Path $outcomeFile) {
    $hits = @(
        Select-String `
            -Path $outcomeFile `
            -Pattern 'id\s*:\s*["''][^"'']+["'']' `
            -ErrorAction SilentlyContinue
    )

    foreach ($hit in $hits) {
        Add-Line (
            "{0}: {1}" -f
            $hit.LineNumber,
            $hit.Line.Trim()
        )
    }
} else {
    Add-Line "(CefrCompetencyOutcome.ts not found)"
}

Add-Section "7. CURRENT CURRICULUM MAPPING / REV1 SAFETY FILES"

$currentTargets = @(
    "core\learning\CefrCurriculumCompetencyMapping.ts",
    "core\learning\CefrCurriculumCompetencyRegistry.ts",
    "core\learning\CefrCurriculumCapabilityObservationEligibility.ts",
    "core\learning\CefrCurriculumCapabilityObservationWrite.ts",
    "core\learning\CefrCurriculumCapabilityObservationWriteSafety.ts",
    "application\learning\CefrMappedListeningPracticeCompletionService.ts"
)

foreach ($relative in $currentTargets) {
    $file = Join-Path $src $relative

    Add-Line ""
    Add-Line ("FILE: app\src\" + $relative)

    if (-not (Test-Path $file)) {
        Add-Line "(file not found)"
        continue
    }

    $lines = @(Get-Content -Path $file)
    $limit = [Math]::Min($lines.Count, 260)

    for ($i = 0; $i -lt $limit; $i++) {
        Add-Line (
            "{0,4}: {1}" -f
            ($i + 1),
            $lines[$i]
        )
    }
}

Add-Section "8. IMPLEMENTATION DECISION"

Add-Line "Question A: Is there an authoritative production registry/catalog defining valid capabilityReference identities?"
Add-Line "Question B: Is there an authoritative production relation from competencyOutcomeId -> one or more capabilityReference values?"
Add-Line "Question C: If no relation exists, do not reopen observation writes."
Add-Line "Question D: Test fixture capabilityReference strings are not production authority."
Add-Line "Question E: Route, Studio, skill label, module family, or outcome wording must not be used to infer a capabilityReference."
Add-Line "If no authority exists, the next required input is a Design Studio decision for an explicit Competency Outcome -> Capability Reference Mapping contract."

$report | Set-Content -Path $out -Encoding UTF8

Write-Host ""
Write-Host "LAF CAPABILITY REFERENCE AUTHORITY DISCOVERY COMPLETE"
Write-Host "Report:"
Write-Host $out
Write-Host ""
Get-Content -Path $out
