export type AiTeacherSurfaceId =
  | "grammar-lab"
  | "reading"
  | "listening"
  | "writing"
  | "speaking"
  | "dialogue"
  | "cefr-learning-path"
  | "translation-studio"
  | "text-workshop";

export type AiTeacherSurfaceClassification =
  | "AI_TEACHER"
  | "AI_PRODUCTIVITY_TOOL"
  | "MIXED_WITH_AUTHORITATIVE_CONTEXT";

export interface AiTeacherSurfaceBinding {
  readonly surfaceId: AiTeacherSurfaceId;
  readonly classification:
    AiTeacherSurfaceClassification;
  readonly existingBehaviorSeams:
    readonly string[];
  readonly learnerAttemptFirstApplies:
    boolean;
  readonly legitimateToolOutputGenerationPreserved:
    boolean;
  readonly authoritativeCefrContextOnly:
    boolean;
}

export interface AiTeacherCoreContractV1 {
  readonly learnerFirst: true;
  readonly minimumUsefulSupport: true;
  readonly feedbackBeforeLecture: true;
  readonly taskSpecificBehaviorPreserved: true;
  readonly answerBearingHintIsNotAHint: true;
  readonly aiOutputMayBecomeLearnerEvidence: false;
  readonly aiFeedbackMeansMastery: false;
  readonly correctAnswerMeansCefrVerification: false;
  readonly aiEvaluationMayAssignCefr: false;
  readonly aiSupportMayProgressLearner: false;
  readonly automaticStudioLaunchAllowed: false;
  readonly newAiRuntimeRequired: false;
  readonly newPromptEngineRequired: false;
  readonly newEvidenceArchitectureRequired: false;
}

export const AI_TEACHER_CORE_CONTRACT_V1:
  AiTeacherCoreContractV1 = {
    learnerFirst: true,
    minimumUsefulSupport: true,
    feedbackBeforeLecture: true,
    taskSpecificBehaviorPreserved: true,
    answerBearingHintIsNotAHint: true,
    aiOutputMayBecomeLearnerEvidence: false,
    aiFeedbackMeansMastery: false,
    correctAnswerMeansCefrVerification: false,
    aiEvaluationMayAssignCefr: false,
    aiSupportMayProgressLearner: false,
    automaticStudioLaunchAllowed: false,
    newAiRuntimeRequired: false,
    newPromptEngineRequired: false,
    newEvidenceArchitectureRequired: false,
  };

export const AI_TEACHER_SURFACE_BINDINGS:
  readonly AiTeacherSurfaceBinding[] = [
    {
      surfaceId: "grammar-lab",
      classification: "AI_TEACHER",
      existingBehaviorSeams: [
        "TranslationGrammarStudySupport",
        "TranslationGrammarTeacherGuide",
        "TranslationGrammarAiAnalysis",
      ],
      learnerAttemptFirstApplies: true,
      legitimateToolOutputGenerationPreserved:
        false,
      authoritativeCefrContextOnly: true,
    },
    {
      surfaceId: "reading",
      classification: "AI_TEACHER",
      existingBehaviorSeams: [
        "TranslationReadingCoach",
        "TranslationReadingComprehension",
      ],
      learnerAttemptFirstApplies: true,
      legitimateToolOutputGenerationPreserved:
        false,
      authoritativeCefrContextOnly: true,
    },
    {
      surfaceId: "listening",
      classification: "AI_TEACHER",
      existingBehaviorSeams: [
        "TranslationListeningCoach",
        "TranslationListeningDictation",
      ],
      learnerAttemptFirstApplies: true,
      legitimateToolOutputGenerationPreserved:
        false,
      authoritativeCefrContextOnly: true,
    },
    {
      surfaceId: "writing",
      classification: "AI_TEACHER",
      existingBehaviorSeams: [
        "TranslationWritingCoach",
        "TranslationWritingRevision",
        "TranslationWritingSession",
      ],
      learnerAttemptFirstApplies: true,
      legitimateToolOutputGenerationPreserved:
        false,
      authoritativeCefrContextOnly: true,
    },
    {
      surfaceId: "speaking",
      classification: "AI_TEACHER",
      existingBehaviorSeams: [
        "TranslationSpeakingCoach",
        "TranslationSpeakingSession",
      ],
      learnerAttemptFirstApplies: true,
      legitimateToolOutputGenerationPreserved:
        false,
      authoritativeCefrContextOnly: true,
    },
    {
      surfaceId: "dialogue",
      classification: "AI_TEACHER",
      existingBehaviorSeams: [
        "TranslationDialogueScenario",
        "TranslationDialogueTurn",
        "TranslationDialogueReview",
        "TranslationDialogueSession",
      ],
      learnerAttemptFirstApplies: true,
      legitimateToolOutputGenerationPreserved:
        false,
      authoritativeCefrContextOnly: true,
    },
    {
      surfaceId: "cefr-learning-path",
      classification:
        "MIXED_WITH_AUTHORITATIVE_CONTEXT",
      existingBehaviorSeams: [
        "CefrProductionRuntimePlatform",
        "CefrSessionBoundEvidenceAdapterService",
        "CefrSessionBoundDelayedRetrievalEvidenceService",
      ],
      learnerAttemptFirstApplies: true,
      legitimateToolOutputGenerationPreserved:
        false,
      authoritativeCefrContextOnly: true,
    },
    {
      surfaceId: "translation-studio",
      classification: "AI_PRODUCTIVITY_TOOL",
      existingBehaviorSeams: [
        "BrowserTranslationAssistanceAiService",
      ],
      learnerAttemptFirstApplies: false,
      legitimateToolOutputGenerationPreserved:
        true,
      authoritativeCefrContextOnly: false,
    },
    {
      surfaceId: "text-workshop",
      classification: "AI_PRODUCTIVITY_TOOL",
      existingBehaviorSeams: [
        "BrowserContextualMeaningAiService",
      ],
      learnerAttemptFirstApplies: false,
      legitimateToolOutputGenerationPreserved:
        true,
      authoritativeCefrContextOnly: false,
    },
  ] as const;

export function getAiTeacherSurfaceBinding(
  surfaceId: AiTeacherSurfaceId,
): AiTeacherSurfaceBinding {
  const binding =
    AI_TEACHER_SURFACE_BINDINGS.find(
      item => item.surfaceId === surfaceId,
    );

  if (!binding) {
    throw new Error(
      `Unknown AI Teacher surface: ${surfaceId}`,
    );
  }

  return binding;
}

export interface AiTeacherInteractionContext {
  readonly surfaceId: AiTeacherSurfaceId;
  readonly learnerAttemptAvailable: boolean;
  readonly authoritativeCefrContextAvailable:
    boolean;
}

export interface AiTeacherInteractionPolicy {
  readonly classification:
    AiTeacherSurfaceClassification;
  readonly learnerMustRemainProducer: boolean;
  readonly answerBearingOutputBeforeAttemptAllowed:
    boolean;
  readonly feedbackAfterAttemptAllowed: boolean;
  readonly graduatedSupportPreferred: boolean;
  readonly legitimateProductivityOutputAllowed:
    boolean;
  readonly mayUseCefrForSupportAdaptation: boolean;
  readonly mayAssignCefr: false;
  readonly mayWriteLearnerEvidenceFromAiOutput:
    false;
  readonly mayClaimMasteryFromFeedback: false;
  readonly mayProgressLearnerAutomatically: false;
}

export function resolveAiTeacherInteractionPolicy(
  input: AiTeacherInteractionContext,
): AiTeacherInteractionPolicy {
  const binding =
    getAiTeacherSurfaceBinding(
      input.surfaceId,
    );

  const productivityTool =
    binding.classification ===
    "AI_PRODUCTIVITY_TOOL";

  return {
    classification: binding.classification,
    learnerMustRemainProducer:
      !productivityTool,
    answerBearingOutputBeforeAttemptAllowed:
      productivityTool,
    feedbackAfterAttemptAllowed:
      !productivityTool &&
      input.learnerAttemptAvailable,
    graduatedSupportPreferred:
      !productivityTool,
    legitimateProductivityOutputAllowed:
      productivityTool &&
      binding
        .legitimateToolOutputGenerationPreserved,
    mayUseCefrForSupportAdaptation:
      !productivityTool &&
      binding.authoritativeCefrContextOnly &&
      input.authoritativeCefrContextAvailable,
    mayAssignCefr: false,
    mayWriteLearnerEvidenceFromAiOutput:
      false,
    mayClaimMasteryFromFeedback: false,
    mayProgressLearnerAutomatically: false,
  };
}
