﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

$viewPath =
    Join-Path $app "src\application\learning\CefrA1DescribePersistedEvidenceView.ts"

$catalogTestPath =
    Join-Path $app "src\core\learning\CefrA1DescribeExecutableTaskCatalog.test.ts"

foreach ($path in @(
    $viewPath,
    $catalogTestPath
)) {
    if (-not (Test-Path $path)) {
        throw "Rev2 required file missing: $path"
    }
}

$utf8 =
    New-Object System.Text.UTF8Encoding($false)

$backupRoot =
    Join-Path $root (
        "_sprint_backups\Sprint1515-1523-Rev2-" +
        (Get-Date -Format "yyyyMMdd-HHmmss")
    )

New-Item `
    -ItemType Directory `
    -Path $backupRoot `
    -Force |
    Out-Null

Copy-Item `
    -LiteralPath $viewPath `
    -Destination (
        Join-Path $backupRoot "CefrA1DescribePersistedEvidenceView.ts"
    ) `
    -Force

Copy-Item `
    -LiteralPath $catalogTestPath `
    -Destination (
        Join-Path $backupRoot "CefrA1DescribeExecutableTaskCatalog.test.ts"
    ) `
    -Force

# ------------------------------------------------------------
# 1. Widen the lookup Map key from the six literal IDs to string.
#    Runtime behavior is unchanged; only TypeScript lookup typing changes.
# ------------------------------------------------------------

$view =
    [System.IO.File]::ReadAllText(
        $viewPath,
        $utf8
    )

$oldMap =
@'
const taskByEvidenceDefinitionId =
  new Map(
    LAF_A1_DESCRIBE_ALL_EXECUTABLE_TASKS.map(
'@

$newMap =
@'
const taskByEvidenceDefinitionId =
  new Map<
    string,
    (typeof LAF_A1_DESCRIBE_ALL_EXECUTABLE_TASKS)[number]
  >(
    LAF_A1_DESCRIBE_ALL_EXECUTABLE_TASKS.map(
'@

if ($view.Contains($oldMap)) {
    $view =
        $view.Replace(
            $oldMap,
            $newMap
        )

    [System.IO.File]::WriteAllText(
        $viewPath,
        $view,
        $utf8
    )

    Write-Host "Rev2 Map key typing widened to string."
}
elseif (
    $view.Contains(
        'new Map<'
    ) -and
    $view.Contains(
        '(typeof LAF_A1_DESCRIBE_ALL_EXECUTABLE_TASKS)[number]'
    )
) {
    Write-Host "Rev2 Map typing repair already present."
}
else {
    throw "Rev2 persisted-evidence Map marker not found."
}

# ------------------------------------------------------------
# 2. Replace impossible literal-union equality test with a widened
#    string collection containment assertion.
# ------------------------------------------------------------

$test =
    [System.IO.File]::ReadAllText(
        $catalogTestPath,
        $utf8
    )

$oldAssertion =
@'
      expect(
        LAF_A1_DESCRIBE_ALL_EXECUTABLE_TASKS.some(
          task =>
            task.evidenceDefinitionId ===
            LAF_A1_DESCRIBE_DELAYED_RETRIEVAL_EVIDENCE_ID,
        ),
      ).toBe(false);
'@

$newAssertion =
@'
      const executableEvidenceDefinitionIds:
        readonly string[] =
          LAF_A1_DESCRIBE_ALL_EXECUTABLE_TASKS.map(
            task =>
              task.evidenceDefinitionId,
          );

      expect(
        executableEvidenceDefinitionIds,
      ).not.toContain(
        LAF_A1_DESCRIBE_DELAYED_RETRIEVAL_EVIDENCE_ID,
      );
'@

if ($test.Contains($oldAssertion)) {
    $test =
        $test.Replace(
            $oldAssertion,
            $newAssertion
        )

    [System.IO.File]::WriteAllText(
        $catalogTestPath,
        $test,
        $utf8
    )

    Write-Host "Rev2 delayed-retrieval test comparison repaired."
}
elseif (
    $test.Contains(
        "executableEvidenceDefinitionIds"
    ) -and
    $test.Contains(
        ").not.toContain("
    )
) {
    Write-Host "Rev2 delayed-retrieval test repair already present."
}
else {
    throw "Rev2 delayed-retrieval stale assertion marker not found."
}

# Structural safety checks.
$viewCheck =
    [System.IO.File]::ReadAllText(
        $viewPath,
        $utf8
    )

if (
    -not $viewCheck.Contains(
        "(typeof LAF_A1_DESCRIBE_ALL_EXECUTABLE_TASKS)[number]"
    )
) {
    throw "Rev2 widened Map value marker missing."
}

$testCheck =
    [System.IO.File]::ReadAllText(
        $catalogTestPath,
        $utf8
    )

if (
    -not $testCheck.Contains(
        "executableEvidenceDefinitionIds"
    )
) {
    throw "Rev2 widened delayed-retrieval assertion marker missing."
}

$vitestPath =
    Join-Path $app "node_modules\.bin\vitest.cmd"

if (-not (Test-Path $vitestPath)) {
    throw "Local Vitest command missing: $vitestPath"
}

$npmPath =
    (Get-Command "npm.cmd" -ErrorAction Stop).Source

if (-not $npmPath) {
    throw "npm.cmd path could not be resolved."
}

Set-Location $app

Write-Host ""
Write-Host "============================================================"
Write-Host "REV2 TARGET TYPE/SAFETY TESTS"
Write-Host "============================================================"

& $vitestPath run `
    "src/application/learning/CefrA1DescribePersistedEvidenceView.test.ts" `
    "src/core/learning/CefrA1DescribeExecutableTaskCatalog.test.ts"

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1515-1523 Rev2 target tests failed."
}

Write-Host ""
Write-Host "SPRINT-1515-1523 REV2 TARGET TESTS PASSED"

Write-Host ""
Write-Host "============================================================"
Write-Host "PRODUCTION BUILD"
Write-Host "============================================================"

& $npmPath run build

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1515-1523 Rev2 production build failed."
}

Write-Host ""
Write-Host "SPRINT-1515-1523 REV2 VERIFICATION COMPLETE"
Write-Host "Backup: $backupRoot"
