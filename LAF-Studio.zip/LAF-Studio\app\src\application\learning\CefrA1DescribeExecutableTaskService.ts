import type {
  LafLearningLanguageCode,
} from "../../core/language/LafLanguageProfile";
import {
  getLafA1DescribeExecutableTask,
  isLafA1DescribeSelectionTask,
  type CefrA1DescribeSelectionTaskId,
} from "../../core/learning/CefrA1DescribeExecutableTaskDefinition";
import {
  getLafA1DescribeLanguageContentPack,
  type CefrA1DescribeRealizedPhrase,
} from "../../core/learning/CefrA1DescribeLanguageContentRegistry";
import type {
  CefrAuthoritativeLanguageRuntimeEvidenceResult,
} from "./CefrAuthoritativeLanguageRuntimeEvidenceService";
import {
  CefrProductionRuntimePlatform,
} from "./CefrProductionRuntimePlatform";

export interface CefrA1DescribeSelectionTaskView {
  readonly taskId:
    CefrA1DescribeSelectionTaskId;
  readonly lessonId: string;
  readonly languageCode:
    LafLearningLanguageCode;
  readonly instructionKey: string;
  readonly taskKind: "controlled-selection";
  readonly options:
    readonly CefrA1DescribeRealizedPhrase[];
  readonly evidenceDefinitionId: string;
  readonly correctAnswerExposed: false;
  readonly evidenceWritten: false;
  readonly targetLanguageExplicit: true;
  readonly targetLanguageInferred: false;
}

export interface CefrA1DescribeSelectionInput {
  readonly taskId:
    CefrA1DescribeSelectionTaskId;
  readonly languageCode:
    LafLearningLanguageCode;
  readonly selectedPhraseId: string;
  readonly eventId: string;
  readonly occurredAt: Date;
  readonly userActionConfirmed: boolean;
}

export interface CefrA1DescribeSelectionResult {
  readonly taskId:
    CefrA1DescribeSelectionTaskId;
  readonly evidenceDefinitionId: string;
  readonly languageCode:
    LafLearningLanguageCode;
  readonly correct: boolean;
  readonly evidenceWritten: boolean;
  readonly runtime:
    CefrAuthoritativeLanguageRuntimeEvidenceResult | null;
  readonly masteryAssigned: false;
  readonly competencySuccessAssigned: false;
  readonly cefrLevelAssigned: false;
  readonly progressionPerformed: false;
  readonly narrativeSequencingPerformed:
    false;
}

export interface CefrA1DescribePersonDescriptionView {
  readonly taskId:
    "a1-describe-task-person-description";
  readonly lessonId:
    "a1-describe-familiar-person";
  readonly evidenceDefinitionId:
    "a1-describe-evidence-person-description";
  readonly languageCode:
    LafLearningLanguageCode;
  readonly options:
    readonly CefrA1DescribeRealizedPhrase[];
  readonly requiredStepCount: 3;
  readonly correctSequenceExposed: false;
  readonly evidenceWritten: false;
  readonly narrativeSequencingRequired:
    false;
}

export interface CefrA1DescribePersonDescriptionInput {
  readonly languageCode:
    LafLearningLanguageCode;
  readonly selectedPhraseIds:
    readonly string[];
  readonly eventId: string;
  readonly occurredAt: Date;
  readonly userActionConfirmed: boolean;
}

export interface CefrA1DescribePersonDescriptionResult {
  readonly correctPrefix: boolean;
  readonly complete: boolean;
  readonly evidenceWritten: boolean;
  readonly runtime:
    CefrAuthoritativeLanguageRuntimeEvidenceResult | null;
  readonly masteryAssigned: false;
  readonly competencySuccessAssigned: false;
  readonly cefrLevelAssigned: false;
  readonly progressionPerformed: false;
  readonly narrativeSequencingPerformed:
    false;
}

export class CefrA1DescribeExecutableTaskService {
  private readonly platform:
    CefrProductionRuntimePlatform;

  constructor(
    platform: CefrProductionRuntimePlatform,
  ) {
    this.platform = platform;
  }

  getSelectionTaskView(
    taskId:
      CefrA1DescribeSelectionTaskId,
    languageCode:
      LafLearningLanguageCode,
  ): CefrA1DescribeSelectionTaskView {
    const task =
      getLafA1DescribeExecutableTask(taskId);

    if (!isLafA1DescribeSelectionTask(task)) {
      throw new Error(
        `A1 DESCRIBE task is not a selection task: ${taskId}`,
      );
    }

    const pack =
      getLafA1DescribeLanguageContentPack(
        languageCode,
      );
    const lesson =
      pack.lessons.find(
        item =>
          item.lessonId === task.lessonId,
      );

    if (!lesson) {
      throw new Error(
        `A1 DESCRIBE task language content missing: ${taskId}/${languageCode}`,
      );
    }

    if (
      !lesson.phrases.some(
        phrase =>
          phrase.phraseId ===
          task.correctPhraseId,
      )
    ) {
      throw new Error(
        `A1 DESCRIBE task answer phrase missing: ${taskId}/${languageCode}`,
      );
    }

    return {
      taskId,
      lessonId: task.lessonId,
      languageCode,
      instructionKey:
        task.instructionKey,
      taskKind: task.taskKind,
      options: lesson.phrases,
      evidenceDefinitionId:
        task.evidenceDefinitionId,
      correctAnswerExposed: false,
      evidenceWritten: false,
      targetLanguageExplicit: true,
      targetLanguageInferred: false,
    };
  }

  executeSelection(
    input:
      CefrA1DescribeSelectionInput,
  ): CefrA1DescribeSelectionResult {
    if (!input.userActionConfirmed) {
      throw new Error(
        "Explicit user action confirmation is required for A1 DESCRIBE evidence.",
      );
    }

    const task =
      getLafA1DescribeExecutableTask(
        input.taskId,
      );

    if (!isLafA1DescribeSelectionTask(task)) {
      throw new Error(
        `A1 DESCRIBE task is not a selection task: ${input.taskId}`,
      );
    }

    const view =
      this.getSelectionTaskView(
        input.taskId,
        input.languageCode,
      );

    if (
      !view.options.some(
        phrase =>
          phrase.phraseId ===
          input.selectedPhraseId,
      )
    ) {
      throw new Error(
        `Unknown A1 DESCRIBE task option: ${input.selectedPhraseId}`,
      );
    }

    const correct =
      input.selectedPhraseId ===
      task.correctPhraseId;

    if (!correct) {
      return {
        taskId: input.taskId,
        evidenceDefinitionId:
          task.evidenceDefinitionId,
        languageCode:
          input.languageCode,
        correct: false,
        evidenceWritten: false,
        runtime: null,
        masteryAssigned: false,
        competencySuccessAssigned: false,
        cefrLevelAssigned: false,
        progressionPerformed: false,
        narrativeSequencingPerformed:
          false,
      };
    }

    const runtime =
      this.platform.recordUserEvidence(
        "a1-describe",
        {
          evidenceDefinitionId:
            task.evidenceDefinitionId,
          eventId: input.eventId,
          occurredAt: input.occurredAt,
          languageCode:
            input.languageCode,
          userActionConfirmed: true,
        },
      );

    return {
      taskId: input.taskId,
      evidenceDefinitionId:
        task.evidenceDefinitionId,
      languageCode:
        input.languageCode,
      correct: true,
      evidenceWritten: true,
      runtime,
      masteryAssigned: false,
      competencySuccessAssigned: false,
      cefrLevelAssigned: false,
      progressionPerformed: false,
      narrativeSequencingPerformed:
        false,
    };
  }

  getPersonDescriptionView(
    languageCode:
      LafLearningLanguageCode,
  ): CefrA1DescribePersonDescriptionView {
    const task =
      getLafA1DescribeExecutableTask(
        "a1-describe-task-person-description",
      );

    if (
      task.taskKind !==
      "controlled-description-sequence"
    ) {
      throw new Error(
        "A1 DESCRIBE person-description task definition is invalid.",
      );
    }

    const pack =
      getLafA1DescribeLanguageContentPack(
        languageCode,
      );
    const lesson =
      pack.lessons.find(
        item =>
          item.lessonId === task.lessonId,
      );

    if (!lesson) {
      throw new Error(
        `A1 DESCRIBE person-description language content missing: ${languageCode}`,
      );
    }

    for (
      const phraseId of
      task.expectedPhraseIds
    ) {
      if (
        !lesson.phrases.some(
          phrase =>
            phrase.phraseId === phraseId,
        )
      ) {
        throw new Error(
          `A1 DESCRIBE person-description phrase missing: ${phraseId}/${languageCode}`,
        );
      }
    }

    return {
      taskId: task.taskId,
      lessonId: task.lessonId,
      evidenceDefinitionId:
        task.evidenceDefinitionId,
      languageCode,
      options: lesson.phrases,
      requiredStepCount: 3,
      correctSequenceExposed: false,
      evidenceWritten: false,
      narrativeSequencingRequired:
        false,
    };
  }

  executePersonDescription(
    input:
      CefrA1DescribePersonDescriptionInput,
  ): CefrA1DescribePersonDescriptionResult {
    if (!input.userActionConfirmed) {
      throw new Error(
        "Explicit user action confirmation is required for A1 DESCRIBE evidence.",
      );
    }

    const task =
      getLafA1DescribeExecutableTask(
        "a1-describe-task-person-description",
      );

    if (
      task.taskKind !==
      "controlled-description-sequence"
    ) {
      throw new Error(
        "A1 DESCRIBE person-description task definition is invalid.",
      );
    }

    const view =
      this.getPersonDescriptionView(
        input.languageCode,
      );

    if (
      input.selectedPhraseIds.length >
      task.expectedPhraseIds.length
    ) {
      throw new Error(
        "A1 DESCRIBE controlled description exceeds the approved step count.",
      );
    }

    for (
      const phraseId of
      input.selectedPhraseIds
    ) {
      if (
        !view.options.some(
          option =>
            option.phraseId === phraseId,
        )
      ) {
        throw new Error(
          `Unknown A1 DESCRIBE person-description option: ${phraseId}`,
        );
      }
    }

    const correctPrefix =
      input.selectedPhraseIds.every(
        (phraseId, index) =>
          phraseId ===
          task.expectedPhraseIds[index],
      );

    const complete =
      correctPrefix &&
      input.selectedPhraseIds.length ===
        task.expectedPhraseIds.length;

    if (!complete) {
      return {
        correctPrefix,
        complete: false,
        evidenceWritten: false,
        runtime: null,
        masteryAssigned: false,
        competencySuccessAssigned: false,
        cefrLevelAssigned: false,
        progressionPerformed: false,
        narrativeSequencingPerformed:
          false,
      };
    }

    const runtime =
      this.platform.recordUserEvidence(
        "a1-describe",
        {
          evidenceDefinitionId:
            task.evidenceDefinitionId,
          eventId: input.eventId,
          occurredAt: input.occurredAt,
          languageCode:
            input.languageCode,
          userActionConfirmed: true,
        },
      );

    return {
      correctPrefix: true,
      complete: true,
      evidenceWritten: true,
      runtime,
      masteryAssigned: false,
      competencySuccessAssigned: false,
      cefrLevelAssigned: false,
      progressionPerformed: false,
      narrativeSequencingPerformed:
        false,
    };
  }
}
