import type {
  LafLearningLanguageCode,
} from "../../core/language/LafLanguageProfile";
import type {
  CefrLanguageEvidenceProvenanceAuthority,
} from "../../core/learning/CefrLanguageEvidenceProvenanceAuthority";
import {
  CefrAuthoritativeRuntimeEvidenceService,
  type CefrAuthoritativeRuntimeEvidenceResult,
} from "./CefrAuthoritativeRuntimeEvidenceService";
import type {
  CefrGuidanceRuntimeProfileRepository,
} from "./CefrGuidanceRuntimeProfileRepository";
import {
  CefrLanguageEvidenceProvenanceCoordinator,
  type CefrLanguageEvidenceProvenanceWriteResult,
} from "./CefrLanguageEvidenceProvenanceCoordinator";

export interface CefrAuthoritativeLanguageRuntimeEvidenceEventInput {
  readonly evidenceDefinitionId: string;
  readonly eventId: string;
  readonly occurredAt: Date;
  readonly languageCode:
    LafLearningLanguageCode;
  readonly userActionConfirmed: true;
}

export interface CefrAuthoritativeLanguageRuntimeEvidenceResult {
  readonly runtime:
    CefrAuthoritativeRuntimeEvidenceResult;
  readonly provenance:
    CefrLanguageEvidenceProvenanceWriteResult;
  readonly evidenceId: string;
  readonly languageCode:
    LafLearningLanguageCode;
  readonly evidencePersisted: true;
  readonly targetLanguageExplicit: true;
  readonly targetLanguageInferred: false;
  readonly masteryAssigned: false;
  readonly competencySuccessAssigned: false;
  readonly cefrLevelAssigned: false;
  readonly progressionPerformed: false;
}

export class CefrAuthoritativeLanguageRuntimeEvidenceService {
  private readonly runtimeService:
    CefrAuthoritativeRuntimeEvidenceService;

  private readonly provenanceCoordinator:
    CefrLanguageEvidenceProvenanceCoordinator;

  constructor(
    repository:
      CefrGuidanceRuntimeProfileRepository,
    provenanceAuthority:
      CefrLanguageEvidenceProvenanceAuthority,
    provenanceCoordinator?:
      CefrLanguageEvidenceProvenanceCoordinator,
    runtimeService?:
      CefrAuthoritativeRuntimeEvidenceService,
  ) {
    this.runtimeService =
      runtimeService ??
      new CefrAuthoritativeRuntimeEvidenceService(
        repository,
      );

    this.provenanceCoordinator =
      provenanceCoordinator ??
      new CefrLanguageEvidenceProvenanceCoordinator(
        provenanceAuthority,
      );
  }

  recordUserEvidence(
    input:
      CefrAuthoritativeLanguageRuntimeEvidenceEventInput,
  ): CefrAuthoritativeLanguageRuntimeEvidenceResult {
    const runtime =
      this.runtimeService.recordUserEvidence({
        evidenceDefinitionId:
          input.evidenceDefinitionId,
        eventId: input.eventId,
        occurredAt:
          input.occurredAt,
        userActionConfirmed:
          input.userActionConfirmed,
      });

    const provenance =
      this.provenanceCoordinator
        .recordPersistedEvidenceLanguage({
          evidenceId:
            runtime.runtimeEvidenceId,
          languageCode:
            input.languageCode,
          observedAt:
            input.occurredAt,
        });

    return {
      runtime,
      provenance,
      evidenceId:
        runtime.runtimeEvidenceId,
      languageCode:
        input.languageCode,
      evidencePersisted: true,
      targetLanguageExplicit: true,
      targetLanguageInferred: false,
      masteryAssigned: false,
      competencySuccessAssigned: false,
      cefrLevelAssigned: false,
      progressionPerformed: false,
    };
  }
}
