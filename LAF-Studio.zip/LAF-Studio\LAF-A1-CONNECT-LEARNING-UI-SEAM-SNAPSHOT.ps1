﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app  = Join-Path $root "app"
$src  = Join-Path $app "src"
$out  = Join-Path $root "LAF_A1_CONNECT_LEARNING_UI_SEAM_SNAPSHOT.txt"

if (-not (Test-Path $src)) {
    throw "Source root not found: $src"
}

$report = New-Object System.Collections.Generic.List[string]

function Add-Line {
    param([string]$Text)
    if ($null -eq $Text) { $Text = "" }
    [void]$report.Add($Text)
}

function Add-Section {
    param([string]$Title)
    Add-Line ""
    Add-Line ("=" * 96)
    Add-Line $Title
    Add-Line ("=" * 96)
}

function Add-File {
    param(
        [string]$AbsolutePath,
        [int]$Limit = 1800
    )

    Add-Section ("FILE: " + $AbsolutePath)

    if (-not (Test-Path $AbsolutePath)) {
        Add-Line "(file not found)"
        return
    }

    $lines = @(Get-Content -Path $AbsolutePath)
    $count = [Math]::Min($lines.Count, $Limit)

    for ($i = 0; $i -lt $count; $i++) {
        Add-Line ("{0,4}: {1}" -f ($i + 1), $lines[$i])
    }

    if ($lines.Count -gt $Limit) {
        Add-Line ("... truncated; total lines: " + $lines.Count)
    }
}

Add-Line "LAF STUDIO - A1 CONNECT LEARNING UI SEAM SNAPSHOT"
Add-Line ("Generated: " + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
Add-Line "READ ONLY - no project source files are modified."
Add-Line "Stable technical baseline expected: Sprint 1304."

$learningPage = Join-Path $src "ui\pages\LearningStudioPage.tsx"
$appFile = Join-Path $src "App.tsx"

Add-File $appFile 300
Add-File $learningPage 2200

Add-Section "RELATED LEARNING STUDIO PAGE FILES"

$candidates = @(
    Get-ChildItem -Path $src -Recurse -File |
    Where-Object {
        $_.Name -like "LearningStudioPage*" -or
        $_.Name -like "*LearningStudio*.css" -or
        $_.Name -like "*LearningStudio*.test.ts" -or
        $_.Name -like "*LearningStudio*.test.tsx"
    } |
    Sort-Object FullName
)

if ($candidates.Count -eq 0) {
    Add-Line "(no related candidates)"
} else {
    foreach ($file in $candidates) {
        Add-Line $file.FullName
    }
}

foreach ($file in $candidates) {
    if ($file.FullName -ne $learningPage) {
        Add-File $file.FullName 1600
    }
}

Add-Section "LEARNING STUDIO PAGE IMPORTS"

if (Test-Path $learningPage) {
    $importHits = @(
        Select-String `
            -Path $learningPage `
            -Pattern '^\s*import\s' `
            -ErrorAction SilentlyContinue
    )

    foreach ($hit in $importHits) {
        Add-Line (
            "{0}: {1}" -f
            $hit.LineNumber,
            $hit.Line.Trim()
        )
    }
}

Add-Section "REAL REFERENCES TO LearningStudioPage"

$sourceFiles = @(
    Get-ChildItem -Path $src -Recurse -File |
    Where-Object {
        $_.Extension -eq ".ts" -or
        $_.Extension -eq ".tsx"
    }
)

$references = New-Object System.Collections.Generic.List[object]

foreach ($file in $sourceFiles) {
    $hits = @(
        Select-String `
            -Path $file.FullName `
            -SimpleMatch `
            -Pattern "LearningStudioPage" `
            -ErrorAction SilentlyContinue
    )

    foreach ($hit in $hits) {
        [void]$references.Add(
            [PSCustomObject]@{
                File = $hit.Path
                Line = $hit.LineNumber
                Text = $hit.Line.Trim()
            }
        )
    }
}

foreach ($ref in (
    $references |
    Sort-Object File, Line |
    Select-Object -First 200
)) {
    Add-Line (
        "{0}:{1}: {2}" -f
        $ref.File,
        $ref.Line,
        $ref.Text
    )
}

Add-Section "A1 CONNECT RUNTIME UI BINDING INPUT"

Add-Line "Need exact insertion point inside LearningStudioPage.tsx."
Add-Line "Need existing page layout sections and current state/hooks."
Add-Line "Need exact CSS ownership for LearningStudioPage."
Add-Line "Need existing nearby tests and preferred test style."
Add-Line "Do not invent a new route."
Add-Line "Existing authorized route remains /learning."
Add-Line "Do not auto-record evidence from render/mount."
Add-Line "Evidence must require a real user action."
Add-Line "No mastery assignment."
Add-Line "No competency success."
Add-Line "No CEFR-level assignment."
Add-Line "No automatic progression."
Add-Line "No automatic Studio launch."

$report | Set-Content -Path $out -Encoding UTF8

Write-Host ""
Write-Host "LAF A1 CONNECT LEARNING UI SEAM SNAPSHOT COMPLETE"
Write-Host "Report:"
Write-Host $out
