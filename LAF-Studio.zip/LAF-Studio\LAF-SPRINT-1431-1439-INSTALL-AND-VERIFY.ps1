﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

$required = @(
    "src\core\learning\CefrRuntimeSliceRegistry.ts",
    "src\core\learning\CefrRuntimeSliceRegistrySafety.ts",
    "src\core\learning\CefrProductionRuntimeSliceRegistry.ts",
    "src\application\learning\CefrRuntimeAssemblyFactory.ts",
    "src\application\learning\CefrProductionRuntimePlatform.ts",
    "src\core\learning\CefrProductionRuntimePlatformSafety.ts"
)

foreach ($relative in $required) {
    if (-not (Test-Path (Join-Path $app $relative))) {
        throw "Sprint 1431-1439 source missing: $relative"
    }
}

Write-Host "SPRINT-1431-1439 SOURCE CHECK PASSED"
Set-Location $app

Write-Host "CHECKPOINT 1/3 — Sprint 1431-1433 target tests"
& npx vitest run @(
    "src/core/learning/CefrRuntimeSliceRegistry.test.ts",
    "src/core/learning/CefrRuntimeSliceRegistrySafety.test.ts",
    "src/core/learning/CefrRuntimeSliceDefinition.test.ts",
    "src/core/learning/CefrA1ConnectRuntimeSliceDefinition.test.ts"
)
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1431-1433 target checkpoint failed."
}
Write-Host "SPRINT-1431-1433 TARGET CHECKPOINT PASSED"

Write-Host "CHECKPOINT 2/3 — Sprint 1434-1436 target tests"
& npx vitest run @(
    "src/core/learning/CefrProductionRuntimeSliceRegistry.test.ts",
    "src/application/learning/CefrRuntimeAssemblyFactory.test.ts",
    "src/application/learning/CefrRuntimeSliceAssembly.test.ts",
    "src/core/learning/CefrRuntimeSliceAssemblySafety.test.ts"
)
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1434-1436 target checkpoint failed."
}
Write-Host "SPRINT-1434-1436 TARGET CHECKPOINT PASSED"

Write-Host "CHECKPOINT 3/3 — Sprint 1437-1439 target tests"
& npx vitest run @(
    "src/application/learning/CefrProductionRuntimePlatform.test.ts",
    "src/core/learning/CefrProductionRuntimePlatformSafety.test.ts",
    "src/application/learning/CefrAuthoritativeLanguageRuntimeEvidenceService.test.ts",
    "src/application/learning/CefrLanguageScopedEvidenceReadService.test.ts"
)
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1437-1439 target checkpoint failed."
}
Write-Host "SPRINT-1437-1439 TARGET CHECKPOINT PASSED"

Write-Host "FINAL BLOCK REGRESSION — one full run only"
& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1431-1439 final full regression failed."
}

Write-Host "FINAL PRODUCTION BUILD"
& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1431-1439 production build failed."
}

Write-Host "SPRINT-1431-1439 VERIFICATION COMPLETE"
