import type {
  TranslationLanguageCode,
} from "../../core/translation/TranslationDraft";
import type {
  TranslationDialogueScenarioId,
} from "./TranslationDialogueScenario";
import type {
  TranslationDialogueHistoryTurn,
} from "./TranslationDialogueTurn";

export interface TranslationDialogueReviewRequest {
  language: TranslationLanguageCode;
  scenarioId: TranslationDialogueScenarioId;
  scenarioTitle: string;
  goal: string;
  history: TranslationDialogueHistoryTurn[];
}

export interface TranslationDialogueReview {
  strength: string;
  nextFocus: string;
  reusablePhraseHint: string;
  nextPractice: string;
}

export type TranslationDialogueReviewIssueCode =
  | "invalid-response"
  | "missing-strength"
  | "missing-next-focus"
  | "missing-phrase-hint"
  | "missing-next-practice";

export interface TranslationDialogueReviewIssue {
  code: TranslationDialogueReviewIssueCode;
}

export type TranslationDialogueReviewPreparation =
  | {
      status: "ready";
      review: TranslationDialogueReview;
      issues: [];
    }
  | {
      status: "blocked";
      review?: never;
      issues: TranslationDialogueReviewIssue[];
    };

const isRecord = (
  value: unknown,
): value is Record<string, unknown> =>
  typeof value === "object" &&
  value !== null &&
  !Array.isArray(value);

export function prepareTranslationDialogueReview(
  value: unknown,
): TranslationDialogueReviewPreparation {
  if (!isRecord(value)) {
    return {
      status: "blocked",
      issues: [
        {
          code: "invalid-response",
        },
      ],
    };
  }

  const strength =
    typeof value.strength === "string"
      ? value.strength.trim()
      : "";
  const nextFocus =
    typeof value.nextFocus === "string"
      ? value.nextFocus.trim()
      : "";
  const reusablePhraseHint =
    typeof value.reusablePhraseHint ===
    "string"
      ? value.reusablePhraseHint.trim()
      : "";
  const nextPractice =
    typeof value.nextPractice ===
    "string"
      ? value.nextPractice.trim()
      : "";

  const issues: TranslationDialogueReviewIssue[] =
    [];

  if (!strength) {
    issues.push({
      code: "missing-strength",
    });
  }

  if (!nextFocus) {
    issues.push({
      code: "missing-next-focus",
    });
  }

  if (!reusablePhraseHint) {
    issues.push({
      code: "missing-phrase-hint",
    });
  }

  if (!nextPractice) {
    issues.push({
      code: "missing-next-practice",
    });
  }

  if (issues.length > 0) {
    return {
      status: "blocked",
      issues,
    };
  }

  return {
    status: "ready",
    issues: [],
    review: {
      strength,
      nextFocus,
      reusablePhraseHint,
      nextPractice,
    },
  };
}
