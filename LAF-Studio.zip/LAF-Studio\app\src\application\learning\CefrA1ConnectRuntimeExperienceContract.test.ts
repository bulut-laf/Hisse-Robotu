import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrA1ConnectRuntimeExperienceContract,
} from "./CefrA1ConnectRuntimeExperienceContract";

describe(
  "CefrA1ConnectRuntimeExperienceContract",
  () => {
    it("requires explicit user evidence capture and keeps practice interaction and activation non-automatic", () => {
      expect(
        createCefrA1ConnectRuntimeExperienceContract(),
      ).toEqual({
        practiceDefinitionCount: 4,
        meaningfulInteractionCount: 3,
        evidenceDefinitionCount: 7,
        activationCount: 1,
        explicitEvidenceDefinitionRequired: true,
        explicitUserActionRequired: true,
        automaticPracticeEvidenceCapture: false,
        automaticInteractionEvidenceCapture:
          false,
        automaticActivationEvidenceCapture:
          false,
        persistedRealEvidenceRequired: true,
        capabilityObservationTarget:
          "social-exchange",
        observationalOnly: true,
        masteryAssignmentAllowed: false,
        competencySuccessAssignmentAllowed:
          false,
        cefrLevelAssignmentAllowed: false,
        automaticProgressionAllowed: false,
        automaticStudioLaunchAllowed: false,
      });
    });
  },
);
