import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrPersonalLanguageProfileState,
  type CefrPersonalLanguageProfileState,
} from "../../core/learning/CefrPersonalLanguageProfileState";
import {
  createCefrA1ConnectGreetingComprehensionTask,
} from "../../core/learning/CefrA1ConnectGreetingComprehensionTask";
import type {
  CefrGuidanceRuntimeProfileRepository,
} from "./CefrGuidanceRuntimeProfileRepository";
import {
  CefrA1ConnectGreetingTaskCompletionService,
} from "./CefrA1ConnectGreetingTaskCompletionService";
import {
  CefrA1ConnectLanguageEvidenceProvenanceRepository,
} from "./CefrA1ConnectLanguageEvidenceProvenanceRepository";

class MemoryStorage {
  private readonly values =
    new Map<string, string>();

  getItem(key: string): string | null {
    return this.values.get(key) ?? null;
  }

  setItem(
    key: string,
    value: string,
  ): void {
    this.values.set(key, value);
  }

  removeItem(key: string): void {
    this.values.delete(key);
  }
}

class MemoryProfileRepository
  implements CefrGuidanceRuntimeProfileRepository {
  private state:
    CefrPersonalLanguageProfileState =
      createCefrPersonalLanguageProfileState(
        [],
        [],
      );

  load(): CefrPersonalLanguageProfileState {
    return this.state;
  }

  save(
    state: CefrPersonalLanguageProfileState,
  ): void {
    this.state = state;
  }

  hasPersistedProfile(): boolean {
    return true;
  }

  clear(): void {
    this.state =
      createCefrPersonalLanguageProfileState(
        [],
        [],
      );
  }
}

describe(
  "A1 CONNECT language evidence provenance integration",
  () => {
    it("writes target-language provenance only after real correct evidence persistence", () => {
      const profileRepository =
        new MemoryProfileRepository();
      const provenanceRepository =
        new CefrA1ConnectLanguageEvidenceProvenanceRepository(
          new MemoryStorage(),
        );
      const service =
        new CefrA1ConnectGreetingTaskCompletionService(
          profileRepository,
          provenanceRepository,
        );
      const task =
        createCefrA1ConnectGreetingComprehensionTask(
          "it",
        );

      const result =
        service.submit({
          languageCode: "it",
          submittedAnswer:
            task.correctAnswer,
          eventId: "provenance-001",
          occurredAt:
            new Date(
              "2026-08-11T19:00:00.000Z",
            ),
          userActionConfirmed: true,
        });

      expect(result.evidencePersisted).toBe(
        true,
      );

      expect(
        provenanceRepository.findByEvidenceId(
          result.evidence?.runtimeEvidenceId ??
            "",
        ),
      ).toMatchObject({
        languageCode: "it",
        authoritativeLanguageProvenance:
          true,
        masteryClaimed: false,
        cefrLevelClaimed: false,
      });
    });

    it("does not write provenance for an incorrect submission", () => {
      const provenanceRepository =
        new CefrA1ConnectLanguageEvidenceProvenanceRepository(
          new MemoryStorage(),
        );
      const service =
        new CefrA1ConnectGreetingTaskCompletionService(
          new MemoryProfileRepository(),
          provenanceRepository,
        );

      service.submit({
        languageCode: "de",
        submittedAnswer: "wrong",
        eventId: "provenance-wrong",
        occurredAt:
          new Date(
            "2026-08-11T19:01:00.000Z",
          ),
        userActionConfirmed: true,
      });

      expect(
        provenanceRepository.loadAll(),
      ).toHaveLength(0);
    });
  },
);
