$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 906-908 Target Tests: Custodial Assimilation ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialAssimilation.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialAssimilationCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialAssimilationAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 906-908 target tests failed." }

Write-Host "=== Sprint 909-911 Target Tests: Custodial Internalization ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialInternalization.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialInternalizationCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialInternalizationAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 909-911 target tests failed." }

Write-Host "=== Sprint 912-914 Target Tests: Custodial Embedding ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialEmbedding.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialEmbeddingCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialEmbeddingAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 912-914 target tests failed." }

Write-Host "=== Combined Sprint 906-914 New Tests ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialAssimilation.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialAssimilationCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialAssimilationAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialInternalization.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialInternalizationCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialInternalizationAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialEmbedding.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialEmbeddingCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialEmbeddingAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 906-914 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-906-914 VERIFICATION COMPLETE"
