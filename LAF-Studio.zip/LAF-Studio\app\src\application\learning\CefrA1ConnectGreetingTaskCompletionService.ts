import type {
  LafLearningLanguageCode,
} from "../../core/language/LafLanguageProfile";
import {
  createCefrA1ConnectGreetingComprehensionTask,
} from "../../core/learning/CefrA1ConnectGreetingComprehensionTask";
import {
  CefrA1ConnectEvidenceProvenanceCoordinator,
} from "./CefrA1ConnectEvidenceProvenanceCoordinator";
import {
  CefrA1ConnectLanguageEvidenceProvenanceRepository,
} from "./CefrA1ConnectLanguageEvidenceProvenanceRepository";
import type {
  CefrGuidanceRuntimeProfileRepository,
} from "./CefrGuidanceRuntimeProfileRepository";
import {
  CefrA1ConnectRuntimeEvidenceService,
  type CefrA1ConnectRuntimeEvidenceResult,
} from "./CefrA1ConnectRuntimeEvidenceService";
import {
  evaluateCefrA1ConnectGreetingComprehension,
  type CefrA1ConnectTaskEvaluation,
} from "./CefrA1ConnectGreetingComprehensionEvaluation";

export interface CefrA1ConnectGreetingTaskSubmissionInput {
  readonly languageCode:
    LafLearningLanguageCode;
  readonly submittedAnswer: string;
  readonly eventId: string;
  readonly occurredAt: Date;
  readonly userActionConfirmed: true;
}

export interface CefrA1ConnectGreetingTaskSubmissionResult {
  readonly evaluation:
    CefrA1ConnectTaskEvaluation;
  readonly evidence:
    CefrA1ConnectRuntimeEvidenceResult | null;
  readonly evidencePersisted: boolean;
  readonly capabilityObservationWritten:
    boolean;
  readonly masteryAssigned: false;
  readonly competencySuccessAssigned: false;
  readonly cefrLevelAssigned: false;
  readonly progressionPerformed: false;
}

export class CefrA1ConnectGreetingTaskCompletionService {
  private readonly evidenceService:
    CefrA1ConnectRuntimeEvidenceService;

  private readonly provenanceCoordinator:
    CefrA1ConnectEvidenceProvenanceCoordinator;

  constructor(
    repository:
      CefrGuidanceRuntimeProfileRepository,
    provenanceCoordinatorOrRepository:
      | CefrA1ConnectEvidenceProvenanceCoordinator
      | CefrA1ConnectLanguageEvidenceProvenanceRepository =
        new CefrA1ConnectEvidenceProvenanceCoordinator(),
  ) {
    this.evidenceService =
      new CefrA1ConnectRuntimeEvidenceService(
        repository,
      );

    this.provenanceCoordinator =
      "recordPersistedEvidenceLanguage" in
      provenanceCoordinatorOrRepository
        ? provenanceCoordinatorOrRepository
        : new CefrA1ConnectEvidenceProvenanceCoordinator(
            provenanceCoordinatorOrRepository,
          );
  }

  submit(
    input:
      CefrA1ConnectGreetingTaskSubmissionInput,
  ): CefrA1ConnectGreetingTaskSubmissionResult {
    const task =
      createCefrA1ConnectGreetingComprehensionTask(
        input.languageCode,
      );

    const evaluation =
      evaluateCefrA1ConnectGreetingComprehension(
        task,
        input.submittedAnswer,
      );

    if (!evaluation.evidenceEligible) {
      return {
        evaluation,
        evidence: null,
        evidencePersisted: false,
        capabilityObservationWritten: false,
        masteryAssigned: false,
        competencySuccessAssigned: false,
        cefrLevelAssigned: false,
        progressionPerformed: false,
      };
    }

    const evidence =
      this.evidenceService.recordUserEvidence({
        evidenceDefinitionId:
          task.evidenceDefinitionId,
        eventId: input.eventId,
        occurredAt: input.occurredAt,
        userActionConfirmed:
          input.userActionConfirmed,
      });

    this.provenanceCoordinator.recordPersistedEvidenceLanguage({
      evidenceId:
        evidence.runtimeEvidenceId,
      languageCode:
        input.languageCode,
      observedAt:
        input.occurredAt,
    });

    return {
      evaluation,
      evidence,
      evidencePersisted:
        evidence.evidence.evidenceAdded,
      capabilityObservationWritten:
        evidence.capabilityObservationWritten,
      masteryAssigned: false,
      competencySuccessAssigned: false,
      cefrLevelAssigned: false,
      progressionPerformed: false,
    };
  }
}
