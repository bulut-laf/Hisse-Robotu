﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

Write-Host "=== Re-run Idempotent Runtime Profile UI Binding Install ==="
Set-Location $root
node ".\LAF-SPRINT-1209-1214-INSTALL.mjs"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1209-1214 Rev1 install failed." }

Set-Location $app

Write-Host "=== Sprint 1209-1210 Rev1 Target Tests: Persistent Runtime Repository ==="
npx vitest run `
  "src/ui/storage/LocalStorageCefrGuidanceProfileRepository.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1209-1210 Rev1 target tests failed." }

Write-Host "=== Sprint 1211-1212 Target Tests: Runtime Service + UI Profile Source ==="
npx vitest run `
  "src/application/learning/CefrGuidanceRuntimeProfileService.test.ts" `
  "src/core/learning/CefrGuidanceUiProfileSource.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1211-1212 target tests failed." }

Write-Host "=== Sprint 1213-1214 Target Tests: Native Learning Studio Runtime Binding ==="
npx vitest run `
  "src/core/learning/CefrGuidanceLearningStudioEntryIntegration.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1213-1214 target tests failed." }

Write-Host "=== Combined Sprint 1209-1214 Rev1 Tests ==="
npx vitest run `
  "src/ui/storage/LocalStorageCefrGuidanceProfileRepository.test.ts" `
  "src/application/learning/CefrGuidanceRuntimeProfileService.test.ts" `
  "src/core/learning/CefrGuidanceUiProfileSource.test.ts" `
  "src/core/learning/CefrGuidanceLearningStudioEntryIntegration.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1209-1214 Rev1 combined tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-1209-1214 REV1 VERIFICATION COMPLETE"
