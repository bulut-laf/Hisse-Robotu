import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrPersonalLanguageProfileState,
  type CefrPersonalLanguageProfileState,
} from "../../core/learning/CefrPersonalLanguageProfileState";
import {
  createCefrA1ConnectPersonalAnswerTask,
  createCefrA1ConnectPersonalQuestionTask,
  createCefrA1ConnectReciprocalExchangeTask,
} from "../../core/learning/CefrA1ConnectExtendedExecutableTasks";
import type {
  CefrGuidanceRuntimeProfileRepository,
} from "./CefrGuidanceRuntimeProfileRepository";
import {
  CefrA1ConnectExtendedTaskCompletionService,
} from "./CefrA1ConnectExtendedTaskCompletionService";

class MemoryRepository
  implements CefrGuidanceRuntimeProfileRepository {
  private state:
    CefrPersonalLanguageProfileState =
      createCefrPersonalLanguageProfileState(
        [],
        [],
      );

  private persisted = false;

  load(): CefrPersonalLanguageProfileState {
    return this.state;
  }

  save(
    state: CefrPersonalLanguageProfileState,
  ): void {
    this.state = state;
    this.persisted = true;
  }

  hasPersistedProfile(): boolean {
    return this.persisted;
  }

  clear(): void {
    this.state =
      createCefrPersonalLanguageProfileState(
        [],
        [],
      );
    this.persisted = false;
  }
}

describe(
  "CefrA1ConnectExtendedTaskCompletionService",
  () => {
    it("does not persist an incorrect personal-answer submission", () => {
      const repository =
        new MemoryRepository();
      const service =
        new CefrA1ConnectExtendedTaskCompletionService(
          repository,
        );

      const result =
        service.submit({
          taskKind: "personal-answer",
          languageCode: "de",
          submittedAnswer: "wrong",
          eventId: "answer-wrong",
          occurredAt:
            new Date(
              "2026-08-11T17:30:00.000Z",
            ),
          userActionConfirmed: true,
        });

      expect(result.evidencePersisted).toBe(
        false,
      );
      expect(
        repository.hasPersistedProfile(),
      ).toBe(false);
    });

    it("persists each of the three approved evidence definitions after correct submissions", () => {
      const repository =
        new MemoryRepository();
      const service =
        new CefrA1ConnectExtendedTaskCompletionService(
          repository,
        );

      const answerTask =
        createCefrA1ConnectPersonalAnswerTask(
          "de",
        );
      const questionTask =
        createCefrA1ConnectPersonalQuestionTask(
          "it",
        );
      const reciprocalTask =
        createCefrA1ConnectReciprocalExchangeTask(
          "ru",
        );

      const answerResult =
        service.submit({
          taskKind: "personal-answer",
          languageCode: "de",
          submittedAnswer:
            answerTask.correctAnswer,
          eventId: "answer-correct",
          occurredAt:
            new Date(
              "2026-08-11T17:31:00.000Z",
            ),
          userActionConfirmed: true,
        });

      const questionResult =
        service.submit({
          taskKind: "personal-question",
          languageCode: "it",
          submittedAnswer:
            questionTask.correctAnswer,
          eventId: "question-correct",
          occurredAt:
            new Date(
              "2026-08-11T17:32:00.000Z",
            ),
          userActionConfirmed: true,
        });

      const reciprocalResult =
        service.submit({
          taskKind: "reciprocal-exchange",
          languageCode: "ru",
          submittedAnswer:
            reciprocalTask.correctAnswer,
          eventId: "reciprocal-correct",
          occurredAt:
            new Date(
              "2026-08-11T17:33:00.000Z",
            ),
          userActionConfirmed: true,
        });

      expect(answerResult.evidencePersisted).toBe(
        true,
      );
      expect(questionResult.evidencePersisted).toBe(
        true,
      );
      expect(
        reciprocalResult.evidencePersisted,
      ).toBe(true);

      const state = repository.load();

      expect(
        state.profileSnapshot
          .evidenceAggregation.evidence,
      ).toHaveLength(3);

      expect(
        state.capabilityObservationRegistry
          .observations,
      ).toHaveLength(3);

      expect(
        state.capabilityObservationRegistry
          .observations.every(
            item =>
              item.capabilityReference ===
                "social-exchange" &&
              item.observationalOnly === true,
          ),
      ).toBe(true);
    });
  },
);
