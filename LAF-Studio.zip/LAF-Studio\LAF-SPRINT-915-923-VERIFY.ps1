$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 915-917 Target Tests: Custodial Persistence ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialPersistence.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialPersistenceCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialPersistenceAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 915-917 target tests failed." }

Write-Host "=== Sprint 918-920 Target Tests: Custodial Retention ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialRetention.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialRetentionCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialRetentionAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 918-920 target tests failed." }

Write-Host "=== Sprint 921-923 Target Tests: Custodial Durability ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialDurability.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialDurabilityCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialDurabilityAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 921-923 target tests failed." }

Write-Host "=== Combined Sprint 915-923 New Tests ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialPersistence.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialPersistenceCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialPersistenceAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialRetention.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialRetentionCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialRetentionAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialDurability.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialDurabilityCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialDurabilityAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 915-923 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-915-923 VERIFICATION COMPLETE"
