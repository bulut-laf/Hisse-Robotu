$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

Set-Location $app

Write-Host "=== Sprint 672-674 Target Tests ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidencePersistence.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidencePersistenceCoordination.test.ts" `
  "src/core/learning/CefrEvidencePersistenceAwareCefrIntelligencePlatform.test.ts"

if ($LASTEXITCODE -ne 0) {
  throw "Sprint 672-674 target tests failed."
}

Write-Host "=== Full Regression ==="
npm run test

if ($LASTEXITCODE -ne 0) {
  throw "Full regression failed."
}

Write-Host "=== Production Build ==="
npm run build

if ($LASTEXITCODE -ne 0) {
  throw "Production build failed."
}

Write-Host "SPRINT-672-674 VERIFICATION COMPLETE"
