import fs from "node:fs";
import path from "node:path";

const root = "D:\\Projects\\LAF-Studio";
const file = path.join(
  root,
  "app",
  "src",
  "ui",
  "pages",
  "GuidanceCenterPage.tsx",
);

if (!fs.existsSync(file)) {
  throw new Error(`GuidanceCenterPage not found: ${file}`);
}

let source = fs.readFileSync(file, "utf8");

const oldImport =
  'import { createCefrGuidanceUiProfileSource } from "../../core/learning/CefrGuidanceUiProfileSource";';
const newImport =
  'import { useCefrGuidanceRuntimeProfileSource } from "../hooks/useCefrGuidanceRuntimeProfileSource";';

if (source.includes(oldImport)) {
  source = source.replace(oldImport, newImport);
} else if (!source.includes(newImport)) {
  throw new Error(
    "GuidanceCenterPage runtime-profile import marker not found.",
  );
}

const oldSourceBlock = `  const source = useMemo(
    () => createCefrGuidanceUiProfileSource(),
    [],
  );`;
const newSourceLine =
  "  const source = useCefrGuidanceRuntimeProfileSource();";

if (source.includes(oldSourceBlock)) {
  source = source.replace(oldSourceBlock, newSourceLine);
} else if (!source.includes(newSourceLine)) {
  throw new Error(
    "GuidanceCenterPage runtime-profile source marker not found.",
  );
}

const importCount = source.split(newImport).length - 1;
const sourceCount = source.split(newSourceLine).length - 1;

if (importCount !== 1 || sourceCount !== 1) {
  throw new Error(
    `Unexpected GuidanceCenter runtime binding counts: import=${importCount}, source=${sourceCount}`,
  );
}

fs.writeFileSync(file, source, "utf8");

console.log("SPRINT-1209-1214 INSTALL COMPLETE");
console.log("GuidanceCenterPage bound to runtime CEFR profile storage.");
