$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 981-983 Target Tests: Approved Guidance Action Planning ==="
npx vitest run `
  "src/core/learning/CefrApprovedGuidanceAction.test.ts" `
  "src/core/learning/CefrGuidanceActionPlan.test.ts" `
  "src/core/learning/CefrGuidanceActionPlanGateway.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 981-983 target tests failed." }

Write-Host "=== Sprint 984-986 Target Tests: Studio Guidance Routing ==="
npx vitest run `
  "src/core/learning/CefrStudioGuidanceRoute.test.ts" `
  "src/core/learning/CefrStudioGuidanceRouteRegistry.test.ts" `
  "src/core/learning/CefrStudioGuidanceRoutingOrchestration.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 984-986 target tests failed." }

Write-Host "=== Sprint 987-989 Target Tests: User-Initiated Guidance Launch ==="
npx vitest run `
  "src/core/learning/CefrGuidanceLaunchRequest.test.ts" `
  "src/core/learning/CefrGuidanceLaunchGate.test.ts" `
  "src/core/learning/CefrUserInitiatedGuidanceLaunch.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 987-989 target tests failed." }

Write-Host "=== Combined Sprint 981-989 New Tests ==="
npx vitest run `
  "src/core/learning/CefrApprovedGuidanceAction.test.ts" `
  "src/core/learning/CefrGuidanceActionPlan.test.ts" `
  "src/core/learning/CefrGuidanceActionPlanGateway.test.ts" `
  "src/core/learning/CefrStudioGuidanceRoute.test.ts" `
  "src/core/learning/CefrStudioGuidanceRouteRegistry.test.ts" `
  "src/core/learning/CefrStudioGuidanceRoutingOrchestration.test.ts" `
  "src/core/learning/CefrGuidanceLaunchRequest.test.ts" `
  "src/core/learning/CefrGuidanceLaunchGate.test.ts" `
  "src/core/learning/CefrUserInitiatedGuidanceLaunch.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 981-989 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-981-989 VERIFICATION COMPLETE"
