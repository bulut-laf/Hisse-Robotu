import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrPersonalLanguageProfileState,
  type CefrPersonalLanguageProfileState,
} from "../../core/learning/CefrPersonalLanguageProfileState";
import type {
  CefrGuidanceRuntimeProfileRepository,
} from "./CefrGuidanceRuntimeProfileRepository";
import {
  createCefrA1ConnectEvidenceCoverageReadModel,
} from "./CefrA1ConnectEvidenceCoverageReadModel";

class MemoryRepository
  implements CefrGuidanceRuntimeProfileRepository {
  private state:
    CefrPersonalLanguageProfileState =
      createCefrPersonalLanguageProfileState(
        [],
        [],
      );

  load(): CefrPersonalLanguageProfileState {
    return this.state;
  }

  save(
    state: CefrPersonalLanguageProfileState,
  ): void {
    this.state = state;
  }

  hasPersistedProfile(): boolean {
    return true;
  }

  clear(): void {
    this.state =
      createCefrPersonalLanguageProfileState(
        [],
        [],
      );
  }
}

describe(
  "CefrA1ConnectEvidenceCoverageReadModel",
  () => {
    it("remains explicitly non-mastery", () => {
      expect(
        createCefrA1ConnectEvidenceCoverageReadModel(
          new MemoryRepository(),
        ),
      ).toMatchObject({
        evidenceCoverageIsMastery: false,
        delayedRetrievalEvidenceWritten:
          false,
      });
    });
  },
);
