import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createTranslationLearningLanguageWorkspace,
  createTranslationTargetLanguageSelectorView,
  getTranslationLearningLanguageOptions,
} from "./TranslationLearningLanguageWorkspace";

describe(
  "TranslationLearningLanguageWorkspace — seven-language core",
  () => {
    it("shows all seven main language options", () => {
      expect(
        getTranslationLearningLanguageOptions().map(
          option => option.code,
        ),
      ).toEqual([
        "hu",
        "tr",
        "de",
        "it",
        "en",
        "es",
        "ru",
      ]);
    });

    it("provides Spanish and Russian samples", () => {
      expect(
        createTranslationLearningLanguageWorkspace(
          "es",
        ).sampleText,
      ).toContain("español");

      expect(
        createTranslationLearningLanguageWorkspace(
          "ru",
        ).sampleText,
      ).toContain("русский");
    });

    it("marks Spanish input assistance available", () => {
      expect(
        createTranslationLearningLanguageWorkspace(
          "es",
        ).hasInputAssist,
      ).toBe(true);
    });

    it("marks Russian Cyrillic keyboard available", () => {
      expect(
        createTranslationLearningLanguageWorkspace(
          "ru",
        ).hasInputAssist,
      ).toBe(true);
    });

    it("does not invent English input assistance", () => {
      expect(
        createTranslationLearningLanguageWorkspace(
          "en",
        ).hasInputAssist,
      ).toBe(false);
    });


    it("creates a compact Turkish target-language selector view", () => {
      const view =
        createTranslationTargetLanguageSelectorView("hu");

      expect(view.caption).toBe("Hedef Dil");
      expect(view.currentLabel).toBe("Macarca • Magyar");
    });

    it("keeps all seven target languages available in the top selector", () => {
      const view =
        createTranslationTargetLanguageSelectorView("de");

      expect(view.options.map(option => option.code)).toEqual([
        "hu",
        "tr",
        "de",
        "it",
        "en",
        "es",
        "ru",
      ]);
    });

    it("preserves native language names instead of translating learning content", () => {
      const view =
        createTranslationTargetLanguageSelectorView("de");

      expect(view.currentLabel).toBe("Almanca • Deutsch");
      expect(
        view.options.find(option => option.code === "ru")?.displayLabel,
      ).toBe("Rusça • Русский");
    });
  },
);
