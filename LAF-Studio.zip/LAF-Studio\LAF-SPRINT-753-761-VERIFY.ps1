$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 753-755 Target Tests: Custodial Reliability ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialReliability.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialReliabilityCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialReliabilityAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 753-755 target tests failed." }

Write-Host "=== Sprint 756-758 Target Tests: Custodial Continuity ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialContinuity.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialContinuityCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialContinuityAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 756-758 target tests failed." }

Write-Host "=== Sprint 759-761 Target Tests: Custodial Trustworthiness ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialTrustworthiness.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialTrustworthinessCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialTrustworthinessAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 759-761 target tests failed." }

Write-Host "=== Combined Sprint 753-761 New Tests ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialReliability.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialReliabilityCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialReliabilityAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialContinuity.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialContinuityCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialContinuityAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialTrustworthiness.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialTrustworthinessCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialTrustworthinessAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 753-761 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-753-761 VERIFICATION COMPLETE"
