import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrPersonalLanguageProfileState,
  type CefrPersonalLanguageProfileState,
} from "../../core/learning/CefrPersonalLanguageProfileState";
import {
  createCefrA1ConnectGreetingComprehensionTask,
} from "../../core/learning/CefrA1ConnectGreetingComprehensionTask";
import type {
  CefrGuidanceRuntimeProfileRepository,
} from "./CefrGuidanceRuntimeProfileRepository";
import {
  CefrA1ConnectGreetingTaskCompletionService,
} from "./CefrA1ConnectGreetingTaskCompletionService";

class MemoryRepository
  implements CefrGuidanceRuntimeProfileRepository {
  private state:
    CefrPersonalLanguageProfileState =
      createCefrPersonalLanguageProfileState(
        [],
        [],
      );

  private persisted = false;

  load(): CefrPersonalLanguageProfileState {
    return this.state;
  }

  save(
    state: CefrPersonalLanguageProfileState,
  ): void {
    this.state = state;
    this.persisted = true;
  }

  hasPersistedProfile(): boolean {
    return this.persisted;
  }

  clear(): void {
    this.state =
      createCefrPersonalLanguageProfileState(
        [],
        [],
      );
    this.persisted = false;
  }
}

describe(
  "CefrA1ConnectGreetingTaskCompletionService",
  () => {
    it("does not persist evidence for an incorrect answer", () => {
      const repository =
        new MemoryRepository();
      const service =
        new CefrA1ConnectGreetingTaskCompletionService(
          repository,
        );

      const result =
        service.submit({
          languageCode: "it",
          submittedAnswer:
            "Yanlış cevap",
          eventId: "wrong-001",
          occurredAt:
            new Date(
              "2026-08-11T16:30:00.000Z",
            ),
          userActionConfirmed: true,
        });

      expect(result).toMatchObject({
        evidence: null,
        evidencePersisted: false,
        capabilityObservationWritten: false,
        masteryAssigned: false,
        competencySuccessAssigned: false,
        cefrLevelAssigned: false,
        progressionPerformed: false,
      });
      expect(
        result.evaluation.correct,
      ).toBe(false);
      expect(
        repository.hasPersistedProfile(),
      ).toBe(false);
    });

    it("persists approved evidence and observational social-exchange capability only after a correct submission", () => {
      const repository =
        new MemoryRepository();
      const service =
        new CefrA1ConnectGreetingTaskCompletionService(
          repository,
        );
      const task =
        createCefrA1ConnectGreetingComprehensionTask(
          "it",
        );

      const result =
        service.submit({
          languageCode: "it",
          submittedAnswer:
            task.correctAnswer,
          eventId: "correct-001",
          occurredAt:
            new Date(
              "2026-08-11T16:31:00.000Z",
            ),
          userActionConfirmed: true,
        });

      expect(result).toMatchObject({
        evidencePersisted: true,
        capabilityObservationWritten: true,
        masteryAssigned: false,
        competencySuccessAssigned: false,
        cefrLevelAssigned: false,
        progressionPerformed: false,
      });

      expect(
        repository.load()
          .profileSnapshot
          .evidenceAggregation.evidence,
      ).toHaveLength(1);

      expect(
        repository.load()
          .capabilityObservationRegistry
          .observations,
      ).toEqual([
        {
          capabilityReference:
            "social-exchange",
          evidenceId:
            "a1-connect-runtime-evidence:a1-connect-evidence-greeting-comprehension:correct-001",
          source: "learning-studio",
          observationalOnly: true,
        },
      ]);
    });
  },
);
