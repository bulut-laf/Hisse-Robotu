$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 726-728 Target Tests: Stewardship ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceStewardship.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceStewardshipCoordination.test.ts" `
  "src/core/learning/CefrEvidenceStewardshipAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 726-728 target tests failed." }

Write-Host "=== Sprint 729-731 Target Tests: Safekeeping ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceSafekeeping.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceSafekeepingCoordination.test.ts" `
  "src/core/learning/CefrEvidenceSafekeepingAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 729-731 target tests failed." }

Write-Host "=== Sprint 732-734 Target Tests: Chain of Custody ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceChainOfCustody.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceChainOfCustodyCoordination.test.ts" `
  "src/core/learning/CefrEvidenceChainOfCustodyAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 732-734 target tests failed." }

Write-Host "=== Combined Sprint 726-734 New Tests ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceStewardship.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceStewardshipCoordination.test.ts" `
  "src/core/learning/CefrEvidenceStewardshipAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceSafekeeping.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceSafekeepingCoordination.test.ts" `
  "src/core/learning/CefrEvidenceSafekeepingAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceChainOfCustody.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceChainOfCustodyCoordination.test.ts" `
  "src/core/learning/CefrEvidenceChainOfCustodyAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 726-734 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-726-734 VERIFICATION COMPLETE"
