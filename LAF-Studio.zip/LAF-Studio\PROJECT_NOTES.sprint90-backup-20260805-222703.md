﻿LAF Studio — Project Notes

Bu dosya LAF Studio geliştirme çalışmalarının kalıcı teknik hafızasıdır. Dosya, çalışma sırasında değil; gün sonunda test, build ve tarayıcı doğrulamaları tamamlandıktan sonra topluca güncellenir.

1. Proje bilgileri

Proje adı: LAF Studio

Açılımı: Language Architecture Framework

Proje türü: Yapay zekâ destekli Language Intelligence Platform

Yerel proje yolu: D:\Projects\LAF-Studio

Geliştirme durumu: Aktif

Son güncelleme: 5 Ağustos 2026 — Sprint 89 tamamlandı

Son tamamlanan sprint: Sprint 89 — İnceleme Geçmişi Kayıt Silme

Sıradaki çalışma: Sprint 90 — Bağlamsal Anlam Geçmişi Arama ve Sıralama

2. Projenin amacı

LAF Studio; dil öğrenmeyi, yazılı çeviriyi, sözlü tercümanlığı ve profesyonel dil kullanımını tek bir kişisel dil zekâsında birleştiren, farklı dillere uyarlanabilir yapay zekâ destekli bir Language Intelligence Platform’dur.

Ürün yalnızca hazır içerik veya hazır çeviri sunmaz. Kullanıcının dili anlamasını, üretmesini, gerçek yaşamda kullanmasını ve gerektiğinde profesyonel çeviri veya tercümanlık çalışmalarında güvenilir destek almasını sağlar.

Ana ürün alanları:

Learning Studio

Dil öğrenme, aktif hatırlama, dinleme, konuşma, okuma, yazma, telaffuz ve kişiselleştirilmiş öğrenme.

Translation Studio

Yazılı çeviri, alternatif çeviri önerileri, anlam ve üslup analizi, terminoloji yönetimi, tutarlılık ve kalite kontrolü.

Interpreting Studio

Ardıl ve simultane tercümanlık eğitimi, mesleki senaryolar, not alma, hızlı hatırlama ve performans analizi.

LAF Intelligence Core

Üç stüdyodan gelen kelimeleri, hataları, güçlü ve zayıf alanları ve mesleki terminolojiyi ortak bir kişisel dil profili altında birleştiren sistem.

Temel ürün farklılaştırıcısı:

Bir stüdyoda ortaya çıkan öğrenme ihtiyacı diğer stüdyolara aktarılır. Çeviride zorlanılan ifadeler öğrenme programına, öğrenilen terminoloji çeviri desteğine, tercümanlık hataları ise hedefli alıştırmalara dönüştürülür.

Platformun temel yaklaşımı:

Mikro öğrenme

Aktif hatırlama

Bağlam içinde öğrenme

Doğal dil kullanımı

Kişiselleştirilmiş geri bildirim

Kullanıcı ilerlemesine göre öneri üretme

Profesyonel çeviri ve tercümanlık desteği

AI tarafından desteklenen fakat kullanıcı kontrolünü koruyan çalışma düzeni

3. Çalışma ayrımı

LAF Studio — Design Studio

Bu çalışma alanında yalnızca aşağıdaki konular ele alınır:

Ürün vizyonu

Öğrenme mimarisi

UX/UI kararları

AI öğretmen davranışları

Gamification

Roadmap

Ürün dokümantasyonu

Yeni özellik değerlendirmeleri

Bu alanda kod yazılmaz. Geliştirmeye aktarılacak kararlar Development Brief olarak hazırlanır.

LAF Studio — Development

Bu çalışma alanında onaylanan ürün kararları uygulanır.

Temel kurallar:

Aynı anda yalnızca bir sprint üzerinde çalışılır.

Mevcut katmanlı mimari korunur.

Gereksiz abstraction eklenmez.

Gereksiz özellik eklenmez.

Her sprint çalışan bir özellik teslim eder.

Her sprint sonunda npm run test başarılı olmalıdır.

Her sprint sonunda npm run build başarılı olmalıdır.

Gün içindeki doğrulamalar tamamlandıktan sonra bu dosya çalışma gününün sonunda topluca güncellenmelidir.

4. Ana proje yapısı

LAF-Studio/
├── app/
├── backend/
├── docs/
├── PROJECT_NOTES.md
└── ...

Frontend uygulamasının güncel hedef yapısı:

app/src/
├── application/
├── core/
├── features/
├── pages/
├── shared/
├── styles/
├── ui/
│   ├── audio/
│   ├── hooks/
│   ├── pages/
│   └── storage/
├── App.tsx
└── main.tsx

5. Kullanılan teknolojiler

Frontend

React

TypeScript

Vite

React Router

CSS

Tarayıcı Web Speech API

Tarayıcı MediaRecorder API

Local Storage

Test ve kalite

Vitest

TypeScript compiler

Vite production build

Geliştirme ortamı

Windows

Visual Studio Code

PowerShell

Git

Node.js

npm

6. Mimari

Güncel öğrenme akışı:

React UI
  → useLearningSession
  → LearningApplicationService
  → LearningSessionController
  → TranslationPipeline
  → Evaluation / Recommendation / Repository

Katmanların sorumlulukları:

Core

Öğrenme oturumu kuralları

Etkinlik modelleri

Cevap değerlendirme

Translation pipeline

Öğrenme önerileri

Repository sözleşmeleri ve uygulamaları

Core katmanı React bileşenlerine bağımlı değildir.

Application

UI ile Core arasında kullanım senaryosu sınırı oluşturur.

LearningApplicationService öğrenme oturumu işlemlerini sunar.

ApplicationFactory gerekli bağımlılıkları oluşturur ve bağlar.

UI

Kullanıcı etkileşimini yönetir.

Core nesnelerini doğrudan oluşturmamalıdır.

Öğrenme işlemlerine useLearningSession ve Application Layer üzerindenerişmelidir.

7. Önemli teknik kararlar

Karar 1 — Merkezi composition root

Bağımlılıkların kurulması ApplicationFactory içerisinde yapılır.

Gerekçe: React bileşenlerinin Core sınıflarını doğrudan oluşturmasınıönlemek ve bağımlılık kurulumunu tek noktada toplamak.

Karar 2 — UI için özel hook

React ekranları öğrenme oturumuna useLearningSession üzerinden bağlanır.

Gerekçe: UI state yönetimini Application Layer çağrılarından ayırmak vebileşenleri sade tutmak.

Karar 3 — Katmanlı geçiş

Eski UI parçaları tek seferde silinmez. Yeni Application Layer tabanlı akışçalışır hâle getirildikçe eski bağlantılar kontrollü biçimde değiştirilir.

Gerekçe: Çalışan sistemi bozmadan aşamalı geçiş yapmak.

Karar 4 — Sprint doğrulama standardı

Bir sprint yalnızca aşağıdaki koşullar birlikte sağlandığında tamamlanmış kabuledilir:

Özellik kullanıcı tarafından çalıştırılabilir.

npm run test başarılıdır.

npm run build başarılıdır.

PROJECT_NOTES.md güncellenmiştir.

8. Tamamlanan ana çalışmalar

Temel frontend

Vite + React + TypeScript uygulaması oluşturuldu.

Ana sayfalar ve React Router yapısı oluşturuldu.

MainLayout oluşturuldu.

Ana navigasyon rotaları bağlandı.

Core Engine

Etkinlik modelleri oluşturuldu.

Translation evaluation akışı oluşturuldu.

TranslationChecker oluşturuldu.

TranslationPipeline oluşturuldu.

ActivityEvaluationEngine oluşturuldu.

LearningRecommendationEngine oluşturuldu.

Öğrenme oturumu ve controller akışı oluşturuldu.

Memory session storage oluşturuldu.

Static activity repository oluşturuldu.

Application Layer

LearningApplicationService oluşturuldu.

ApplicationFactory oluşturuldu.

Core bağımlılıkları factory içerisinde bağlandı.

Application Layer testleri oluşturuldu.

React entegrasyonu

useLearningSession hook'u oluşturuldu.

Hook üzerinden oturum başlatma eklendi.

Cevap gönderme eklendi.

Geri bildirim state'i eklendi.

Sonraki etkinliğe geçme eklendi.

Önceki etkinliğe geçme desteği hook'a eklendi.

Önceki doğrulama durumu

Test paketi başarılı çalıştı.

Production build başarılı çalıştı.

Sprint 13 test sonucu: 7 test dosyası ve 44 test başarılı.

Sprint 13 build sonucu: Başarılı — Vite production build 2.82 saniye.

9. Sprint 13 — İlk çalışan LessonPage

Amaç

Application Layer üzerinden çalışan ilk gerçek ders ekranını tamamlamak.

Kabul kriterleri

Etkinlik sorusu ekranda gösterilir.

Kullanıcı cevap yazabilir.

Boş cevap gönderilemez.

Cevap yalnızca bir kez değerlendirilebilir.

Doğru veya yanlış geri bildirimi gösterilir.

Geri bildirimden sonra sonraki etkinliğe geçilebilir.

Son etkinlikten sonra dersin tamamlandığı gösterilir.

Enter tuşu ile cevap gönderilebilir.

Testler başarılıdır.

Production build başarılıdır.

Yapılan değişiklikler

LessonPage.tsx, useLearningSession hook'una bağlandı.

Soru, cevap alanı, gönderme işlemi, geri bildirim ve sonraki etkinlik akışıhazırlandı.

/lessons/:id rotasının eski LessonDetailPage yerine yeni LessonPagebileşenini açması için App.tsx güncellendi.

Tarihsel not: ContinueLessonCard.tsx dosyasının sonuna yanlışlıkla eklenen S karakteri TypeScript build hatasına neden oldu. Karakter kaldırıldı; test, build ve tarayıcı akışı daha sonra başarıyla doğrulandı.

10. Sprint 14–49 — Ana geliştirme özeti

Sprint 14–49 arasında aşağıdaki ana çalışmalar tamamlandı:

Ders oturumları tarayıcı Local Storage üzerinde kalıcı hâle getirildi.

Dersi yeniden başlatma ve mevcut aktiviteyi tekrar deneme akışları tamamlandı.

Çoklu ders desteği ve ders bazlı çeviri etkinlikleri oluşturuldu.

İtalyanca A1 seviyesinde üç ders ve her ders için üç çeviri etkinliği eklendi.

Dersler, Ana Sayfa ve İlerleme ekranları gerçek oturum verilerine bağlandı.

Ders ve genel ilerleme yüzdeleri ayrı ayrı hesaplanır hâle getirildi.

Haftalık çalışma grafiği ve gerçek çalışma serisi eklendi.

Günlük çalışma serisi ve çalışma günü serisi hesaplamaları eklendi.

Çeviri cevaplarında noktalama, büyük-küçük harf ve normalizasyon desteği geliştirildi.

Tarayıcı seslendirme servisi oluşturuldu.

Kelime ve örnek cümle seslendirmeleri eklendi.

Ana ders oturumundan ayrı çalışan dinleme pratiği rotası oluşturuldu:

/lessons/:id/listening

Dinleme pratiği sonuç özeti, doğru cevap sayısı, başarı yüzdesi ve ilk denemede doğru metriği eklendi.

Ders bazında en iyi dinleme sonucu Local Storage üzerinde saklanır hâle getirildi.

Kullanıcının kendi sesini kaydedip tekrar dinleyebilmesi için tarayıcı MediaRecorder desteği eklendi.

11. Sprint 50–57 — Gün sonu geliştirme kaydı

Kayıt dönemi: 24–27 Temmuz 2026

Sprint 50 — Genel dinleme ilerlemesi

İlerleme ekranına Ortalama dinleme başarısı kartı eklendi.

Dinleme çalışması yapılan ders sayısı toplam ders sayısından ayrı gösterildi.

Dinleme başarısı ana ders ilerleme yüzdesine katılmadı.

Genel dinleme özeti saf ve test edilebilir bir servis fonksiyonu olarak oluşturuldu.

Sprint 51 — Ders bazlı dinleme durumu

İlerleme ekranındaki her ders kartına en iyi dinleme puanı eklendi.

Dinleme kaydı olmayan derslerde Henüz yapılmadı bilgisi gösterildi.

Her ders kartına Dinleme Çalış veya Tekrar Dinle bağlantısı eklendi.

Sprint 52 — Ana Sayfada dinlemeye devam

Ana Sayfaya Dinlemeye Devam Et kartı eklendi.

En son tamamlanan dinleme çalışması tarih üzerinden belirlenir hâle getirildi.

Kartta ders adı, en iyi başarı yüzdesi ve son çalışma tarihi gösterildi.

Kart ilgili dersin dinleme pratiği rotasına bağlandı.

Sprint 53 — Kişisel dinleme rekoru

Dinleme sonucu önceki en iyi puanla karşılaştırılır hâle getirildi.

İlk sonuç, yeni kişisel rekor, eşit rekor ve rekor altı sonuç durumları oluşturuldu.

Tamamlanma ekranına kişisel rekor geri bildirimi eklendi.

Sprint 54 — Öğretici sesli geri bildirim

Dinleme cevabından sonra doğru yabancı ifade ve örnek cümle için ayrı seslendirme düğmeleri eklendi.

İlk yanlış cevapta doğru bilginin gizli kalması davranışı korundu.

Doğru cevapta veya ikinci denemeden sonra öğretici geri bildirim ve seslendirme açıldı.

Sprint 55 — Dinleme tekrar sayacı

Her sorunun çözüm sırasında kaç kez dinlendiği oturum içinde sayılır hâle getirildi.

Normal ve yavaş dinleme işlemleri sayaca dâhil edildi.

Geri bildirim alanındaki ifade ve örnek seslendirmeleri sayaç dışında bırakıldı.

Tamamlanma ekranına Toplam dinleme metriği eklendi.

Eski dinleme sonuçları için geriye uyumluluk korundu; listenCount bulunmayan kayıtlar sıfır kabul edildi.

Sprint 56 — Soru bazlı dinleme özeti

Dinleme çalışması tamamlanma ekranına soru bazlı dinleme özeti eklendi.

Her ifade için kaç kez dinleme yapıldığı ayrı ayrı gösterilir hâle getirildi.

Toplam dinleme metriği ve eski dinleme kayıtlarıyla geriye uyumluluk korundu.

Sprint 57 — Dinleme tekrar önerisi

Dinleme sonuçları kullanılarak öğrenciye ifade bazlı tekrar önerisi üretilir hâle getirildi.

Tamamlanma ekranına Tekrar Önerisi kartı eklendi.

Öneride tekrar edilmesi yararlı olan ifade ve yapılan dinleme sayısı gösterildi.

Soru bazlı özet, toplam dinleme sayısı ve tekrar önerisi aynı tamamlanma ekranında birlikte doğrulandı.

Sprint 58 — Tamamlanma ekranında ifadeyi dinleme

Dinleme pratiği tamamlanma ekranındaki Tekrar Önerisi kartına “İfadeyi Dinle” düğmesi eklendi.

Düğme, önerilen yabancı ifadeyi mevcut tarayıcı seslendirme servisiyle seslendirir hâle getirildi.

Tamamlanma ekranındaki seslendirme toplam dinleme sayacına dâhil edilmedi.

Mevcut Local Storage yapısı, dinleme sayaçları ve katmanlı mimari değiştirilmedi.

Sprint 59 — Translation Studio ilk çalışan çalışma alanı

Translation Studio için /translation rotası ve navigasyon bağlantısı eklendi.

Macarca ↔ Türkçe dil yönü ve aynı kaynak-hedef dil seçimini engelleyen seçim davranışı oluşturuldu.

Genel, hukuk, sağlık, ekonomi, akademik ve kurumsal uzmanlık alanları eklendi.

“Ben Çevireceğim” ve “Çeviri Yardımı” çalışma biçimleri oluşturuldu.

Kaynak metin ve çeviri taslağı alanları, karakter sayaçları ve çalışma alanı durum göstergesi eklendi.

Mobil uyumlu Translation Studio arayüzü teslim edildi.

Sprint 60 — Translation Studio taslak kaydı

Translation Studio için aktif taslak veri modeli oluşturuldu.

Dil yönü, uzmanlık alanı, çalışma biçimi, kaynak metin ve çeviri taslağı Local Storage üzerinde otomatik kaydedilir hâle getirildi.

Sayfa yeniden açıldığında veya yenilendiğinde kayıtlı taslağın geri yüklenmesi sağlandı.

Bozuk veya mevcut modelle uyumsuz kayıtların uygulamayı etkilemeden yok sayılması sağlandı.

Taslağın son kaydedilme saati çalışma alanında görünür hâle getirildi.

Storage adaptörü için boş kayıt, kayıt/geri yükleme, boş metinler, bozuk veri ve uyumsuz veri senaryolarını kapsayan 5 test eklendi.

Sprint 61 — Translation Studio taslak yönetimi

Translation Studio başlığına “Yeni Çalışma” düğmesi eklendi.

Kaynak metin veya çeviri taslağı doluyken yeni çalışma başlatılmadan önce kullanıcı onayı alınır hâle getirildi.

Kullanıcı işlemi iptal ettiğinde mevcut taslağın ve ayarların korunması sağlandı.

Kullanıcı işlemi onayladığında kaynak metin, çeviri taslağı ve kayıtlı Local Storage verisi temizlenir hâle getirildi.

Yeni çalışmanın Macarca → Türkçe, Genel ve “Ben Çevireceğim” varsayılan ayarlarıyla başlaması sağlandı.

Storage adaptörüne yalnızca aktif çeviri taslağı anahtarını kaldıran clear işlemi ve bu davranışı doğrulayan test eklendi.

Sprint 62 — Kaynak metni çalışma bölümlerine ayırma

Kaynak metni cümle sonu işaretleri ve satır sınırlarına göre çalışma bölümlerine ayıran saf Core fonksiyonu eklendi.

Boş parçaların elenmesi, bölüm sırasının korunması ve her bölümün karakter sayısının hesaplanması sağlandı.

Translation Studio çalışma alanına “Kaynak metin bölümleri” görünümü eklendi.

Her bölümün sıra numarası, metni ve karakter sayısı kullanıcıya gösterilir hâle getirildi.

Kaynak metin boşaltıldığında bölüm görünümünün otomatik olarak kaldırılması sağlandı.

Boş metin, tek cümle, farklı noktalama işaretleri, satır sınırları ve boşluk normalizasyonunu kapsayan 5 Core testi eklendi.

Sprint 63 — Bölüm seçimi ve odaklı çeviri

Kaynak metin bölüm kartları tıklanabilir hâle getirildi.

İlk bölümün çalışma başladığında otomatik olarak seçilmesi sağlandı.

Seçilen bölüm kartı görsel olarak vurgulanır hâle getirildi.

Çalışma alanına seçilen kaynak metni gösteren “Odaklanan bölüm” alanı eklendi.

Odaklanan bölümün sıra numarası ve toplam bölüm sayısı birlikte gösterilir hâle getirildi.

Kaynak metin değiştiğinde artık bulunmayan bir seçimin güvenli biçimde ilk geçerli bölüme dönmesi sağlandı.

Sprint 64 — Bölüm bazlı çeviri taslakları

Her kaynak metin bölümü için ayrı çeviri taslağı oluşturulabilir hâle getirildi.

Sağdaki çeviri alanı yalnızca seçili kaynak bölümün taslağını düzenler hâle getirildi.

Bölümler arasında geçiş yapıldığında daha önce yazılan taslakların korunması sağlandı.

Bölüm kartlarına “Taslak hazır” ve “Taslak bekliyor” durumları eklendi.

Tamamlanan bölüm taslağı sayısı “1 / 3 çevrildi” biçiminde gösterilir hâle getirildi.

Bölüm bazlı taslaklar mevcut otomatik Local Storage kaydına dâhil edildi.

Eski tek parça çeviri taslaklarının ilk bölüme aktarılması ve eski kayıtların geriye uyumlu açılması sağlandı.

Eski kayıt ve geçersiz bölüm taslağı senaryolarını kapsayan 2 yeni storage testi eklendi.

Sprint 65 — Birleştirilmiş çeviri önizlemesi

Bölüm taslaklarını kaynak bölüm sırasına göre birleştiren saf Core servisi eklendi.

Translation Studio çalışma alanına “Tam çeviri önizlemesi” bölümü eklendi.

Tamamlanan bölüm taslakları iki satır arayla tek bir çeviri metninde birleştirilir hâle getirildi.

Eksik çalışma durumunda bekleyen bölüm sayısının gösterilmesi sağlandı.

Bütün bölümler tamamlandığında “Tüm bölümler hazır” durumu eklendi.

Artık kaynak metinde bulunmayan eski bölüm taslaklarının önizlemeye dâhil edilmemesi sağlandı.

Boş çalışma, kaynak sırası, boş taslak, tamamlanma ve eski taslak senaryolarını kapsayan 5 Core testi eklendi.

Sprint 66 — Tam çeviriyi panoya kopyalama

Tam veya kısmi çeviri önizlemesini tarayıcı panosuna kopyalayan UI katmanı servisi eklendi.

“Tam çeviri önizlemesi” başlığına “Çeviriyi Kopyala” düğmesi eklendi.

Kopyalama devam ederken, başarıyla tamamlandığında ve başarısız olduğunda kullanıcıya ayrı durum geri bildirimleri gösterilir hâle getirildi.

Boş çeviri önizlemesinde kopyalama düğmesinin pasif kalması sağlandı.

Pano erişiminin bulunmaması, boş metin ve tarayıcı izin hataları güvenli biçimde ele alındı.

Pano servisi için başarılı kopyalama, boş metin, kullanılamayan pano ve yazma hatası senaryolarını kapsayan 4 test eklendi.

İlk teslim paketindeki fazladan app klasörü düzeltildi; Sprint 66 Rev2 paketi proje köküne göre src klasöründen başlayacak biçimde hazırlandı.

Sprint 67 — Çeviri çalışmasını UTF-8 metin dosyası olarak indirme

Tarayıcıya özgü dosya üretimi ve indirme işlemleri için UI katmanında BrowserTextDownloadService eklendi.

“Tam çeviri önizlemesi” alanına “Çalışmayı İndir” düğmesi eklendi.

İndirilen UTF-8 metin dosyasına LAF Studio başlığı, dil yönü, uzmanlık alanı ve çalışma biçimi bilgileri eklendi.

Kaynak metin “KAYNAK METİN”, tamamlanan çeviri ise “ÇEVİRİ” başlığı altında aynı dosyada birlikte sunulur hâle getirildi.

Türkçe ve Macarca karakterlerin, bölüm sırasının ve satır aralıklarının korunması sağlandı.

İndirme başarı ve hata durumları kullanıcıya ayrı geri bildirimlerle gösterilir hâle getirildi.

İlk sürümde yalnızca hedef çevirinin indirilmesi tarayıcı doğrulamasında tespit edildi; Sprint 67 Rev1 ile iki dilli çalışma belgesi biçimine geçirildi.

İndirme servisi için UTF-8 içerik, boş metin, desteklenmeyen tarayıcı ve indirme hatası sonrası kaynak temizliği senaryolarını kapsayan 4 test eklendi.

12. Güncel doğrulama durumu

Tarihsel kayıt (28 Temmuz 2026): Son tamamlanan sprint Sprint 67

Doğrulama tarihi: 28 Temmuz 2026

Sprint 67 doğrulama saati: 01:02

Test sonucu: 20 test dosyası ve 173 test başarılı.

Production build: Başarılı.

Vite build: 97 modül dönüştürüldü.

Son build çıktısı:

CSS: 39.09 kB — gzip 7.12 kB

JavaScript: 321.05 kB — gzip 94.67 kB

Sprint 67 Rev1 son build süresi: 750 ms

Tarayıcı doğrulaması: Olumlu.

Sprint 67 için tarayıcıda doğrulanan özellikler:

“Çalışmayı İndir” düğmesinin “Tam çeviri önizlemesi” alanında görünmesi

UTF-8 metin dosyasının tarayıcı üzerinden indirilmesi

Kaynak metin ve çevirinin aynı dosyada ayrı başlıklarla bulunması

Türkçe ve Macarca karakterlerin korunması

Başarılı indirme sonrasında kullanıcı geri bildiriminin görünmesi

13. Güncel teknik kararlar

Dinleme pratiği ana LearningSession oturumundan ayrı tutulur.

Dinleme metrikleri ana ders tamamlanma yüzdesini değiştirmez.

Tarayıcıya özgü seslendirme, kayıt ve Local Storage uygulamaları UI katmanında tutulur.

Dinleme hesaplamaları features/lessons servisleri içerisinde saf fonksiyonlarla yapılır.

Ses kaydı geçici tarayıcı URL'si kullanır; sunucuya veya kalıcı depoya ses dosyası gönderilmez.

Ders ve dinleme kayıtları ders kimliğine göre ayrı Local Storage anahtarlarında tutulur.

Kod teslimleri klasör yapısını koruyan LAF-Studio-Sprint-XX.zip değişiklik paketleriyle yapılır.

Bir sprint yalnızca test, build ve tarayıcı doğrulaması olumlu olduğunda tamamlanır.

Her tamamlanan ve doğrulanan sprintten sonra PROJECT_NOTES.md dosyasına kısa bir kontrol noktası eklenir.

Çalışma gününün sonunda kısa kontrol noktaları tarih, saat ve toplam çalışma bilgileriyle topluca düzenlenir.

14. Devam eden işler

Aktif ve yarım kalmış bir sprint bulunmuyor.

Sprint 67 tamamen doğrulandı ve kapatıldı.

Translation Studio’nun ilk çalışma alanı, taslak sürekliliği, yeni çalışma akışı, kaynak metin bölümleme, odaklı bölüm seçimi, bölüm bazlı taslaklar, tam çeviri önizlemesi, panoya kopyalama ve iki dilli metin dosyası indirme akışı çalışır durumdadır.

15. Bir sonraki adımlar

Ana ürün mimarisi Learning Studio, Translation Studio, Interpreting Studio ve LAF Intelligence Core olarak onaylandı.

Translation Studio V1 kapsamı ve temel kullanıcı akışı onaylandı.

Translation Studio Development Brief hazırlandı ve onaylandı:

TRANSLATION_STUDIO_V1_DEVELOPMENT_BRIEF.md

Sprint 67 hedefi tamamen teslim edildi.

Sprint 68 hedefi, “Ben Çevireceğim” modunda kaynak metin ve kullanıcı çevirisinden doğrulanabilir bir değerlendirme isteği oluşturabilmektir.

Sprint 68’de sahte AI değerlendirme sonucu üretilmeyecek; değerlendirme isteği modeli, hazırlık doğrulaması ve kullanıcı akışı kurulacaktır.

Sprint 1–58 arasında tamamlanan çalışmalar Learning Studio temel prototipi; Sprint 59–67 ise Translation Studio’nun ilk çalışan temeli, taslak sürekliliği, yeni çalışma akışı, kaynak metin bölümleme, odaklı bölüm seçimi, bölüm bazlı taslaklar, birleşik önizleme, panoya kopyalama ve iki dilli dosya indirme olarak kabul edilir.

Geliştirme sırasında mevcut katmanlı mimari, Local Storage uyumluluğu ve ana ders ilerleme hesapları korunacaktır.

16. Çalışma sonu güncelleme şablonu

Her çalışma gününün sonunda aşağıdaki kayıt belgenin güncel durum bölümüne eklenir:

## Çalışma Kaydı — DD.MM.YYYY, SS:DD–SS:DD

- Başlangıç saati:
- Bitiş saati:
- Toplam çalışma süresi:
- Tamamlanan sprintler:
- Amaç:
- Yapılan değişiklikler:
- Değiştirilen dosyalar:
- Alınan kararlar:
- Test sonucu:
- Build sonucu:
- Tarayıcı doğrulaması:
- Çalışan özellikler:
- Açık sorunlar:
- Sonraki adım:

17. Yeni sohbet başlangıç talimatı

Yeni bir LAF Studio — Development sohbetinde aşağıdaki mesaj kullanılmalıdır:

LAF Studio — Development projesine devam ediyoruz.

Önce proje kökündeki PROJECT_NOTES.md dosyasını oku.

Mevcut durumu, mimari kararları, tamamlanan işleri, devam eden sprinti ve bir sonraki adımı bu dosyaya göre belirle.

Mevcut katmanlı mimariyi ve çalışma kurallarını koru.

Aynı anda yalnızca bir sprint üzerinde çalış.

Her sprint sonunda npm run test, npm run build ve tarayıcı doğrulaması yap.

Kod teslimlerini klasör yapısını koruyan ZIP değişiklik paketleriyle hazırla.

Her tamamlanan sprintten sonra PROJECT_NOTES.md dosyasına kısa bir kontrol noktası ekle.

Çalışma gününün sonunda bu kayıtları tarih, saat ve toplam çalışma süresiyle topluca düzenle.

---

## Sprint 85 — Bağlamsal anlam isteği ve manuel sonuç kaydı

Durum: TAMAMLANDI ve TARAYICIDA DOĞRULANDI

Amaç:
Metin ve Kelime Atölyesi içinde seçilen bir kelime için bağlama özel anlam inceleme akışını kurmak; ilgili cümleyi ve dil yönünü belirlemek, yapılandırılmış AI isteği üretmek, sonucu kullanıcı tarafından karşılık + gerekçe + güven düzeyi ile kaydetmek ve kullanıcı onayı olmadan Terminoloji Merkezi'ne otomatik kayıt yapmamak.

Doğrulanan akış:
- Kaynak dili Macarca seçildi.
- Test metni: "Az egészségügy új intézkedéseket vezetett be. Az intézkedéseket sokan vitatják."
- "vitatják" kelimesi seçildi.
- İlgili cümle doğru bulundu: "Az intézkedéseket sokan vitatják."
- Çeviri yönü doğru belirlendi: Macarca → Türkçe.
- Bağlamsal anlam için yapılandırılmış AI isteği oluşturuldu.
- "Panoya Kopyala" işlevi çalıştı.
- Ana karşılık alanına "eleştiriyorlar" yazılabildi.
- Gerekçe alanına "Bu bağlamda alınan önlemlere karşı çıkılması anlatılıyor." yazılabildi.
- Güven düzeyi seçilebildi.
- Sonuç başarıyla kaydedilebildi.
- Sonuç kullanıcı onayı olmadan Terminoloji Merkezi'ne otomatik eklenmedi.

Teknik doğrulama:
- Test dosyası: 42 passed
- Test: 290 passed / 0 failed
- Production build: başarılı
- Vite: 125 modül dönüştürüldü
- Build süresi: 719 ms
- Tarayıcı doğrulaması: OLUMLU

Kararlı taban:
Sprint 85 / 290 passed / 0 failed

Sıradaki sprint:
Sprint 86 — Bağlamsal anlamın sistem tarafından otomatik üretilmesi.

LAF Studio geliştirme çalışma standardı:
- Aynı anda yalnızca tek sprint yürütülür.
- Önce hedef test, ardından tam regresyon çalıştırılır.
- Kararlı taban korunur.
- Teslim mümkün olduğunca tek ZIP + tek PowerShell ile yapılır.
- Parçalı yama yerine mümkün olduğunca tam dosya değişikliği kullanılır.
- Test, build ve tarayıcı doğrulaması tamamlanmadan sonraki sprinte geçilmez.
- Kullanıcı onayı olmadan Terminoloji Merkezi'ne otomatik aktarım yapılmaz.

Not:
Proje kökündeki PROJECT_NOTES.md kaydı Sprint 67'de kalmıştı. Kaynak kod incelemesi ve doğrulama geçmişi Sprint 85'in tamamlandığını gösterdi. Bu kontrol noktası gerçek kararlı geliştirme durumunu yeniden senkronize eder.

---

## Sprint 86 — Bağlamsal anlamın sistem tarafından otomatik üretilmesi

Durum: TAMAMLANDI ve TARAYICIDA DOĞRULANDI

Amaç:
Metin ve Kelime Atölyesi içinde seçilen bir kelime için bağlama özel anlamın yapay zekâ tarafından otomatik üretilmesini sağlamak; Sprint 85'teki manuel inceleme ve kullanıcı onayı güvenlik davranışını korumak.

Uygulanan davranış:
- Seçilen kelime ve bağlam cümlesinden yapılandırılmış AI isteği hazırlanır.
- AI sonucu ana karşılık, bağlam gerekçesi ve güven düzeyi alanlarına otomatik getirilir.
- Kullanıcı AI sonucunu kaydetmeden önce düzenleyebilir.
- Sonuç kullanıcı eylemi olmadan kesinleştirilmez.
- Terminoloji Merkezi'ne otomatik kayıt yapılmaz.
- Terminolojiye aktarım yalnızca açık kullanıcı eylemiyle gerçekleşir.
- API anahtarı tarayıcı tarafına taşınmaz; yerel backend/provider sınırı kullanılır.

Teknik doğrulama:
- Sprint 86 hedef testleri: 3 test dosyası / 18 test başarılı
- Tam regresyon: 44 test dosyası / 299 test başarılı
- Hata: 0
- Production build: başarılı
- Vite: 127 modül dönüştürüldü
- Build süresi: 6.32 sn
- Başlangıç kararlı tabanı: Sprint 85 / 290 passed / 0 failed
- Sprint 85 yedeği: D:\Projects\LAF-Studio\_sprint_backups\Sprint86-20260805-211104

Tarayıcı doğrulaması:
- Kaynak dil: Macarca
- Test metni: "Az egészségügy új intézkedéseket vezetett be. Az intézkedéseket sokan vitatják."
- Seçilen kelime: "vitatják"
- Bağlam cümlesi doğru bulundu: "Az intézkedéseket sokan vitatják."
- AI otomatik sonuç üretti.
- Ana karşılık örneği: "tartışıyorlar"
- Bağlam gerekçesi otomatik üretildi.
- Güven düzeyi otomatik üretildi: Yüksek
- Sonuç kullanıcı tarafından kaydedilebilir durumda doğrulandı.
- Terminoloji Merkezi'ne kendiliğinden eklenmediği doğrulandı.
- Tarayıcı doğrulaması: OLUMLU

Yeni kararlı taban:
Sprint 86 / 299 passed / 0 failed

Çalışma kuralı:
Sprint 86 tamamen kapanmıştır. Yeni sprint, kapsamı belirlenip onaylanmadan başlatılmayacaktır.

---

## Sprint 87 — Bağlamsal Anlam İnceleme Geçmişi

Durum: TAMAMLANDI ve TARAYICIDA DOĞRULANDI

Amaç:
Kaydedilen bağlamsal anlam sonuçlarını kalıcı inceleme geçmişi olarak saklamak; aynı kelime tekrar seçildiğinde önceki incelemeleri göstermek; birebir aynı kaydın çoğalmasını engellemek ve Sprint 86'daki kullanıcı onayı güvenlik davranışını korumak.

Uygulanan davranış:
- "Anlamı İncelemeye Ekle" ile kaydedilen sonuçlar Local Storage üzerinde kalıcı tutulur.
- Aynı kelime yeniden seçildiğinde önceki bağlamsal anlam incelemeleri gösterilir.
- Birebir aynı inceleme sonucu tekrar kaydedildiğinde yeni kopya oluşturulmaz.
- Düzenlenmiş veya farklı sonuçlar ayrı tarihsel kayıt olarak saklanabilir.
- AI otomatik üretim akışı korunur.
- Terminoloji Merkezi'ne otomatik aktarım yapılmaz.
- Terminolojiye aktarım yalnızca açık kullanıcı eylemiyle gerçekleşir.

Teknik doğrulama:
- Tam regresyon: 45 test dosyası / 307 test başarılı
- Hata: 0
- Production build: başarılı
- Vite: 128 modül dönüştürüldü
- Build süresi: 2.85 sn
- Başlangıç kararlı tabanı: Sprint 86 / 299 passed / 0 failed
- Sprint 86 yedeği: D:\Projects\LAF-Studio\_sprint_backups\Sprint87-20260805-214009

Tarayıcı doğrulaması:
- Kaynak dil: Macarca
- Test kelimesi: "vitatják"
- AI sonucu oluşturuldu ve "Anlamı İncelemeye Ekle" ile kaydedildi.
- "İNCELEME GEÇMİŞİ / Kaydedilen bağlamsal anlamlar" bölümü görüntülendi.
- Kayıtta karşılık, bağlam cümlesi, gerekçe, güven düzeyi ve kayıt zamanı görüntülendi.
- Ctrl + F5 sonrasında geçmiş kaydı yeniden göründü.
- Aynı sonuç ikinci kez kaydedildiğinde kayıt sayısı çoğalmadı.
- Terminoloji Merkezi'ne kendiliğinden kayıt yapılmadı.
- Tarayıcı doğrulaması: OLUMLU

Yeni kararlı taban:
Sprint 87 / 307 passed / 0 failed

Çalışma kuralı:
Sprint 87 tamamen kapanmıştır. Yeni sprint kapsamı belirlenmeden ve onaylanmadan sonraki geliştirmeye geçilmeyecektir.

---

## Sprint 88 — İnceleme Geçmişinden Yeniden Kullanım

Durum: TAMAMLANDI ve TARAYICIDA DOĞRULANDI

Amaç:
Bağlamsal anlam inceleme geçmişindeki bir kaydı yeniden düzenleme alanlarına yükleyebilmek; kullanıcının eski karşılık, gerekçe ve güven düzeyini düzenleyip yeniden kaydedebilmesini sağlamak ve Sprint 87 tekrar-kayıt korumasını sürdürmek.

Uygulanan davranış:
- İnceleme geçmişindeki kayıtlara "Düzenlemeye Yükle" eylemi eklendi.
- Geçmiş kaydı ana karşılık, bağlam gerekçesi ve güven düzeyi alanlarına geri yüklenir.
- Kullanıcı yüklenen alanları düzenleyebilir.
- Birebir aynı içerik değiştirilmeden yeniden kaydedildiğinde yeni kopya oluşturulmaz.
- Düzenlenmiş/farklı sonuç ayrı tarihsel kayıt olarak saklanır.
- AI otomatik üretim akışı korunur.
- Terminoloji Merkezi'ne otomatik aktarım yapılmaz.
- Terminolojiye aktarım yalnızca açık kullanıcı eylemiyle gerçekleşir.

Teknik doğrulama:
- Tam regresyon: 45 test dosyası / 309 test başarılı
- Hata: 0
- Production build: başarılı
- Vite: 128 modül dönüştürüldü
- Build süresi: 963 ms
- Başlangıç kararlı tabanı: Sprint 87 / 307 passed / 0 failed
- Sprint 87 yedeği: D:\Projects\LAF-Studio\_sprint_backups\Sprint88-20260805-215158

Tarayıcı doğrulaması:
- Geçmiş kaydındaki "Düzenlemeye Yükle" eylemi çalıştı.
- Ana karşılık yeniden düzenleme alanına geldi.
- Bağlam gerekçesi yeniden düzenleme alanına geldi.
- Güven düzeyi yeniden yüklendi.
- Alanlar kullanıcı tarafından düzenlenebildi.
- Değiştirilmeden yeniden kaydedilen aynı sonuç geçmişte çoğalmadı.
- Düzenlenmiş farklı sonuç ayrı geçmiş kaydı oluşturdu.
- Terminoloji Merkezi'ne otomatik kayıt yapılmadı.
- Tarayıcı doğrulaması: OLUMLU

Yeni kararlı taban:
Sprint 88 / 309 passed / 0 failed

Çalışma kuralı:
Sprint 88 tamamen kapanmıştır. Yeni sprint kapsamı belirlenmeden ve onaylanmadan sonraki geliştirmeye geçilmeyecektir.

---

## Sprint 89 — İnceleme Geçmişi Kayıt Silme

Durum: TAMAMLANDI ve TARAYICIDA DOĞRULANDI

Uygulanan davranış:
- Tek bir bağlamsal anlam geçmiş kaydı "Kaydı Sil" eylemiyle kaldırılabilir.
- Silmeden önce kullanıcı onayı alınır.
- İptal edilirse kayıt korunur.
- Onaylanırsa yalnız seçilen kayıt silinir.
- Ctrl + F5 sonrasında silinen kayıt geri gelmez.
- Diğer geçmiş kayıtları korunur.
- Terminoloji Merkezi etkilenmez.

Teknik doğrulama:
- Başlangıç kararlı tabanı: Sprint 88 / 309 passed / 0 failed
- Sprint 89 hedef testleri başarılı
- Tam regresyon başarılı
- Production build başarılı
- Sprint 89 paketi üç yeni regresyon testi ekledi.
- Kararlı test tabanı: Sprint 89 / 312 passed / 0 failed

Tarayıcı doğrulaması: OLUMLU

Yeni kararlı taban:
Sprint 89 / 312 passed / 0 failed
