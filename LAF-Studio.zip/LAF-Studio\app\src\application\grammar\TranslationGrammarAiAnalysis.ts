import type {
  TranslationLanguageCode,
} from "../../core/translation/TranslationDraft";
import type {
  TranslationGrammarObservationConfidence,
} from "../../ui/grammar/LocalStorageTranslationGrammarObservationStorage";

export interface TranslationGrammarAiRequest {
  sourceLanguage: TranslationLanguageCode;
  focusTerm: string;
  contextSentence: string;
}

export interface TranslationGrammarAiDraft {
  pattern: string;
  functionText: string;
  explanation: string;
  confidence: TranslationGrammarObservationConfidence;
}

export type TranslationGrammarAiDraftIssueCode =
  | "invalid-response"
  | "missing-pattern"
  | "missing-function"
  | "missing-explanation"
  | "invalid-confidence";

export interface TranslationGrammarAiDraftIssue {
  code: TranslationGrammarAiDraftIssueCode;
}

export type TranslationGrammarAiDraftPreparation =
  | {
      status: "ready";
      draft: TranslationGrammarAiDraft;
      issues: [];
    }
  | {
      status: "blocked";
      draft?: never;
      issues: TranslationGrammarAiDraftIssue[];
    };

const isRecord = (
  value: unknown,
): value is Record<string, unknown> =>
  typeof value === "object" &&
  value !== null &&
  !Array.isArray(value);

const isConfidence = (
  value: unknown,
): value is TranslationGrammarObservationConfidence =>
  value === "low" ||
  value === "medium" ||
  value === "high";

export function prepareTranslationGrammarAiDraft(
  value: unknown,
): TranslationGrammarAiDraftPreparation {
  if (!isRecord(value)) {
    return {
      status: "blocked",
      issues: [
        {
          code: "invalid-response",
        },
      ],
    };
  }

  const pattern =
    typeof value.pattern === "string"
      ? value.pattern.trim()
      : "";
  const functionText =
    typeof value.functionText === "string"
      ? value.functionText.trim()
      : "";
  const explanation =
    typeof value.explanation === "string"
      ? value.explanation.trim()
      : "";
  const issues: TranslationGrammarAiDraftIssue[] =
    [];

  if (!pattern) {
    issues.push({
      code: "missing-pattern",
    });
  }

  if (!functionText) {
    issues.push({
      code: "missing-function",
    });
  }

  if (!explanation) {
    issues.push({
      code: "missing-explanation",
    });
  }

  if (!isConfidence(value.confidence)) {
    issues.push({
      code: "invalid-confidence",
    });
  }

  if (
    issues.length > 0 ||
    !isConfidence(value.confidence)
  ) {
    return {
      status: "blocked",
      issues,
    };
  }

  return {
    status: "ready",
    issues: [],
    draft: {
      pattern,
      functionText,
      explanation,
      confidence: value.confidence,
    },
  };
}
