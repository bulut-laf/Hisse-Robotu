$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

Set-Location $app

Write-Host "=== Sprint 636-638 Target Tests ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCompletion.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCompletionCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCompletionAwareCefrIntelligencePlatform.test.ts"

if ($LASTEXITCODE -ne 0) {
  throw "Sprint 636-638 target tests failed."
}

Write-Host "=== Full Regression ==="
npm run test

if ($LASTEXITCODE -ne 0) {
  throw "Full regression failed."
}

Write-Host "=== Production Build ==="
npm run build

if ($LASTEXITCODE -ne 0) {
  throw "Production build failed."
}

Write-Host "SPRINT-636-638 VERIFICATION COMPLETE"
