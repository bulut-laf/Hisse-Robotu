$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 798-800 Target Tests: Custodial Implication ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialImplication.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialImplicationCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialImplicationAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 798-800 target tests failed." }

Write-Host "=== Sprint 801-803 Target Tests: Custodial Repercussion ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialRepercussion.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialRepercussionCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialRepercussionAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 801-803 target tests failed." }

Write-Host "=== Sprint 804-806 Target Tests: Custodial Ramification ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialRamification.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialRamificationCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialRamificationAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 804-806 target tests failed." }

Write-Host "=== Combined Sprint 798-806 New Tests ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialImplication.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialImplicationCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialImplicationAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialRepercussion.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialRepercussionCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialRepercussionAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialRamification.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialRamificationCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialRamificationAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 798-806 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-798-806 VERIFICATION COMPLETE"
