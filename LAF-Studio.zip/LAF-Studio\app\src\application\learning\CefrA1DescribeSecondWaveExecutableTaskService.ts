import type {
  LafLearningLanguageCode,
} from "../../core/language/LafLanguageProfile";
import {
  getLafA1DescribeLanguageContentPack,
  type CefrA1DescribeRealizedPhrase,
} from "../../core/learning/CefrA1DescribeLanguageContentRegistry";
import {
  getLafA1DescribeSecondWaveTask,
} from "../../core/learning/CefrA1DescribeSecondWaveExecutableTaskDefinition";
import type {
  CefrAuthoritativeLanguageRuntimeEvidenceResult,
} from "./CefrAuthoritativeLanguageRuntimeEvidenceService";
import {
  CefrProductionRuntimePlatform,
} from "./CefrProductionRuntimePlatform";

export interface CefrA1DescribeSequenceTaskView {
  readonly taskId:
    | "a1-describe-task-place-thing-description"
    | "a1-describe-task-reciprocal-description";
  readonly lessonId: string;
  readonly evidenceDefinitionId: string;
  readonly languageCode:
    LafLearningLanguageCode;
  readonly options:
    readonly CefrA1DescribeRealizedPhrase[];
  readonly requiredStepCount: number;
  readonly correctSequenceExposed: false;
  readonly evidenceWritten: false;
  readonly narrativeSequencingRequired:
    false;
}

export interface CefrA1DescribeSequenceTaskInput {
  readonly taskId:
    | "a1-describe-task-place-thing-description"
    | "a1-describe-task-reciprocal-description";
  readonly languageCode:
    LafLearningLanguageCode;
  readonly selectedPhraseIds:
    readonly string[];
  readonly eventId: string;
  readonly occurredAt: Date;
  readonly userActionConfirmed: boolean;
}

export interface CefrA1DescribeSequenceTaskResult {
  readonly correctPrefix: boolean;
  readonly complete: boolean;
  readonly evidenceWritten: boolean;
  readonly runtime:
    CefrAuthoritativeLanguageRuntimeEvidenceResult | null;
  readonly masteryAssigned: false;
  readonly competencySuccessAssigned: false;
  readonly cefrLevelAssigned: false;
  readonly progressionPerformed: false;
  readonly narrativeSequencingPerformed:
    false;
}

export interface CefrA1DescribeFollowUpTaskView {
  readonly taskId:
    "a1-describe-task-follow-up-response";
  readonly lessonId:
    "a1-describe-complete-basic-description";
  readonly evidenceDefinitionId:
    "a1-describe-evidence-follow-up-response";
  readonly languageCode:
    LafLearningLanguageCode;
  readonly promptPhrase:
    CefrA1DescribeRealizedPhrase;
  readonly options:
    readonly CefrA1DescribeRealizedPhrase[];
  readonly correctAnswerExposed: false;
  readonly evidenceWritten: false;
}

export interface CefrA1DescribeFollowUpInput {
  readonly languageCode:
    LafLearningLanguageCode;
  readonly selectedPhraseId: string;
  readonly eventId: string;
  readonly occurredAt: Date;
  readonly userActionConfirmed: boolean;
}

export interface CefrA1DescribeFollowUpResult {
  readonly correct: boolean;
  readonly evidenceWritten: boolean;
  readonly runtime:
    CefrAuthoritativeLanguageRuntimeEvidenceResult | null;
  readonly masteryAssigned: false;
  readonly competencySuccessAssigned: false;
  readonly cefrLevelAssigned: false;
  readonly progressionPerformed: false;
  readonly narrativeSequencingPerformed:
    false;
}

export class CefrA1DescribeSecondWaveExecutableTaskService {
  private readonly platform:
    CefrProductionRuntimePlatform;

  constructor(
    platform: CefrProductionRuntimePlatform,
  ) {
    this.platform = platform;
  }

  getSequenceTaskView(
    taskId:
      CefrA1DescribeSequenceTaskView["taskId"],
    languageCode:
      LafLearningLanguageCode,
  ): CefrA1DescribeSequenceTaskView {
    const task =
      getLafA1DescribeSecondWaveTask(
        taskId,
      );

    if (
      task.taskKind !==
        "controlled-description-sequence" &&
      task.taskKind !==
        "controlled-reciprocal-description"
    ) {
      throw new Error(
        `A1 DESCRIBE task is not a sequence task: ${taskId}`,
      );
    }

    const pack =
      getLafA1DescribeLanguageContentPack(
        languageCode,
      );

    const lesson =
      pack.lessons.find(
        item =>
          item.lessonId === task.lessonId,
      );

    if (!lesson) {
      throw new Error(
        `A1 DESCRIBE second-wave language content missing: ${taskId}/${languageCode}`,
      );
    }

    for (
      const phraseId of
      task.expectedPhraseIds
    ) {
      if (
        !lesson.phrases.some(
          phrase =>
            phrase.phraseId === phraseId,
        )
      ) {
        throw new Error(
          `A1 DESCRIBE second-wave phrase missing: ${phraseId}/${languageCode}`,
        );
      }
    }

    return {
      taskId,
      lessonId: task.lessonId,
      evidenceDefinitionId:
        task.evidenceDefinitionId,
      languageCode,
      options: lesson.phrases,
      requiredStepCount:
        task.expectedPhraseIds.length,
      correctSequenceExposed: false,
      evidenceWritten: false,
      narrativeSequencingRequired:
        false,
    };
  }

  executeSequenceTask(
    input:
      CefrA1DescribeSequenceTaskInput,
  ): CefrA1DescribeSequenceTaskResult {
    if (!input.userActionConfirmed) {
      throw new Error(
        "Explicit user action confirmation is required for A1 DESCRIBE evidence.",
      );
    }

    const task =
      getLafA1DescribeSecondWaveTask(
        input.taskId,
      );

    if (
      task.taskKind !==
        "controlled-description-sequence" &&
      task.taskKind !==
        "controlled-reciprocal-description"
    ) {
      throw new Error(
        `A1 DESCRIBE task is not a sequence task: ${input.taskId}`,
      );
    }

    const view =
      this.getSequenceTaskView(
        input.taskId,
        input.languageCode,
      );

    if (
      input.selectedPhraseIds.length >
      task.expectedPhraseIds.length
    ) {
      throw new Error(
        "A1 DESCRIBE controlled sequence exceeds the approved step count.",
      );
    }

    for (
      const phraseId of
      input.selectedPhraseIds
    ) {
      if (
        !view.options.some(
          option =>
            option.phraseId === phraseId,
        )
      ) {
        throw new Error(
          `Unknown A1 DESCRIBE second-wave option: ${phraseId}`,
        );
      }
    }

    const correctPrefix =
      input.selectedPhraseIds.every(
        (phraseId, index) =>
          phraseId ===
          task.expectedPhraseIds[index],
      );

    const complete =
      correctPrefix &&
      input.selectedPhraseIds.length ===
        task.expectedPhraseIds.length;

    if (!complete) {
      return {
        correctPrefix,
        complete: false,
        evidenceWritten: false,
        runtime: null,
        masteryAssigned: false,
        competencySuccessAssigned: false,
        cefrLevelAssigned: false,
        progressionPerformed: false,
        narrativeSequencingPerformed:
          false,
      };
    }

    const runtime =
      this.platform.recordUserEvidence(
        "a1-describe",
        {
          evidenceDefinitionId:
            task.evidenceDefinitionId,
          eventId: input.eventId,
          occurredAt: input.occurredAt,
          languageCode:
            input.languageCode,
          userActionConfirmed: true,
        },
      );

    return {
      correctPrefix: true,
      complete: true,
      evidenceWritten: true,
      runtime,
      masteryAssigned: false,
      competencySuccessAssigned: false,
      cefrLevelAssigned: false,
      progressionPerformed: false,
      narrativeSequencingPerformed:
        false,
    };
  }

  getFollowUpTaskView(
    languageCode:
      LafLearningLanguageCode,
  ): CefrA1DescribeFollowUpTaskView {
    const task =
      getLafA1DescribeSecondWaveTask(
        "a1-describe-task-follow-up-response",
      );

    if (
      task.taskKind !==
      "controlled-follow-up-selection"
    ) {
      throw new Error(
        "A1 DESCRIBE follow-up task definition is invalid.",
      );
    }

    const pack =
      getLafA1DescribeLanguageContentPack(
        languageCode,
      );

    const lesson =
      pack.lessons.find(
        item =>
          item.lessonId === task.lessonId,
      );

    if (!lesson) {
      throw new Error(
        `A1 DESCRIBE follow-up language content missing: ${languageCode}`,
      );
    }

    const promptPhrase =
      lesson.phrases.find(
        phrase =>
          phrase.phraseId ===
          task.promptPhraseId,
      );

    if (!promptPhrase) {
      throw new Error(
        `A1 DESCRIBE follow-up prompt missing: ${languageCode}`,
      );
    }

    if (
      !lesson.phrases.some(
        phrase =>
          phrase.phraseId ===
          task.correctPhraseId,
      )
    ) {
      throw new Error(
        `A1 DESCRIBE follow-up answer missing: ${languageCode}`,
      );
    }

    return {
      taskId: task.taskId,
      lessonId: task.lessonId,
      evidenceDefinitionId:
        task.evidenceDefinitionId,
      languageCode,
      promptPhrase,
      options: lesson.phrases,
      correctAnswerExposed: false,
      evidenceWritten: false,
    };
  }

  executeFollowUp(
    input:
      CefrA1DescribeFollowUpInput,
  ): CefrA1DescribeFollowUpResult {
    if (!input.userActionConfirmed) {
      throw new Error(
        "Explicit user action confirmation is required for A1 DESCRIBE evidence.",
      );
    }

    const task =
      getLafA1DescribeSecondWaveTask(
        "a1-describe-task-follow-up-response",
      );

    if (
      task.taskKind !==
      "controlled-follow-up-selection"
    ) {
      throw new Error(
        "A1 DESCRIBE follow-up task definition is invalid.",
      );
    }

    const view =
      this.getFollowUpTaskView(
        input.languageCode,
      );

    if (
      !view.options.some(
        option =>
          option.phraseId ===
          input.selectedPhraseId,
      )
    ) {
      throw new Error(
        `Unknown A1 DESCRIBE follow-up option: ${input.selectedPhraseId}`,
      );
    }

    const correct =
      input.selectedPhraseId ===
      task.correctPhraseId;

    if (!correct) {
      return {
        correct: false,
        evidenceWritten: false,
        runtime: null,
        masteryAssigned: false,
        competencySuccessAssigned: false,
        cefrLevelAssigned: false,
        progressionPerformed: false,
        narrativeSequencingPerformed:
          false,
      };
    }

    const runtime =
      this.platform.recordUserEvidence(
        "a1-describe",
        {
          evidenceDefinitionId:
            task.evidenceDefinitionId,
          eventId: input.eventId,
          occurredAt: input.occurredAt,
          languageCode:
            input.languageCode,
          userActionConfirmed: true,
        },
      );

    return {
      correct: true,
      evidenceWritten: true,
      runtime,
      masteryAssigned: false,
      competencySuccessAssigned: false,
      cefrLevelAssigned: false,
      progressionPerformed: false,
      narrativeSequencingPerformed:
        false,
    };
  }
}
