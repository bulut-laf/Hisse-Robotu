$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

Set-Location $app

Write-Host "=== Sprint 543-545 Target Tests ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidencePriority.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidencePriorityCoordination.test.ts" `
  "src/core/learning/CefrEvidencePriorityAwareCefrIntelligencePlatform.test.ts"

if ($LASTEXITCODE -ne 0) {
  throw "Sprint 543-545 target tests failed."
}

Write-Host "=== Full Regression ==="
npm run test

if ($LASTEXITCODE -ne 0) {
  throw "Full regression failed."
}

Write-Host "=== Production Build ==="
npm run build

if ($LASTEXITCODE -ne 0) {
  throw "Production build failed."
}

Write-Host "SPRINT-543-545 VERIFICATION COMPLETE"
