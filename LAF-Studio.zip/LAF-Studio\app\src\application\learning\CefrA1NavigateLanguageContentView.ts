import type {
  LafLearningLanguageCode,
} from "../../core/language/LafLanguageProfile";
import {
  getLafA1NavigateLanguageContentPack,
  type CefrA1NavigateRealizedPhrase,
} from "../../core/learning/CefrA1NavigateLanguageContentRegistry";

export interface CefrA1NavigateLanguageContentView {
  readonly languageCode:
    LafLearningLanguageCode;
  readonly lessonId: string;
  readonly phrases:
    readonly CefrA1NavigateRealizedPhrase[];
  readonly languageContentAvailable: true;
  readonly assistantAuthoredV1: true;
  readonly nativeReviewValidated: false;
  readonly executableTaskAvailable: true;
  readonly executableImmediateTaskCount: 6;
  readonly evidenceCaptureAvailable: true;
  readonly evidenceRequiresUserAction: true;
  readonly delayedRetrievalRuntimeAvailable:
    false;
}

export function createCefrA1NavigateLanguageContentView(
  languageCode: LafLearningLanguageCode,
  lessonId: string,
): CefrA1NavigateLanguageContentView {
  const pack =
    getLafA1NavigateLanguageContentPack(
      languageCode,
    );

  const lesson =
    pack.lessons.find(
      item => item.lessonId === lessonId,
    );

  if (!lesson) {
    throw new Error(
      `A1 NAVIGATE realized lesson not found: ${lessonId}`,
    );
  }

  return {
    languageCode,
    lessonId,
    phrases: lesson.phrases,
    languageContentAvailable: true,
    assistantAuthoredV1: true,
    nativeReviewValidated: false,
    executableTaskAvailable: true,
    executableImmediateTaskCount: 6,
    evidenceCaptureAvailable: true,
    evidenceRequiresUserAction: true,
    delayedRetrievalRuntimeAvailable:
      false,
  };
}
