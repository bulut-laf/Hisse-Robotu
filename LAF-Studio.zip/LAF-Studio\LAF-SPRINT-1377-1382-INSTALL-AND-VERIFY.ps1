﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$panel = Join-Path $app "src\ui\learning\A1ConnectNativeLearningPanel.tsx"
$css = Join-Path $app "src\ui\learning\A1ConnectContinuityPanel.css"
$cssPart = Join-Path $app "src\ui\learning\A1ConnectContinuityPanel.advisory.css"

if (-not (Test-Path $panel)) {
    throw "A1ConnectNativeLearningPanel.tsx missing."
}

if (-not (Test-Path $css)) {
    throw "A1ConnectContinuityPanel.css missing."
}

if (-not (Test-Path $cssPart)) {
    throw "Advisory CSS fragment missing."
}

$utf8 =
    New-Object System.Text.UTF8Encoding($false)

$cssText =
    [System.IO.File]::ReadAllText(
        $css,
        $utf8
    )
$extraCss =
    [System.IO.File]::ReadAllText(
        $cssPart,
        $utf8
    )

if (-not $cssText.Contains(
    ".a1-connect-next-step button {"
)) {
    [System.IO.File]::WriteAllText(
        $css,
        $cssText +
        [Environment]::NewLine +
        $extraCss,
        $utf8
    )
}

Remove-Item $cssPart -Force

$text =
    [System.IO.File]::ReadAllText(
        $panel,
        $utf8
    )

$callbackMarker =
    'const applyAdvisoryLesson = ('

if (-not $text.Contains($callbackMarker)) {
    $restoreDeclaration =
        '  const restoreRememberedSelection = ('

    $restoreIndex =
        $text.IndexOf(
            $restoreDeclaration
        )

    if ($restoreIndex -lt 0) {
        throw "Explicit restore declaration anchor not found."
    }

    $mainReturnIndex =
        $text.IndexOf(
            '  return (' +
            [Environment]::NewLine +
            '    <section',
            $restoreIndex
        )

    if ($mainReturnIndex -lt 0) {
        # Fallback for LF-only source.
        $mainReturnIndex =
            $text.IndexOf(
                "  return (`n    <section",
                $restoreIndex
            )
    }

    if ($mainReturnIndex -lt 0) {
        throw "Component return anchor after restore function not found."
    }

    $callback = @'
  const applyAdvisoryLesson = (
    lessonId: string,
  ) => {
    if (
      model.lessonCards.some(
        lesson =>
          lesson.lessonId === lessonId,
      )
    ) {
      setSelectedLessonId(lessonId);
    }
  };

'@

    $text =
        $text.Insert(
            $mainReturnIndex,
            $callback
        )
}

$oldProps = @'
        onRestoreSelection={
          restoreRememberedSelection
        }
      />
'@

$newProps = @'
        onRestoreSelection={
          restoreRememberedSelection
        }
        onApplyAdvisoryLesson={
          applyAdvisoryLesson
        }
      />
'@

if (-not $text.Contains(
    'onApplyAdvisoryLesson={'
)) {
    if (-not $text.Contains($oldProps)) {
        throw "Continuity advisory prop anchor not found."
    }

    $text = $text.Replace(
        $oldProps,
        $newProps
    )
}

[System.IO.File]::WriteAllText(
    $panel,
    $text,
    $utf8
)

$request = Join-Path $app "src\core\learning\CefrA1ConnectAdvisoryLessonApplyRequest.ts"
$boundary = Join-Path $app "src\application\learning\CefrA1ConnectAdvisoryLessonApplyBoundary.ts"
$continuity = Join-Path $app "src\ui\learning\A1ConnectContinuityPanel.tsx"
$safety = Join-Path $app "src\core\learning\CefrA1ConnectAdvisoryApplySafety.ts"

foreach ($file in @(
    $request,
    $boundary,
    $continuity,
    $safety,
    $panel
)) {
    if (-not (Test-Path $file)) {
        throw "Sprint 1377-1382 source missing: $file"
    }
}

$checks = @{
    $request = @(
        'userActionConfirmed: true',
        'taskExecuted: false',
        'evidenceCreated: false'
    )
    $boundary = @(
        'authoritativeLessonIds.includes(',
        'automaticSelectionPerformed:',
        'false'
    )
    $continuity = @(
        'Önerilen Dersi Seç',
        'onApplyAdvisoryLesson('
    )
    $safety = @(
        'automaticLessonSelectionAllowed:',
        'false',
        'applyingSuggestionCreatesEvidence:',
        'false'
    )
    $panel = @(
        'const applyAdvisoryLesson = (',
        'onApplyAdvisoryLesson={'
    )
}

foreach ($entry in $checks.GetEnumerator()) {
    foreach ($marker in $entry.Value) {
        if (-not (
            Select-String `
                -Path $entry.Key `
                -SimpleMatch `
                -Pattern $marker `
                -Quiet
        )) {
            throw "Required Sprint 1377-1382 marker missing: $marker"
        }
    }
}

Write-Host "SPRINT-1377-1382 SOURCE CHECK PASSED"

Set-Location $app

$targets = @(
    "src/core/learning/CefrA1ConnectAdvisoryLessonApplyRequest.test.ts",
    "src/application/learning/CefrA1ConnectAdvisoryLessonApplyBoundary.test.ts",
    "src/core/learning/CefrA1ConnectAdvisoryApplySafety.test.ts",
    "src/ui/learning/A1ConnectContinuityPanel.advisory.test.ts",
    "src/core/learning/CefrA1ConnectAdvisoryNextStep.test.ts",
    "src/application/learning/CefrA1ConnectLanguageScopedAdvisoryReadModel.test.ts",
    "src/core/learning/CefrA1ConnectSessionRestoreRequest.test.ts",
    "src/application/learning/CefrA1ConnectSessionRestoreBoundary.test.ts"
)

& npx vitest run $targets
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1377-1382 target tests failed."
}

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Full regression failed."
}

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Production build failed."
}

Write-Host "SPRINT-1377-1382 VERIFICATION COMPLETE"
