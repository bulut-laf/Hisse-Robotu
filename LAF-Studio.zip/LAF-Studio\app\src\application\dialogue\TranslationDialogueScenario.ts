import type {
  TranslationLanguageCode,
} from "../../core/translation/TranslationDraft";

export type TranslationDialogueScenarioId =
  | "cafe"
  | "introduction"
  | "directions";

export interface TranslationDialoguePrompt {
  id: string;
  partnerText: string;
  supportHint: string;
}

export interface TranslationDialogueScenario {
  id: TranslationDialogueScenarioId;
  title: string;
  goal: string;
  learnerRole: string;
  partnerRole: string;
  prompts: TranslationDialoguePrompt[];
}

const COMMON_META: Record<
  TranslationDialogueScenarioId,
  Pick<TranslationDialogueScenario, "title" | "goal" | "learnerRole" | "partnerRole">
> = {
  cafe: {
    title: "Kafede sipariş",
    goal: "Basit bir içecek veya yiyecek isteyin ve kısa takip sorularına cevap verin.",
    learnerRole: "Müşteri",
    partnerRole: "Kafe çalışanı",
  },
  introduction: {
    title: "Tanışma",
    goal: "Adınızı, nereden geldiğinizi ve basit bir kişisel bilgiyi paylaşın.",
    learnerRole: "Yeni tanışan kişi",
    partnerRole: "Yeni tanıştığınız kişi",
  },
  directions: {
    title: "Yol sorma",
    goal: "Bir yeri sorun, yön bilgisini anladığınızı belirtin ve teşekkür edin.",
    learnerRole: "Yol soran kişi",
    partnerRole: "Yoldan geçen kişi",
  },
};

type PromptSet = Record<
  TranslationDialogueScenarioId,
  readonly [string, string, string]
>;

const PROMPTS: Record<TranslationLanguageCode, PromptSet> = {
  hu: {
    cafe: ["Jó napot! Mit kér?", "Rendben. Még valamit?", "Helyben fogyasztja vagy elvitelre kéri?"],
    introduction: ["Szia! Hogy hívnak?", "Örülök. Honnan jöttél?", "Mit szeretsz csinálni szabadidődben?"],
    directions: ["Jó napot! Segíthetek?", "Menjen egyenesen, aztán forduljon balra.", "A gyógyszertár a bank mellett van."],
  },
  tr: {
    cafe: ["Merhaba! Ne almak istersiniz?", "Peki. Başka bir şey ister misiniz?", "Burada mı içeceksiniz, paket mi olsun?"],
    introduction: ["Merhaba! Adınız ne?", "Memnun oldum. Nereden geldiniz?", "Boş zamanınızda ne yapmayı seversiniz?"],
    directions: ["Merhaba! Yardımcı olabilir miyim?", "Düz gidin, sonra sola dönün.", "Eczane bankanın yanında."],
  },
  de: {
    cafe: ["Guten Tag! Was möchten Sie?", "Möchten Sie noch etwas?", "Hier oder zum Mitnehmen?"],
    introduction: ["Hallo! Wie heißen Sie?", "Woher kommen Sie?", "Was machen Sie gern in Ihrer Freizeit?"],
    directions: ["Guten Tag! Kann ich Ihnen helfen?", "Gehen Sie geradeaus und biegen Sie dann links ab.", "Die Apotheke ist neben der Bank."],
  },
  it: {
    cafe: ["Buongiorno! Cosa desidera?", "Desidera altro?", "Qui o da asporto?"],
    introduction: ["Ciao! Come si chiama?", "Di dove è?", "Cosa le piace fare nel tempo libero?"],
    directions: ["Buongiorno! Posso aiutarla?", "Vada dritto, poi giri a sinistra.", "La farmacia è accanto alla banca."],
  },
  en: {
    cafe: ["Hello! What would you like?", "Anything else?", "For here or to go?"],
    introduction: ["Hi! What's your name?", "Where are you from?", "What do you like to do in your free time?"],
    directions: ["Hello! Can I help you?", "Go straight ahead, then turn left.", "The pharmacy is next to the bank."],
  },
  es: {
    cafe: ["¡Buenos días! ¿Qué desea?", "¿Algo más?", "¿Para tomar aquí o para llevar?"],
    introduction: ["¡Hola! ¿Cómo se llama?", "¿De dónde es?", "¿Qué le gusta hacer en su tiempo libre?"],
    directions: ["¡Buenos días! ¿Puedo ayudarle?", "Siga recto y luego gire a la izquierda.", "La farmacia está al lado del banco."],
  },
  ru: {
    cafe: ["Здравствуйте! Что вы будете?", "Что-нибудь ещё?", "Здесь или с собой?"],
    introduction: ["Здравствуйте! Как вас зовут?", "Откуда вы?", "Что вы любите делать в свободное время?"],
    directions: ["Здравствуйте! Я могу вам помочь?", "Идите прямо, потом поверните налево.", "Аптека рядом с банком."],
  },
};

const SUPPORT_HINTS: Record<TranslationDialogueScenarioId, readonly [string, string, string]> = {
  cafe: [
    "Ne istediğinizi kısa bir cümleyle söyleyin.",
    "Başka bir şey isteyin veya gerek olmadığını söyleyin.",
    "Burada mı yoksa paket mi istediğinizi söyleyin.",
  ],
  introduction: [
    "Adınızı söyleyin.",
    "Hangi ülkeden veya şehirden geldiğinizi söyleyin.",
    "Boş zamanda sevdiğiniz tek bir etkinliği söyleyin.",
  ],
  directions: [
    "Aradığınız yeri sorun.",
    "Kısa biçimde anladığınızı belirtin.",
    "Teşekkür ederek konuşmayı tamamlayın.",
  ],
};

const createScenario = (
  language: TranslationLanguageCode,
  id: TranslationDialogueScenarioId,
): TranslationDialogueScenario => {
  const meta = COMMON_META[id];
  const prompts = PROMPTS[language][id];
  const supportHints = SUPPORT_HINTS[id];

  return {
    id,
    ...meta,
    prompts: prompts.map((partnerText, index) => ({
      id: `${id}-${index + 1}`,
      partnerText,
      supportHint: supportHints[index] ?? "",
    })),
  };
};

export function getTranslationDialogueScenarios(
  language: TranslationLanguageCode,
): TranslationDialogueScenario[] {
  return [
    createScenario(language, "cafe"),
    createScenario(language, "introduction"),
    createScenario(language, "directions"),
  ];
}

export function getTranslationDialogueScenario(
  language: TranslationLanguageCode,
  scenarioId: TranslationDialogueScenarioId,
): TranslationDialogueScenario {
  const scenario = getTranslationDialogueScenarios(language).find(
    candidate => candidate.id === scenarioId,
  );

  if (!scenario) {
    throw new Error(`Bilinmeyen role-play senaryosu: ${scenarioId}`);
  }

  return scenario;
}

export function normalizeTranslationDialogueReply(value: string): string {
  return value.replace(/\s+/g, " ").trim();
}

export function isTranslationDialogueReplyReady(value: string): boolean {
  return normalizeTranslationDialogueReply(value).length > 0;
}
