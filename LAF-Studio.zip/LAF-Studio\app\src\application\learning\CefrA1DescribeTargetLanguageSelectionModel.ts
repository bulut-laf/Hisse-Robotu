import {
  LAF_LEARNING_LANGUAGE_CODES,
  getLafLanguageProfile,
  type LafLearningLanguageCode,
} from "../../core/language/LafLanguageProfile";
import {
  getLafA1DescribeLanguageRealization,
  type CefrA1DescribeLanguageRealizationDescriptor,
} from "../../core/learning/CefrA1DescribeLanguageRealizationRegistry";

export interface CefrA1DescribeTargetLanguageOption {
  readonly code: LafLearningLanguageCode;
  readonly label: string;
  readonly nativeLabel: string;
  readonly locale: string;
}

export interface CefrA1DescribeTargetLanguageSelectionModel {
  readonly options:
    readonly CefrA1DescribeTargetLanguageOption[];
  readonly selectedLanguageCode:
    LafLearningLanguageCode | null;
  readonly selectionRequired: boolean;
  readonly selectedByUser: boolean;
  readonly realization:
    CefrA1DescribeLanguageRealizationDescriptor | null;
  readonly languageContentBound: boolean;
  readonly executableTaskAvailable: boolean;
  readonly evidenceCaptureAvailable: boolean;
  readonly delayedRetrievalRuntimeAvailable:
    boolean;
  readonly narrativeSequencingIntroduced:
    false;
  readonly targetLanguageInferred: false;
}

export function createCefrA1DescribeTargetLanguageSelectionModel(
  selectedLanguageCode:
    LafLearningLanguageCode | null,
): CefrA1DescribeTargetLanguageSelectionModel {
  const options =
    LAF_LEARNING_LANGUAGE_CODES.map(code => {
      const profile = getLafLanguageProfile(code);

      return {
        code,
        label: profile.label,
        nativeLabel: profile.nativeLabel,
        locale: profile.locale,
      };
    });

  const realization =
    selectedLanguageCode === null
      ? null
      : getLafA1DescribeLanguageRealization(
          selectedLanguageCode,
        );

  return {
    options,
    selectedLanguageCode,
    selectionRequired:
      selectedLanguageCode === null,
    selectedByUser:
      selectedLanguageCode !== null,
    realization,
    languageContentBound:
      realization?.languageContentBound ??
      false,
    executableTaskAvailable:
      realization?.executableTaskAvailable ??
      false,
    evidenceCaptureAvailable:
      realization?.evidenceCaptureAvailable ??
      false,
    delayedRetrievalRuntimeAvailable:
      realization?.delayedRetrievalRuntimeAvailable ??
      false,
    narrativeSequencingIntroduced:
      false,
    targetLanguageInferred: false,
  };
}
