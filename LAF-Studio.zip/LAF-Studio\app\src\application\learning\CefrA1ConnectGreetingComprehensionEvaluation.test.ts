import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrA1ConnectGreetingComprehensionTask,
} from "../../core/learning/CefrA1ConnectGreetingComprehensionTask";
import {
  evaluateCefrA1ConnectGreetingComprehension,
} from "./CefrA1ConnectGreetingComprehensionEvaluation";

describe(
  "CefrA1ConnectGreetingComprehensionEvaluation",
  () => {
    it("permits evidence only after a correct real user submission", () => {
      const task =
        createCefrA1ConnectGreetingComprehensionTask(
          "de",
        );

      expect(
        evaluateCefrA1ConnectGreetingComprehension(
          task,
          task.correctAnswer,
        ),
      ).toEqual({
        submitted: true,
        correct: true,
        evidenceEligible: true,
        masteryAssigned: false,
        competencySuccessAssigned: false,
        cefrLevelAssigned: false,
        progressionPerformed: false,
      });

      expect(
        evaluateCefrA1ConnectGreetingComprehension(
          task,
          "Yanlış cevap",
        ).evidenceEligible,
      ).toBe(false);
    });
  },
);
