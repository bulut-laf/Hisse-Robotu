﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

Set-Location $root
node ".\LAF-SPRINT-1269-1274-INSTALL.mjs"
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1269-1274 install failed."
}

Set-Location $app

$targets = @(
  "src/application/learning/CefrMappedListeningPracticeCompletionService.test.ts",
  "src/application/learning/CefrListeningCurriculumObservationBindingSafety.test.ts",
  "src/core/learning/CefrCurriculumCapabilityObservationWrite.test.ts",
  "src/application/learning/CefrCurriculumCapabilityObservationWriter.test.ts",
  "src/core/learning/CefrCurriculumCompetencyMapping.test.ts"
)

& npx vitest run $targets
if ($LASTEXITCODE -ne 0) {
  throw "Sprint 1269-1274 target tests failed."
}

& npm run test
if ($LASTEXITCODE -ne 0) {
  throw "Full regression failed."
}

& npm run build
if ($LASTEXITCODE -ne 0) {
  throw "Production build failed."
}

Write-Host "SPRINT-1269-1274 VERIFICATION COMPLETE"
