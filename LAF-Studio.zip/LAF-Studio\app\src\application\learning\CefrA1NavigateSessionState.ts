import type {
  LafLearningLanguageCode,
} from "../../core/language/LafLanguageProfile";
import {
  LAF_A1_NAVIGATE_ALL_EXECUTABLE_TASKS,
  type CefrA1NavigateAllExecutableTaskId,
} from "../../core/learning/CefrA1NavigateExecutableTaskCatalog";

export interface CefrA1NavigateSessionState {
  readonly languageCode:
    LafLearningLanguageCode;
  readonly selectedTaskId:
    CefrA1NavigateAllExecutableTaskId;
  readonly completedTaskIds:
    readonly CefrA1NavigateAllExecutableTaskId[];
  readonly exchangeSelections:
    readonly string[];
  readonly updatedAt: string;
  readonly evidenceCoverageScope:
    "current-explicit-session";
  readonly masteryClaimed: false;
  readonly cefrLevelClaimed: false;
}

export function createCefrA1NavigateSessionState(
  input: {
    readonly languageCode:
      LafLearningLanguageCode;
    readonly selectedTaskId:
      CefrA1NavigateAllExecutableTaskId;
    readonly completedTaskIds:
      readonly CefrA1NavigateAllExecutableTaskId[];
    readonly exchangeSelections:
      readonly string[];
    readonly updatedAt: Date;
  },
): CefrA1NavigateSessionState {
  const allowedTaskIds =
    new Set(
      LAF_A1_NAVIGATE_ALL_EXECUTABLE_TASKS.map(
        task => task.taskId,
      ),
    );

  if (!allowedTaskIds.has(input.selectedTaskId)) {
    throw new Error(
      `Unknown A1 NAVIGATE session task: ${input.selectedTaskId}`,
    );
  }

  const completedTaskIds = [
    ...new Set(input.completedTaskIds),
  ];

  for (const taskId of completedTaskIds) {
    if (!allowedTaskIds.has(taskId)) {
      throw new Error(
        `Unknown completed A1 NAVIGATE session task: ${taskId}`,
      );
    }
  }

  return {
    languageCode: input.languageCode,
    selectedTaskId: input.selectedTaskId,
    completedTaskIds,
    exchangeSelections: [
      ...input.exchangeSelections,
    ],
    updatedAt:
      input.updatedAt.toISOString(),
    evidenceCoverageScope:
      "current-explicit-session",
    masteryClaimed: false,
    cefrLevelClaimed: false,
  };
}
