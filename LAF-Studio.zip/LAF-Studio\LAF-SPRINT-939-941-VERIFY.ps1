$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 939-941 Target Tests: Integrated Evidence Pipeline ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceEvidenceIngestion.test.ts" `
  "src/core/learning/CefrIntelligenceEvidenceCoordination.test.ts" `
  "src/core/learning/CefrIntelligenceIntegratedEvidencePipeline.test.ts"

if ($LASTEXITCODE -ne 0) {
  throw "Sprint 939-941 target tests failed."
}

Write-Host "=== Full Regression ==="
npm run test

if ($LASTEXITCODE -ne 0) {
  throw "Full regression failed."
}

Write-Host "=== Production Build ==="
npm run build

if ($LASTEXITCODE -ne 0) {
  throw "Production build failed."
}

Write-Host "SPRINT-939-941 VERIFICATION COMPLETE"
