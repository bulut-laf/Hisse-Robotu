$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 948-950 Target Tests: Read-Only Learner Context ==="
npx vitest run `
  "src/core/learning/CefrLearnerContextProjection.test.ts" `
  "src/core/learning/CefrLearnerContextSummary.test.ts" `
  "src/core/learning/CefrAiTeacherContext.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 948-950 target tests failed." }

Write-Host "=== Sprint 951-953 Target Tests: Adaptive + Context Orchestration Bridge ==="
npx vitest run `
  "src/core/learning/CefrAdaptiveLearningContext.test.ts" `
  "src/core/learning/CefrLearnerContextBridge.test.ts" `
  "src/core/learning/CefrIntelligenceContextOrchestration.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 951-953 target tests failed." }

Write-Host "=== Combined Sprint 948-953 New Tests ==="
npx vitest run `
  "src/core/learning/CefrLearnerContextProjection.test.ts" `
  "src/core/learning/CefrLearnerContextSummary.test.ts" `
  "src/core/learning/CefrAiTeacherContext.test.ts" `
  "src/core/learning/CefrAdaptiveLearningContext.test.ts" `
  "src/core/learning/CefrLearnerContextBridge.test.ts" `
  "src/core/learning/CefrIntelligenceContextOrchestration.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 948-953 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-948-953 VERIFICATION COMPLETE"
