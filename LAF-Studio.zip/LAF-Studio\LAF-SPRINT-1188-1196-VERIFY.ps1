$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 1188-1190 Target Tests: Public Guidance Read/Review/Selection Facades ==="
npx vitest run `
  "src/core/learning/CefrGuidanceApplicationReadFacade.test.ts" `
  "src/core/learning/CefrGuidanceApplicationReviewFacade.test.ts" `
  "src/core/learning/CefrGuidanceApplicationSelectionFacade.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1188-1190 target tests failed." }

Write-Host "=== Sprint 1191-1193 Target Tests: Launch/Route/Feedback Facades ==="
npx vitest run `
  "src/core/learning/CefrGuidanceApplicationLaunchFacade.test.ts" `
  "src/core/learning/CefrGuidanceApplicationRouteFacade.test.ts" `
  "src/core/learning/CefrGuidanceApplicationFeedbackFacade.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1191-1193 target tests failed." }

Write-Host "=== Sprint 1194-1196 Target Tests: Integration Readiness + Public API ==="
npx vitest run `
  "src/core/learning/CefrGuidanceApplicationCapabilities.test.ts" `
  "src/core/learning/CefrGuidanceApplicationIntegrationReadiness.test.ts" `
  "src/core/learning/CefrGuidanceApplicationFacade.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1194-1196 target tests failed." }

Write-Host "=== Combined Sprint 1188-1196 New Tests ==="
npx vitest run `
  "src/core/learning/CefrGuidanceApplicationReadFacade.test.ts" `
  "src/core/learning/CefrGuidanceApplicationReviewFacade.test.ts" `
  "src/core/learning/CefrGuidanceApplicationSelectionFacade.test.ts" `
  "src/core/learning/CefrGuidanceApplicationLaunchFacade.test.ts" `
  "src/core/learning/CefrGuidanceApplicationRouteFacade.test.ts" `
  "src/core/learning/CefrGuidanceApplicationFeedbackFacade.test.ts" `
  "src/core/learning/CefrGuidanceApplicationCapabilities.test.ts" `
  "src/core/learning/CefrGuidanceApplicationIntegrationReadiness.test.ts" `
  "src/core/learning/CefrGuidanceApplicationFacade.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1188-1196 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-1188-1196 VERIFICATION COMPLETE"
