﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$panel = Join-Path $app "src\ui\learning\A1ConnectNativeLearningPanel.tsx"

if (-not (Test-Path $panel)) {
    throw "A1ConnectNativeLearningPanel.tsx missing."
}

$utf8 =
    New-Object System.Text.UTF8Encoding($false)

$text =
    [System.IO.File]::ReadAllText(
        $panel,
        $utf8
    )

$importLine =
    'import { A1ConnectAdditionalTaskPanel } from "./A1ConnectAdditionalTaskPanel";'

if (-not $text.Contains($importLine)) {
    $anchor =
        'import { A1ConnectGreetingComprehensionTaskPanel } from "./A1ConnectGreetingComprehensionTaskPanel";'

    if (-not $text.Contains($anchor)) {
        throw "Additional task import anchor not found."
    }

    $text = $text.Replace(
        $anchor,
        $anchor +
        [Environment]::NewLine +
        $importLine
    )
}

$greetingMarker =
    'taskKind="greeting-response"'

if (-not $text.Contains($greetingMarker)) {
    $anchor =
        '      <div className="a1-connect-native-gate">'

    if (-not $text.Contains($anchor)) {
        throw "Additional task render anchor not found."
    }

    $render = @'
      {selectedLanguageCode &&
      selectedLesson?.lessonId ===
        "a1-connect-greeting-response" ? (
        <A1ConnectAdditionalTaskPanel
          languageCode={selectedLanguageCode}
          taskKind="greeting-response"
        />
      ) : null}

      {selectedLanguageCode &&
      selectedLesson?.lessonId ===
        "a1-connect-self-introduction" ? (
        <A1ConnectAdditionalTaskPanel
          languageCode={selectedLanguageCode}
          taskKind="self-introduction"
        />
      ) : null}

'@

    $text = $text.Replace(
        $anchor,
        $render + $anchor
    )
}

[System.IO.File]::WriteAllText(
    $panel,
    $text,
    $utf8
)

$tasks = Join-Path $app "src\core\learning\CefrA1ConnectAdditionalExecutableTasks.ts"
$completion = Join-Path $app "src\application\learning\CefrA1ConnectChoiceTaskCompletionService.ts"
$taskPanel = Join-Path $app "src\ui\learning\A1ConnectAdditionalTaskPanel.tsx"
$safety = Join-Path $app "src\core\learning\CefrA1ConnectExpandedExecutableTaskSafety.ts"

foreach ($file in @(
    $tasks,
    $completion,
    $taskPanel,
    $safety
)) {
    if (-not (Test-Path $file)) {
        throw "Sprint 1329-1334 source missing: $file"
    }
}

$checks = @{
    $tasks = @(
        '"a1-connect-evidence-greeting-response"',
        '"a1-connect-evidence-self-introduction"',
        'evidenceOnCorrectSubmissionOnly: true'
    )
    $completion = @(
        'if (!evaluation.evidenceEligible)',
        'recordUserEvidence({'
    )
    $taskPanel = @(
        'Cevabı Gönder',
        'service.submit({'
    )
    $panel = @(
        'taskKind="greeting-response"',
        'taskKind="self-introduction"'
    )
    $safety = @(
        'executableTaskCount: 3',
        'incorrectSubmissionCreatesEvidence:',
        'false'
    )
}

foreach ($entry in $checks.GetEnumerator()) {
    foreach ($marker in $entry.Value) {
        if (-not (
            Select-String `
                -Path $entry.Key `
                -SimpleMatch `
                -Pattern $marker `
                -Quiet
        )) {
            throw "Required Sprint 1329-1334 marker missing: $marker"
        }
    }
}

Write-Host "SPRINT-1329-1334 SOURCE CHECK PASSED"

Set-Location $app

$targets = @(
    "src/core/learning/CefrA1ConnectAdditionalExecutableTasks.test.ts",
    "src/application/learning/CefrA1ConnectChoiceTaskEvaluation.test.ts",
    "src/application/learning/CefrA1ConnectChoiceTaskCompletionService.test.ts",
    "src/core/learning/CefrA1ConnectExpandedExecutableTaskSafety.test.ts",
    "src/ui/learning/A1ConnectAdditionalTaskPanel.test.ts",
    "src/core/learning/CefrA1ConnectGreetingComprehensionTask.test.ts",
    "src/application/learning/CefrA1ConnectGreetingTaskCompletionService.test.ts",
    "src/application/learning/CefrA1ConnectRuntimeEvidenceService.test.ts"
)

& npx vitest run $targets
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1329-1334 target tests failed."
}

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Full regression failed."
}

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Production build failed."
}

Write-Host "SPRINT-1329-1334 VERIFICATION COMPLETE"
