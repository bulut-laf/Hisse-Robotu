export interface CefrEmbeddedStudioCompletionBindingSafety {
  readonly readingCompletionSignal:
    "finish-reading-mode";
  readonly speakingCompletionSignal:
    "complete-speaking-session";
  readonly dialogueCompletionSignal:
    "complete-dialogue-session";
  readonly completionIsUserAuthorized: true;
  readonly capabilityObservationFabricationAllowed: false;
  readonly automaticMasteryMutationAllowed: false;
  readonly automaticCefrLevelMutationAllowed: false;
  readonly automaticProgressionAllowed: false;
  readonly writingCompletionBindingPending: true;
}

export function createCefrEmbeddedStudioCompletionBindingSafety(): CefrEmbeddedStudioCompletionBindingSafety {
  return {
    readingCompletionSignal:
      "finish-reading-mode",
    speakingCompletionSignal:
      "complete-speaking-session",
    dialogueCompletionSignal:
      "complete-dialogue-session",
    completionIsUserAuthorized: true,
    capabilityObservationFabricationAllowed: false,
    automaticMasteryMutationAllowed: false,
    automaticCefrLevelMutationAllowed: false,
    automaticProgressionAllowed: false,
    writingCompletionBindingPending: true,
  };
}
