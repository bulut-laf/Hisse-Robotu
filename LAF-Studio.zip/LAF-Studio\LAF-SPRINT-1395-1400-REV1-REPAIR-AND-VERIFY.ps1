﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

$panel = Join-Path $app "src\ui\learning\A1ConnectNativeLearningPanel.tsx"
$unitPanel = Join-Path $app "src\ui\learning\A1ConnectUnitRuntimePanel.tsx"
$unitCss = Join-Path $app "src\ui\learning\A1ConnectUnitRuntimePanel.css"
$cssPart = Join-Path $app "src\ui\learning\A1ConnectUnitRuntimePanel.lesson.css"
$readModel = Join-Path $app "src\application\learning\CefrA1ConnectLessonScopedCoverageReadModel.ts"
$safety = Join-Path $app "src\core\learning\CefrA1ConnectLessonContextSafety.ts"

foreach ($file in @(
    $panel,
    $unitPanel,
    $unitCss,
    $cssPart,
    $readModel,
    $safety
)) {
    if (-not (Test-Path $file)) {
        throw "Sprint 1395-1400 source missing: $file"
    }
}

$utf8 =
    New-Object System.Text.UTF8Encoding($false)

# Append small CSS fragment idempotently.
$cssText =
    [System.IO.File]::ReadAllText(
        $unitCss,
        $utf8
    )
$extraCss =
    [System.IO.File]::ReadAllText(
        $cssPart,
        $utf8
    )

if (-not $cssText.Contains(
    ".a1-connect-unit-runtime-lesson {"
)) {
    [System.IO.File]::WriteAllText(
        $unitCss,
        $cssText +
        [Environment]::NewLine +
        $extraCss,
        $utf8
    )
}

Remove-Item $cssPart -Force

# Patch selected lesson identity into the existing UnitRuntimePanel instance.
$text =
    [System.IO.File]::ReadAllText(
        $panel,
        $utf8
    )

$unitPattern =
    '<A1ConnectUnitRuntimePanel\b[\s\S]*?/>'

$unitMatches =
    [regex]::Matches(
        $text,
        $unitPattern,
        [System.Text.RegularExpressions.RegexOptions]::Singleline
    )

if ($unitMatches.Count -ne 1) {
    throw "Expected exactly one A1ConnectUnitRuntimePanel; found $($unitMatches.Count)."
}

$unitBlock =
    $unitMatches[0].Value

if (-not $unitBlock.Contains(
    'selectedLessonId={'
)) {
    $closingIndex =
        $unitBlock.LastIndexOf('/>')

    if ($closingIndex -lt 0) {
        throw "A1ConnectUnitRuntimePanel closing marker missing."
    }

    $prop = @'
          selectedLessonId={
            selectedLesson?.lessonId ?? null
          }
'@

    $newUnitBlock =
        $unitBlock.Insert(
            $closingIndex,
            $prop
        )

    $text =
        $text.Substring(
            0,
            $unitMatches[0].Index
        ) +
        $newUnitBlock +
        $text.Substring(
            $unitMatches[0].Index +
            $unitMatches[0].Length
        )
}

[System.IO.File]::WriteAllText(
    $panel,
    $text,
    $utf8
)

# Verify the task visibility boundary already present in the stable source.
$text =
    [System.IO.File]::ReadAllText(
        $panel,
        $utf8
    )

$visibilityChecks = @(
    @{
        Lesson = '"a1-connect-greeting-response"'
        Task = '<A1ConnectGreetingComprehensionTaskPanel'
    },
    @{
        Lesson = '"a1-connect-greeting-response"'
        Task = 'taskKind="greeting-response"'
    },
    @{
        Lesson = '"a1-connect-self-introduction"'
        Task = 'taskKind="self-introduction"'
    },
    @{
        Lesson = '"a1-connect-personal-questions"'
        Task = 'taskKind="personal-answer"'
    },
    @{
        Lesson = '"a1-connect-personal-questions"'
        Task = 'taskKind="personal-question"'
    },
    @{
        Lesson = '"a1-connect-complete-social-exchange"'
        Task = 'taskKind="reciprocal-exchange"'
    }
)

foreach ($check in $visibilityChecks) {
    if (
        -not $text.Contains($check.Lesson) -or
        -not $text.Contains($check.Task)
    ) {
        throw "Existing lesson/task visibility boundary missing: $($check.Lesson) / $($check.Task)"
    }
}

$sourceChecks = @{
    $unitPanel = @(
        'selectedLessonId?: string | null',
        'createCefrA1ConnectLessonScopedCoverageReadModel(',
        'SEÇİLİ DERS EVIDENCE',
        'Başka ders evidence'
    )
    $readModel = @(
        'getLafA1ConnectEvidenceForLearningItem(',
        'crossLessonEvidenceExcluded: true',
        'delayedRetrievalPending:'
    )
    $safety = @(
        'selectedLessonScopesVisibleTask:',
        'true',
        'lessonSelectionCreatesEvidence: false',
        'lessonSelectionExecutesTask: false',
        'lessonSelectionPerformsProgression:',
        'false'
    )
    $panel = @(
        'selectedLessonId={',
        'selectedLesson?.lessonId ?? null'
    )
}

foreach ($entry in $sourceChecks.GetEnumerator()) {
    foreach ($marker in $entry.Value) {
        if (-not (
            Select-String `
                -Path $entry.Key `
                -SimpleMatch `
                -Pattern $marker `
                -Quiet
        )) {
            throw "Required Sprint 1395-1400 marker missing: $marker"
        }
    }
}

Write-Host "SPRINT-1395-1400 REV1 SOURCE CHECK PASSED"

Set-Location $app

$targets = @(
    "src/core/learning/CefrA1ConnectLessonContextSafety.test.ts",
    "src/application/learning/CefrA1ConnectLessonScopedCoverageReadModel.test.ts",
    "src/ui/learning/A1ConnectUnitRuntimePanel.lesson.test.ts",
    "src/ui/learning/A1ConnectUnitRuntimePanel.test.ts",
    "src/application/learning/CefrA1ConnectLanguageScopedCoverageReadModel.test.ts",
    "src/core/learning/CefrA1ConnectEvidenceCoverage.test.ts",
    "src/core/learning/CefrA1ConnectEvidenceDefinition.test.ts",
    "src/core/learning/CefrA1ConnectTaskContextIsolationSafety.test.ts"
)

& npx vitest run $targets
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1395-1400 Rev1 target tests failed."
}

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Full regression failed."
}

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Production build failed."
}

Write-Host "SPRINT-1395-1400 REV1 VERIFICATION COMPLETE"
