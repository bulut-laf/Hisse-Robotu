import type {
  LafLearningLanguageCode,
} from "../../core/language/LafLanguageProfile";
import {
  LAF_A1_DESCRIBE_ALL_EXECUTABLE_TASKS,
  type CefrA1DescribeAllExecutableTaskId,
} from "../../core/learning/CefrA1DescribeExecutableTaskCatalog";
import {
  CefrProductionRuntimePlatform,
} from "./CefrProductionRuntimePlatform";

export interface CefrA1DescribePersistedCoverageItem {
  readonly taskId:
    CefrA1DescribeAllExecutableTaskId;
  readonly evidenceDefinitionId: string;
  readonly sourceLearningItemId: string;
  readonly observed: boolean;
  readonly matchingEvidenceIds:
    readonly string[];
  readonly persistedRealEvidenceOnly: true;
  readonly targetLanguageScoped: true;
  readonly masteryClaimed: false;
  readonly cefrLevelClaimed: false;
}

export interface CefrA1DescribePersistedCoverageView {
  readonly languageCode:
    LafLearningLanguageCode;
  readonly items:
    readonly CefrA1DescribePersistedCoverageItem[];
  readonly observedImmediateEvidenceCount:
    number;
  readonly immediateEvidenceCount: 6;
  readonly allImmediateEvidenceObserved:
    boolean;
  readonly delayedRetrievalIncluded: false;
  readonly crossLanguageEvidenceExcluded:
    true;
  readonly unscopedEvidenceExcluded: true;
  readonly persistedRealEvidenceOnly: true;
  readonly coverageOnly: true;
  readonly masteryInferred: false;
  readonly cefrLevelInferred: false;
  readonly progressionTriggered: false;
  readonly narrativeSequencingInferred:
    false;
}

export type CefrA1DescribePersistedAdvisoryStatus =
  | "next-persisted-evidence-task"
  | "guided-activation-available"
  | "no-runtime-evidence-defined";

export interface CefrA1DescribePersistedAdvisoryView {
  readonly status:
    CefrA1DescribePersistedAdvisoryStatus;
  readonly nextTaskId:
    CefrA1DescribeAllExecutableTaskId | null;
  readonly evidenceDefinitionId:
    string | null;
  readonly guidedActivationAvailable:
    boolean;
  readonly advisoryOnly: true;
  readonly userApplyRequired: true;
  readonly delayedRetrievalRecommended:
    false;
  readonly delayedRetrievalExecutable:
    false;
  readonly automaticTaskSelection: false;
  readonly automaticEvidenceWrite: false;
  readonly masteryInferred: false;
  readonly cefrLevelInferred: false;
  readonly progressionTriggered: false;
  readonly narrativeSequencingInferred:
    false;
}

export interface CefrA1DescribePersistedEvidenceView {
  readonly coverage:
    CefrA1DescribePersistedCoverageView;
  readonly advisory:
    CefrA1DescribePersistedAdvisoryView;
  readonly readOnly: true;
  readonly learningStateMutated: false;
  readonly masteryMutated: false;
  readonly cefrLevelMutated: false;
  readonly progressionPerformed: false;
  readonly narrativeSequencingPerformed:
    false;
}

const taskByEvidenceDefinitionId =
  new Map<
    string,
    (typeof LAF_A1_DESCRIBE_ALL_EXECUTABLE_TASKS)[number]
  >(
    LAF_A1_DESCRIBE_ALL_EXECUTABLE_TASKS.map(
      task => [
        task.evidenceDefinitionId,
        task,
      ] as const,
    ),
  );

export function createCefrA1DescribePersistedEvidenceView(
  platform:
    CefrProductionRuntimePlatform,
  languageCode:
    LafLearningLanguageCode,
): CefrA1DescribePersistedEvidenceView {
  const runtimeRead =
    platform.readLanguageEvidence(
      "a1-describe",
      languageCode,
    );

  const items =
    runtimeRead.coverage.items.map(
      item => {
        const task =
          taskByEvidenceDefinitionId.get(
            item.evidenceDefinitionId,
          );

        if (!task) {
          throw new Error(
            `A1 DESCRIBE runtime evidence is not mapped to an immediate task: ${item.evidenceDefinitionId}`,
          );
        }

        return {
          taskId: task.taskId,
          evidenceDefinitionId:
            item.evidenceDefinitionId,
          sourceLearningItemId:
            item.sourceLearningItemId,
          observed: item.observed,
          matchingEvidenceIds:
            item.matchingEvidenceIds,
          persistedRealEvidenceOnly: true,
          targetLanguageScoped: true,
          masteryClaimed: false,
          cefrLevelClaimed: false,
        } satisfies
          CefrA1DescribePersistedCoverageItem;
      },
    );

  if (
    items.length !==
    LAF_A1_DESCRIBE_ALL_EXECUTABLE_TASKS.length
  ) {
    throw new Error(
      `A1 DESCRIBE runtime evidence count mismatch: expected 6, received ${items.length}`,
    );
  }

  const observedCount =
    items.filter(
      item => item.observed,
    ).length;

  let advisory:
    CefrA1DescribePersistedAdvisoryView;

  if (
    runtimeRead.advisory.status ===
    "no-authoritative-evidence-defined"
  ) {
    advisory = {
      status:
        "no-runtime-evidence-defined",
      nextTaskId: null,
      evidenceDefinitionId: null,
      guidedActivationAvailable: false,
      advisoryOnly: true,
      userApplyRequired: true,
      delayedRetrievalRecommended: false,
      delayedRetrievalExecutable: false,
      automaticTaskSelection: false,
      automaticEvidenceWrite: false,
      masteryInferred: false,
      cefrLevelInferred: false,
      progressionTriggered: false,
      narrativeSequencingInferred:
        false,
    };
  } else if (
    runtimeRead.advisory.status ===
    "authoritative-evidence-covered"
  ) {
    advisory = {
      status:
        "guided-activation-available",
      nextTaskId: null,
      evidenceDefinitionId: null,
      guidedActivationAvailable: true,
      advisoryOnly: true,
      userApplyRequired: true,
      delayedRetrievalRecommended: false,
      delayedRetrievalExecutable: false,
      automaticTaskSelection: false,
      automaticEvidenceWrite: false,
      masteryInferred: false,
      cefrLevelInferred: false,
      progressionTriggered: false,
      narrativeSequencingInferred:
        false,
    };
  } else {
    const evidenceDefinitionId =
      runtimeRead.advisory
        .evidenceDefinitionId;

    if (!evidenceDefinitionId) {
      throw new Error(
        "A1 DESCRIBE persisted advisory is missing its evidence definition.",
      );
    }

    const task =
      taskByEvidenceDefinitionId.get(
        evidenceDefinitionId,
      );

    if (!task) {
      throw new Error(
        `A1 DESCRIBE persisted advisory points outside immediate runtime tasks: ${evidenceDefinitionId}`,
      );
    }

    advisory = {
      status:
        "next-persisted-evidence-task",
      nextTaskId: task.taskId,
      evidenceDefinitionId,
      guidedActivationAvailable: false,
      advisoryOnly: true,
      userApplyRequired: true,
      delayedRetrievalRecommended: false,
      delayedRetrievalExecutable: false,
      automaticTaskSelection: false,
      automaticEvidenceWrite: false,
      masteryInferred: false,
      cefrLevelInferred: false,
      progressionTriggered: false,
      narrativeSequencingInferred:
        false,
    };
  }

  return {
    coverage: {
      languageCode,
      items,
      observedImmediateEvidenceCount:
        observedCount,
      immediateEvidenceCount: 6,
      allImmediateEvidenceObserved:
        observedCount === 6,
      delayedRetrievalIncluded: false,
      crossLanguageEvidenceExcluded:
        true,
      unscopedEvidenceExcluded: true,
      persistedRealEvidenceOnly: true,
      coverageOnly: true,
      masteryInferred: false,
      cefrLevelInferred: false,
      progressionTriggered: false,
      narrativeSequencingInferred:
        false,
    },
    advisory,
    readOnly: true,
    learningStateMutated: false,
    masteryMutated: false,
    cefrLevelMutated: false,
    progressionPerformed: false,
    narrativeSequencingPerformed:
      false,
  };
}
