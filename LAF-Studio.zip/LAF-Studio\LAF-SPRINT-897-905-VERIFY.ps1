$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 897-899 Target Tests: Custodial Application ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialApplication.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialApplicationCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialApplicationAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 897-899 target tests failed." }

Write-Host "=== Sprint 900-902 Target Tests: Custodial Utilization ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialUtilization.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialUtilizationCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialUtilizationAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 900-902 target tests failed." }

Write-Host "=== Sprint 903-905 Target Tests: Custodial Adoption ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialAdoption.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialAdoptionCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialAdoptionAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 903-905 target tests failed." }

Write-Host "=== Combined Sprint 897-905 New Tests ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialApplication.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialApplicationCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialApplicationAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialUtilization.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialUtilizationCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialUtilizationAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialAdoption.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialAdoptionCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialAdoptionAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 897-905 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-897-905 VERIFICATION COMPLETE"
