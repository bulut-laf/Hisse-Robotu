import {
  describe,
  expect,
  it,
} from "vitest";

import type {
  CefrA1ConnectLanguageScopedCoverageReadModel,
} from "./CefrA1ConnectLanguageScopedCoverageReadModel";
import {
  createCefrA1ConnectLessonScopedCoverageReadModel,
} from "./CefrA1ConnectLessonScopedCoverageReadModel";

const unitCoverage:
  CefrA1ConnectLanguageScopedCoverageReadModel = {
  languageCode: "it",
  coverage: {
    items: [
      {
        evidenceDefinitionId:
          "a1-connect-evidence-greeting-comprehension",
        present: true,
      },
      {
        evidenceDefinitionId:
          "a1-connect-evidence-greeting-response",
        present: false,
      },
      {
        evidenceDefinitionId:
          "a1-connect-evidence-self-introduction",
        present: true,
      },
      {
        evidenceDefinitionId:
          "a1-connect-evidence-personal-answer",
        present: true,
      },
      {
        evidenceDefinitionId:
          "a1-connect-evidence-personal-question",
        present: false,
      },
      {
        evidenceDefinitionId:
          "a1-connect-evidence-reciprocal-exchange",
        present: true,
      },
    ],
    observedImmediateEvidenceCount: 4,
    totalImmediateEvidenceCount: 6,
    delayedRetrievalPending: true,
    progressOnly: true,
    masteryInferred: false,
    cefrLevelInferred: false,
    progressionTriggered: false,
  },
  scopedEvidence: [],
  unscopedImmediateEvidenceCount: 0,
  crossLanguageEvidenceExcluded: true,
  unscopedEvidenceAttributed: false,
  evidenceCoverageIsMastery: false,
};

describe(
  "CefrA1ConnectLessonScopedCoverageReadModel",
  () => {
    it("counts only evidence definitions belonging to the selected lesson", () => {
      expect(
        createCefrA1ConnectLessonScopedCoverageReadModel(
          unitCoverage,
          "a1-connect-greeting-response",
        ),
      ).toEqual({
        lessonId:
          "a1-connect-greeting-response",
        items: [
          {
            evidenceDefinitionId:
              "a1-connect-evidence-greeting-comprehension",
            present: true,
          },
          {
            evidenceDefinitionId:
              "a1-connect-evidence-greeting-response",
            present: false,
          },
        ],
        observedEvidenceCount: 1,
        totalEvidenceCount: 2,
        delayedRetrievalPending: false,
        crossLessonEvidenceExcluded: true,
        progressOnly: true,
        masteryInferred: false,
        cefrLevelInferred: false,
        progressionTriggered: false,
      });
    });

    it("keeps delayed retrieval separate from immediate lesson evidence", () => {
      expect(
        createCefrA1ConnectLessonScopedCoverageReadModel(
          unitCoverage,
          "a1-connect-complete-social-exchange",
        ),
      ).toMatchObject({
        observedEvidenceCount: 1,
        totalEvidenceCount: 1,
        delayedRetrievalPending: true,
        masteryInferred: false,
      });
    });
  },
);
