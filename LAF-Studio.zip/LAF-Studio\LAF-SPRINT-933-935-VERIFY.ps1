$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

Set-Location $app

Write-Host "=== Sprint 933-935 Target Tests: Intelligence Integration Foundation ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceIntegrationSource.test.ts" `
  "src/core/learning/CefrIntelligenceEvidenceEnvelope.test.ts" `
  "src/core/learning/CefrIntelligenceIntegrationGateway.test.ts"

if ($LASTEXITCODE -ne 0) {
  throw "Sprint 933-935 target tests failed."
}

Write-Host "=== Full Regression ==="
npm run test

if ($LASTEXITCODE -ne 0) {
  throw "Full regression failed."
}

Write-Host "=== Production Build ==="
npm run build

if ($LASTEXITCODE -ne 0) {
  throw "Production build failed."
}

Write-Host "SPRINT-933-935 VERIFICATION COMPLETE"
