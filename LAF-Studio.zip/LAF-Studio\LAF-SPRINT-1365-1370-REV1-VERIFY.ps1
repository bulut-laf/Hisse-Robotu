﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

$services = @(
    (Join-Path $app "src\application\learning\CefrA1ConnectGreetingTaskCompletionService.ts"),
    (Join-Path $app "src\application\learning\CefrA1ConnectChoiceTaskCompletionService.ts"),
    (Join-Path $app "src\application\learning\CefrA1ConnectExtendedTaskCompletionService.ts")
)

foreach ($file in $services) {
    if (-not (Test-Path $file)) {
        throw "Sprint 1365-1370 Rev1 service missing: $file"
    }

    foreach ($marker in @(
        'CefrA1ConnectEvidenceProvenanceCoordinator',
        'CefrA1ConnectLanguageEvidenceProvenanceRepository',
        '"recordPersistedEvidenceLanguage" in',
        'new CefrA1ConnectEvidenceProvenanceCoordinator('
    )) {
        if (-not (
            Select-String `
                -Path $file `
                -SimpleMatch `
                -Pattern $marker `
                -Quiet
        )) {
            throw "Sprint 1365-1370 Rev1 compatibility marker missing: $marker"
        }
    }
}

Write-Host "SPRINT-1365-1370 REV1 SOURCE CHECK PASSED"

Set-Location $app

$targets = @(
    "src/application/learning/CefrA1ConnectEvidenceProvenanceConstructorCompatibility.test.ts",
    "src/application/learning/CefrA1ConnectLanguageEvidenceProvenanceIntegration.test.ts",
    "src/core/learning/CefrA1ConnectEvidenceProvenanceRecoveryRecord.test.ts",
    "src/application/learning/CefrA1ConnectEvidenceProvenanceRecoveryRepository.test.ts",
    "src/application/learning/CefrA1ConnectEvidenceProvenanceCoordinator.test.ts",
    "src/core/learning/CefrA1ConnectEvidenceConsistencySafety.test.ts",
    "src/application/learning/CefrA1ConnectEvidenceProvenanceConsistencyIntegration.test.ts",
    "src/ui/learning/A1ConnectEvidenceIntegrityPanel.test.ts",
    "src/application/learning/CefrA1ConnectGreetingTaskCompletionService.test.ts",
    "src/application/learning/CefrA1ConnectChoiceTaskCompletionService.test.ts",
    "src/application/learning/CefrA1ConnectExtendedTaskCompletionService.test.ts"
)

& npx vitest run $targets
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1365-1370 Rev1 target tests failed."
}

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Full regression failed."
}

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Production build failed."
}

Write-Host "SPRINT-1365-1370 REV1 VERIFICATION COMPLETE"
