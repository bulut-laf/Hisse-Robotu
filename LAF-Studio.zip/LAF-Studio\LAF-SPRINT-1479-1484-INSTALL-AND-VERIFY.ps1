﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

$required = @(
    "src\application\learning\CefrA1NavigateSessionState.ts",
    "src\application\learning\CefrA1NavigateSessionState.test.ts",
    "src\application\learning\CefrA1NavigateSessionAdvisory.ts",
    "src\application\learning\CefrA1NavigateSessionAdvisory.test.ts",
    "src\application\learning\CefrA1NavigateGuidedActivation.ts",
    "src\application\learning\CefrA1NavigateGuidedActivation.test.ts",
    "src\core\learning\CefrA1NavigateSessionActivationSafety.ts",
    "src\core\learning\CefrA1NavigateSessionActivationSafety.test.ts",
    "src\ui\learning\LocalStorageA1NavigateSessionStorage.ts",
    "src\ui\learning\LocalStorageA1NavigateSessionStorage.test.ts",
    "src\ui\learning\A1NavigateNativeLearningPanel.tsx",
    "src\ui\learning\A1NavigateNativeLearningPanel.css"
)

foreach ($relative in $required) {
    if (-not (Test-Path (Join-Path $app $relative))) {
        throw "Sprint 1479-1484 required file missing: $relative"
    }
}

$positiveChecks = @(
    @(
      "src\application\learning\CefrA1NavigateSessionAdvisory.ts",
      'delayedRetrievalRecommended: false'
    ),
    @(
      "src\application\learning\CefrA1NavigateSessionAdvisory.ts",
      '"guided-activation-available"'
    ),
    @(
      "src\application\learning\CefrA1NavigateGuidedActivation.ts",
      '"a1-navigate-activation-immediate-everyday-need"'
    ),
    @(
      "src\application\learning\CefrA1NavigateGuidedActivation.ts",
      'activationEvidenceWritten: false'
    ),
    @(
      "src\ui\learning\LocalStorageA1NavigateSessionStorage.ts",
      '"laf.cefr.a1-navigate.session.v1"'
    ),
    @(
      "src\ui\learning\A1NavigateNativeLearningPanel.tsx",
      'Önerilen Görevi Seç'
    ),
    @(
      "src\ui\learning\A1NavigateNativeLearningPanel.tsx",
      'Guided Real-Life Activation'
    ),
    @(
      "src\ui\learning\A1NavigateNativeLearningPanel.tsx",
      'Oturum coverage ≠ global mastery'
    )
)

foreach ($check in $positiveChecks) {
    $path = Join-Path $app $check[0]

    if (-not (
        Select-String `
            -Path $path `
            -SimpleMatch `
            -Pattern $check[1] `
            -Quiet
    )) {
        throw "Sprint 1479-1484 source marker missing: $($check[1])"
    }
}

$panelPath =
    Join-Path $app "src\ui\learning\A1NavigateNativeLearningPanel.tsx"
$panelText =
    [System.IO.File]::ReadAllText($panelPath)

if ($panelText.Contains(
    "a1-navigate-task-delayed-retrieval"
)) {
    throw "Delayed retrieval task exposure detected in native NAVIGATE UI."
}

Write-Host "SPRINT-1479-1484 SOURCE CHECK PASSED"

Set-Location $app

Write-Host ""
Write-Host "CHECKPOINT 1/2 — Sprint 1479-1481 explicit session continuity + advisory"

& npx vitest run @(
    "src/application/learning/CefrA1NavigateSessionState.test.ts",
    "src/application/learning/CefrA1NavigateSessionAdvisory.test.ts",
    "src/ui/learning/LocalStorageA1NavigateSessionStorage.test.ts",
    "src/application/learning/CefrA1NavigateNativeLearningUiModel.test.ts",
    "src/core/learning/CefrA1NavigateExecutableTaskCatalog.test.ts"
)

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1479-1481 target checkpoint failed."
}

Write-Host "SPRINT-1479-1481 TARGET CHECKPOINT PASSED"

Write-Host ""
Write-Host "CHECKPOINT 2/2 — Sprint 1482-1484 guided activation + runtime safety"

& npx vitest run @(
    "src/application/learning/CefrA1NavigateGuidedActivation.test.ts",
    "src/core/learning/CefrA1NavigateSessionActivationSafety.test.ts",
    "src/application/learning/CefrA1NavigateExecutableTaskService.test.ts",
    "src/application/learning/CefrA1NavigateSecondWaveExecutableTaskService.test.ts",
    "src/core/learning/CefrA1NavigateRuntimeSliceDefinition.test.ts",
    "src/core/learning/CefrProductionRuntimeRegistryEnforcement.test.ts",
    "src/application/learning/CefrProductionRuntimeDelayedRetrievalVisibility.test.ts"
)

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1482-1484 target checkpoint failed."
}

Write-Host "SPRINT-1482-1484 TARGET CHECKPOINT PASSED"

Write-Host ""
Write-Host "FINAL 6-SPRINT BLOCK REGRESSION — one full run only"

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1479-1484 final full regression failed."
}

Write-Host ""
Write-Host "FINAL PRODUCTION BUILD"

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1479-1484 production build failed."
}

Write-Host ""
Write-Host "SPRINT-1479-1484 VERIFICATION COMPLETE"
