import {
  describe,
  expect,
  it,
} from "vitest";

import {
  A1_CONNECT_SESSION_STORAGE_KEY,
  CefrA1ConnectSessionStateRepository,
} from "./CefrA1ConnectSessionStateRepository";

class MemoryStorage {
  private readonly values =
    new Map<string, string>();

  getItem(key: string): string | null {
    return this.values.get(key) ?? null;
  }

  setItem(
    key: string,
    value: string,
  ): void {
    this.values.set(key, value);
  }

  removeItem(key: string): void {
    this.values.delete(key);
  }
}

describe(
  "CefrA1ConnectSessionStateRepository",
  () => {
    it("restores explicit user language and lesson selection without creating learning evidence", () => {
      const storage =
        new MemoryStorage();
      const repository =
        new CefrA1ConnectSessionStateRepository(
          storage,
        );

      repository.saveSelection(
        "it",
        "a1-connect-personal-questions",
        new Date(
          "2026-08-11T18:35:00.000Z",
        ),
      );

      expect(repository.load()).toMatchObject({
        selectedLanguageCode: "it",
        selectedLessonId:
          "a1-connect-personal-questions",
        learningDecisionClaimed: false,
        masteryClaimed: false,
        cefrLevelClaimed: false,
      });

      expect(
        storage.getItem(
          A1_CONNECT_SESSION_STORAGE_KEY,
        ),
      ).not.toContain("evidenceId");
    });
  },
);
