import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrPersonalLanguageProfileState,
  type CefrPersonalLanguageProfileState,
} from "../../core/learning/CefrPersonalLanguageProfileState";
import {
  createCefrA1ConnectLanguageEvidenceProvenance,
} from "../../core/learning/CefrA1ConnectLanguageEvidenceProvenance";
import type {
  CefrGuidanceRuntimeProfileRepository,
} from "./CefrGuidanceRuntimeProfileRepository";
import {
  CefrA1ConnectLanguageEvidenceProvenanceRepository,
} from "./CefrA1ConnectLanguageEvidenceProvenanceRepository";
import {
  createCefrA1ConnectLanguageScopedCoverageReadModel,
} from "./CefrA1ConnectLanguageScopedCoverageReadModel";

class MemoryStorage {
  private readonly values =
    new Map<string, string>();

  getItem(key: string): string | null {
    return this.values.get(key) ?? null;
  }

  setItem(
    key: string,
    value: string,
  ): void {
    this.values.set(key, value);
  }

  removeItem(key: string): void {
    this.values.delete(key);
  }
}

class MemoryProfileRepository
  implements CefrGuidanceRuntimeProfileRepository {
  private state:
    CefrPersonalLanguageProfileState;

  constructor(
    state: CefrPersonalLanguageProfileState,
  ) {
    this.state = state;
  }

  load(): CefrPersonalLanguageProfileState {
    return this.state;
  }

  save(
    state: CefrPersonalLanguageProfileState,
  ): void {
    this.state = state;
  }

  hasPersistedProfile(): boolean {
    return true;
  }

  clear(): void {
    this.state =
      createCefrPersonalLanguageProfileState(
        [],
        [],
      );
  }
}

describe(
  "CefrA1ConnectLanguageScopedCoverageReadModel",
  () => {
    it("does not let Italian evidence satisfy Hungarian coverage", () => {
      const italianEvidenceId =
        "a1-connect-runtime-evidence:a1-connect-evidence-greeting-comprehension:it-1";

      const state =
        createCefrPersonalLanguageProfileState(
          [
            {
              evidenceId:
                italianEvidenceId,
              source:
                "learning-studio",
              observedAt:
                "2026-08-11T18:55:00.000Z",
              payloadReference: "payload",
              masteryClaimed: false,
              cefrLevelClaimed: false,
            },
          ],
          [],
        );

      const provenance =
        new CefrA1ConnectLanguageEvidenceProvenanceRepository(
          new MemoryStorage(),
        );

      provenance.save(
        createCefrA1ConnectLanguageEvidenceProvenance({
          evidenceId:
            italianEvidenceId,
          languageCode: "it",
          observedAt:
            new Date(
              "2026-08-11T18:55:00.000Z",
            ),
        }),
      );

      expect(
        createCefrA1ConnectLanguageScopedCoverageReadModel(
          new MemoryProfileRepository(
            state,
          ),
          provenance,
          "hu",
        ).coverage
          .observedImmediateEvidenceCount,
      ).toBe(0);

      expect(
        createCefrA1ConnectLanguageScopedCoverageReadModel(
          new MemoryProfileRepository(
            state,
          ),
          provenance,
          "it",
        ).coverage
          .observedImmediateEvidenceCount,
      ).toBe(1);
    });

    it("does not silently attribute legacy unscoped evidence to the selected language", () => {
      const state =
        createCefrPersonalLanguageProfileState(
          [
            {
              evidenceId:
                "a1-connect-runtime-evidence:a1-connect-evidence-self-introduction:legacy",
              source:
                "learning-studio",
              observedAt:
                "2026-08-11T18:56:00.000Z",
              payloadReference: "payload",
              masteryClaimed: false,
              cefrLevelClaimed: false,
            },
          ],
          [],
        );

      const result =
        createCefrA1ConnectLanguageScopedCoverageReadModel(
          new MemoryProfileRepository(
            state,
          ),
          new CefrA1ConnectLanguageEvidenceProvenanceRepository(
            new MemoryStorage(),
          ),
          "de",
        );

      expect(
        result.coverage
          .observedImmediateEvidenceCount,
      ).toBe(0);
      expect(
        result.unscopedImmediateEvidenceCount,
      ).toBe(1);
      expect(
        result.unscopedEvidenceAttributed,
      ).toBe(false);
    });
  },
);
