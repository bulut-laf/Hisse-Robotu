﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$testPath = Join-Path $app "src\application\learning\CefrA1DescribeTargetLanguageSelectionModel.test.ts"

if (-not (Test-Path $testPath)) {
    throw "Target test file missing: $testPath"
}

$utf8 = New-Object System.Text.UTF8Encoding($false)
$text = [System.IO.File]::ReadAllText($testPath, $utf8)

$old = "executableTaskCount: 3,"
$new = "executableTaskCount: 6,"

$count = [regex]::Matches($text, [regex]::Escape($old)).Count

if ($count -eq 1) {
    $backupRoot = Join-Path $root ("_sprint_backups\Sprint1515-1523-Rev1-" + (Get-Date -Format "yyyyMMdd-HHmmss"))
    New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null
    Copy-Item -LiteralPath $testPath -Destination (Join-Path $backupRoot "CefrA1DescribeTargetLanguageSelectionModel.test.ts") -Force

    $text = $text.Replace($old, $new)
    $text = $text.Replace(
        "exposes the first three executable tasks only after explicit target-language selection",
        "exposes all six immediate executable tasks only after explicit target-language selection"
    )

    [System.IO.File]::WriteAllText($testPath, $text, $utf8)
    Write-Host "Rev1 stale 3-task expectation repaired to 6."
}
elseif ($count -eq 0 -and $text.Contains($new)) {
    Write-Host "Rev1 repair already present; continuing verification."
}
else {
    throw "Unexpected stale expectation state. Found $count old markers."
}

$verify = [System.IO.File]::ReadAllText($testPath, $utf8)
if (-not $verify.Contains($new) -or $verify.Contains($old)) {
    throw "Rev1 expectation verification failed."
}

$vitestPath = Join-Path $app "node_modules\.bin\vitest.cmd"
if (-not (Test-Path $vitestPath)) {
    throw "Local Vitest command missing: $vitestPath"
}

$npmPath = (Get-Command "npm.cmd" -ErrorAction Stop).Source
if (-not $npmPath) {
    throw "npm.cmd path could not be resolved."
}

Set-Location $app

Write-Host ""
Write-Host "REV1 TARGET TEST"
& $vitestPath run "src/application/learning/CefrA1DescribeTargetLanguageSelectionModel.test.ts"
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1515-1523 Rev1 repaired target test failed."
}

Write-Host ""
Write-Host "FINAL FULL REGRESSION"
& $npmPath run test
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1515-1523 Rev1 final full regression failed."
}

Write-Host ""
Write-Host "FINAL PRODUCTION BUILD"
& $npmPath run build
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1515-1523 Rev1 production build failed."
}

Write-Host ""
Write-Host "SPRINT-1515-1523 REV1 VERIFICATION COMPLETE"
