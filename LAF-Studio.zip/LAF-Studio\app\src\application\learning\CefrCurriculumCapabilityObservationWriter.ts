import type {
  CefrCapabilityTaxonomyRegistry,
} from "../../core/learning/CefrCapabilityTaxonomyRegistry";
import type {
  CefrCompetencyCapabilityMappingRegistry,
} from "../../core/learning/CefrCompetencyCapabilityMappingRegistry";
import type {
  CefrCurriculumCompetencyRegistry,
} from "../../core/learning/CefrCurriculumCompetencyRegistry";
import {
  writeCefrCurriculumCapabilityObservations,
  type CefrCurriculumCapabilityObservationWriteResult,
} from "../../core/learning/CefrCurriculumCapabilityObservationWrite";
import type {
  CefrGuidanceRuntimeProfileRepository,
} from "./CefrGuidanceRuntimeProfileRepository";

export interface CefrCurriculumCapabilityObservationWriterInput {
  readonly learningItemType: string;
  readonly learningItemId: string;
  readonly evidenceId: string;
}

export class CefrCurriculumCapabilityObservationWriter {
  private readonly repository:
    CefrGuidanceRuntimeProfileRepository;

  private readonly curriculumRegistry:
    CefrCurriculumCompetencyRegistry;

  private readonly capabilityTaxonomyRegistry:
    CefrCapabilityTaxonomyRegistry;

  private readonly competencyCapabilityMappingRegistry:
    CefrCompetencyCapabilityMappingRegistry;

  constructor(
    repository:
      CefrGuidanceRuntimeProfileRepository,
    curriculumRegistry:
      CefrCurriculumCompetencyRegistry,
    capabilityTaxonomyRegistry:
      CefrCapabilityTaxonomyRegistry,
    competencyCapabilityMappingRegistry:
      CefrCompetencyCapabilityMappingRegistry,
  ) {
    this.repository = repository;
    this.curriculumRegistry =
      curriculumRegistry;
    this.capabilityTaxonomyRegistry =
      capabilityTaxonomyRegistry;
    this.competencyCapabilityMappingRegistry =
      competencyCapabilityMappingRegistry;
  }

  write(
    input:
      CefrCurriculumCapabilityObservationWriterInput,
  ): CefrCurriculumCapabilityObservationWriteResult {
    const result =
      writeCefrCurriculumCapabilityObservations({
        currentState: this.repository.load(),
        curriculumRegistry:
          this.curriculumRegistry,
        capabilityTaxonomyRegistry:
          this.capabilityTaxonomyRegistry,
        competencyCapabilityMappingRegistry:
          this.competencyCapabilityMappingRegistry,
        learningItemType:
          input.learningItemType,
        learningItemId:
          input.learningItemId,
        evidenceId:
          input.evidenceId,
      });

    if (
      result.observationCountAdded > 0
    ) {
      this.repository.save(result.state);
    }

    return result;
  }
}
