﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app  = Join-Path $root "app"

$practice = Join-Path $app "src\core\learning\CefrA1ConnectPracticeDefinition.ts"
$interaction = Join-Path $app "src\core\learning\CefrA1ConnectInteractionDefinition.ts"
$evidence = Join-Path $app "src\core\learning\CefrA1ConnectEvidenceDefinition.ts"
$activation = Join-Path $app "src\core\learning\CefrA1ConnectActivationDefinition.ts"

$requiredFiles = @(
    $practice,
    $interaction,
    $evidence,
    $activation
)

foreach ($file in $requiredFiles) {
    if (-not (Test-Path $file)) {
        throw "A1 CONNECT experience source missing: $file"
    }
}

$requiredMarkers = @{
    $interaction = @(
        '"a1-connect-interaction-greeting"',
        '"a1-connect-interaction-introduction"',
        '"a1-connect-interaction-first-encounter"'
    )
    $evidence = @(
        '"a1-connect-evidence-greeting-comprehension"',
        '"a1-connect-evidence-reciprocal-exchange"',
        '"a1-connect-evidence-delayed-retrieval"'
    )
    $activation = @(
        '"a1-connect-activation-first-social-encounter"',
        'masteryGate: false',
        'automaticProgression: false'
    )
}

foreach ($entry in $requiredMarkers.GetEnumerator()) {
    foreach ($marker in $entry.Value) {
        if (-not (
            Select-String -Path $entry.Key -SimpleMatch `
                -Pattern $marker -Quiet
        )) {
            throw "Required A1 CONNECT marker missing: $marker"
        }
    }
}

Write-Host "SPRINT-1293-1298 SOURCE CHECK PASSED"

Set-Location $app

$targets = @(
    "src/core/learning/CefrA1ConnectPracticeDefinition.test.ts",
    "src/core/learning/CefrA1ConnectInteractionDefinition.test.ts",
    "src/core/learning/CefrA1ConnectEvidenceDefinition.test.ts",
    "src/core/learning/CefrA1ConnectActivationDefinition.test.ts",
    "src/core/learning/CefrA1ConnectLearningExperienceCatalog.test.ts",
    "src/core/learning/CefrA1ConnectExperienceSafety.test.ts",
    "src/core/learning/CefrAuthoritativeCurriculumCatalog.test.ts",
    "src/core/learning/CefrAuthoritativeCurriculumRegistry.test.ts",
    "src/core/learning/CefrA1ConnectAuthoritativeCurriculumIntegration.test.ts"
)

& npx vitest run $targets
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1293-1298 target tests failed."
}

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Full regression failed."
}

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Production build failed."
}

Write-Host "SPRINT-1293-1298 VERIFICATION COMPLETE"
