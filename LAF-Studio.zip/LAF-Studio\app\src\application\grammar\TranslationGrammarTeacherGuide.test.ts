import {
  describe,
  expect,
  it,
} from "vitest";

import {
  prepareTranslationGrammarTeacherGuide,
} from "./TranslationGrammarTeacherGuide";

describe(
  "prepareTranslationGrammarTeacherGuide",
  () => {
    it("accepts a complete beginner guide", () => {
      expect(
        prepareTranslationGrammarTeacherGuide({
          simpleExplanation:
            "-val/-vel Türkçedeki 'ile' anlamına yaklaşır.",
          whyHere:
            "busszal, yolculuğun hangi araçla yapıldığını söyler.",
          examples: [
            {
              sourceText:
                "Autóval megyek.",
              targetText:
                "Arabayla gidiyorum.",
            },
            {
              sourceText:
                "A barátommal beszélek.",
              targetText:
                "Arkadaşımla konuşuyorum.",
            },
          ],
          commonMistake:
            "Ünsüzle biten kelimelerde benzeşmeyi unutmayın.",
        }),
      ).toEqual({
        status: "ready",
        issues: [],
        guide: {
          simpleExplanation:
            "-val/-vel Türkçedeki 'ile' anlamına yaklaşır.",
          whyHere:
            "busszal, yolculuğun hangi araçla yapıldığını söyler.",
          examples: [
            {
              sourceText:
                "Autóval megyek.",
              targetText:
                "Arabayla gidiyorum.",
            },
            {
              sourceText:
                "A barátommal beszélek.",
              targetText:
                "Arkadaşımla konuşuyorum.",
            },
          ],
          commonMistake:
            "Ünsüzle biten kelimelerde benzeşmeyi unutmayın.",
        },
      });
    });

    it("trims guide text and example fields", () => {
      const result =
        prepareTranslationGrammarTeacherGuide({
          simpleExplanation:
            "  Basit açıklama.  ",
          whyHere:
            "  Bu cümledeki nedeni.  ",
          examples: [
            {
              sourceText:
                "  Példa.  ",
              targetText:
                "  Örnek.  ",
            },
          ],
          commonMistake:
            "  Yaygın hata.  ",
        });

      expect(result).toMatchObject({
        status: "ready",
        guide: {
          simpleExplanation:
            "Basit açıklama.",
          whyHere:
            "Bu cümledeki nedeni.",
          examples: [
            {
              sourceText: "Példa.",
              targetText: "Örnek.",
            },
          ],
          commonMistake:
            "Yaygın hata.",
        },
      });
    });

    it("keeps at most three valid examples", () => {
      const result =
        prepareTranslationGrammarTeacherGuide({
          simpleExplanation: "A",
          whyHere: "B",
          examples: [
            {
              sourceText: "1",
              targetText: "1T",
            },
            {
              sourceText: "2",
              targetText: "2T",
            },
            {
              sourceText: "3",
              targetText: "3T",
            },
            {
              sourceText: "4",
              targetText: "4T",
            },
          ],
          commonMistake: "C",
        });

      expect(
        result.status === "ready"
          ? result.guide.examples
          : [],
      ).toHaveLength(3);
    });

    it("ignores malformed examples when valid examples remain", () => {
      const result =
        prepareTranslationGrammarTeacherGuide({
          simpleExplanation: "A",
          whyHere: "B",
          examples: [
            {
              sourceText: "",
              targetText: "Geçersiz",
            },
            {
              sourceText: "Valid",
              targetText: "Geçerli",
            },
          ],
          commonMistake: "C",
        });

      expect(
        result.status === "ready"
          ? result.guide.examples
          : [],
      ).toEqual([
        {
          sourceText: "Valid",
          targetText: "Geçerli",
        },
      ]);
    });

    it("blocks missing simple explanation", () => {
      const result =
        prepareTranslationGrammarTeacherGuide({
          simpleExplanation: "",
          whyHere: "B",
          examples: [
            {
              sourceText: "A",
              targetText: "B",
            },
          ],
          commonMistake: "C",
        });

      expect(result.status).toBe(
        "blocked",
      );
      expect(
        result.status === "blocked"
          ? result.issues
          : [],
      ).toContainEqual({
        code:
          "missing-simple-explanation",
      });
    });

    it("blocks missing why-here explanation", () => {
      const result =
        prepareTranslationGrammarTeacherGuide({
          simpleExplanation: "A",
          whyHere: "",
          examples: [
            {
              sourceText: "A",
              targetText: "B",
            },
          ],
          commonMistake: "C",
        });

      expect(result.status).toBe(
        "blocked",
      );
      expect(
        result.status === "blocked"
          ? result.issues
          : [],
      ).toContainEqual({
        code: "missing-why-here",
      });
    });

    it("blocks a guide with no valid example", () => {
      const result =
        prepareTranslationGrammarTeacherGuide({
          simpleExplanation: "A",
          whyHere: "B",
          examples: [],
          commonMistake: "C",
        });

      expect(result.status).toBe(
        "blocked",
      );
      expect(
        result.status === "blocked"
          ? result.issues
          : [],
      ).toContainEqual({
        code: "invalid-examples",
      });
    });

    it("blocks missing common mistake", () => {
      const result =
        prepareTranslationGrammarTeacherGuide({
          simpleExplanation: "A",
          whyHere: "B",
          examples: [
            {
              sourceText: "A",
              targetText: "B",
            },
          ],
          commonMistake: "",
        });

      expect(result.status).toBe(
        "blocked",
      );
      expect(
        result.status === "blocked"
          ? result.issues
          : [],
      ).toContainEqual({
        code: "missing-common-mistake",
      });
    });

    it("blocks non-object provider output", () => {
      expect(
        prepareTranslationGrammarTeacherGuide(
          "invalid",
        ),
      ).toEqual({
        status: "blocked",
        issues: [
          {
            code: "invalid-response",
          },
        ],
      });
    });
  },
);
