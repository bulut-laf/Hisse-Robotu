import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrPersonalLanguageProfileState,
  type CefrPersonalLanguageProfileState,
} from "../../core/learning/CefrPersonalLanguageProfileState";
import {
  createCefrA1ConnectGreetingResponseTask,
  createCefrA1ConnectSelfIntroductionTask,
} from "../../core/learning/CefrA1ConnectAdditionalExecutableTasks";
import type {
  CefrGuidanceRuntimeProfileRepository,
} from "./CefrGuidanceRuntimeProfileRepository";
import {
  CefrA1ConnectChoiceTaskCompletionService,
} from "./CefrA1ConnectChoiceTaskCompletionService";

class MemoryRepository
  implements CefrGuidanceRuntimeProfileRepository {
  private state:
    CefrPersonalLanguageProfileState =
      createCefrPersonalLanguageProfileState(
        [],
        [],
      );

  private persisted = false;

  load(): CefrPersonalLanguageProfileState {
    return this.state;
  }

  save(
    state: CefrPersonalLanguageProfileState,
  ): void {
    this.state = state;
    this.persisted = true;
  }

  hasPersistedProfile(): boolean {
    return this.persisted;
  }

  clear(): void {
    this.state =
      createCefrPersonalLanguageProfileState(
        [],
        [],
      );
    this.persisted = false;
  }
}

describe(
  "CefrA1ConnectChoiceTaskCompletionService",
  () => {
    it("persists greeting-response evidence only after correct submission", () => {
      const repository =
        new MemoryRepository();
      const service =
        new CefrA1ConnectChoiceTaskCompletionService(
          repository,
        );
      const task =
        createCefrA1ConnectGreetingResponseTask(
          "de",
        );

      const wrong =
        service.submit({
          taskKind: "greeting-response",
          languageCode: "de",
          submittedAnswer:
            "wrong",
          eventId: "greeting-wrong",
          occurredAt:
            new Date(
              "2026-08-11T17:00:00.000Z",
            ),
          userActionConfirmed: true,
        });

      expect(wrong.evidencePersisted).toBe(
        false,
      );

      const correct =
        service.submit({
          taskKind: "greeting-response",
          languageCode: "de",
          submittedAnswer:
            task.correctAnswer,
          eventId: "greeting-correct",
          occurredAt:
            new Date(
              "2026-08-11T17:01:00.000Z",
            ),
          userActionConfirmed: true,
        });

      expect(correct).toMatchObject({
        evidencePersisted: true,
        capabilityObservationWritten: true,
        masteryAssigned: false,
        competencySuccessAssigned: false,
        cefrLevelAssigned: false,
        progressionPerformed: false,
      });
    });

    it("persists self-introduction evidence as observational social-exchange only", () => {
      const repository =
        new MemoryRepository();
      const service =
        new CefrA1ConnectChoiceTaskCompletionService(
          repository,
        );
      const task =
        createCefrA1ConnectSelfIntroductionTask(
          "it",
        );

      const result =
        service.submit({
          taskKind: "self-introduction",
          languageCode: "it",
          submittedAnswer:
            task.correctAnswer,
          eventId: "intro-correct",
          occurredAt:
            new Date(
              "2026-08-11T17:05:00.000Z",
            ),
          userActionConfirmed: true,
        });

      expect(result.evidencePersisted).toBe(
        true,
      );

      expect(
        repository.load()
          .capabilityObservationRegistry
          .observations,
      ).toEqual([
        {
          capabilityReference:
            "social-exchange",
          evidenceId:
            "a1-connect-runtime-evidence:a1-connect-evidence-self-introduction:intro-correct",
          source: "learning-studio",
          observationalOnly: true,
        },
      ]);
    });
  },
);
