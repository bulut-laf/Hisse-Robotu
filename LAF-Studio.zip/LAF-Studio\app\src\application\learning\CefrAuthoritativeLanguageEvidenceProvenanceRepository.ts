import type {
  LafLearningLanguageCode,
} from "../../core/language/LafLanguageProfile";
import type {
  CefrAuthoritativeLanguageEvidenceProvenance,
} from "../../core/learning/CefrAuthoritativeLanguageEvidenceProvenance";
import type {
  CefrLanguageEvidenceProvenanceAuthority,
} from "../../core/learning/CefrLanguageEvidenceProvenanceAuthority";

export interface CefrLanguageEvidenceStorageLike {
  getItem(key: string): string | null;
  setItem(
    key: string,
    value: string,
  ): void;
  removeItem(key: string): void;
}

interface StoredEnvelope {
  readonly version: 1;
  readonly items:
    readonly CefrAuthoritativeLanguageEvidenceProvenance[];
}

function isProvenance(
  value: unknown,
  authority:
    CefrLanguageEvidenceProvenanceAuthority,
): value is CefrAuthoritativeLanguageEvidenceProvenance {
  if (
    typeof value !== "object" ||
    value === null
  ) {
    return false;
  }

  const item =
    value as Partial<CefrAuthoritativeLanguageEvidenceProvenance>;

  return (
    typeof item.evidenceId === "string" &&
    typeof item.languageCode === "string" &&
    typeof item.observedAt === "string" &&
    item.source === authority.source &&
    item.authoritativeLanguageProvenance ===
      true &&
    item.masteryClaimed === false &&
    item.cefrLevelClaimed === false
  );
}

export class CefrAuthoritativeLanguageEvidenceProvenanceRepository {
  private readonly authority:
    CefrLanguageEvidenceProvenanceAuthority;

  private readonly storage:
    CefrLanguageEvidenceStorageLike | null;

  constructor(
    authority:
      CefrLanguageEvidenceProvenanceAuthority,
    storage:
      CefrLanguageEvidenceStorageLike | null =
        typeof window !== "undefined"
          ? window.localStorage
          : null,
  ) {
    this.authority = authority;
    this.storage = storage;
  }

  loadAll():
    readonly CefrAuthoritativeLanguageEvidenceProvenance[] {
    if (!this.storage) {
      return [];
    }

    const raw =
      this.storage.getItem(
        this.authority.storageKey,
      );

    if (!raw) {
      return [];
    }

    try {
      const parsed =
        JSON.parse(
          raw,
        ) as Partial<StoredEnvelope>;

      if (
        parsed.version !== 1 ||
        !Array.isArray(parsed.items)
      ) {
        return [];
      }

      return parsed.items.filter(
        item =>
          isProvenance(
            item,
            this.authority,
          ),
      );
    }
    catch {
      return [];
    }
  }

  save(
    provenance:
      CefrAuthoritativeLanguageEvidenceProvenance,
  ):
    CefrAuthoritativeLanguageEvidenceProvenance {
    if (
      provenance.source !==
      this.authority.source
    ) {
      throw new Error(
        `Evidence language provenance source conflict: ${provenance.evidenceId}`,
      );
    }

    const all =
      this.loadAll();

    const existing =
      all.find(
        item =>
          item.evidenceId ===
          provenance.evidenceId,
      );

    if (
      existing &&
      existing.languageCode !==
        provenance.languageCode
    ) {
      throw new Error(
        `Evidence language provenance conflict: ${provenance.evidenceId}`,
      );
    }

    if (!this.storage) {
      return existing ?? provenance;
    }

    const next =
      existing
        ? all
        : [
            ...all,
            provenance,
          ];

    this.storage.setItem(
      this.authority.storageKey,
      JSON.stringify({
        version: 1,
        items: next,
      }),
    );

    return existing ?? provenance;
  }

  findByEvidenceId(
    evidenceId: string,
  ):
    CefrAuthoritativeLanguageEvidenceProvenance | null {
    return (
      this.loadAll().find(
        item =>
          item.evidenceId === evidenceId,
      ) ?? null
    );
  }

  findForLanguage(
    languageCode: LafLearningLanguageCode,
  ):
    readonly CefrAuthoritativeLanguageEvidenceProvenance[] {
    return this.loadAll().filter(
      item =>
        item.languageCode ===
        languageCode,
    );
  }

  clear(): void {
    this.storage?.removeItem(
      this.authority.storageKey,
    );
  }
}
