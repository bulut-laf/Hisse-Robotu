import {
  createCefrA1ConnectEvidenceCoverage,
  type CefrA1ConnectEvidenceCoverage,
} from "../../core/learning/CefrA1ConnectEvidenceCoverage";
import type {
  CefrGuidanceRuntimeProfileRepository,
} from "./CefrGuidanceRuntimeProfileRepository";

export interface CefrA1ConnectEvidenceCoverageReadModel {
  readonly coverage:
    CefrA1ConnectEvidenceCoverage;
  readonly evidenceCoverageIsMastery:
    false;
  readonly delayedRetrievalEvidenceWritten:
    false;
}

export function createCefrA1ConnectEvidenceCoverageReadModel(
  repository:
    CefrGuidanceRuntimeProfileRepository,
): CefrA1ConnectEvidenceCoverageReadModel {
  const state = repository.load();

  return {
    coverage:
      createCefrA1ConnectEvidenceCoverage(
        state.profileSnapshot
          .evidenceAggregation.evidence,
      ),
    evidenceCoverageIsMastery: false,
    delayedRetrievalEvidenceWritten: false,
  };
}
