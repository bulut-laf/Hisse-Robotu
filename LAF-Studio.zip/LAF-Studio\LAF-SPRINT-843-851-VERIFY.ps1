$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 843-845 Target Tests: Custodial Connectivity ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialConnectivity.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialConnectivityCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialConnectivityAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 843-845 target tests failed." }

Write-Host "=== Sprint 846-848 Target Tests: Custodial Coherence ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialCoherence.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialCoherenceCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialCoherenceAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 846-848 target tests failed." }

Write-Host "=== Sprint 849-851 Target Tests: Custodial Alignment ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialAlignment.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialAlignmentCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialAlignmentAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 849-851 target tests failed." }

Write-Host "=== Combined Sprint 843-851 New Tests ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialConnectivity.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialConnectivityCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialConnectivityAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialCoherence.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialCoherenceCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialCoherenceAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialAlignment.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialAlignmentCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialAlignmentAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 843-851 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-843-851 VERIFICATION COMPLETE"
