import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrPersonalLanguageProfileState,
  type CefrPersonalLanguageProfileState,
} from "../../core/learning/CefrPersonalLanguageProfileState";
import type {
  CefrLanguageEvidenceStorageLike,
} from "./CefrAuthoritativeLanguageEvidenceProvenanceRepository";
import type {
  CefrGuidanceRuntimeProfileRepository,
} from "./CefrGuidanceRuntimeProfileRepository";
import {
  CefrProductionRuntimePlatform,
} from "./CefrProductionRuntimePlatform";
import {
  createCefrA1AuthoritativeJourneyView,
} from "./CefrA1AuthoritativeJourneyView";

class MemoryProfileRepository
  implements CefrGuidanceRuntimeProfileRepository {
  private state:
    CefrPersonalLanguageProfileState =
      createCefrPersonalLanguageProfileState(
        [],
        [],
      );

  load(): CefrPersonalLanguageProfileState {
    return this.state;
  }

  save(
    state: CefrPersonalLanguageProfileState,
  ): void {
    this.state = state;
  }

  hasPersistedProfile(): boolean {
    return false;
  }

  clear(): void {}
}

class MemoryStorage
  implements CefrLanguageEvidenceStorageLike {
  private readonly items =
    new Map<string, string>();

  getItem(key: string): string | null {
    return this.items.get(key) ?? null;
  }

  setItem(
    key: string,
    value: string,
  ): void {
    this.items.set(key, value);
  }

  removeItem(key: string): void {
    this.items.delete(key);
  }
}

function createPlatform() {
  return new CefrProductionRuntimePlatform(
    new MemoryProfileRepository(),
    new MemoryStorage(),
  );
}

describe(
  "A1 authoritative Learning Journey view",
  () => {
    it("combines exactly the approved CONNECT, NAVIGATE, and DESCRIBE production runtime slices", () => {
      const result =
        createCefrA1AuthoritativeJourneyView(
          createPlatform(),
          "hu",
        );

      expect(result).toMatchObject({
        levelCode: "A1",
        levelIdentity: "RESPOND",
        languageCode: "hu",
        activeAuthoritativeSliceCount: 3,
        totalObservedImmediateEvidenceCount:
          0,
        totalImmediateEvidenceCount: 18,
        targetLanguageScoped: true,
        crossLanguageEvidenceExcluded:
          true,
        unscopedEvidenceExcluded: true,
        delayedRetrievalIncluded: false,
        coverageOnly: true,
        masteryInferred: false,
        cefrLevelInferred: false,
        automaticProgressionPerformed:
          false,
      });

      expect(
        result.slices.map(
          slice => slice.sliceId,
        ),
      ).toEqual([
        "a1-connect",
        "a1-navigate",
        "a1-describe",
      ]);

      expect(
        result.slices.map(
          slice =>
            slice.immediateEvidenceCount,
        ),
      ).toEqual([6, 6, 6]);

      expect(
        result.slices[2],
      ).toMatchObject({
        moduleFamily:
          "DESCRIBE & NARRATE",
        competencyOutcomeId:
          "describe-narrate-a1",
        capabilityReference:
          "description-production",
        unitId:
          "a1-describe-basic-familiar-world",
      });
    });

    it("reads persisted evidence independently for all three A1 slices and exact target language", () => {
      const platform =
        createPlatform();

      platform.recordUserEvidence(
        "a1-connect",
        {
          evidenceDefinitionId:
            "a1-connect-evidence-greeting-comprehension",
          eventId:
            "journey-connect-hu",
          occurredAt:
            new Date(
              "2026-08-12T13:00:00.000Z",
            ),
          languageCode: "hu",
          userActionConfirmed: true,
        },
      );

      platform.recordUserEvidence(
        "a1-navigate",
        {
          evidenceDefinitionId:
            "a1-navigate-evidence-need-comprehension",
          eventId:
            "journey-navigate-hu",
          occurredAt:
            new Date(
              "2026-08-12T13:01:00.000Z",
            ),
          languageCode: "hu",
          userActionConfirmed: true,
        },
      );

      platform.recordUserEvidence(
        "a1-describe",
        {
          evidenceDefinitionId:
            "a1-describe-evidence-basic-feature",
          eventId:
            "journey-describe-hu",
          occurredAt:
            new Date(
              "2026-08-12T13:02:00.000Z",
            ),
          languageCode: "hu",
          userActionConfirmed: true,
        },
      );

      const hu =
        createCefrA1AuthoritativeJourneyView(
          platform,
          "hu",
        );

      expect(
        hu.slices.map(
          slice =>
            slice.observedImmediateEvidenceCount,
        ),
      ).toEqual([1, 1, 1]);

      expect(
        hu.totalObservedImmediateEvidenceCount,
      ).toBe(3);

      const en =
        createCefrA1AuthoritativeJourneyView(
          platform,
          "en",
        );

      expect(
        en.totalObservedImmediateEvidenceCount,
      ).toBe(0);
    });

    it("does not expose delayed retrieval as part of the 18 immediate evidence journey", () => {
      const result =
        createCefrA1AuthoritativeJourneyView(
          createPlatform(),
          "de",
        );

      for (const slice of result.slices) {
        expect(
          slice.delayedRetrievalIncluded,
        ).toBe(false);
        expect(slice.coverageOnly).toBe(
          true,
        );
        expect(slice.masteryInferred).toBe(
          false,
        );
      }
    });
  },
);
