import type {
  TranslationLanguageCode,
} from "../../core/translation/TranslationDraft";
import type {
  TranslationDialogueScenarioId,
} from "./TranslationDialogueScenario";

export type TranslationDialogueSpeaker =
  | "partner"
  | "learner";

export interface TranslationDialogueHistoryTurn {
  speaker: TranslationDialogueSpeaker;
  text: string;
}

export interface TranslationDialogueTurnRequest {
  language: TranslationLanguageCode;
  scenarioId: TranslationDialogueScenarioId;
  scenarioTitle: string;
  goal: string;
  learnerRole: string;
  partnerRole: string;
  history: TranslationDialogueHistoryTurn[];
  learnerText: string;
}

export type TranslationDialogueGoalProgress =
  | "starting"
  | "progressing"
  | "ready-to-close";

export interface TranslationDialogueTurnResult {
  partnerReply: string;
  supportHint: string;
  goalProgress: TranslationDialogueGoalProgress;
}

export type TranslationDialogueTurnIssueCode =
  | "invalid-response"
  | "missing-partner-reply"
  | "missing-support-hint"
  | "invalid-goal-progress";

export interface TranslationDialogueTurnIssue {
  code: TranslationDialogueTurnIssueCode;
}

export type TranslationDialogueTurnPreparation =
  | {
      status: "ready";
      result: TranslationDialogueTurnResult;
      issues: [];
    }
  | {
      status: "blocked";
      result?: never;
      issues: TranslationDialogueTurnIssue[];
    };

const isRecord = (
  value: unknown,
): value is Record<string, unknown> =>
  typeof value === "object" &&
  value !== null &&
  !Array.isArray(value);

const isGoalProgress = (
  value: unknown,
): value is TranslationDialogueGoalProgress =>
  value === "starting" ||
  value === "progressing" ||
  value === "ready-to-close";

export function prepareTranslationDialogueTurnResult(
  value: unknown,
): TranslationDialogueTurnPreparation {
  if (!isRecord(value)) {
    return {
      status: "blocked",
      issues: [
        {
          code: "invalid-response",
        },
      ],
    };
  }

  const partnerReply =
    typeof value.partnerReply ===
    "string"
      ? value.partnerReply.trim()
      : "";
  const supportHint =
    typeof value.supportHint ===
    "string"
      ? value.supportHint.trim()
      : "";
  const goalProgress =
    isGoalProgress(
      value.goalProgress,
    )
      ? value.goalProgress
      : undefined;

  const issues: TranslationDialogueTurnIssue[] =
    [];

  if (!partnerReply) {
    issues.push({
      code: "missing-partner-reply",
    });
  }

  if (!supportHint) {
    issues.push({
      code: "missing-support-hint",
    });
  }

  if (!goalProgress) {
    issues.push({
      code: "invalid-goal-progress",
    });
  }

  if (issues.length > 0) {
    return {
      status: "blocked",
      issues,
    };
  }

  if (!goalProgress) {
    return {
      status: "blocked",
      issues: [
        {
          code: "invalid-goal-progress",
        },
      ],
    };
  }

  return {
    status: "ready",
    issues: [],
    result: {
      partnerReply,
      supportHint,
      goalProgress,
    },
  };
}
