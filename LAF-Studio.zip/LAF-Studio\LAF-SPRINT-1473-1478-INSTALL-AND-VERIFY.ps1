﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

$required = @(
    "src\core\learning\CefrA1NavigateSecondWaveExecutableTaskDefinition.ts",
    "src\core\learning\CefrA1NavigateSecondWaveExecutableTaskDefinition.test.ts",
    "src\core\learning\CefrA1NavigateExecutableTaskCatalog.ts",
    "src\core\learning\CefrA1NavigateExecutableTaskCatalog.test.ts",
    "src\core\learning\CefrA1NavigateImmediateEvidenceCompletionSafety.ts",
    "src\core\learning\CefrA1NavigateImmediateEvidenceCompletionSafety.test.ts",
    "src\application\learning\CefrA1NavigateSecondWaveExecutableTaskService.ts",
    "src\application\learning\CefrA1NavigateSecondWaveExecutableTaskService.test.ts",
    "src\application\learning\CefrA1NavigateNativeLearningUiModel.ts",
    "src\application\learning\CefrA1NavigateNativeLearningUiModel.test.ts",
    "src\application\learning\CefrA1NavigateTargetLanguageSelectionModel.test.ts",
    "src\application\learning\CefrA1NavigateLanguageContentView.ts",
    "src\application\learning\CefrA1NavigateLanguageContentView.test.ts",
    "src\core\learning\CefrA1NavigateLanguageRealizationRegistry.ts",
    "src\core\learning\CefrA1NavigateLanguageRealizationRegistry.test.ts",
    "src\ui\learning\A1NavigateNativeLearningPanel.tsx",
    "src\ui\learning\A1NavigateNativeLearningPanel.css"
)

foreach ($relative in $required) {
    if (-not (Test-Path (Join-Path $app $relative))) {
        throw "Sprint 1473-1478 required file missing: $relative"
    }
}

$checks = @(
    @(
      "src\core\learning\CefrA1NavigateExecutableTaskCatalog.ts",
      "LAF_A1_NAVIGATE_ALL_EXECUTABLE_TASKS"
    ),
    @(
      "src\core\learning\CefrA1NavigateExecutableTaskCatalog.ts",
      '"a1-navigate-evidence-delayed-retrieval"'
    ),
    @(
      "src\application\learning\CefrA1NavigateSecondWaveExecutableTaskService.ts",
      'selectedPhraseIds.length ==='
    ),
    @(
      "src\application\learning\CefrA1NavigateSecondWaveExecutableTaskService.ts",
      'this.platform.recordUserEvidence('
    ),
    @(
      "src\ui\learning\A1NavigateNativeLearningPanel.tsx",
      'Cevabı Dinle'
    ),
    @(
      "src\ui\learning\A1NavigateNativeLearningPanel.tsx",
      '6 immediate evidence çalıştırılabilir'
    ),
    @(
      "src\core\learning\CefrA1NavigateLanguageRealizationRegistry.ts",
      'executableTaskCount: 6'
    )
)

foreach ($check in $checks) {
    $path = Join-Path $app $check[0]

    if (-not (
        Select-String `
            -Path $path `
            -SimpleMatch `
            -Pattern $check[1] `
            -Quiet
    )) {
        throw "Sprint 1473-1478 source marker missing: $($check[1])"
    }
}

# Delayed retrieval must not appear as a task definition in either wave.
$catalogPath =
    Join-Path $app "src\core\learning\CefrA1NavigateExecutableTaskCatalog.ts"
$catalogText =
    [System.IO.File]::ReadAllText($catalogPath)

if ($catalogText.Contains(
    '"a1-navigate-task-delayed-retrieval"'
)) {
    throw "Delayed retrieval task exposure detected."
}

Write-Host "SPRINT-1473-1478 SOURCE CHECK PASSED"

Set-Location $app

Write-Host ""
Write-Host "CHECKPOINT 1/2 — Sprint 1473-1475 immediate evidence task completion"

& npx vitest run @(
    "src/core/learning/CefrA1NavigateSecondWaveExecutableTaskDefinition.test.ts",
    "src/core/learning/CefrA1NavigateExecutableTaskCatalog.test.ts",
    "src/core/learning/CefrA1NavigateImmediateEvidenceCompletionSafety.test.ts",
    "src/application/learning/CefrA1NavigateSecondWaveExecutableTaskService.test.ts",
    "src/core/learning/CefrA1NavigateExecutableTaskDefinition.test.ts",
    "src/application/learning/CefrA1NavigateExecutableTaskService.test.ts"
)

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1473-1475 target checkpoint failed."
}

Write-Host "SPRINT-1473-1475 TARGET CHECKPOINT PASSED"

Write-Host ""
Write-Host "CHECKPOINT 2/2 — Sprint 1476-1478 native UI + production runtime safety"

& npx vitest run @(
    "src/application/learning/CefrA1NavigateNativeLearningUiModel.test.ts",
    "src/application/learning/CefrA1NavigateTargetLanguageSelectionModel.test.ts",
    "src/application/learning/CefrA1NavigateLanguageContentView.test.ts",
    "src/core/learning/CefrA1NavigateLanguageRealizationRegistry.test.ts",
    "src/core/learning/CefrA1NavigateRuntimeSliceDefinition.test.ts",
    "src/application/learning/CefrA1NavigateProductionRuntime.test.ts",
    "src/core/learning/CefrProductionRuntimeRegistryEnforcement.test.ts",
    "src/application/learning/CefrProductionRuntimeDelayedRetrievalVisibility.test.ts"
)

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1476-1478 target checkpoint failed."
}

Write-Host "SPRINT-1476-1478 TARGET CHECKPOINT PASSED"

Write-Host ""
Write-Host "FINAL 6-SPRINT BLOCK REGRESSION — one full run only"

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1473-1478 final full regression failed."
}

Write-Host ""
Write-Host "FINAL PRODUCTION BUILD"

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1473-1478 production build failed."
}

Write-Host ""
Write-Host "SPRINT-1473-1478 VERIFICATION COMPLETE"
