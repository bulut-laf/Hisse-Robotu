import type {
  TranslationGrammarObservationItem,
} from "../../ui/grammar/LocalStorageTranslationGrammarObservationStorage";

export interface TranslationGrammarStudySupport {
  hints: [string, string];
}

const normalize = (
  value: string,
): string =>
  value.replace(/\s+/g, " ").trim();

export function createTranslationGrammarStudySupport(
  observation: TranslationGrammarObservationItem,
): TranslationGrammarStudySupport {
  const focusTerm =
    normalize(observation.focusTerm);
  const functionText =
    normalize(observation.functionText);

  return {
    hints: [
      focusTerm
        ? `“${focusTerm}” ifadesinin cümlede hangi anlam ilişkisini kurduğuna dikkat edin.`
        : "Seçili öğenin cümlede hangi anlam ilişkisini kurduğuna dikkat edin.",
      functionText
        ? `Bir ipucu daha: Bu yapının bu cümledeki görevi “${functionText}”. Yapının adını hatırlamaya çalışın.`
        : "Bir ipucu daha: Yapının cümledeki görevini düşünün ve adını hatırlamaya çalışın.",
    ],
  };
}
