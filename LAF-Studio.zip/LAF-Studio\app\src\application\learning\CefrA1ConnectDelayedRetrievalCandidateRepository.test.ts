import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrA1ConnectDelayedRetrievalCandidate,
} from "../../core/learning/CefrA1ConnectDelayedRetrievalCandidate";
import {
  A1_CONNECT_DELAYED_RETRIEVAL_STORAGE_KEY,
  CefrA1ConnectDelayedRetrievalCandidateRepository,
} from "./CefrA1ConnectDelayedRetrievalCandidateRepository";

class MemoryStorage {
  private readonly values =
    new Map<string, string>();

  getItem(key: string): string | null {
    return this.values.get(key) ?? null;
  }

  setItem(
    key: string,
    value: string,
  ): void {
    this.values.set(key, value);
  }

  removeItem(key: string): void {
    this.values.delete(key);
  }
}

describe(
  "CefrA1ConnectDelayedRetrievalCandidateRepository",
  () => {
    it("persists real delayed-retrieval candidates separately from learner evidence", () => {
      const storage =
        new MemoryStorage();
      const repository =
        new CefrA1ConnectDelayedRetrievalCandidateRepository(
          storage,
        );

      const candidate =
        createCefrA1ConnectDelayedRetrievalCandidate({
          languageCode: "hu",
          sourceEvidenceId:
            "reciprocal-evidence-001",
          sourceObservedAt:
            new Date(
              "2026-08-11T17:45:00.000Z",
            ),
          queuedAt:
            new Date(
              "2026-08-11T17:45:01.000Z",
            ),
        });

      repository.save(candidate);

      expect(
        repository.findLatestForLanguage(
          "hu",
        ),
      ).toEqual(candidate);

      expect(
        storage.getItem(
          A1_CONNECT_DELAYED_RETRIEVAL_STORAGE_KEY,
        ),
      ).toContain(
        "waiting-for-approved-delay-policy",
      );
    });

    it("does not fabricate state when storage is empty", () => {
      expect(
        new CefrA1ConnectDelayedRetrievalCandidateRepository(
          new MemoryStorage(),
        ).findLatestForLanguage("ru"),
      ).toBeNull();
    });
  },
);
