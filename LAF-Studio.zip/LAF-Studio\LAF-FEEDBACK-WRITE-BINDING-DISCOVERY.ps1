﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$src = Join-Path $app "src"
$out = Join-Path $root "LAF_FEEDBACK_WRITE_BINDING_DISCOVERY.txt"

if (-not (Test-Path $src)) {
    throw "Source root not found: $src"
}

$report = New-Object System.Collections.Generic.List[string]

function Add-Line {
    param([string]$Text)
    if ($null -eq $Text) { $Text = "" }
    [void]$report.Add($Text)
}

function Add-Section {
    param([string]$Title)
    Add-Line ""
    Add-Line ("=" * 88)
    Add-Line $Title
    Add-Line ("=" * 88)
}

function Rel {
    param([string]$FullPath)
    $prefix = $root + "\"
    if ($FullPath.StartsWith($prefix)) {
        return $FullPath.Substring($prefix.Length)
    }
    return $FullPath
}

function Search-Source {
    param(
        [string]$Title,
        [string[]]$Patterns,
        [int]$Limit = 220
    )

    Add-Section $Title

    $files = @(
        Get-ChildItem -Path $src -Recurse -File -ErrorAction SilentlyContinue |
        Where-Object {
            $_.Extension -eq ".ts" -or $_.Extension -eq ".tsx"
        }
    )

    $items = New-Object System.Collections.Generic.List[object]

    foreach ($file in $files) {
        foreach ($pattern in $Patterns) {
            $hits = @(
                Select-String -Path $file.FullName -Pattern $pattern -SimpleMatch -ErrorAction SilentlyContinue
            )

            foreach ($hit in $hits) {
                $obj = New-Object PSObject
                Add-Member -InputObject $obj -MemberType NoteProperty -Name File -Value (Rel $hit.Path)
                Add-Member -InputObject $obj -MemberType NoteProperty -Name Line -Value $hit.LineNumber
                Add-Member -InputObject $obj -MemberType NoteProperty -Name Pattern -Value $pattern
                Add-Member -InputObject $obj -MemberType NoteProperty -Name Text -Value $hit.Line.Trim()
                [void]$items.Add($obj)
            }
        }
    }

    $matches = @(
        $items |
        Sort-Object File, Line, Pattern -Unique |
        Select-Object -First $Limit
    )

    if ($matches.Count -eq 0) {
        Add-Line "(no matches)"
        return
    }

    foreach ($m in $matches) {
        Add-Line ("{0}:{1} [{2}] {3}" -f $m.File, $m.Line, $m.Pattern, $m.Text)
    }
}

function Preview-Matches {
    param(
        [string]$Title,
        [string[]]$Names,
        [int]$MaxLines = 260
    )

    Add-Section $Title

    foreach ($name in $Names) {
        $hits = @(
            Get-ChildItem -Path $src -Recurse -File -Filter $name -ErrorAction SilentlyContinue
        )

        foreach ($file in $hits) {
            Add-Line ""
            Add-Line ("FILE: " + (Rel $file.FullName))
            Add-Line ("-" * 88)

            $content = @(Get-Content -Path $file.FullName)
            $limit = [Math]::Min($content.Count, $MaxLines)

            for ($i = 0; $i -lt $limit; $i++) {
                Add-Line ("{0,4}: {1}" -f ($i + 1), $content[$i])
            }

            if ($content.Count -gt $MaxLines) {
                Add-Line ("... truncated; total lines: " + $content.Count)
            }
        }
    }
}

Add-Line "LAF STUDIO - REAL FEEDBACK WRITE BINDING DISCOVERY"
Add-Line ("Generated: " + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
Add-Line "READ ONLY - no project source files are modified."

Search-Source -Title "1. REAL SESSION / LESSON COMPLETION SIGNALS" -Patterns @(
    "completeLesson("
    "completeActivity("
    "completedAt"
    "onComplete"
    "handleComplete"
    "sessionCompleted"
    "completionAcknowledged"
    "evidenceReturnReady"
    "outcomeReference"
) -Limit 260

Search-Source -Title "2. GUIDANCE FEEDBACK / RUNTIME PROFILE WRITE SIGNALS" -Patterns @(
    "CefrGuidanceRuntimeProfileService"
    "integrateCompletion("
    "LocalStorageCefrGuidanceProfileRepository"
    "createFeedback("
    "createCefrGuidanceApplicationIntegrationPlatform"
    "CefrGuidanceSessionCompletionAcknowledgement"
) -Limit 220

Search-Source -Title "3. LEARNING STUDIO COMPLETION / RESULT ADAPTER SIGNALS" -Patterns @(
    "CefrLearningStudioEvidenceAdapter"
    "CefrLearningFocusFeedbackBundle"
    "CefrGuidanceSessionEvidenceReturn"
    "CefrGuidanceSessionCapabilityObservationReturn"
    "LearningSessionService"
    "learning-session"
) -Limit 260

Search-Source -Title "4. UI CALLBACK / PAGE SIGNALS" -Patterns @(
    "LessonPage"
    "LearningStudioPage"
    "ListeningPracticePage"
    "WritingStudio"
    "ReadingStudio"
    "Speaking"
    "Dialogue"
    "Practice"
    "Finish"
    "Tamamla"
    "Bitir"
) -Limit 260

Search-Source -Title "5. EXISTING PERSISTENCE BOUNDARIES" -Patterns @(
    "new LocalStorageProvider"
    ".saveSession("
    ".set("
    ".save("
    "Repository"
    "Storage"
) -Limit 220

Preview-Matches -Title "6. FOCUSED FILE PREVIEWS" -Names @(
    "LessonPage.tsx"
    "LearningStudioPage.tsx"
    "ListeningPracticePage.tsx"
    "LearningSessionService.ts"
    "CefrLearningStudioEvidenceAdapter.ts"
    "CefrLearningFocusFeedbackBundle.ts"
    "CefrGuidanceApplicationIntegrationPlatform.ts"
    "CefrGuidanceRuntimeProfileService.ts"
    "CefrGuidanceSessionCompletionAcknowledgement.ts"
) -MaxLines 280

Add-Section "7. NEXT IMPLEMENTATION INPUT"
Add-Line "Need the exact production completion callback or service call."
Add-Line "Need the exact data already available at completion time."
Add-Line "Need the correct capability reference source."
Add-Line "Need the correct payload/outcome reference source."
Add-Line "Need to bind persistence once, without duplicate evidence writes."
Add-Line "Need to preserve user-authorized navigation and no automatic mastery/CEFR/progression."

$report | Set-Content -Path $out -Encoding UTF8

Write-Host ""
Write-Host "LAF FEEDBACK WRITE BINDING DISCOVERY COMPLETE"
Write-Host "Report:"
Write-Host $out
Write-Host ""
Get-Content -Path $out
