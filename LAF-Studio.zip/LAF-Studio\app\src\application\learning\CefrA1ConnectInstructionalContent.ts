﻿export interface CefrA1ConnectInstructionalContent {
  readonly lessonId: string;
  readonly communicativeStep: string;
  readonly contextDescription: string;
  readonly practiceSequence: readonly [
    string,
    string,
    string,
    string,
    string,
  ];
  readonly uiLanguage: "tr";
  readonly authoritativeCurriculumIdentityPreserved: true;
  readonly masteryClaimed: false;
  readonly cefrLevelClaimed: false;
  readonly automaticProgressionPerformed: false;
}

const CONTENT: readonly CefrA1ConnectInstructionalContent[] = [
  {
    lessonId: "a1-connect-greeting-response",
    communicativeStep:
      "Yaygın bir selamlaşmayı tanıyın ve uygun kısa bir karşılık verin.",
    contextDescription:
      "Öğrenen, tanıdık ya da yeni biriyle basit günlük bir ortamda karşılaşır; selamlaşmayı tanır ve uygun biçimde karşılık verir.",
    practiceSequence: [
      "Bağlam içinde birkaç kısa selamlaşmayı dinleyin.",
      "Selamlaşmayı iletişimsel anlamıyla eşleştirin.",
      "Uygun bir karşılık seçin.",
      "Tam modeli görmeden bir karşılığı hatırlayıp üretin.",
      "Kısa bir selamlaşma karşılığı üretin.",
    ],
    uiLanguage: "tr",
    authoritativeCurriculumIdentityPreserved: true,
    masteryClaimed: false,
    cefrLevelClaimed: false,
    automaticProgressionPerformed: false,
  },
  {
    lessonId: "a1-connect-self-introduction",
    communicativeStep:
      "Selamlaşmanın ardından çok temel bir kendini tanıtma ifadesi kullanın.",
    contextDescription:
      "Öğrenen biriyle ilk kez karşılaşır ve destekle adını ya da başka temel bir kimlik bilgisini söyler.",
    practiceSequence: [
      "Kısa kendini tanıtma örneklerini dinleyin.",
      "Adı veya tanıtma işlevini belirleyin.",
      "İpuçlarından basit bir tanıtma ifadesini yeniden kurun.",
      "Destekli bir kendini tanıtma ifadesi üretin.",
      "Başka birinin kendini tanıtmasına kısa bir karşılık verin.",
    ],
    uiLanguage: "tr",
    authoritativeCurriculumIdentityPreserved: true,
    masteryClaimed: false,
    cefrLevelClaimed: false,
    automaticProgressionPerformed: false,
  },
  {
    lessonId: "a1-connect-personal-questions",
    communicativeStep:
      "Bir veya iki basit kişisel soruyu anlayın, sorun ve yanıtlayın.",
    contextDescription:
      "Öğrenen kısa bir ilk karşılaşmayı; ad, köken veya nasıl olduğu gibi çok tanıdık kişisel soruları sorup yanıtlayarak sürdürür.",
    practiceSequence: [
      "Basit kişisel soruları dinleyin ve hangi bilginin istendiğini belirleyin.",
      "Kısa yanıtları uygun sorularla eşleştirin.",
      "Kısa bir kişisel yanıt üretin.",
      "Destekle bir kişisel soru sorun.",
      "İki turluk kısa bir soru-cevap alışverişini tamamlayın.",
    ],
    uiLanguage: "tr",
    authoritativeCurriculumIdentityPreserved: true,
    masteryClaimed: false,
    cefrLevelClaimed: false,
    automaticProgressionPerformed: false,
  },
  {
    lessonId: "a1-connect-complete-social-exchange",
    communicativeStep:
      "Selamlaşma, tanışma, basit kişisel alışveriş ve kapanışı kısa bir etkileşimde birleştirin.",
    contextDescription:
      "Öğrenen açılış, bir veya iki karşılıklı katkı ve uygun kapanış içeren çok kısa bir ilk sosyal karşılaşmayı destekle yönetir.",
    practiceSequence: [
      "Selamlaşma ve kendini tanıtma dilini hatırlayın.",
      "Kısa bir sosyal etkileşimi anlamlı sıraya koyun.",
      "Eksik konuşma turlarını ipuçlarından üretin.",
      "Rehberli kısa bir etkileşimi tamamlayın.",
      "Aynı etkileşimi daha az destekle tekrar edin.",
    ],
    uiLanguage: "tr",
    authoritativeCurriculumIdentityPreserved: true,
    masteryClaimed: false,
    cefrLevelClaimed: false,
    automaticProgressionPerformed: false,
  },
];

export function resolveCefrA1ConnectInstructionalContent(
  lessonId: string,
): CefrA1ConnectInstructionalContent | null {
  return CONTENT.find(item => item.lessonId === lessonId) ?? null;
}

export const LAF_A1_CONNECT_INSTRUCTIONAL_CONTENT = CONTENT;
