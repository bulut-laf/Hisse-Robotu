import {
  createCefrA1ConnectAdvisoryLessonApplyRequest,
  type CefrA1ConnectAdvisoryLessonApplyRequest,
} from "../../core/learning/CefrA1ConnectAdvisoryLessonApplyRequest";
import type {
  CefrA1ConnectAdvisoryNextStep,
} from "../../core/learning/CefrA1ConnectAdvisoryNextStep";

export interface CefrA1ConnectAdvisoryLessonApplyResult {
  readonly request:
    CefrA1ConnectAdvisoryLessonApplyRequest | null;
  readonly applicable: boolean;
  readonly authoritativeLessonRequired:
    true;
  readonly automaticSelectionPerformed:
    false;
}

export function createCefrA1ConnectAdvisoryLessonApplyResult(
  nextStep:
    CefrA1ConnectAdvisoryNextStep | null,
  authoritativeLessonIds:
    readonly string[],
): CefrA1ConnectAdvisoryLessonApplyResult {
  const lessonId =
    nextStep?.lessonId ?? null;

  if (
    lessonId === null ||
    !authoritativeLessonIds.includes(
      lessonId,
    )
  ) {
    return {
      request: null,
      applicable: false,
      authoritativeLessonRequired:
        true,
      automaticSelectionPerformed:
        false,
    };
  }

  return {
    request:
      createCefrA1ConnectAdvisoryLessonApplyRequest({
        lessonId,
        userActionConfirmed: true,
      }),
    applicable: true,
    authoritativeLessonRequired: true,
    automaticSelectionPerformed: false,
  };
}
