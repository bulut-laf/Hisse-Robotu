import {
  createCefrA1ConnectRuntimeReadModel,
} from "./CefrA1ConnectRuntimeReadModel";

export interface CefrA1ConnectNativeLessonCardModel {
  readonly lessonId: string;
  readonly sequence: number;
  readonly communicativeStep: string;
  readonly contextDescription: string;
  readonly practiceStepCount: number;
  readonly evidenceOpportunityCount: number;
}

export interface CefrA1ConnectNativeLearningUiModel {
  readonly eyebrow: "A1 · RESPOND · CONNECT";
  readonly title: "First Social Encounter";
  readonly competencyLabel:
    "connect-a1 · Basic Social Response";
  readonly unitId:
    "a1-connect-first-social-encounter";
  readonly lessonCards:
    readonly CefrA1ConnectNativeLessonCardModel[];
  readonly meaningfulInteractionCount: 3;
  readonly evidenceDefinitionCount: 7;
  readonly realLifeActivationAvailable: true;
  readonly languageRealizationBound: false;
  readonly evidenceCaptureEnabled: false;
  readonly evidenceCaptureStatus:
    "language-realization-required";
  readonly existingLearningQueuePreserved: true;
  readonly userActionRequired: true;
  readonly readOnlyCurriculumPreview: true;
}

export function createCefrA1ConnectNativeLearningUiModel():
  CefrA1ConnectNativeLearningUiModel {
  const runtime =
    createCefrA1ConnectRuntimeReadModel();

  const lessonCards =
    runtime.lessons.map(
      (lesson, index) => {
        const practice =
          runtime.practices.find(
            candidate =>
              candidate.lessonId === lesson.id,
          );

        const evidenceOpportunityCount =
          runtime.evidenceDefinitions.filter(
            candidate =>
              candidate.sourceLearningItemId ===
              lesson.id,
          ).length;

        return {
          lessonId: lesson.id,
          sequence: index + 1,
          communicativeStep:
            lesson.communicativeStep,
          contextDescription:
            lesson.contextDescription,
          practiceStepCount:
            practice?.sequence.length ?? 0,
          evidenceOpportunityCount,
        };
      },
    );

  return {
    eyebrow: "A1 · RESPOND · CONNECT",
    title: "First Social Encounter",
    competencyLabel:
      "connect-a1 · Basic Social Response",
    unitId:
      "a1-connect-first-social-encounter",
    lessonCards,
    meaningfulInteractionCount:
      runtime.interactions.length as 3,
    evidenceDefinitionCount:
      runtime.evidenceDefinitions.length as 7,
    realLifeActivationAvailable: true,
    languageRealizationBound: false,
    evidenceCaptureEnabled: false,
    evidenceCaptureStatus:
      "language-realization-required",
    existingLearningQueuePreserved: true,
    userActionRequired: true,
    readOnlyCurriculumPreview: true,
  };
}
