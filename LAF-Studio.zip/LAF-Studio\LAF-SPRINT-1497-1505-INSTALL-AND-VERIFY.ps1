﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$core = Join-Path $app "src\core\learning"

$utf8 =
    New-Object System.Text.UTF8Encoding($false)

function Read-Utf8([string]$path) {
    return [System.IO.File]::ReadAllText(
        $path,
        $utf8
    )
}

function Write-Utf8(
    [string]$path,
    [string]$text
) {
    [System.IO.File]::WriteAllText(
        $path,
        $text,
        $utf8
    )
}

# ------------------------------------------------------------
# 1. Register A1 DESCRIBE Unit + lessons in authoritative catalog.
# Patch the current file; do not rewrite CONNECT/NAVIGATE content.
# ------------------------------------------------------------
$catalogPath =
    Join-Path $core "CefrAuthoritativeCurriculumCatalog.ts"

if (-not (Test-Path $catalogPath)) {
    throw "CefrAuthoritativeCurriculumCatalog.ts missing."
}

$catalog =
    Read-Utf8 $catalogPath

$describeImportModule =
    'from "./CefrA1DescribeCurriculum";'

if (-not $catalog.Contains(
    $describeImportModule
)) {
    $exportAnchor =
        'export const LAF_A1_CONNECT_FIRST_SOCIAL_ENCOUNTER_UNIT:'

    $exportIndex =
        $catalog.IndexOf($exportAnchor)

    if ($exportIndex -lt 0) {
        throw "Authoritative curriculum export anchor missing."
    }

    $describeImport = @'
import {
  LAF_A1_DESCRIBE_BASIC_FAMILIAR_WORLD_LESSONS,
  LAF_A1_DESCRIBE_BASIC_FAMILIAR_WORLD_UNIT,
} from "./CefrA1DescribeCurriculum";

'@

    $catalog =
        $catalog.Insert(
            $exportIndex,
            $describeImport
        )
}

$unitsStartMarker =
    'export const LAF_AUTHORITATIVE_CEFR_UNITS:'
$unitsStart =
    $catalog.IndexOf(
        $unitsStartMarker
    )

if ($unitsStart -lt 0) {
    throw "Authoritative CEFR Unit array start missing."
}

$describeUnitUse =
    '  LAF_A1_DESCRIBE_BASIC_FAMILIAR_WORLD_UNIT,'

if (
    $catalog.IndexOf(
        $describeUnitUse,
        $unitsStart
    ) -lt 0
) {
    $navigateUnitUse =
        '  LAF_A1_NAVIGATE_IMMEDIATE_EVERYDAY_NEEDS_UNIT,'

    $navigateUnitIndex =
        $catalog.IndexOf(
            $navigateUnitUse,
            $unitsStart
        )

    if ($navigateUnitIndex -lt 0) {
        throw "A1 NAVIGATE Unit array entry missing."
    }

    $insertAt =
        $navigateUnitIndex +
        $navigateUnitUse.Length

    $catalog =
        $catalog.Insert(
            $insertAt,
            [Environment]::NewLine +
            $describeUnitUse
        )
}

$lessonsStartMarker =
    'export const LAF_AUTHORITATIVE_CEFR_LESSONS:'
$lessonsStart =
    $catalog.IndexOf(
        $lessonsStartMarker
    )

if ($lessonsStart -lt 0) {
    throw "Authoritative CEFR Lesson array start missing."
}

$describeLessonsUse =
    '  ...LAF_A1_DESCRIBE_BASIC_FAMILIAR_WORLD_LESSONS,'

if (
    $catalog.IndexOf(
        $describeLessonsUse,
        $lessonsStart
    ) -lt 0
) {
    $navigateLessonsUse =
        '  ...LAF_A1_NAVIGATE_IMMEDIATE_EVERYDAY_NEEDS_LESSONS,'

    $navigateLessonsIndex =
        $catalog.IndexOf(
            $navigateLessonsUse,
            $lessonsStart
        )

    if ($navigateLessonsIndex -lt 0) {
        throw "A1 NAVIGATE Lesson array entry missing."
    }

    $insertAt =
        $navigateLessonsIndex +
        $navigateLessonsUse.Length

    $catalog =
        $catalog.Insert(
            $insertAt,
            [Environment]::NewLine +
            $describeLessonsUse
        )
}

Write-Utf8 $catalogPath $catalog

# ------------------------------------------------------------
# 2. Register four authoritative Learning Item -> Competency mappings.
# ------------------------------------------------------------
$registryPath =
    Join-Path $core "CefrAuthoritativeCurriculumRegistry.ts"

if (-not (Test-Path $registryPath)) {
    throw "CefrAuthoritativeCurriculumRegistry.ts missing."
}

$registry =
    Read-Utf8 $registryPath

if (-not $registry.Contains(
    '"curriculum-map-a1-describe-v1"'
)) {
    $mappingStart =
        $registry.IndexOf(
            'export const LAF_CEFR_CURRICULUM_COMPETENCY_MAPPINGS:'
        )

    if ($mappingStart -lt 0) {
        throw "Curriculum mapping array start missing."
    }

    $mappingEnd =
        $registry.IndexOf(
            '];',
            $mappingStart
        )

    if ($mappingEnd -lt 0) {
        throw "Curriculum mapping array end missing."
    }

    $describeMappings = @'
  {
    learningItemId:
      "a1-describe-identify-basic-features",
    learningItemType: "lesson",
    competencyOutcomeIds: [
      "describe-narrate-a1",
    ],
    mappingAuthority:
      "unit-lesson-curriculum-definition",
    mappingVersion:
      "curriculum-map-a1-describe-v1",
    authoritative: true,
  },
  {
    learningItemId:
      "a1-describe-familiar-person",
    learningItemType: "lesson",
    competencyOutcomeIds: [
      "describe-narrate-a1",
    ],
    mappingAuthority:
      "unit-lesson-curriculum-definition",
    mappingVersion:
      "curriculum-map-a1-describe-v1",
    authoritative: true,
  },
  {
    learningItemId:
      "a1-describe-familiar-place-thing",
    learningItemType: "lesson",
    competencyOutcomeIds: [
      "describe-narrate-a1",
    ],
    mappingAuthority:
      "unit-lesson-curriculum-definition",
    mappingVersion:
      "curriculum-map-a1-describe-v1",
    authoritative: true,
  },
  {
    learningItemId:
      "a1-describe-complete-basic-description",
    learningItemType: "lesson",
    competencyOutcomeIds: [
      "describe-narrate-a1",
    ],
    mappingAuthority:
      "unit-lesson-curriculum-definition",
    mappingVersion:
      "curriculum-map-a1-describe-v1",
    authoritative: true,
  },

'@

    $registry =
        $registry.Insert(
            $mappingEnd,
            $describeMappings
        )
}

Write-Utf8 $registryPath $registry

# ------------------------------------------------------------
# 3. Register A1 DESCRIBE in the existing generic production runtime.
# No parallel runtime architecture.
# ------------------------------------------------------------
$productionRegistryPath =
    Join-Path $core "CefrProductionRuntimeSliceRegistry.ts"

if (-not (Test-Path $productionRegistryPath)) {
    throw "CefrProductionRuntimeSliceRegistry.ts missing."
}

$productionRegistry =
    Read-Utf8 $productionRegistryPath

if (-not $productionRegistry.Contains(
    'from "./CefrA1DescribeRuntimeSliceDefinition";'
)) {
    $navigateImportModule =
        'from "./CefrA1NavigateRuntimeSliceDefinition";'

    $navigateImportPos =
        $productionRegistry.IndexOf(
            $navigateImportModule
        )

    if ($navigateImportPos -lt 0) {
        throw "A1 NAVIGATE production runtime import anchor missing."
    }

    $lineEnd =
        $productionRegistry.IndexOf(
            [Environment]::NewLine,
            $navigateImportPos
        )

    if ($lineEnd -lt 0) {
        $lineEnd =
            $navigateImportPos +
            $navigateImportModule.Length
    }

    $describeRuntimeImport =
        [Environment]::NewLine +
        'import {' +
        [Environment]::NewLine +
        '  createLafA1DescribeRuntimeSliceDefinition,' +
        [Environment]::NewLine +
        '} from "./CefrA1DescribeRuntimeSliceDefinition";'

    $productionRegistry =
        $productionRegistry.Insert(
            $lineEnd,
            $describeRuntimeImport
        )
}

$sliceArrayMarker =
    'return createCefrRuntimeSliceRegistry(['
$sliceStart =
    $productionRegistry.IndexOf(
        $sliceArrayMarker
    )

if ($sliceStart -lt 0) {
    throw "Production runtime slice registry array start missing."
}

$describeSliceUse =
    '    createLafA1DescribeRuntimeSliceDefinition(),'

if (
    $productionRegistry.IndexOf(
        $describeSliceUse,
        $sliceStart
    ) -lt 0
) {
    $navigateSliceUse =
        '    createLafA1NavigateRuntimeSliceDefinition(),'

    $navigateSliceIndex =
        $productionRegistry.IndexOf(
            $navigateSliceUse,
            $sliceStart
        )

    if ($navigateSliceIndex -lt 0) {
        throw "A1 NAVIGATE production runtime slice entry missing."
    }

    $insertAt =
        $navigateSliceIndex +
        $navigateSliceUse.Length

    $productionRegistry =
        $productionRegistry.Insert(
            $insertAt,
            [Environment]::NewLine +
            $describeSliceUse
        )
}

Write-Utf8 $productionRegistryPath $productionRegistry

# ------------------------------------------------------------
# 4. Fail-closed source checks before tests.
# ------------------------------------------------------------
$sourceChecks = @(
    @(
      (Join-Path $core "CefrA1DescribeCurriculum.ts"),
      '"a1-describe-basic-familiar-world"'
    ),
    @(
      (Join-Path $core "CefrA1DescribeCurriculum.ts"),
      '"describe-narrate-a1"'
    ),
    @(
      (Join-Path $core "CefrA1DescribeEvidenceDefinition.ts"),
      '"a1-describe-evidence-delayed-retrieval"'
    ),
    @(
      (Join-Path $core "CefrA1DescribeEvidenceDefinition.ts"),
      'runtimeWriteEnabled: false'
    ),
    @(
      (Join-Path $core "CefrA1DescribeImplementationSafety.ts"),
      'a2NarrativeSequencingExcluded:'
    ),
    @(
      $catalogPath,
      'LAF_A1_DESCRIBE_BASIC_FAMILIAR_WORLD_UNIT,'
    ),
    @(
      $catalogPath,
      '...LAF_A1_DESCRIBE_BASIC_FAMILIAR_WORLD_LESSONS,'
    ),
    @(
      $registryPath,
      '"curriculum-map-a1-describe-v1"'
    ),
    @(
      $productionRegistryPath,
      'createLafA1DescribeRuntimeSliceDefinition(),'
    )
)

foreach ($pair in $sourceChecks) {
    if (-not (
        Select-String `
            -Path $pair[0] `
            -SimpleMatch `
            -Pattern $pair[1] `
            -Quiet
    )) {
        throw "Sprint 1497-1505 source marker missing: $($pair[1])"
    }
}

$describeEvidenceText =
    Read-Utf8 (
      Join-Path $core "CefrA1DescribeRuntimeEvidenceCatalog.ts"
    )

if ($describeEvidenceText.Contains(
    '"a1-describe-evidence-delayed-retrieval"'
)) {
    throw "Delayed retrieval leaked into A1 DESCRIBE executable runtime catalog."
}

$describeSafetyText =
    Read-Utf8 (
      Join-Path $core "CefrA1DescribeImplementationSafety.ts"
    )

if (-not (
    Select-String `
        -Path (
          Join-Path $core "CefrA1DescribeImplementationSafety.ts"
        ) `
        -SimpleMatch `
        -Pattern '"description-production"' `
        -Quiet
)) {
    throw "A1 DESCRIBE description-production authority marker missing."
}

Write-Host "SPRINT-1497-1505 SOURCE CHECK PASSED"

Set-Location $app

# ------------------------------------------------------------
# 3 x 3-sprint target checkpoints.
# One full regression + one build only at block end.
# ------------------------------------------------------------
Write-Host ""
Write-Host "CHECKPOINT 1/3 — Sprint 1497-1499 authoritative curriculum + experience identities"

& npx vitest run @(
    "src/core/learning/CefrA1DescribeCurriculum.test.ts",
    "src/core/learning/CefrA1DescribePracticeDefinition.test.ts",
    "src/core/learning/CefrA1DescribeInteractionDefinition.test.ts",
    "src/core/learning/CefrA1DescribeEvidenceDefinition.test.ts",
    "src/core/learning/CefrA1DescribeActivationDefinition.test.ts",
    "src/core/learning/CefrA1DescribeLearningExperienceCatalog.test.ts",
    "src/core/learning/CefrA1DescribeImplementationSafety.test.ts"
)

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1497-1499 target checkpoint failed."
}

Write-Host "SPRINT-1497-1499 TARGET CHECKPOINT PASSED"

Write-Host ""
Write-Host "CHECKPOINT 2/3 — Sprint 1500-1502 authoritative registry + runtime evidence/provenance"

& npx vitest run @(
    "src/core/learning/CefrA1DescribeAuthoritativeCatalog.test.ts",
    "src/core/learning/CefrA1DescribeCurriculumRegistry.test.ts",
    "src/core/learning/CefrA1DescribeRuntimeEvidenceCatalog.test.ts",
    "src/core/learning/CefrAuthoritativeCurriculumCatalog.test.ts",
    "src/core/learning/CefrAuthoritativeCurriculumRegistry.test.ts",
    "src/core/learning/CefrAuthoritativeCapabilityRegistry.test.ts"
)

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1500-1502 target checkpoint failed."
}

Write-Host "SPRINT-1500-1502 TARGET CHECKPOINT PASSED"

Write-Host ""
Write-Host "CHECKPOINT 3/3 — Sprint 1503-1505 existing generic production runtime activation"

& npx vitest run @(
    "src/core/learning/CefrA1DescribeRuntimeSliceDefinition.test.ts",
    "src/core/learning/CefrProductionRuntimeSliceRegistry.test.ts",
    "src/core/learning/CefrProductionRuntimeRegistryEnforcement.test.ts",
    "src/application/learning/CefrProductionRuntimeDelayedRetrievalVisibility.test.ts",
    "src/application/learning/CefrA1DescribeProductionRuntime.test.ts",
    "src/application/learning/CefrProductionRuntimePlatform.test.ts"
)

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1503-1505 target checkpoint failed."
}

Write-Host "SPRINT-1503-1505 TARGET CHECKPOINT PASSED"

Write-Host ""
Write-Host "FINAL 9-SPRINT BLOCK REGRESSION — one full run only"

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1497-1505 final full regression failed."
}

Write-Host ""
Write-Host "FINAL PRODUCTION BUILD"

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1497-1505 production build failed."
}

Write-Host ""
Write-Host "SPRINT-1497-1505 VERIFICATION COMPLETE"
