﻿LAF Studio — Project Notes

Bu dosya LAF Studio geliştirme çalışmalarının kalıcı teknik hafızasıdır. Dosya, çalışma sırasında değil; gün sonunda test, build ve tarayıcı doğrulamaları tamamlandıktan sonra topluca güncellenir.

1. Proje bilgileri

Proje adı: LAF Studio

Açılımı: Language Architecture Framework

Proje türü: Yapay zekâ destekli Language Intelligence Platform

Yerel proje yolu: D:\Projects\LAF-Studio

Geliştirme durumu: Aktif

Son güncelleme: 7 Ağustos 2026 — Sprint 116–118 Speaking & Pronunciation Studio bloğu kapatıldı

Son tamamlanan sprint: Sprint 118 — Speaking & Pronunciation Studio

Sıradaki çalışma: Sprint 119–121 — Dialogue & Role-play Studio

2. Projenin amacı

LAF Studio; dil öğrenmeyi, yazılı çeviriyi, sözlü tercümanlığı ve profesyonel dil kullanımını tek bir kişisel dil zekâsında birleştiren, farklı dillere uyarlanabilir yapay zekâ destekli bir Language Intelligence Platform’dur.

Ürün yalnızca hazır içerik veya hazır çeviri sunmaz. Kullanıcının dili anlamasını, üretmesini, gerçek yaşamda kullanmasını ve gerektiğinde profesyonel çeviri veya tercümanlık çalışmalarında güvenilir destek almasını sağlar.

Ana ürün alanları:

Learning Studio

Dil öğrenme, aktif hatırlama, dinleme, konuşma, okuma, yazma, telaffuz ve kişiselleştirilmiş öğrenme.

Translation Studio

Yazılı çeviri, alternatif çeviri önerileri, anlam ve üslup analizi, terminoloji yönetimi, tutarlılık ve kalite kontrolü.

Interpreting Studio

Ardıl ve simultane tercümanlık eğitimi, mesleki senaryolar, not alma, hızlı hatırlama ve performans analizi.

LAF Intelligence Core

Üç stüdyodan gelen kelimeleri, hataları, güçlü ve zayıf alanları ve mesleki terminolojiyi ortak bir kişisel dil profili altında birleştiren sistem.

Temel ürün farklılaştırıcısı:

Bir stüdyoda ortaya çıkan öğrenme ihtiyacı diğer stüdyolara aktarılır. Çeviride zorlanılan ifadeler öğrenme programına, öğrenilen terminoloji çeviri desteğine, tercümanlık hataları ise hedefli alıştırmalara dönüştürülür.

Platformun temel yaklaşımı:

Mikro öğrenme

Aktif hatırlama

Bağlam içinde öğrenme

Doğal dil kullanımı

Kişiselleştirilmiş geri bildirim

Kullanıcı ilerlemesine göre öneri üretme

Profesyonel çeviri ve tercümanlık desteği

AI tarafından desteklenen fakat kullanıcı kontrolünü koruyan çalışma düzeni

3. Çalışma ayrımı

LAF Studio — Design Studio

Bu çalışma alanında yalnızca aşağıdaki konular ele alınır:

Ürün vizyonu

Öğrenme mimarisi

UX/UI kararları

AI öğretmen davranışları

Gamification

Roadmap

Ürün dokümantasyonu

Yeni özellik değerlendirmeleri

Bu alanda kod yazılmaz. Geliştirmeye aktarılacak kararlar Development Brief olarak hazırlanır.

LAF Studio — Development

Bu çalışma alanında onaylanan ürün kararları uygulanır.

Temel kurallar:

Aynı anda yalnızca bir sprint üzerinde çalışılır.

Mevcut katmanlı mimari korunur.

Gereksiz abstraction eklenmez.

Gereksiz özellik eklenmez.

Her sprint çalışan bir özellik teslim eder.

Her sprint sonunda npm run test başarılı olmalıdır.

Her sprint sonunda npm run build başarılı olmalıdır.

Gün içindeki doğrulamalar tamamlandıktan sonra bu dosya çalışma gününün sonunda topluca güncellenmelidir.

4. Ana proje yapısı

LAF-Studio/
├── app/
├── backend/
├── docs/
├── PROJECT_NOTES.md
└── ...

Frontend uygulamasının güncel hedef yapısı:

app/src/
├── application/
├── core/
├── features/
├── pages/
├── shared/
├── styles/
├── ui/
│   ├── audio/
│   ├── hooks/
│   ├── pages/
│   └── storage/
├── App.tsx
└── main.tsx

5. Kullanılan teknolojiler

Frontend

React

TypeScript

Vite

React Router

CSS

Tarayıcı Web Speech API

Tarayıcı MediaRecorder API

Local Storage

Test ve kalite

Vitest

TypeScript compiler

Vite production build

Geliştirme ortamı

Windows

Visual Studio Code

PowerShell

Git

Node.js

npm

6. Mimari

Güncel öğrenme akışı:

React UI
  → useLearningSession
  → LearningApplicationService
  → LearningSessionController
  → TranslationPipeline
  → Evaluation / Recommendation / Repository

Katmanların sorumlulukları:

Core

Öğrenme oturumu kuralları

Etkinlik modelleri

Cevap değerlendirme

Translation pipeline

Öğrenme önerileri

Repository sözleşmeleri ve uygulamaları

Core katmanı React bileşenlerine bağımlı değildir.

Application

UI ile Core arasında kullanım senaryosu sınırı oluşturur.

LearningApplicationService öğrenme oturumu işlemlerini sunar.

ApplicationFactory gerekli bağımlılıkları oluşturur ve bağlar.

UI

Kullanıcı etkileşimini yönetir.

Core nesnelerini doğrudan oluşturmamalıdır.

Öğrenme işlemlerine useLearningSession ve Application Layer üzerindenerişmelidir.

7. Önemli teknik kararlar

Karar 1 — Merkezi composition root

Bağımlılıkların kurulması ApplicationFactory içerisinde yapılır.

Gerekçe: React bileşenlerinin Core sınıflarını doğrudan oluşturmasınıönlemek ve bağımlılık kurulumunu tek noktada toplamak.

Karar 2 — UI için özel hook

React ekranları öğrenme oturumuna useLearningSession üzerinden bağlanır.

Gerekçe: UI state yönetimini Application Layer çağrılarından ayırmak vebileşenleri sade tutmak.

Karar 3 — Katmanlı geçiş

Eski UI parçaları tek seferde silinmez. Yeni Application Layer tabanlı akışçalışır hâle getirildikçe eski bağlantılar kontrollü biçimde değiştirilir.

Gerekçe: Çalışan sistemi bozmadan aşamalı geçiş yapmak.

Karar 4 — Sprint doğrulama standardı

Bir sprint yalnızca aşağıdaki koşullar birlikte sağlandığında tamamlanmış kabuledilir:

Özellik kullanıcı tarafından çalıştırılabilir.

npm run test başarılıdır.

npm run build başarılıdır.

PROJECT_NOTES.md güncellenmiştir.

8. Tamamlanan ana çalışmalar

Temel frontend

Vite + React + TypeScript uygulaması oluşturuldu.

Ana sayfalar ve React Router yapısı oluşturuldu.

MainLayout oluşturuldu.

Ana navigasyon rotaları bağlandı.

Core Engine

Etkinlik modelleri oluşturuldu.

Translation evaluation akışı oluşturuldu.

TranslationChecker oluşturuldu.

TranslationPipeline oluşturuldu.

ActivityEvaluationEngine oluşturuldu.

LearningRecommendationEngine oluşturuldu.

Öğrenme oturumu ve controller akışı oluşturuldu.

Memory session storage oluşturuldu.

Static activity repository oluşturuldu.

Application Layer

LearningApplicationService oluşturuldu.

ApplicationFactory oluşturuldu.

Core bağımlılıkları factory içerisinde bağlandı.

Application Layer testleri oluşturuldu.

React entegrasyonu

useLearningSession hook'u oluşturuldu.

Hook üzerinden oturum başlatma eklendi.

Cevap gönderme eklendi.

Geri bildirim state'i eklendi.

Sonraki etkinliğe geçme eklendi.

Önceki etkinliğe geçme desteği hook'a eklendi.

Önceki doğrulama durumu

Test paketi başarılı çalıştı.

Production build başarılı çalıştı.

Sprint 13 test sonucu: 7 test dosyası ve 44 test başarılı.

Sprint 13 build sonucu: Başarılı — Vite production build 2.82 saniye.

9. Sprint 13 — İlk çalışan LessonPage

Amaç

Application Layer üzerinden çalışan ilk gerçek ders ekranını tamamlamak.

Kabul kriterleri

Etkinlik sorusu ekranda gösterilir.

Kullanıcı cevap yazabilir.

Boş cevap gönderilemez.

Cevap yalnızca bir kez değerlendirilebilir.

Doğru veya yanlış geri bildirimi gösterilir.

Geri bildirimden sonra sonraki etkinliğe geçilebilir.

Son etkinlikten sonra dersin tamamlandığı gösterilir.

Enter tuşu ile cevap gönderilebilir.

Testler başarılıdır.

Production build başarılıdır.

Yapılan değişiklikler

LessonPage.tsx, useLearningSession hook'una bağlandı.

Soru, cevap alanı, gönderme işlemi, geri bildirim ve sonraki etkinlik akışıhazırlandı.

/lessons/:id rotasının eski LessonDetailPage yerine yeni LessonPagebileşenini açması için App.tsx güncellendi.

Tarihsel not: ContinueLessonCard.tsx dosyasının sonuna yanlışlıkla eklenen S karakteri TypeScript build hatasına neden oldu. Karakter kaldırıldı; test, build ve tarayıcı akışı daha sonra başarıyla doğrulandı.

10. Sprint 14–49 — Ana geliştirme özeti

Sprint 14–49 arasında aşağıdaki ana çalışmalar tamamlandı:

Ders oturumları tarayıcı Local Storage üzerinde kalıcı hâle getirildi.

Dersi yeniden başlatma ve mevcut aktiviteyi tekrar deneme akışları tamamlandı.

Çoklu ders desteği ve ders bazlı çeviri etkinlikleri oluşturuldu.

İtalyanca A1 seviyesinde üç ders ve her ders için üç çeviri etkinliği eklendi.

Dersler, Ana Sayfa ve İlerleme ekranları gerçek oturum verilerine bağlandı.

Ders ve genel ilerleme yüzdeleri ayrı ayrı hesaplanır hâle getirildi.

Haftalık çalışma grafiği ve gerçek çalışma serisi eklendi.

Günlük çalışma serisi ve çalışma günü serisi hesaplamaları eklendi.

Çeviri cevaplarında noktalama, büyük-küçük harf ve normalizasyon desteği geliştirildi.

Tarayıcı seslendirme servisi oluşturuldu.

Kelime ve örnek cümle seslendirmeleri eklendi.

Ana ders oturumundan ayrı çalışan dinleme pratiği rotası oluşturuldu:

/lessons/:id/listening

Dinleme pratiği sonuç özeti, doğru cevap sayısı, başarı yüzdesi ve ilk denemede doğru metriği eklendi.

Ders bazında en iyi dinleme sonucu Local Storage üzerinde saklanır hâle getirildi.

Kullanıcının kendi sesini kaydedip tekrar dinleyebilmesi için tarayıcı MediaRecorder desteği eklendi.

11. Sprint 50–57 — Gün sonu geliştirme kaydı

Kayıt dönemi: 24–27 Temmuz 2026

Sprint 50 — Genel dinleme ilerlemesi

İlerleme ekranına Ortalama dinleme başarısı kartı eklendi.

Dinleme çalışması yapılan ders sayısı toplam ders sayısından ayrı gösterildi.

Dinleme başarısı ana ders ilerleme yüzdesine katılmadı.

Genel dinleme özeti saf ve test edilebilir bir servis fonksiyonu olarak oluşturuldu.

Sprint 51 — Ders bazlı dinleme durumu

İlerleme ekranındaki her ders kartına en iyi dinleme puanı eklendi.

Dinleme kaydı olmayan derslerde Henüz yapılmadı bilgisi gösterildi.

Her ders kartına Dinleme Çalış veya Tekrar Dinle bağlantısı eklendi.

Sprint 52 — Ana Sayfada dinlemeye devam

Ana Sayfaya Dinlemeye Devam Et kartı eklendi.

En son tamamlanan dinleme çalışması tarih üzerinden belirlenir hâle getirildi.

Kartta ders adı, en iyi başarı yüzdesi ve son çalışma tarihi gösterildi.

Kart ilgili dersin dinleme pratiği rotasına bağlandı.

Sprint 53 — Kişisel dinleme rekoru

Dinleme sonucu önceki en iyi puanla karşılaştırılır hâle getirildi.

İlk sonuç, yeni kişisel rekor, eşit rekor ve rekor altı sonuç durumları oluşturuldu.

Tamamlanma ekranına kişisel rekor geri bildirimi eklendi.

Sprint 54 — Öğretici sesli geri bildirim

Dinleme cevabından sonra doğru yabancı ifade ve örnek cümle için ayrı seslendirme düğmeleri eklendi.

İlk yanlış cevapta doğru bilginin gizli kalması davranışı korundu.

Doğru cevapta veya ikinci denemeden sonra öğretici geri bildirim ve seslendirme açıldı.

Sprint 55 — Dinleme tekrar sayacı

Her sorunun çözüm sırasında kaç kez dinlendiği oturum içinde sayılır hâle getirildi.

Normal ve yavaş dinleme işlemleri sayaca dâhil edildi.

Geri bildirim alanındaki ifade ve örnek seslendirmeleri sayaç dışında bırakıldı.

Tamamlanma ekranına Toplam dinleme metriği eklendi.

Eski dinleme sonuçları için geriye uyumluluk korundu; listenCount bulunmayan kayıtlar sıfır kabul edildi.

Sprint 56 — Soru bazlı dinleme özeti

Dinleme çalışması tamamlanma ekranına soru bazlı dinleme özeti eklendi.

Her ifade için kaç kez dinleme yapıldığı ayrı ayrı gösterilir hâle getirildi.

Toplam dinleme metriği ve eski dinleme kayıtlarıyla geriye uyumluluk korundu.

Sprint 57 — Dinleme tekrar önerisi

Dinleme sonuçları kullanılarak öğrenciye ifade bazlı tekrar önerisi üretilir hâle getirildi.

Tamamlanma ekranına Tekrar Önerisi kartı eklendi.

Öneride tekrar edilmesi yararlı olan ifade ve yapılan dinleme sayısı gösterildi.

Soru bazlı özet, toplam dinleme sayısı ve tekrar önerisi aynı tamamlanma ekranında birlikte doğrulandı.

Sprint 58 — Tamamlanma ekranında ifadeyi dinleme

Dinleme pratiği tamamlanma ekranındaki Tekrar Önerisi kartına “İfadeyi Dinle” düğmesi eklendi.

Düğme, önerilen yabancı ifadeyi mevcut tarayıcı seslendirme servisiyle seslendirir hâle getirildi.

Tamamlanma ekranındaki seslendirme toplam dinleme sayacına dâhil edilmedi.

Mevcut Local Storage yapısı, dinleme sayaçları ve katmanlı mimari değiştirilmedi.

Sprint 59 — Translation Studio ilk çalışan çalışma alanı

Translation Studio için /translation rotası ve navigasyon bağlantısı eklendi.

Macarca ↔ Türkçe dil yönü ve aynı kaynak-hedef dil seçimini engelleyen seçim davranışı oluşturuldu.

Genel, hukuk, sağlık, ekonomi, akademik ve kurumsal uzmanlık alanları eklendi.

“Ben Çevireceğim” ve “Çeviri Yardımı” çalışma biçimleri oluşturuldu.

Kaynak metin ve çeviri taslağı alanları, karakter sayaçları ve çalışma alanı durum göstergesi eklendi.

Mobil uyumlu Translation Studio arayüzü teslim edildi.

Sprint 60 — Translation Studio taslak kaydı

Translation Studio için aktif taslak veri modeli oluşturuldu.

Dil yönü, uzmanlık alanı, çalışma biçimi, kaynak metin ve çeviri taslağı Local Storage üzerinde otomatik kaydedilir hâle getirildi.

Sayfa yeniden açıldığında veya yenilendiğinde kayıtlı taslağın geri yüklenmesi sağlandı.

Bozuk veya mevcut modelle uyumsuz kayıtların uygulamayı etkilemeden yok sayılması sağlandı.

Taslağın son kaydedilme saati çalışma alanında görünür hâle getirildi.

Storage adaptörü için boş kayıt, kayıt/geri yükleme, boş metinler, bozuk veri ve uyumsuz veri senaryolarını kapsayan 5 test eklendi.

Sprint 61 — Translation Studio taslak yönetimi

Translation Studio başlığına “Yeni Çalışma” düğmesi eklendi.

Kaynak metin veya çeviri taslağı doluyken yeni çalışma başlatılmadan önce kullanıcı onayı alınır hâle getirildi.

Kullanıcı işlemi iptal ettiğinde mevcut taslağın ve ayarların korunması sağlandı.

Kullanıcı işlemi onayladığında kaynak metin, çeviri taslağı ve kayıtlı Local Storage verisi temizlenir hâle getirildi.

Yeni çalışmanın Macarca → Türkçe, Genel ve “Ben Çevireceğim” varsayılan ayarlarıyla başlaması sağlandı.

Storage adaptörüne yalnızca aktif çeviri taslağı anahtarını kaldıran clear işlemi ve bu davranışı doğrulayan test eklendi.

Sprint 62 — Kaynak metni çalışma bölümlerine ayırma

Kaynak metni cümle sonu işaretleri ve satır sınırlarına göre çalışma bölümlerine ayıran saf Core fonksiyonu eklendi.

Boş parçaların elenmesi, bölüm sırasının korunması ve her bölümün karakter sayısının hesaplanması sağlandı.

Translation Studio çalışma alanına “Kaynak metin bölümleri” görünümü eklendi.

Her bölümün sıra numarası, metni ve karakter sayısı kullanıcıya gösterilir hâle getirildi.

Kaynak metin boşaltıldığında bölüm görünümünün otomatik olarak kaldırılması sağlandı.

Boş metin, tek cümle, farklı noktalama işaretleri, satır sınırları ve boşluk normalizasyonunu kapsayan 5 Core testi eklendi.

Sprint 63 — Bölüm seçimi ve odaklı çeviri

Kaynak metin bölüm kartları tıklanabilir hâle getirildi.

İlk bölümün çalışma başladığında otomatik olarak seçilmesi sağlandı.

Seçilen bölüm kartı görsel olarak vurgulanır hâle getirildi.

Çalışma alanına seçilen kaynak metni gösteren “Odaklanan bölüm” alanı eklendi.

Odaklanan bölümün sıra numarası ve toplam bölüm sayısı birlikte gösterilir hâle getirildi.

Kaynak metin değiştiğinde artık bulunmayan bir seçimin güvenli biçimde ilk geçerli bölüme dönmesi sağlandı.

Sprint 64 — Bölüm bazlı çeviri taslakları

Her kaynak metin bölümü için ayrı çeviri taslağı oluşturulabilir hâle getirildi.

Sağdaki çeviri alanı yalnızca seçili kaynak bölümün taslağını düzenler hâle getirildi.

Bölümler arasında geçiş yapıldığında daha önce yazılan taslakların korunması sağlandı.

Bölüm kartlarına “Taslak hazır” ve “Taslak bekliyor” durumları eklendi.

Tamamlanan bölüm taslağı sayısı “1 / 3 çevrildi” biçiminde gösterilir hâle getirildi.

Bölüm bazlı taslaklar mevcut otomatik Local Storage kaydına dâhil edildi.

Eski tek parça çeviri taslaklarının ilk bölüme aktarılması ve eski kayıtların geriye uyumlu açılması sağlandı.

Eski kayıt ve geçersiz bölüm taslağı senaryolarını kapsayan 2 yeni storage testi eklendi.

Sprint 65 — Birleştirilmiş çeviri önizlemesi

Bölüm taslaklarını kaynak bölüm sırasına göre birleştiren saf Core servisi eklendi.

Translation Studio çalışma alanına “Tam çeviri önizlemesi” bölümü eklendi.

Tamamlanan bölüm taslakları iki satır arayla tek bir çeviri metninde birleştirilir hâle getirildi.

Eksik çalışma durumunda bekleyen bölüm sayısının gösterilmesi sağlandı.

Bütün bölümler tamamlandığında “Tüm bölümler hazır” durumu eklendi.

Artık kaynak metinde bulunmayan eski bölüm taslaklarının önizlemeye dâhil edilmemesi sağlandı.

Boş çalışma, kaynak sırası, boş taslak, tamamlanma ve eski taslak senaryolarını kapsayan 5 Core testi eklendi.

Sprint 66 — Tam çeviriyi panoya kopyalama

Tam veya kısmi çeviri önizlemesini tarayıcı panosuna kopyalayan UI katmanı servisi eklendi.

“Tam çeviri önizlemesi” başlığına “Çeviriyi Kopyala” düğmesi eklendi.

Kopyalama devam ederken, başarıyla tamamlandığında ve başarısız olduğunda kullanıcıya ayrı durum geri bildirimleri gösterilir hâle getirildi.

Boş çeviri önizlemesinde kopyalama düğmesinin pasif kalması sağlandı.

Pano erişiminin bulunmaması, boş metin ve tarayıcı izin hataları güvenli biçimde ele alındı.

Pano servisi için başarılı kopyalama, boş metin, kullanılamayan pano ve yazma hatası senaryolarını kapsayan 4 test eklendi.

İlk teslim paketindeki fazladan app klasörü düzeltildi; Sprint 66 Rev2 paketi proje köküne göre src klasöründen başlayacak biçimde hazırlandı.

Sprint 67 — Çeviri çalışmasını UTF-8 metin dosyası olarak indirme

Tarayıcıya özgü dosya üretimi ve indirme işlemleri için UI katmanında BrowserTextDownloadService eklendi.

“Tam çeviri önizlemesi” alanına “Çalışmayı İndir” düğmesi eklendi.

İndirilen UTF-8 metin dosyasına LAF Studio başlığı, dil yönü, uzmanlık alanı ve çalışma biçimi bilgileri eklendi.

Kaynak metin “KAYNAK METİN”, tamamlanan çeviri ise “ÇEVİRİ” başlığı altında aynı dosyada birlikte sunulur hâle getirildi.

Türkçe ve Macarca karakterlerin, bölüm sırasının ve satır aralıklarının korunması sağlandı.

İndirme başarı ve hata durumları kullanıcıya ayrı geri bildirimlerle gösterilir hâle getirildi.

İlk sürümde yalnızca hedef çevirinin indirilmesi tarayıcı doğrulamasında tespit edildi; Sprint 67 Rev1 ile iki dilli çalışma belgesi biçimine geçirildi.

İndirme servisi için UTF-8 içerik, boş metin, desteklenmeyen tarayıcı ve indirme hatası sonrası kaynak temizliği senaryolarını kapsayan 4 test eklendi.

12. Güncel doğrulama durumu

Tarihsel kayıt (28 Temmuz 2026): Son tamamlanan sprint Sprint 67

Doğrulama tarihi: 28 Temmuz 2026

Sprint 67 doğrulama saati: 01:02

Test sonucu: 20 test dosyası ve 173 test başarılı.

Production build: Başarılı.

Vite build: 97 modül dönüştürüldü.

Son build çıktısı:

CSS: 39.09 kB — gzip 7.12 kB

JavaScript: 321.05 kB — gzip 94.67 kB

Sprint 67 Rev1 son build süresi: 750 ms

Tarayıcı doğrulaması: Olumlu.

Sprint 67 için tarayıcıda doğrulanan özellikler:

“Çalışmayı İndir” düğmesinin “Tam çeviri önizlemesi” alanında görünmesi

UTF-8 metin dosyasının tarayıcı üzerinden indirilmesi

Kaynak metin ve çevirinin aynı dosyada ayrı başlıklarla bulunması

Türkçe ve Macarca karakterlerin korunması

Başarılı indirme sonrasında kullanıcı geri bildiriminin görünmesi

13. Güncel teknik kararlar

Dinleme pratiği ana LearningSession oturumundan ayrı tutulur.

Dinleme metrikleri ana ders tamamlanma yüzdesini değiştirmez.

Tarayıcıya özgü seslendirme, kayıt ve Local Storage uygulamaları UI katmanında tutulur.

Dinleme hesaplamaları features/lessons servisleri içerisinde saf fonksiyonlarla yapılır.

Ses kaydı geçici tarayıcı URL'si kullanır; sunucuya veya kalıcı depoya ses dosyası gönderilmez.

Ders ve dinleme kayıtları ders kimliğine göre ayrı Local Storage anahtarlarında tutulur.

Kod teslimleri klasör yapısını koruyan LAF-Studio-Sprint-XX.zip değişiklik paketleriyle yapılır.

Bir sprint yalnızca test, build ve tarayıcı doğrulaması olumlu olduğunda tamamlanır.

Her tamamlanan ve doğrulanan sprintten sonra PROJECT_NOTES.md dosyasına kısa bir kontrol noktası eklenir.

Çalışma gününün sonunda kısa kontrol noktaları tarih, saat ve toplam çalışma bilgileriyle topluca düzenlenir.

14. Devam eden işler

Aktif ve yarım kalmış bir sprint bulunmuyor.

Sprint 67 tamamen doğrulandı ve kapatıldı.

Translation Studio’nun ilk çalışma alanı, taslak sürekliliği, yeni çalışma akışı, kaynak metin bölümleme, odaklı bölüm seçimi, bölüm bazlı taslaklar, tam çeviri önizlemesi, panoya kopyalama ve iki dilli metin dosyası indirme akışı çalışır durumdadır.

15. Bir sonraki adımlar

Ana ürün mimarisi Learning Studio, Translation Studio, Interpreting Studio ve LAF Intelligence Core olarak onaylandı.

Translation Studio V1 kapsamı ve temel kullanıcı akışı onaylandı.

Translation Studio Development Brief hazırlandı ve onaylandı:

TRANSLATION_STUDIO_V1_DEVELOPMENT_BRIEF.md

Sprint 67 hedefi tamamen teslim edildi.

Sprint 68 hedefi, “Ben Çevireceğim” modunda kaynak metin ve kullanıcı çevirisinden doğrulanabilir bir değerlendirme isteği oluşturabilmektir.

Sprint 68’de sahte AI değerlendirme sonucu üretilmeyecek; değerlendirme isteği modeli, hazırlık doğrulaması ve kullanıcı akışı kurulacaktır.

Sprint 1–58 arasında tamamlanan çalışmalar Learning Studio temel prototipi; Sprint 59–67 ise Translation Studio’nun ilk çalışan temeli, taslak sürekliliği, yeni çalışma akışı, kaynak metin bölümleme, odaklı bölüm seçimi, bölüm bazlı taslaklar, birleşik önizleme, panoya kopyalama ve iki dilli dosya indirme olarak kabul edilir.

Geliştirme sırasında mevcut katmanlı mimari, Local Storage uyumluluğu ve ana ders ilerleme hesapları korunacaktır.

16. Çalışma sonu güncelleme şablonu

Her çalışma gününün sonunda aşağıdaki kayıt belgenin güncel durum bölümüne eklenir:

## Çalışma Kaydı — DD.MM.YYYY, SS:DD–SS:DD

- Başlangıç saati:
- Bitiş saati:
- Toplam çalışma süresi:
- Tamamlanan sprintler:
- Amaç:
- Yapılan değişiklikler:
- Değiştirilen dosyalar:
- Alınan kararlar:
- Test sonucu:
- Build sonucu:
- Tarayıcı doğrulaması:
- Çalışan özellikler:
- Açık sorunlar:
- Sonraki adım:

17. Yeni sohbet başlangıç talimatı

Yeni bir LAF Studio — Development sohbetinde aşağıdaki mesaj kullanılmalıdır:

LAF Studio — Development projesine devam ediyoruz.

Önce proje kökündeki PROJECT_NOTES.md dosyasını oku.

Mevcut durumu, mimari kararları, tamamlanan işleri, devam eden sprinti ve bir sonraki adımı bu dosyaya göre belirle.

Mevcut katmanlı mimariyi ve çalışma kurallarını koru.

Aynı anda yalnızca bir sprint üzerinde çalış.

Her sprint sonunda npm run test, npm run build ve tarayıcı doğrulaması yap.

Kod teslimlerini klasör yapısını koruyan ZIP değişiklik paketleriyle hazırla.

Her tamamlanan sprintten sonra PROJECT_NOTES.md dosyasına kısa bir kontrol noktası ekle.

Çalışma gününün sonunda bu kayıtları tarih, saat ve toplam çalışma süresiyle topluca düzenle.

---

## Sprint 85 — Bağlamsal anlam isteği ve manuel sonuç kaydı

Durum: TAMAMLANDI ve TARAYICIDA DOĞRULANDI

Amaç:
Metin ve Kelime Atölyesi içinde seçilen bir kelime için bağlama özel anlam inceleme akışını kurmak; ilgili cümleyi ve dil yönünü belirlemek, yapılandırılmış AI isteği üretmek, sonucu kullanıcı tarafından karşılık + gerekçe + güven düzeyi ile kaydetmek ve kullanıcı onayı olmadan Terminoloji Merkezi'ne otomatik kayıt yapmamak.

Doğrulanan akış:
- Kaynak dili Macarca seçildi.
- Test metni: "Az egészségügy új intézkedéseket vezetett be. Az intézkedéseket sokan vitatják."
- "vitatják" kelimesi seçildi.
- İlgili cümle doğru bulundu: "Az intézkedéseket sokan vitatják."
- Çeviri yönü doğru belirlendi: Macarca → Türkçe.
- Bağlamsal anlam için yapılandırılmış AI isteği oluşturuldu.
- "Panoya Kopyala" işlevi çalıştı.
- Ana karşılık alanına "eleştiriyorlar" yazılabildi.
- Gerekçe alanına "Bu bağlamda alınan önlemlere karşı çıkılması anlatılıyor." yazılabildi.
- Güven düzeyi seçilebildi.
- Sonuç başarıyla kaydedilebildi.
- Sonuç kullanıcı onayı olmadan Terminoloji Merkezi'ne otomatik eklenmedi.

Teknik doğrulama:
- Test dosyası: 42 passed
- Test: 290 passed / 0 failed
- Production build: başarılı
- Vite: 125 modül dönüştürüldü
- Build süresi: 719 ms
- Tarayıcı doğrulaması: OLUMLU

Kararlı taban:
Sprint 85 / 290 passed / 0 failed

Sıradaki sprint:
Sprint 86 — Bağlamsal anlamın sistem tarafından otomatik üretilmesi.

LAF Studio geliştirme çalışma standardı:
- Aynı anda yalnızca tek sprint yürütülür.
- Önce hedef test, ardından tam regresyon çalıştırılır.
- Kararlı taban korunur.
- Teslim mümkün olduğunca tek ZIP + tek PowerShell ile yapılır.
- Parçalı yama yerine mümkün olduğunca tam dosya değişikliği kullanılır.
- Test, build ve tarayıcı doğrulaması tamamlanmadan sonraki sprinte geçilmez.
- Kullanıcı onayı olmadan Terminoloji Merkezi'ne otomatik aktarım yapılmaz.

Not:
Proje kökündeki PROJECT_NOTES.md kaydı Sprint 67'de kalmıştı. Kaynak kod incelemesi ve doğrulama geçmişi Sprint 85'in tamamlandığını gösterdi. Bu kontrol noktası gerçek kararlı geliştirme durumunu yeniden senkronize eder.

---

## Sprint 86 — Bağlamsal anlamın sistem tarafından otomatik üretilmesi

Durum: TAMAMLANDI ve TARAYICIDA DOĞRULANDI

Amaç:
Metin ve Kelime Atölyesi içinde seçilen bir kelime için bağlama özel anlamın yapay zekâ tarafından otomatik üretilmesini sağlamak; Sprint 85'teki manuel inceleme ve kullanıcı onayı güvenlik davranışını korumak.

Uygulanan davranış:
- Seçilen kelime ve bağlam cümlesinden yapılandırılmış AI isteği hazırlanır.
- AI sonucu ana karşılık, bağlam gerekçesi ve güven düzeyi alanlarına otomatik getirilir.
- Kullanıcı AI sonucunu kaydetmeden önce düzenleyebilir.
- Sonuç kullanıcı eylemi olmadan kesinleştirilmez.
- Terminoloji Merkezi'ne otomatik kayıt yapılmaz.
- Terminolojiye aktarım yalnızca açık kullanıcı eylemiyle gerçekleşir.
- API anahtarı tarayıcı tarafına taşınmaz; yerel backend/provider sınırı kullanılır.

Teknik doğrulama:
- Sprint 86 hedef testleri: 3 test dosyası / 18 test başarılı
- Tam regresyon: 44 test dosyası / 299 test başarılı
- Hata: 0
- Production build: başarılı
- Vite: 127 modül dönüştürüldü
- Build süresi: 6.32 sn
- Başlangıç kararlı tabanı: Sprint 85 / 290 passed / 0 failed
- Sprint 85 yedeği: D:\Projects\LAF-Studio\_sprint_backups\Sprint86-20260805-211104

Tarayıcı doğrulaması:
- Kaynak dil: Macarca
- Test metni: "Az egészségügy új intézkedéseket vezetett be. Az intézkedéseket sokan vitatják."
- Seçilen kelime: "vitatják"
- Bağlam cümlesi doğru bulundu: "Az intézkedéseket sokan vitatják."
- AI otomatik sonuç üretti.
- Ana karşılık örneği: "tartışıyorlar"
- Bağlam gerekçesi otomatik üretildi.
- Güven düzeyi otomatik üretildi: Yüksek
- Sonuç kullanıcı tarafından kaydedilebilir durumda doğrulandı.
- Terminoloji Merkezi'ne kendiliğinden eklenmediği doğrulandı.
- Tarayıcı doğrulaması: OLUMLU

Yeni kararlı taban:
Sprint 86 / 299 passed / 0 failed

Çalışma kuralı:
Sprint 86 tamamen kapanmıştır. Yeni sprint, kapsamı belirlenip onaylanmadan başlatılmayacaktır.

---

## Sprint 87 — Bağlamsal Anlam İnceleme Geçmişi

Durum: TAMAMLANDI ve TARAYICIDA DOĞRULANDI

Amaç:
Kaydedilen bağlamsal anlam sonuçlarını kalıcı inceleme geçmişi olarak saklamak; aynı kelime tekrar seçildiğinde önceki incelemeleri göstermek; birebir aynı kaydın çoğalmasını engellemek ve Sprint 86'daki kullanıcı onayı güvenlik davranışını korumak.

Uygulanan davranış:
- "Anlamı İncelemeye Ekle" ile kaydedilen sonuçlar Local Storage üzerinde kalıcı tutulur.
- Aynı kelime yeniden seçildiğinde önceki bağlamsal anlam incelemeleri gösterilir.
- Birebir aynı inceleme sonucu tekrar kaydedildiğinde yeni kopya oluşturulmaz.
- Düzenlenmiş veya farklı sonuçlar ayrı tarihsel kayıt olarak saklanabilir.
- AI otomatik üretim akışı korunur.
- Terminoloji Merkezi'ne otomatik aktarım yapılmaz.
- Terminolojiye aktarım yalnızca açık kullanıcı eylemiyle gerçekleşir.

Teknik doğrulama:
- Tam regresyon: 45 test dosyası / 307 test başarılı
- Hata: 0
- Production build: başarılı
- Vite: 128 modül dönüştürüldü
- Build süresi: 2.85 sn
- Başlangıç kararlı tabanı: Sprint 86 / 299 passed / 0 failed
- Sprint 86 yedeği: D:\Projects\LAF-Studio\_sprint_backups\Sprint87-20260805-214009

Tarayıcı doğrulaması:
- Kaynak dil: Macarca
- Test kelimesi: "vitatják"
- AI sonucu oluşturuldu ve "Anlamı İncelemeye Ekle" ile kaydedildi.
- "İNCELEME GEÇMİŞİ / Kaydedilen bağlamsal anlamlar" bölümü görüntülendi.
- Kayıtta karşılık, bağlam cümlesi, gerekçe, güven düzeyi ve kayıt zamanı görüntülendi.
- Ctrl + F5 sonrasında geçmiş kaydı yeniden göründü.
- Aynı sonuç ikinci kez kaydedildiğinde kayıt sayısı çoğalmadı.
- Terminoloji Merkezi'ne kendiliğinden kayıt yapılmadı.
- Tarayıcı doğrulaması: OLUMLU

Yeni kararlı taban:
Sprint 87 / 307 passed / 0 failed

Çalışma kuralı:
Sprint 87 tamamen kapanmıştır. Yeni sprint kapsamı belirlenmeden ve onaylanmadan sonraki geliştirmeye geçilmeyecektir.

---

## Sprint 88 — İnceleme Geçmişinden Yeniden Kullanım

Durum: TAMAMLANDI ve TARAYICIDA DOĞRULANDI

Amaç:
Bağlamsal anlam inceleme geçmişindeki bir kaydı yeniden düzenleme alanlarına yükleyebilmek; kullanıcının eski karşılık, gerekçe ve güven düzeyini düzenleyip yeniden kaydedebilmesini sağlamak ve Sprint 87 tekrar-kayıt korumasını sürdürmek.

Uygulanan davranış:
- İnceleme geçmişindeki kayıtlara "Düzenlemeye Yükle" eylemi eklendi.
- Geçmiş kaydı ana karşılık, bağlam gerekçesi ve güven düzeyi alanlarına geri yüklenir.
- Kullanıcı yüklenen alanları düzenleyebilir.
- Birebir aynı içerik değiştirilmeden yeniden kaydedildiğinde yeni kopya oluşturulmaz.
- Düzenlenmiş/farklı sonuç ayrı tarihsel kayıt olarak saklanır.
- AI otomatik üretim akışı korunur.
- Terminoloji Merkezi'ne otomatik aktarım yapılmaz.
- Terminolojiye aktarım yalnızca açık kullanıcı eylemiyle gerçekleşir.

Teknik doğrulama:
- Tam regresyon: 45 test dosyası / 309 test başarılı
- Hata: 0
- Production build: başarılı
- Vite: 128 modül dönüştürüldü
- Build süresi: 963 ms
- Başlangıç kararlı tabanı: Sprint 87 / 307 passed / 0 failed
- Sprint 87 yedeği: D:\Projects\LAF-Studio\_sprint_backups\Sprint88-20260805-215158

Tarayıcı doğrulaması:
- Geçmiş kaydındaki "Düzenlemeye Yükle" eylemi çalıştı.
- Ana karşılık yeniden düzenleme alanına geldi.
- Bağlam gerekçesi yeniden düzenleme alanına geldi.
- Güven düzeyi yeniden yüklendi.
- Alanlar kullanıcı tarafından düzenlenebildi.
- Değiştirilmeden yeniden kaydedilen aynı sonuç geçmişte çoğalmadı.
- Düzenlenmiş farklı sonuç ayrı geçmiş kaydı oluşturdu.
- Terminoloji Merkezi'ne otomatik kayıt yapılmadı.
- Tarayıcı doğrulaması: OLUMLU

Yeni kararlı taban:
Sprint 88 / 309 passed / 0 failed

Çalışma kuralı:
Sprint 88 tamamen kapanmıştır. Yeni sprint kapsamı belirlenmeden ve onaylanmadan sonraki geliştirmeye geçilmeyecektir.

---

## Sprint 89 — İnceleme Geçmişi Kayıt Silme

Durum: TAMAMLANDI ve TARAYICIDA DOĞRULANDI

Uygulanan davranış:
- Tek bir bağlamsal anlam geçmiş kaydı "Kaydı Sil" eylemiyle kaldırılabilir.
- Silmeden önce kullanıcı onayı alınır.
- İptal edilirse kayıt korunur.
- Onaylanırsa yalnız seçilen kayıt silinir.
- Ctrl + F5 sonrasında silinen kayıt geri gelmez.
- Diğer geçmiş kayıtları korunur.
- Terminoloji Merkezi etkilenmez.

Teknik doğrulama:
- Başlangıç kararlı tabanı: Sprint 88 / 309 passed / 0 failed
- Sprint 89 hedef testleri başarılı
- Tam regresyon başarılı
- Production build başarılı
- Sprint 89 paketi üç yeni regresyon testi ekledi.
- Kararlı test tabanı: Sprint 89 / 312 passed / 0 failed

Tarayıcı doğrulaması: OLUMLU

Yeni kararlı taban:
Sprint 89 / 312 passed / 0 failed

---

## Sprint 90 — Bağlamsal Anlam Geçmişi Arama ve Sıralama

Durum: TAMAMLANDI ve TARAYICIDA DOĞRULANDI

Amaç:
Bağlamsal anlam inceleme geçmişini daha büyük ve kullanışlı bir çalışma alanına dönüştürmek; geçmiş kayıtlarında arama, sıralama ve tüm eşleşen kayıtlara erişim sağlamak.

Uygulanan davranış:
- Geçmişte karşılık, gerekçe ve bağlam metnine göre arama yapılabilir.
- Geçmiş "En yeni önce" ve "En eski önce" olarak sıralanabilir.
- Önceki 5 kayıt görünüm sınırı kaldırıldı; eşleşen tüm geçmiş kayıtları görüntülenebilir.
- Filtrelenen / toplam kayıt sayısı gösterilir.
- Filtre tek eylemle temizlenebilir.
- Önceki "Düzenlemeye Yükle" davranışı korunur.
- Tek kayıt silme ve kullanıcı onayı davranışı korunur.
- Birebir aynı kaydın çoğalmasını engelleyen koruma sürer.
- Terminoloji Merkezi'ne otomatik aktarım yapılmaz.

Teknik doğrulama:
- Başlangıç kararlı tabanı: Sprint 89 / 312 passed / 0 failed
- Sprint 90 hedef testleri başarılı
- Tam regresyon: 46 test dosyası / 319 test başarılı
- Hata: 0
- Production build: başarılı

Tarayıcı doğrulaması:
- Geçmiş arama alanı çalıştı.
- Karşılık, gerekçe veya bağlam metnine göre filtreleme çalıştı.
- En yeni / en eski sıralama çalıştı.
- Filtrelenen / toplam kayıt sayısı doğru gösterildi.
- Filtreyi temizleme çalıştı.
- Önceki geçmiş yönetimi işlevleri bozulmadı.
- Terminoloji Merkezi'ne otomatik aktarım yapılmadı.
- Tarayıcı doğrulaması: OLUMLU

Yeni kararlı taban:
Sprint 90 / 319 passed / 0 failed

Çalışma modeli:
Sprint 90'dan itibaren kalite ve güvenlik kapıları azaltılmadan daha orta büyüklükte sprintler uygulanır:
- tek sprint,
- hedef test,
- tam regresyon,
- production build,
- tarayıcı doğrulaması,
- kararlı taban yedeği,
- başarısızlıkta geri dönüş,
- tek ZIP + tek PowerShell,
- mümkün olduğunca tam dosya değişikliği,
- doğrulanmadan sonraki sprinte geçmeme.

---

## Sprint 91 — Bağlamsal Anlam Geçmişi Akıllı Filtreleme ve Özet

Durum: TAMAMLANDI ve TARAYICIDA DOĞRULANDI

Amaç:
Bağlamsal anlam inceleme geçmişini güven düzeyi ve bağlam kapsamı ile daha hızlı süzülebilir hâle getirmek; görünür geçmiş için özet sayaçları sunmak ve mevcut arama/sıralama davranışlarıyla birlikte çalışmasını sağlamak.

Uygulanan davranış:
- Güven filtresi: Tümü / Yüksek / Orta / Düşük.
- Bağlam kapsamı: Tüm bağlamlar / Yalnız bu cümle.
- Eşleşen kayıt sayısı gösterilir.
- Yüksek / Orta / Düşük güven dağılımı özetlenir.
- Arama, sıralama, güven filtresi ve bağlam filtresi birlikte çalışır.
- Tüm aktif filtreler tek eylemle temizlenebilir.
- Geçmişten düzenlemeye yükleme korunur.
- Tek kayıt silme ve kullanıcı onayı korunur.
- Birebir aynı kaydın çoğalmasını engelleyen koruma sürer.
- AI otomatik üretimi korunur.
- Terminoloji Merkezi'ne otomatik aktarım yapılmaz.

Teknik doğrulama:
- Başlangıç kararlı tabanı: Sprint 90 / 319 passed / 0 failed
- Sprint 91 hedef testleri başarılı
- Tam regresyon başarılı
- Sprint 91 paketinde 6 yeni test
- Yeni kararlı test tabanı: Sprint 91 / 325 passed / 0 failed
- Production build başarılı

Tarayıcı doğrulaması:
- Güven filtresi görüntülendi ve çalıştı.
- Bağlam kapsamı filtresi görüntülendi ve çalıştı.
- Eşleşen / Yüksek / Orta / Düşük özet sayaçları doğru davrandı.
- Arama + güven filtresi + bağlam filtresi birlikte çalıştı.
- Filtreleri Temizle varsayılan duruma döndürdü.
- Önceki sıralama, Düzenlemeye Yükle ve Kaydı Sil işlevleri korunmuş durumda.
- Terminoloji Merkezi'ne otomatik kayıt yapılmadı.
- Tarayıcı doğrulaması: OLUMLU

Yeni kararlı taban:
Sprint 91 / 325 passed / 0 failed

Çalışma modeli:
Kalite ve güvenlik kapıları korunarak orta büyüklükte sprintlerle ilerleme sürdürülür.

---

## Sprint 92–94 Blok Kapanışı

Durum: TAMAMLANDI ve TOPLU TARAYICI DOĞRULAMASI OLUMLU

Başlangıç kararlı tabanı:
Sprint 91 / 325 passed / 0 failed

### Sprint 92 Rev1 — Bağlamsal Anlam Geçmişi Dışa Aktarma
- Görünen / filtrelenmiş geçmiş panoya kopyalanabilir.
- Görünen / filtrelenmiş geçmiş UTF-8 TXT dosyası olarak indirilebilir.
- Dışa aktarılan içerikte kelime, dil yönü, aktif filtreler, sıralama, bağlam kapsamı ve kayıt sayıları bulunur.
- İlk Sprint 92 denemesinde test dosyasındaki iki TypeScript strict-build hatası nedeniyle production build başarısız oldu.
- Kurucu Sprint 91 tabanını otomatik geri yükledi.
- Sprint 92 Rev1'de yalnız test tipi uyumluluğu düzeltildi ve teknik doğrulama başarıyla tamamlandı.

### Sprint 93 — İki Kaydı Karşılaştırma
- Geçmişten en fazla iki inceleme kaydı seçilebilir.
- Kayıt A ve Kayıt B yan yana karşılaştırılabilir.
- Karşılık, Güven, Bağlam ve Gerekçe alanları için Aynı / Farklı özeti gösterilir.
- İki kayıt seçiliyken üçüncü seçim engellenir.
- Seçim temizlenebilir.
- Silinen kayıt karşılaştırma seçiminden otomatik çıkarılır.

### Sprint 94 — Karşılaştırma Sonucunu Kullanma ve Özetleme
- Tüm alanlar / Yalnız farklı alanlar görünümü vardır.
- Kayıt A ve B karşılaştırma tablosunda yan yana gösterilir.
- Farklı alanlar görsel olarak ayrıştırılır.
- Kayıt A veya Kayıt B doğrudan düzenleme alanına yüklenebilir.
- Karşılaştırma özeti panoya kopyalanabilir.
- Fark bulunmayan karşılaştırma açıkça gösterilir.

Teknik doğrulama:
- Sprint 92 Rev1: başarılı
- Sprint 93: başarılı
- Sprint 94: başarılı
- Yeni kararlı test tabanı: Sprint 94 / 349 passed / 0 failed
- Production build: başarılı
- Otomatik yedek / geri dönüş koruması: aktif

Toplu tarayıcı doğrulaması:
- Sprint 92 dışa aktarma davranışları: OLUMLU
- Sprint 93 iki kayıt karşılaştırma davranışları: OLUMLU
- Sprint 94 karşılaştırma sonucu kullanma ve özetleme davranışları: OLUMLU
- Önceki arama, sıralama, filtreleme, Düzenlemeye Yükle ve Kaydı Sil işlevleri korunuyor.
- Terminoloji Merkezi'ne otomatik aktarım yapılmıyor.
- Toplu tarayıcı doğrulaması: OLUMLU

Risk sınırları:
- Local Storage şeması değiştirilmedi.
- AI/backend değiştirilmedi.
- Routing değiştirilmedi.
- Terminoloji Merkezi güvenlik davranışı değiştirilmedi.

Yeni kararlı taban:
Sprint 94 / 349 passed / 0 failed

Çalışma modeli:
- İlişkili geliştirmeler 3 sprintlik bloklar hâlinde ilerletilir.
- Her sprintte hedef test + tam regresyon + production build + yedek/geri dönüş korunur.
- Manuel tarayıcı doğrulaması ve PROJECT_NOTES kapanışı blok sonunda toplu yapılır.
- Yüksek riskli değişikliklerde ara manuel doğrulama zorunludur.

Planlanan sonraki bağımsız geliştirme alanı:
Belge ve Görsel Çeviri Girdisi
- PDF
- JPG
- JPEG
- PNG
- Metin tabanlı PDF'de doğrudan metin katmanı
- Taranmış PDF/görsellerde gerektiğinde OCR
- Çıkarılan metni kullanıcıya gösterme ve düzeltme
- Kullanıcı onayından sonra mevcut çeviri ve Metin/Kelime Atölyesi zincirine aktarma
- Sessiz otomatik çeviri yapılmaması

---

## Sprint 95–97 Blok Kapanışı — Belge ve Görsel Çeviri Girdisi

Durum: TAMAMLANDI ve TOPLU TARAYICI DOĞRULAMASI OLUMLU

Başlangıç kararlı tabanı:
Sprint 94 / 349 passed / 0 failed

### Sprint 95 — Güvenli Dosya Kabulü ve Önizleme
- PDF / JPG / JPEG / PNG dosyası seçme.
- Sürükleyip bırakma.
- Dosya türü, boş dosya ve 20 MB boyut sınırı doğrulaması.
- Yerel görsel / PDF önizleme.
- Dosya adı, türü, boyutu ve son değişiklik bilgisi.
- Dosyayı Kaldır davranışı.
- Dosya bu aşamada backend, AI veya OCR işlemine gönderilmez.

### Sprint 96 Rev4 — PDF Metin Katmanı ve OCR Hazırlık Mimarisi
- Metin tabanlı PDF'lerde yerel PDF.js metin çıkarımı.
- Sayfa bazlı metin birleştirme.
- Metin katmanı bulundu / OCR gerekli / çıkarım hatası ayrımı.
- Görsel ve taranmış PDF için OCR gerekli sınıflandırması.
- PDF.js TypeScript uyumluluk düzeltmeleri.
- Windows PowerShell 5.1 native stderr / exit code build doğrulaması düzeltildi.
- Teknik doğrulama Rev4'te başarıyla tamamlandı.

### Sprint 97 Rev1 — OCR, Kullanıcı Kontrolü ve Çalışma Alanına Aktarım
- JPG / JPEG / PNG için kullanıcı başlatmalı tarayıcı içi OCR.
- Taranmış PDF sayfalarının yerel rasterizasyonu ve OCR akışı.
- Macarca OCR modeli: hun.
- Türkçe OCR modeli: tur.
- Sayfa bazlı OCR ilerleme göstergesi.
- OCR/PDF çıkarım sonucunu düzenlenebilir kullanıcı kontrol alanında gösterme.
- Düzeltmeleri Sıfırla.
- Açık kullanıcı onayıyla Metni Çalışma Alanına Aktar.
- Aktarım otomatik çeviri başlatmaz.
- Terminoloji Merkezi'ne otomatik kayıt yapılmaz.
- İlk Sprint 97 denemesinde Node/Vitest ortamındaki DOM/canvas bağımlı test hatası nedeniyle rollback çalıştı.
- Rev1 testleri DOM bağımsız hâle getirildi ve teknik doğrulama başarıyla tamamlandı.

Toplu tarayıcı doğrulaması:
- PDF/JPG/PNG dosya kabulü ve önizleme: OLUMLU
- Dosyayı Kaldır: OLUMLU
- PDF metin katmanı çıkarımı: OLUMLU
- OCR gerekli sınıflandırması: OLUMLU
- Kullanıcı başlatmalı OCR: OLUMLU
- Düzenlenebilir çıkarılan metin: OLUMLU
- Düzeltmeleri Sıfırla: OLUMLU
- Metni Çalışma Alanına Aktar: OLUMLU
- Otomatik çeviri başlatılmaması: OLUMLU
- Terminoloji Merkezi'ne otomatik kayıt yapılmaması: OLUMLU
- Önceki manuel metin ve kelime/bağlamsal anlam akışları: OLUMLU

Teknik durum:
- Sprint 95 teknik doğrulaması: başarılı
- Sprint 96 Rev4 teknik doğrulaması: başarılı
- Sprint 97 Rev1 teknik doğrulaması: başarılı
- Tam regresyon ve production build Sprint 97 Rev1 kurulumunda başarıyla geçti
- Son manuel doğrulanmış ürün durumu: Sprint 97 Rev1

UX notu:
"Dosyayı Kaldır" yalnız belgeyi ve önizlemeyi kaldırır.
Daha önce çalışma alanına aktarılmış metin otomatik silinmez.
Gelecekte ayrı ve açık bir "Belgeyi ve Aktarılan Metni Temizle" eylemi eklenmesi planlanmalıdır.

Yeni kararlı checkpoint:
Sprint 97 Rev1 — Belge ve Görsel Çeviri Girdisi tamamlandı

Sıradaki planlanan geliştirme bloğu:
Sprint 98–100 — Kelime & Hafıza Studio

---

## Sprint 98–100 Blok Kapanışı — Kelime & Hafıza Studio

Durum: TAMAMLANDI ve TOPLU TARAYICI DOĞRULAMASI OLUMLU

Başlangıç kararlı tabanı:
Sprint 97 Rev1 — Belge ve Görsel Çeviri Girdisi

### Sprint 98 — Öğrenme Adayı Havuzu
- Bağlamsal anlam sonucundan “Öğrenmeye Ekle”.
- İnceleme geçmişindeki kayıttan “Öğrenmeye Ekle”.
- Terminoloji karşılığından “Öğrenmeye Ekle”.
- Aynı kelime + aynı anlam + aynı bağlamın tekrar kaydedilmesini engelleme.
- Aynı kelimenin farklı anlamını veya farklı bağlamını ayrı öğrenme adayı olarak kabul etme.
- Seçili kelime için öğrenme adaylarını gösterme.
- “Öğrenmeden Çıkar”.
- Öğrenme havuzu, Terminoloji ve bağlamsal anlam verilerinden ayrı Local Storage katmanında tutulur.

### Sprint 99 Rev1 — Aktif Hatırlama ve Kelime Çalışma Kartları
- Öğrenme adayından “Çalış” ile aktif hatırlama kartı.
- Cevap kullanıcı “Cevabı Göster” demeden görünmez.
- “Bilemedim / Zorlandım / Hatırladım” öz değerlendirmeleri.
- Tekrar sayısı, hatırlama sayısı ve lapse/bilemedim sayısı.
- Basit sonraki çalışma zamanı:
  - Bilemedim: yaklaşık 10 dakika
  - Zorlandım: yaklaşık 1 gün
  - Hatırladım: yaklaşık 3 gün, sonraki olumlu değerlendirmelerde artan aralık
- Öğrenme içeriği ile çalışma ilerlemesi ayrı saklanır.
- İlk Sprint 99 denemesinde find() metodundaki TypeScript parse hatası nedeniyle hedef test durdu.
- Otomatik rollback Sprint 98 tabanını geri yükledi.
- Rev1 parse düzeltmesiyle teknik doğrulama başarıyla tamamlandı.

### Sprint 100 — Günlük Tekrar Kuyruğu ve Çalışma Planı
- Dil yönüne göre kişisel günlük çalışma planı.
- Zamanı gelen tekrarlar önce, yeni kartlar sonra.
- Varsayılan günlük üst sınır: 20 kart.
- Varsayılan yeni kart üst sınırı: 10 kart.
- “Bugün Hazır / Tekrar / Yeni / Bugün Çalışılan / İleri Tarihli” özetleri.
- “Günlük Çalışmayı Başlat”.
- “Sıradaki Kartı Aç”.
- “Planı Yenile”.
- Kuyruktaki kartı doğrudan “Çalış”.
- Bugünkü sıra tamamlandığında sonraki planlı tekrar zamanını gösterme.
- Günlük plan türetilmiş görünüm katmanıdır; ayrı kalıcı plan verisi yazmaz.
- Arka planda polling veya otomatik çalışma başlatılmaz.

Toplu tarayıcı doğrulaması:
- “Öğrenmeye Ekle” görünürlüğü ve kayıt oluşturma: OLUMLU
- Aynı anlam/bağlam için duplicate engeli: OLUMLU
- Öğrenme adayı havuzu: OLUMLU
- “Çalış” çalışma kartı: OLUMLU
- “Cevabı Göster”: OLUMLU
- Bilemedim / Zorlandım / Hatırladım değerlendirmeleri: OLUMLU
- Günlük çalışma planı: OLUMLU
- Bugün Hazır / Tekrar / Yeni / Bugün Çalışılan / İleri Tarihli özetleri: OLUMLU
- Günlük Çalışmayı Başlat / Planı Yenile / kuyruktan Çalış: OLUMLU
- Önceki PDF/OCR, bilinmeyen kelimeler, bağlamsal anlam ve Terminoloji akışları: OLUMLU

Teknik durum:
- Sprint 98 teknik doğrulaması: başarılı
- Sprint 99 Rev1 teknik doğrulaması: başarılı
- Sprint 100 teknik doğrulaması: başarılı
- Tam regresyon: 473 passed / 0 failed (71 test dosyası)
- Production build: başarılı
- Son manuel doğrulanmış ürün durumu: Sprint 100

Yeni kararlı checkpoint:
Sprint 100 — Kelime & Hafıza Studio günlük çalışma planı tamamlandı

Sıradaki planlanan geliştirme bloğu:
Sprint 101–103 — Grammar Lab

---

## Sprint 101–103 Blok Kapanışı — Grammar Lab

Durum: TAMAMLANDI ve TOPLU TARAYICI DOĞRULAMASI OLUMLU

Başlangıç kararlı tabanı:
Sprint 100 — Kelime & Hafıza Studio günlük çalışma planı

### Sprint 101 — Yapı Gözlemi ve Dilbilgisi Not Havuzu
- Metinden seçilen kelimenin bulunduğu cümleyi Grammar Lab bağlamı olarak alma.
- Yapı / dilbilgisi konusu.
- Yapının cümledeki işlevi.
- Kısa kural / açıklama.
- Yüksek / Orta / Düşük güven düzeyi.
- Aynı cümle + aynı yapı duplicate koruması.
- Aynı cümlede farklı yapıları ayrı gözlem olarak kaydetme.
- Tek gözlem silme.
- Grammar verisini ayrı Local Storage katmanında saklama.

### Sprint 102 — Aktif Grammar Alıştırmaları
- Grammar gözleminden “Çalış”.
- Cevap kullanıcı “Cevabı Göster” demeden görünmez.
- Yapı, işlev ve kuralın birlikte gösterilmesi.
- Bilemedim / Zorlandım / Bildim öz değerlendirmeleri.
- Tekrar, başarı ve lapse/bilemedim sayıları.
- Basit sonraki çalışma zamanı ve artan tekrar aralığı.
- Grammar gözlemi silinince bağlı ilerleme kaydını temizleme.

### Sprint 103 — Grammar Günlük Tekrar Kuyruğu
- Zamanı gelen tekrarlar önce, yeni yapılar sonra.
- Varsayılan günlük üst sınır: 15 Grammar kartı.
- Varsayılan yeni yapı üst sınırı: 6.
- Bugün Hazır / Tekrar / Yeni / Bugün Çalışılan / İleri Tarihli özetleri.
- Grammar Çalışmasını Başlat.
- Sıradaki Grammar Kartını Aç.
- Planı Yenile.
- Kuyruktaki kartı doğrudan Çalış.
- Günlük plan tamamlanınca sonraki planlı tekrar zamanını gösterme.
- Günlük plan türetilmiş görünüm; ayrı kalıcı plan verisi yazmaz.

Toplu tarayıcı doğrulaması:
- Grammar Lab görünürlüğü ve cümle bağlamı: OLUMLU
- Manuel yapı / işlev / kural / güven kaydı: OLUMLU
- Duplicate koruması: OLUMLU
- Aktif Grammar çalışma kartı: OLUMLU
- Cevabı Göster: OLUMLU
- Bilemedim / Zorlandım / Bildim: OLUMLU
- Tekrar ve sonraki çalışma bilgileri: OLUMLU
- Grammar günlük çalışma planı: OLUMLU
- Bugün Çalışılan / İleri Tarihli güncellemesi: OLUMLU
- Önceki Kelime & Hafıza Studio ve Bilinmeyen Kelimeler akışları: OLUMLU

Teknik durum:
- Sprint 101 teknik doğrulaması: başarılı
- Sprint 102 teknik doğrulaması: başarılı
- Sprint 103 teknik doğrulaması: başarılı
- Tam regresyon: 473 passed / 0 failed (71 test dosyası)
- Production build: başarılı
- Son manuel doğrulanmış ürün durumu: Sprint 103

### Ürün yönü kararı — Beginner-first Grammar Lab
LAF Studio özellikle yeni başlayanların da kullanabileceği bir dil öğrenme platformu olacaktır.
Kullanıcıdan bilmediği gramer yapısını, işlevini ve kuralını önceden bilerek manuel doldurması beklenmemelidir.

Bu nedenle:
- Sistem AI destekli Grammar analizi önerebilir.
- AI önerisi yapı / işlev / kısa kural / güven alanlarını doldurabilir.
- Öneri doğrudan kalıcı kayda dönüşmez.
- Kullanıcı öneriyi görür, kontrol eder ve gerekirse düzenler.
- Kalıcı kayıt yalnız açık kullanıcı onayıyla yapılır.
- Sistem “öğretmen yardımcısı” gibi davranır; kullanıcı kontrolünü kaldırmaz.

Yol haritası güncellemesi:
- Sprint 104–106: AI Grammar Teacher
- Reading Studio bu blok sonrasına kaydırıldı.

Yeni kararlı checkpoint:
Sprint 103 — Grammar Lab günlük çalışma planı tamamlandı

Sıradaki geliştirme bloğu:
Sprint 104–106 — AI Grammar Teacher

---

## Sprint 104–106 Blok Kapanışı — AI Grammar Teacher

Durum: TAMAMLANDI ve TOPLU TARAYICI DOĞRULAMASI OLUMLU

Başlangıç kararlı tabanı:
Sprint 103 — Grammar Lab günlük çalışma planı

### Sprint 104 Rev2 — Kontrollü AI Grammar Analizi
- Metinden seçilen kelime ve bağlam cümlesi AI Grammar analizine gönderilir.
- Sistem şu alanları öneri olarak doldurur:
  - Yapı / dilbilgisi konusu
  - Bu cümledeki işlevi
  - Kısa kural / açıklama
  - Güven düzeyi
- AI önerisi otomatik kaydedilmez.
- Kullanıcı öneriyi kontrol edebilir ve değiştirebilir.
- Kalıcı kayıt yalnız “Yapıyı Grammar Lab'e Ekle” açık kullanıcı onayıyla oluşur.
- Hatalı/eksik AI JSON yanıtı uygulama katmanında bloke edilir.
- Backend endpoint: POST /api/grammar-analysis

Revizyon notu:
- Rev1 production build sırasında test mock typing sorunu verdi.
- Rev2 bu test tipini güvenli hale getirdi.
- Ürün davranışı değiştirilmedi.

### Sprint 105 Rev1 — Başlangıç Seviyesi AI Grammar Öğretmeni
- “Bunu Bana Öğret” akışı.
- AI şu öğrenme desteğini üretir:
  - Basit anlatım
  - Bu cümlede neden kullanıldığı
  - Kaynak dil örnekleri + Türkçe karşılıkları
  - Yaygın hata / dikkat noktası
- Öğretmen açıklaması geçici ekrandır.
- Local Storage'a veya Grammar kaydına otomatik yazılmaz.
- Form değişirse eski öğretmen açıklaması temizlenir.
- Backend endpoint: POST /api/grammar-teacher-guide

Revizyon notu:
- İlk Sprint 105 hedef testlerinde tek hatalı test beklentisi vardı.
- Rev1 yalnız test beklentisini düzeltti.
- AI Grammar Teacher ürün kodu ve davranışı değiştirilmedi.

### Sprint 106 — Kademeli Grammar Çalışma Desteği
Grammar çalışma kartı akışı:
1. Öğrenci önce kendi başına hatırlamaya çalışır.
2. İpucu Göster.
3. Bir İpucu Daha.
4. Cevabı Göster.
5. Gerekirse AI ile Açıkla.
6. Bilemedim / Zorlandım / Bildim.

Özellikler:
- İlk ipucu seçili öğenin cümledeki anlam ilişkisine odaklanır.
- İkinci ipucu yapının cümledeki işlevini söyler; yapının adını doğrudan vermez.
- AI çalışma açıklaması kayıtlı Grammar gözlemini değiştirmez.
- İpuçları ve AI çalışma açıklaması Local Storage'a yazılmaz.
- Mevcut Sprint 102 tekrar/ilerleme sistemi kullanılmaya devam eder.
- Günlük Grammar planı değerlendirme sonrası anında güncellenir.

### Toplu tarayıcı doğrulaması
- iskolában seçimi ve bağlam cümlesi: OLUMLU
- AI ile Grammar Analizi: OLUMLU
- -ban/-ben bulunma hâli analizi: OLUMLU
- AI önerisinin otomatik kaydedilmemesi: OLUMLU
- Bunu Bana Öğret: OLUMLU
- Basit anlatım / bağlam nedeni / örnekler / dikkat: OLUMLU
- Kullanıcı onayıyla Grammar Lab kaydı: OLUMLU
- İpucu Göster: OLUMLU
- Bir İpucu Daha: OLUMLU
- Cevabı Göster: OLUMLU
- Cevap sonrası AI ile Açıkla: OLUMLU
- Bilemedim / Zorlandım / Bildim: OLUMLU
- Günlük plan güncellemesi: OLUMLU
- Önceki Kelime & Hafıza ve Bilinmeyen Kelimeler akışları: OLUMLU

Teknik durum:
- Sprint 104 Rev2 teknik doğrulaması: başarılı
- Sprint 105 Rev1 teknik doğrulaması: başarılı
- Sprint 106 teknik doğrulaması: başarılı
- Tam regresyon: 473 passed / 0 failed (71 test dosyası)
- Production build: başarılı
- Son manuel doğrulanmış ürün durumu: Sprint 106

### Ürün ilkesi — Beginner-first AI Teacher
LAF Studio özellikle yeni başlayanların da kullanabileceği bir dil öğrenme platformudur.
Kullanıcıdan bilmediği Grammar yapısını önceden bilerek manuel doldurması beklenmez.

Kalıcı ilke:
- Sistem bilmediği alanları AI ile önerebilir.
- AI öğretmen gibi açıklayabilir.
- Kullanıcı kontrolü korunur.
- AI önerisi açık kullanıcı onayı olmadan kalıcı kayda dönüşmez.
- Öğrenme desteği mümkün olduğunca önce ipucu, sonra cevap, sonra AI açıklama şeklinde kademeli verilir.

### UX bakım notu
AI açıklamalarında zaman zaman Markdown işaretleri (**...**) düz metin olarak görünebiliyor.
Bu kritik hata değildir; sonraki uygun UX bakımında güvenli biçimde temizlenmelidir.

Yeni kararlı checkpoint:
Sprint 106 — AI Grammar Teacher kademeli çalışma desteği tamamlandı

Sıradaki geliştirme bloğu:
Sprint 107–109 — Reading Studio

---

## Sprint 107–109 Blok Kapanışı — Reading Studio

Durum: TAMAMLANDI ve TOPLU TARAYICI DOĞRULAMASI OLUMLU

Başlangıç kararlı tabanı:
Sprint 106 — AI Grammar Teacher
71 test dosyası / 473 passed / 0 failed

### Sprint 107 — Odaklı Okuma Temeli
- Metni cümlelere ayırma.
- Cümle sayısı.
- Toplam kelime sayısı.
- Farklı kelime sayısı.
- Tahmini okuma süresi.
- Okuma Modunu Başlat.
- Tek cümle odak kartı.
- Cümle sıra göstergesi ve progress.
- Önceki Cümle / Sonraki Cümle.
- Son cümlede Okumayı Tamamla.
- Metin veya dil değişince aktif Reading oturumunu güvenli sıfırlama.
- Kalıcı Reading verisi yok.

### Sprint 108 — AI Reading Coach
- Kullanıcı tarafından başlatılan “Reading Coach'u Aç”.
- Aktif cümle için:
  - Genel anlam
  - 1–3 önemli kelime/ifade ve kısa Türkçe ipucu
  - Okuma ipucu
  - Kısa anlama sorusu
- Cümle değişince eski AI açıklamasını temizleme.
- Metni veya başka öğrenme kayıtlarını değiştirmeme.
- Otomatik AI çağrısı yok.
- Backend endpoint: POST /api/reading-coach

### Sprint 109 — Okuduğunu Anlama Kontrolü ve Oturum Özeti
- Öğrenci Reading Coach sorusuna kısa Türkçe cevap yazar.
- “Yanıtımı Kontrol Et” kullanıcı tarafından başlatılır.
- AI değerlendirme sonuçları:
  - Doğru
  - Kısmen doğru
  - Tekrar bak
- Kısa öğretici geri bildirim.
- Örnek doğru cevap.
- Kısa cevaplarda gereksiz ayrıntı beklenmez.
- Türkçe yazım/dilbilgisi kusuru anlamı bozmuyorsa değerlendirme düşürülmez.
- Canlı oturum sayacı.
- Okuma tamamlanınca geçici oturum özeti:
  - Kontrol edildi
  - Doğru
  - Kısmen
  - Tekrar bak
  - Kontrol edilmedi
- Yeni Okuma Oturumu Başlat.
- Aynı cümlede Reading Coach yeniden üretilirse eski soru/değerlendirme eşleşmesi temizlenir.
- Backend endpoint: POST /api/reading-comprehension

### Toplu tarayıcı doğrulaması
- Reading Studio görünürlüğü: OLUMLU
- 3 cümle / 17 kelime / 17 farklı kelime / ~1 dk özeti: OLUMLU
- Odaklı okuma ve cümle navigasyonu: OLUMLU
- AI Reading Coach: OLUMLU
- Genel anlam / önemli ifadeler / okuma ipucu / anlama sorusu: OLUMLU
- Yanıtımı Kontrol Et: OLUMLU
- Doğru / Kısmen doğru / Tekrar bak değerlendirmesi: OLUMLU
- Geri bildirim ve örnek doğru cevap: OLUMLU
- Okuma Oturumu Özeti: OLUMLU
- Yeni Okuma Oturumu Başlat: OLUMLU
- Önceki Bağlamsal Anlam akışı: OLUMLU
- Grammar Lab: OLUMLU
- Kelime & Hafıza Studio: OLUMLU
- Bilinmeyen Kelimeler: OLUMLU

Tarayıcı örnek doğrulaması:
- 3 cümlelik Macarca metin doğru ayrıştırıldı.
- Oturum sonunda 1 kontrol edildi / 1 doğru / 0 kısmen / 0 tekrar bak / 2 kontrol edilmedi sonucu doğru gösterildi.

Teknik durum:
- Sprint 107 teknik doğrulaması: başarılı
- Sprint 108 teknik doğrulaması: başarılı
- Sprint 109 teknik doğrulaması: başarılı
- Tam regresyon: 563 passed / 0 failed (84 test dosyası)
- Production build: başarılı
- Son manuel doğrulanmış ürün durumu: Sprint 109

### Reading Studio ürün ilkesi
- Öğrenci önce kendi başına okumaya çalışır.
- AI yardım isteğe bağlıdır.
- AI açıklama yerine öğrencinin anlam kurmasını destekler.
- Okuduğunu anlama kontrolü kısa ve öğretici geri bildirim vermelidir.
- İlk Reading Studio bloğunda performans ve cevap geçmişi kalıcı değildir.
- Kalıcı Reading ilerleme mimarisi ancak ayrı bir ürün kararıyla eklenmelidir.

Yeni kararlı checkpoint:
Sprint 109 — Reading Studio Okuduğunu Anlama ve Oturum Özeti tamamlandı

Sıradaki geliştirme bloğu:
Sprint 110–112 — Listening Studio

---

## Sprint 110–112 Blok Kapanışı — Listening Studio

Durum: TAMAMLANDI ve TOPLU TARAYICI DOĞRULAMASI OLUMLU

Başlangıç kararlı tabanı:
Sprint 109 — Reading Studio Okuduğunu Anlama ve Oturum Özeti

### Sprint 110 — Cümle Bazlı Dinleme Temeli
- Metin başlangıçta gizli tutulur.
- Dinle / Yavaş Dinle / Durdur.
- Tarayıcı SpeechSynthesis kullanılır.
- Macarca hu-HU / Türkçe tr-TR.
- Normal hız 0.9.
- Yavaş hız 0.65.
- Yeni ses başlamadan önce önceki ses durdurulur.
- Metni Göster / Metni Gizle.
- Önceki Parça / Sonraki Parça.
- Son parçada Dinlemeyi Tamamla.
- Parça değişince transkript tekrar gizlenir.
- Metin veya dil değişince Listening oturumu temizlenir.
- Geçici dinleme sayacı: farklı parça, toplam dinleme, mevcut parça.
- Geçici oturum özeti.
- Kalıcı Listening verisi yok.

### Sprint 111 — AI Listening Coach
- Listening Coach yalnız parça en az bir kez dinlendikten sonra açılır.
- Kullanıcı tarafından başlatılır.
- AI desteği:
  - Dinleme hedefi
  - 1–3 kritik ses/ifade ipucu
  - Yapı/ses birleşmesi ipucu
  - Kısa anlama sorusu
- Tam kaynak cümle otomatik yeniden yazılmaz.
- Tam Türkçe çeviri otomatik verilmez.
- Parça değişince eski Listening Coach içeriği temizlenir.
- İçerik geçicidir.
- Backend endpoint: POST /api/listening-coach

### Sprint 112 — Dinlediğini Yazma ve Kontrollü AI Değerlendirme
- Öğrenci duyduğunu kaynak dilde yazar.
- “Yazdığımı Kontrol Et” kullanıcı tarafından başlatılır.
- AI sonucu:
  - Çok iyi yakaladın
  - Yaklaştın
  - Bir kez daha dinle
- Küçük yazım, noktalama, büyük/küçük harf ve aksan/diakritik hataları başlangıç seviyesinde aşırı cezalandırılmaz.
- Kısa öğretici geri bildirim verilir.
- Gerçek cümle kontrol sonucunda gösterilir.
- Öğrenci yazdığı metni değiştirirse eski değerlendirme geçersiz olur.
- Canlı yazma kontrol sayacı.
- Oturum sonunda dinlediğini yazma özeti:
  - Kontrol edilen
  - Çok iyi
  - Yaklaştın
  - Tekrar dinle
  - Kontrol edilmedi
- Sprint 110 dinleme oturum özeti ayrıca korunur.
- Backend endpoint: POST /api/listening-dictation

### Toplu tarayıcı doğrulaması
- Listening Studio görünürlüğü: OLUMLU
- Metin başlangıçta gizli: OLUMLU
- Dinle / Yavaş Dinle / Durdur: OLUMLU
- Metni Göster / Metni Gizle: OLUMLU
- Parça navigasyonu: OLUMLU
- Listening Coach ilk dinlemeden sonra açılıyor: OLUMLU
- Dinleme hedefi / kritik ifadeler / yapı ipucu / anlama sorusu: OLUMLU
- Tam metin/tam çeviri otomatik açılmıyor: OLUMLU
- Dinlediğini Yaz: OLUMLU
- Yazdığımı Kontrol Et: OLUMLU
- Çok iyi / Yaklaştın / Bir kez daha dinle değerlendirmesi: OLUMLU
- Öğretici geri bildirim ve gerçek cümle: OLUMLU
- Dinleme oturumu özeti: OLUMLU
- Dinlediğini yazma özeti: OLUMLU
- Yeni Dinleme Oturumu Başlat: OLUMLU
- Reading Studio / Bağlamsal Anlam / Grammar Lab / Kelime & Hafıza / Terminoloji: OLUMLU

Teknik durum:
- Sprint 110 teknik doğrulaması: başarılı
- Sprint 111 teknik doğrulaması: başarılı
- Sprint 112 teknik doğrulaması: başarılı
- Tam regresyon: 563 passed / 0 failed (84 test dosyası)
- Production build: başarılı
- Son manuel doğrulanmış ürün durumu: Sprint 112

### Listening Studio ürün ilkesi
- Öğrenci önce dinler; metin başlangıçta gizli kalır.
- AI ilk eylem değil, gerektiğinde kullanılan öğretmen desteğidir.
- AI tam transkript veya tam çeviriyle görevi öğrencinin yerine yapmaz.
- Öğrenci duyduğunu kaynak dilde üretmeye çalışır.
- Başlangıç seviyesinde küçük yazım ve diakritik hatalar ana dinleme başarısını gölgelememelidir.
- İlk Listening Studio bloğunda performans ve cevap geçmişi kalıcı değildir.
- Kalıcı Listening ilerleme mimarisi ayrı bir ürün kararıyla eklenmelidir.

Yeni kararlı checkpoint:
Sprint 112 — Listening Studio Dinlediğini Yazma ve Kontrollü AI Değerlendirme tamamlandı

Sıradaki geliştirme bloğu:
Sprint 113–115 — Writing Studio

---

## Sprint 113–115 Blok Kapanışı — Writing Studio

Durum: TAMAMLANDI ve TOPLU TARAYICI DOĞRULAMASI OLUMLU

Başlangıç kararlı tabanı:
Sprint 112 — Listening Studio

### Sprint 113 — Guided Writing Foundation
- Writing Studio temel katmanı oluşturuldu.
- Üç başlangıç seviyesi görevi:
  - Tek cümle kur
  - Mini paragraf
  - Günlük rutin
- Öğrenci hedef dilde kendi metnini yazar.
- Sistem yalnız anlık ilerleme ölçer:
  - Kelime sayısı
  - Cümle sayısı
  - Farklı kelime sayısı
  - Hedefe kalan kelime/cümle miktarı
- Minimum görev hedefi tamamlandığında Writing Coach aşamasına hazır durumu gösterilir.
- Taslak geçicidir.
- Sprint 113'te AI çağrısı yoktur.

### Sprint 114 — Controlled AI Writing Coach
- Writing Coach yalnız minimum görev hedefi tamamlandıktan sonra açılır.
- Kullanıcı tarafından başlatılır.
- AI yalnız dört kontrollü öğe üretir:
  - Güçlü taraf
  - Önce bunu geliştir
  - Neden?
  - Revizyon ipucu
- AI öğrencinin yerine metin yazmaz.
- Tam düzeltilmiş cümle/paragraf üretmez.
- Bütün hataları listelemek yerine tek yüksek öğrenme değerli öncelik seçer.
- Taslak değişirse eski AI geri bildirimi temizlenir.
- Geri bildirim geçicidir.
- Backend endpoint: POST /api/writing-coach

### Sprint 115 — Learner Revision ve AI Revision Check
- Writing Coach sonrası “Revizyona Başla” akışı eklendi.
- İlk taslak dondurulur ve görünür kalır.
- Öğrenci revizyonu ayrı alanda kendisi yazar.
- İlk taslak ve revizyon kelime/cümle sayıları karşılaştırılır.
- “Revizyonumu Kontrol Et” kullanıcı tarafından başlatılır.
- AI yalnız önceki Writing Coach önceliğine göre değerlendirir:
  - Revizyon hedefi karşılandı
  - Kısmen gelişti
  - Bir tur daha dene
- Sonuç alanları:
  - Ne değişti?
  - Değerlendirme
  - Sonraki adım
- Yeni geniş hata listesi açılmaz.
- Tam düzeltilmiş alternatif metin üretilmez.
- Yazma Oturumunu Tamamla akışı eklendi.
- Geçici Writing oturum özeti:
  - İlk taslak kelime
  - Revizyon kelime
  - İlk taslak cümle
  - Revizyon cümle
  - Sonuç
- “Yeni Yazma Oturumu Başlat” eklendi.
- Backend endpoint: POST /api/writing-revision

### Sprint 115 Rev1 — Macarca Karakter Paleti
Tarayıcı doğrulaması sırasında fiziksel klavyede Macarca alfabenin tüm karakterlerinin bulunmaması UX sorunu olarak tespit edildi.

Çözüm:
- İlk taslak alanında Macarca karakter paleti.
- Revizyon alanında aynı karakter paleti.
- Desteklenen karakterler:
  á é í ó ö ő ú ü ű
  Á É Í Ó Ö Ő Ú Ü Ű
- Seçilen karakter imlecin bulunduğu konuma eklenir.
- Seçili metin varsa seçimin yerini alır.
- Macarca dışındaki dil modlarında gösterilmez.

### Toplu tarayıcı doğrulaması
- Writing Studio görünürlüğü: OLUMLU
- Tek cümle kur görevi: OLUMLU
- Mini paragraf seçimi: OLUMLU
- Günlük rutin seçimi: OLUMLU
- Kelime / cümle / farklı kelime sayaçları: OLUMLU
- Hedefe kalan miktar: OLUMLU
- Writing Coach minimum hedef sonrası açılıyor: OLUMLU
- Güçlü taraf / Önce bunu geliştir / Neden? / Revizyon ipucu: OLUMLU
- AI öğrencinin yerine tam metin yazmıyor: OLUMLU
- Revizyona Başla: OLUMLU
- İlk taslak korunuyor: OLUMLU
- Revizyon ayrı alanda öğrenci tarafından yapılıyor: OLUMLU
- Revizyon karşılaştırması: OLUMLU
- Revizyonumu Kontrol Et: OLUMLU
- Revizyon hedefi karşılandı / Kısmen gelişti / Bir tur daha dene akışı: OLUMLU
- Ne değişti? / Değerlendirme / Sonraki adım: OLUMLU
- Yazma Oturumunu Tamamla: OLUMLU
- YAZMA OTURUMU özeti: OLUMLU
- Yeni Yazma Oturumu Başlat: OLUMLU
- Macarca karakter paleti ilk taslakta: OLUMLU
- Macarca karakter paleti revizyonda: OLUMLU
- Listening Studio korunuyor: OLUMLU
- Reading Studio korunuyor: OLUMLU
- Grammar Lab korunuyor: OLUMLU
- Kelime & Hafıza Studio korunuyor: OLUMLU
- Terminoloji / Bilinmeyen Kelimeler korunuyor: OLUMLU

Teknik durum:
- Sprint 113 teknik doğrulaması: başarılı
- Sprint 114 teknik doğrulaması: 87 test dosyası / 588 passed / 0 failed
- Sprint 115 teknik doğrulaması: 90 test dosyası / 609 passed / 0 failed
- Sprint 115 Rev1 teknik doğrulaması: başarılı
- Tam regresyon: 615 passed / 0 failed (91 test dosyası)
- Production build: başarılı
- Son manuel doğrulanmış ürün durumu: Sprint 115 Rev1

### Writing Studio ürün ilkesi
- Öğrenci önce kendi metnini üretir.
- AI ancak kullanıcı isterse ve görev hedefi tamamlandıysa devreye girer.
- AI öğrencinin yerine yazmaz.
- AI geri bildirimi tek odaklı ve öğrenme amaçlıdır.
- Revizyonu öğrenci kendisi yapar.
- AI revizyonu yalnız önceki öğrenme önceliğine göre değerlendirir.
- İlk Writing Studio bloğunda taslak, geri bildirim, revizyon ve performans geçmişi kalıcı değildir.
- Kalıcı Writing ilerleme mimarisi ayrı bir ürün kararıyla ele alınmalıdır.

Yeni kararlı checkpoint:
Sprint 115 Rev1 — Writing Studio Revizyon Akışı ve Macarca Karakter Paleti tamamlandı

Sıradaki geliştirme bloğu:
Sprint 116–118 — Speaking & Pronunciation Studio

---

## Sprint 116–118 Blok Kapanışı — Speaking & Pronunciation Studio

Durum: KAPATILDI

Teknik doğrulama:
- 96 test dosyası
- 654 test
- 654 passed
- 0 failed
- Production build: başarılı

### Sprint 116 — Speaking Foundation
- Kaynak metin cümle bazında konuşma parçalarına ayrılır.
- Referans cümle normal ve yavaş hızda dinlenebilir.
- Tarayıcı Web Speech Recognition katmanı hazırlandı.
- Macarca: hu-HU
- Türkçe: tr-TR
- Kullanıcı “Mikrofonla Söyle” ile konuşma tanımayı kendisi başlatır.
- Tarayıcının duyduğu metin görünür.
- Deterministik metin eşleşme yüzdesi hesaplanır.
- Tarayıcı konuşma tanıma güveni gösterilir.
- Metin eşleşmesi açıkça “telaffuz notu” olarak sunulmaz.
- Sonuçlar geçicidir; Local Storage kullanılmaz.

### Sprint 117 — AI Speaking Coach
- Speaking Coach yalnız kullanıcı tarafından başlatılır.
- AI gerçek ses kaydını doğrudan dinlediğini iddia etmez.
- AI girdileri:
  - Hedef cümle
  - Tarayıcının duyduğu metin
  - Metin eşleşme yüzdesi
  - Tarayıcı tanıma güveni
- AI çıktıları:
  - Anlaşılabilirlik
  - Telaffuz odağı
  - Pratik ipucu
  - Tekrar görevi
- Prompt kesin akustik teşhis ve uydurma fonetik hata iddiasını yasaklar.
- Düşük güven değerlerinde mikrofon, ortam gürültüsü ve tarayıcı belirsizliği dikkate alınır.
- Endpoint: POST /api/speaking-coach
- Geri bildirim geçicidir.

### Sprint 118 — Repeat Loop & Session Summary
- Aynı konuşma parçası birden fazla kez denenebilir.
- Her başarılı konuşma tanıma deneme olarak tutulur.
- Oturum özeti her parça için en iyi metin eşleşmesini kullanır.
- Özet alanları:
  - Çalışılan parça
  - Toplam deneme
  - Ortalama en iyi eşleşme
  - En iyi eşleşme
  - Tekrar çalışılacak parça
- “Konuşma Oturumunu Tamamla” akışı eklendi.
- “Yeni Konuşma Oturumu Başlat” eklendi.
- Sonuçlar geçicidir; Local Storage kullanılmaz.

### Toplu tarayıcı doğrulaması
Mikrofonsuz doğrulanan alanlar:
- Speaking & Pronunciation Studio görünürlüğü: OLUMLU
- Referans cümle görünümü: OLUMLU
- Dinle: OLUMLU
- Yavaş Dinle: OLUMLU
- Önceki / Sonraki parça geçişleri: OLUMLU
- Writing Studio korunuyor: OLUMLU
- Listening Studio korunuyor: OLUMLU
- Reading Studio korunuyor: OLUMLU
- Grammar Lab korunuyor: OLUMLU
- Kelime & Hafıza Studio korunuyor: OLUMLU

Donanım nedeniyle ertelenen manuel doğrulama:
- Mikrofonla Söyle
- Tarayıcının duyduğu metin
- Metin eşleşmesi / tarayıcı güveni canlı sonucu
- Speaking Coach canlı sonucu
- Tekrar Söyle
- Konuşma Oturumunu Tamamla
- KONUŞMA OTURUMU canlı özeti

Not:
Kullanıcının kısa sürede mikrofon donanımına erişemeyecek olması nedeniyle yukarıdaki mikrofon bağımlı manuel doğrulama kullanıcı kararıyla blok kapanışını engellemeyecek şekilde ertelendi.
Bu alanların teknik testleri ve production build doğrulaması başarılıdır.
Mikrofon bağlandığında canlı donanım doğrulaması ayrıca yapılabilir.

### Ürün ilkesi
- Mikrofon yalnız kullanıcı açıkça başlattığında kullanılır.
- AI gerçek sesi dinlemediği durumda bunu açıkça belirtir.
- Tarayıcı konuşma tanıma sonucu telaffuz doğruluğu ile eşitlenmez.
- Belirsizlik kullanıcıya görünür tutulur.
- Konuşma performansı ilk blokta kalıcı olarak saklanmaz.

Yeni kararlı checkpoint:
Sprint 118 — Speaking & Pronunciation Studio

Sıradaki geliştirme bloğu:
Sprint 119–121 — Dialogue & Role-play Studio
