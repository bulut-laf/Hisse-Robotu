﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$testPath =
    Join-Path $app "src\core\learning\CefrRuntimeSliceDefinition.test.ts"

$utf8 = New-Object System.Text.UTF8Encoding($false)

function Read-Utf8([string]$path) {
    return [System.IO.File]::ReadAllText($path, $utf8)
}

function Write-Utf8(
    [string]$path,
    [string]$text
) {
    [System.IO.File]::WriteAllText($path, $text, $utf8)
}

if (-not (Test-Path $testPath)) {
    throw "CefrRuntimeSliceDefinition.test.ts missing."
}

$text = Read-Utf8 $testPath

# Fail closed: patch only the known stale assertion in this exact test.
$oldCount =
    'evidenceDefinitionCount: 7'
$newCount =
    'evidenceDefinitionCount: 6'

$countMatches =
    [regex]::Matches(
        $text,
        [regex]::Escape($oldCount)
    ).Count

if ($countMatches -ne 1) {
    throw "Expected exactly one stale evidenceDefinitionCount: 7 assertion; found $countMatches."
}

$text =
    $text.Replace(
        $oldCount,
        $newCount
    )

# Keep the test description aligned with the runtime contract.
$oldDescription =
    'preflights every authoritative evidence definition before runtime assembly'
$newDescription =
    'preflights every executable authoritative evidence definition before runtime assembly'

if ($text.Contains($oldDescription)) {
    $text =
        $text.Replace(
            $oldDescription,
            $newDescription
        )
}

Write-Utf8 $testPath $text

# Source verification
$updated = Read-Utf8 $testPath

if (-not $updated.Contains($newCount)) {
    throw "Updated executable evidence count marker missing."
}

if ($updated.Contains($oldCount)) {
    throw "Stale evidenceDefinitionCount: 7 assertion still present."
}

Write-Host "SPRINT-1449-1457 REV1 SOURCE CHECK PASSED"

Set-Location $app

Write-Host ""
Write-Host "TARGET REPAIR VERIFICATION"

& npx vitest run `
    "src/core/learning/CefrRuntimeSliceDefinition.test.ts"

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1449-1457 Rev1 target repair verification failed."
}

Write-Host "SPRINT-1449-1457 REV1 TARGET REPAIR PASSED"

Write-Host ""
Write-Host "FINAL 9-SPRINT BLOCK REGRESSION — one full rerun"

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1449-1457 Rev1 final full regression failed."
}

Write-Host ""
Write-Host "FINAL PRODUCTION BUILD"

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1449-1457 Rev1 production build failed."
}

Write-Host ""
Write-Host "SPRINT-1449-1457 REV1 VERIFICATION COMPLETE"
