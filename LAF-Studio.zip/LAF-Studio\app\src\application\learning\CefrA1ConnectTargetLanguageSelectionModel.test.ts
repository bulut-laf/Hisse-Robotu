import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrA1ConnectTargetLanguageSelectionModel,
} from "./CefrA1ConnectTargetLanguageSelectionModel";

describe(
  "CefrA1ConnectTargetLanguageSelectionModel",
  () => {
    it("does not fabricate a default target language", () => {
      const result =
        createCefrA1ConnectTargetLanguageSelectionModel(
          null,
        );

      expect(result).toMatchObject({
        selectedLanguageCode: null,
        selectionRequired: true,
        selectedByUser: false,
        realization: null,
        languageContentBound: false,
        executableTaskAvailable: false,
        evidenceCaptureAvailable: false,
      });

      expect(result.options).toHaveLength(7);
    });

    it("resolves a language only after explicit selection", () => {
      const result =
        createCefrA1ConnectTargetLanguageSelectionModel(
          "it",
        );

      expect(result).toMatchObject({
        selectedLanguageCode: "it",
        selectionRequired: false,
        selectedByUser: true,
        languageContentBound: false,
        executableTaskAvailable: false,
        evidenceCaptureAvailable: false,
      });

      expect(result.realization).toMatchObject({
        languageCode: "it",
        locale: "it-IT",
        textToSpeechLocale: "it-IT",
        speechRecognitionLocale: "it-IT",
      });
    });
  },
);
