﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$payloadRoot =
    Join-Path $root "_sprint_payload"

if (-not (Test-Path $app)) {
    throw "LAF Studio app folder missing: $app"
}

$requiredBaseline = @(
    "src\core\learning\CefrA1DescribeRuntimeSliceDefinition.ts",
    "src\core\learning\CefrA1DescribeRuntimeEvidenceCatalog.ts",
    "src\application\learning\CefrProductionRuntimePlatform.ts",
    "src\core\learning\CefrProductionRuntimeSliceRegistry.ts",
    "src\core\learning\CefrProductionRuntimeEvidenceEligibilityAudit.ts"
)

foreach ($relative in $requiredBaseline) {
    $path = Join-Path $app $relative
    if (-not (Test-Path $path)) {
        throw "Sprint 1505 stable baseline file missing: $relative"
    }
}

$registrySource =
    [System.IO.File]::ReadAllText(
        (Join-Path $app "src\core\learning\CefrProductionRuntimeSliceRegistry.ts")
    )

if (-not $registrySource.Contains(
    "createLafA1DescribeRuntimeSliceDefinition"
)) {
    throw "Sprint 1505 production runtime does not contain A1 DESCRIBE slice."
}

$auditSource =
    [System.IO.File]::ReadAllText(
        (Join-Path $app "src\core\learning\CefrProductionRuntimeEvidenceEligibilityAudit.ts")
    )

if (-not $auditSource.Contains(
    "a1-describe-evidence-delayed-retrieval"
)) {
    throw "Sprint 1505 delayed-retrieval production guard is missing for A1 DESCRIBE."
}

$backupRoot =
    Join-Path $root (
        "_sprint_backups\Sprint1506-1514-" +
        (Get-Date -Format "yyyyMMdd-HHmmss")
    )

New-Item `
    -ItemType Directory `
    -Path $backupRoot `
    -Force |
    Out-Null

function Install-CheckpointPayload {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Checkpoint
    )

    $sourceRoot =
        Join-Path $payloadRoot $Checkpoint

    if (-not (Test-Path $sourceRoot)) {
        throw "Checkpoint payload missing: $Checkpoint"
    }

    $files =
        Get-ChildItem `
            -Path $sourceRoot `
            -Recurse `
            -File

    foreach ($file in $files) {
        $relative =
            $file.FullName.Substring(
                $sourceRoot.Length
            ).TrimStart(
                [char[]]@("\", "/")
            )

        $destination =
            Join-Path $root $relative

        $destinationDir =
            Split-Path $destination -Parent

        New-Item `
            -ItemType Directory `
            -Path $destinationDir `
            -Force |
            Out-Null

        if (Test-Path $destination) {
            $backup =
                Join-Path $backupRoot $relative

            $backupDir =
                Split-Path $backup -Parent

            New-Item `
                -ItemType Directory `
                -Path $backupDir `
                -Force |
                Out-Null

            if (-not (Test-Path $backup)) {
                Copy-Item `
                    -LiteralPath $destination `
                    -Destination $backup `
                    -Force
            }
        }

        Copy-Item `
            -LiteralPath $file.FullName `
            -Destination $destination `
            -Force
    }
}

function Run-TargetTests {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Label,

        [Parameter(Mandatory = $true)]
        [string[]]$Tests
    )

    Write-Host ""
    Write-Host "============================================================"
    Write-Host $Label
    Write-Host "============================================================"

    $args = @(
        "vitest",
        "run"
    )

    foreach ($test in $Tests) {
        $args += $test
    }

    & npx @args

    if ($LASTEXITCODE -ne 0) {
        throw "$Label failed."
    }
}

Set-Location $app

# ------------------------------------------------------------
# Sprint 1506-1508
# Explicit target-language realization foundation only.
# ------------------------------------------------------------

Install-CheckpointPayload `
    -Checkpoint "1506-1508"

Run-TargetTests `
    -Label "SPRINT-1506-1508 TARGET CHECKPOINT" `
    -Tests @(
        "src/core/learning/CefrA1DescribeLanguageRealizationBoundary.test.ts",
        "src/core/learning/CefrA1DescribeLanguageRealizationFoundationSafety.test.ts",
        "src/core/learning/CefrA1DescribeLanguageRealizationRegistry.test.ts",
        "src/application/learning/CefrA1DescribeTargetLanguageSelectionModel.test.ts"
    )

Write-Host "SPRINT-1506-1508 TARGET CHECKPOINT PASSED"

# ------------------------------------------------------------
# Sprint 1509-1511
# Seven-language assistant-authored content V1.
# No executable evidence yet.
# ------------------------------------------------------------

Install-CheckpointPayload `
    -Checkpoint "1509-1511"

Run-TargetTests `
    -Label "SPRINT-1509-1511 TARGET CHECKPOINT" `
    -Tests @(
        "src/core/learning/CefrA1DescribeLanguageRealizationRegistry.test.ts",
        "src/core/learning/CefrA1DescribeLanguageContentRegistry.test.ts",
        "src/core/learning/CefrA1DescribeLanguageContentSafety.test.ts",
        "src/application/learning/CefrA1DescribeLanguageContentView.test.ts",
        "src/application/learning/CefrA1DescribeTargetLanguageSelectionModel.test.ts"
    )

Write-Host "SPRINT-1509-1511 TARGET CHECKPOINT PASSED"

# ------------------------------------------------------------
# Sprint 1512-1514
# First three deterministic executable tasks and real
# language-scoped evidence through existing production runtime.
# ------------------------------------------------------------

Install-CheckpointPayload `
    -Checkpoint "1512-1514"

Run-TargetTests `
    -Label "SPRINT-1512-1514 TARGET CHECKPOINT" `
    -Tests @(
        "src/core/learning/CefrA1DescribeLanguageRealizationRegistry.test.ts",
        "src/core/learning/CefrA1DescribeExecutableTaskDefinition.test.ts",
        "src/core/learning/CefrA1DescribeExecutableTaskSafety.test.ts",
        "src/application/learning/CefrA1DescribeExecutableTaskService.test.ts",
        "src/application/learning/CefrA1DescribeTargetLanguageSelectionModel.test.ts"
    )

Write-Host "SPRINT-1512-1514 TARGET CHECKPOINT PASSED"

Write-Host ""
Write-Host "============================================================"
Write-Host "FINAL 9-SPRINT BLOCK REGRESSION"
Write-Host "============================================================"

& npm run test

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1506-1514 final full regression failed."
}

Write-Host ""
Write-Host "============================================================"
Write-Host "FINAL PRODUCTION BUILD"
Write-Host "============================================================"

& npm run build

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1506-1514 production build failed."
}

Write-Host ""
Write-Host "SPRINT-1506-1514 VERIFICATION COMPLETE"
Write-Host "Backup: $backupRoot"
