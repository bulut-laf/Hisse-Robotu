import fs from "node:fs";
import path from "node:path";

const root = "D:\\Projects\\LAF-Studio";
const file = path.join(
  root,
  "app",
  "src",
  "ui",
  "pages",
  "ListeningPracticePage.tsx",
);

if (!fs.existsSync(file)) {
  throw new Error(
    `ListeningPracticePage not found: ${file}`,
  );
}

let source =
  fs.readFileSync(file, "utf8");

const oldImport =
  'import { CefrGuidanceRuntimeProfileService } from "../../application/learning/CefrGuidanceRuntimeProfileService";';

const newImport =
  'import { CefrMappedListeningPracticeCompletionService } from "../../application/learning/CefrMappedListeningPracticeCompletionService";';

if (source.includes(oldImport)) {
  source =
    source.replace(
      oldImport,
      newImport,
    );
} else if (!source.includes(newImport)) {
  throw new Error(
    "ListeningPracticePage CEFR runtime service import marker not found.",
  );
}

const oldConstructor =
  "new CefrGuidanceRuntimeProfileService(";
const newConstructor =
  "new CefrMappedListeningPracticeCompletionService(";

if (source.includes(oldConstructor)) {
  source =
    source.replace(
      oldConstructor,
      newConstructor,
    );
} else if (!source.includes(newConstructor)) {
  throw new Error(
    "ListeningPracticePage CEFR runtime constructor marker not found.",
  );
}

const mappedImportCount =
  source.split(newImport).length - 1;
const mappedConstructorCount =
  source.split(newConstructor).length - 1;
const completionCallCount =
  source.split(
    "recordListeningPracticeCompletion({",
  ).length - 1;

if (
  mappedImportCount !== 1 ||
  mappedConstructorCount !== 1 ||
  completionCallCount !== 1
) {
  throw new Error(
    [
      "Listening mapped curriculum binding validation failed:",
      `import=${mappedImportCount}`,
      `constructor=${mappedConstructorCount}`,
      `completion=${completionCallCount}`,
    ].join(" "),
  );
}

fs.writeFileSync(
  file,
  source,
  "utf8",
);

console.log(
  "SPRINT-1269-1274 INSTALL COMPLETE",
);
console.log(
  "Listening Practice now uses authoritative curriculum observation binding.",
);
