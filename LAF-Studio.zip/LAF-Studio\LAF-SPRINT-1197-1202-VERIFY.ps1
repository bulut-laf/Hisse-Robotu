﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 1197-1199 Target Tests: UI Route + Profile Source + View Model ==="
npx vitest run `
  "src/core/learning/CefrGuidanceUiRouteCatalog.test.ts" `
  "src/core/learning/CefrGuidanceUiProfileSource.test.ts" `
  "src/core/learning/CefrGuidanceUiViewModel.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1197-1199 target tests failed." }

Write-Host "=== Sprint 1200-1202 Target Tests: User Navigation + UI Integration Contract ==="
npx vitest run `
  "src/core/learning/CefrGuidanceUiNavigationAction.test.ts" `
  "src/core/learning/CefrGuidanceUiIntegrationContract.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1200-1202 target tests failed." }

Write-Host "=== Combined Sprint 1197-1202 New Tests ==="
npx vitest run `
  "src/core/learning/CefrGuidanceUiRouteCatalog.test.ts" `
  "src/core/learning/CefrGuidanceUiProfileSource.test.ts" `
  "src/core/learning/CefrGuidanceUiViewModel.test.ts" `
  "src/core/learning/CefrGuidanceUiNavigationAction.test.ts" `
  "src/core/learning/CefrGuidanceUiIntegrationContract.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1197-1202 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Set-Location $root
& ".\LAF-UI-BINDING-SNAPSHOT.ps1"
if ($LASTEXITCODE -ne 0) { throw "UI binding snapshot failed." }

Write-Host "SPRINT-1197-1202 VERIFICATION COMPLETE"
