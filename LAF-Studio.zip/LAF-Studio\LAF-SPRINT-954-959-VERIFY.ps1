$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 954-956 Target Tests: Grammar / Reading / Listening AI Teacher Context Consumers ==="
npx vitest run `
  "src/core/learning/CefrGrammarAiTeacherContextConsumer.test.ts" `
  "src/core/learning/CefrReadingAiTeacherContextConsumer.test.ts" `
  "src/core/learning/CefrListeningAiTeacherContextConsumer.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 954-956 target tests failed." }

Write-Host "=== Sprint 957-959 Target Tests: Writing / Speaking / Dialogue AI Teacher Context Consumers ==="
npx vitest run `
  "src/core/learning/CefrWritingAiTeacherContextConsumer.test.ts" `
  "src/core/learning/CefrSpeakingAiTeacherContextConsumer.test.ts" `
  "src/core/learning/CefrDialogueAiTeacherContextConsumer.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 957-959 target tests failed." }

Write-Host "=== Combined Sprint 954-959 New Tests ==="
npx vitest run `
  "src/core/learning/CefrGrammarAiTeacherContextConsumer.test.ts" `
  "src/core/learning/CefrReadingAiTeacherContextConsumer.test.ts" `
  "src/core/learning/CefrListeningAiTeacherContextConsumer.test.ts" `
  "src/core/learning/CefrWritingAiTeacherContextConsumer.test.ts" `
  "src/core/learning/CefrSpeakingAiTeacherContextConsumer.test.ts" `
  "src/core/learning/CefrDialogueAiTeacherContextConsumer.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 954-959 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-954-959 VERIFICATION COMPLETE"
