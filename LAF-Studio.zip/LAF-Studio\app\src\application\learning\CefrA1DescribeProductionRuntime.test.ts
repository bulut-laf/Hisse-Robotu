import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrPersonalLanguageProfileState,
  type CefrPersonalLanguageProfileState,
} from "../../core/learning/CefrPersonalLanguageProfileState";
import type {
  CefrLanguageEvidenceStorageLike,
} from "./CefrAuthoritativeLanguageEvidenceProvenanceRepository";
import type {
  CefrGuidanceRuntimeProfileRepository,
} from "./CefrGuidanceRuntimeProfileRepository";
import {
  CefrProductionRuntimePlatform,
} from "./CefrProductionRuntimePlatform";

class MemoryProfileRepository
  implements CefrGuidanceRuntimeProfileRepository {
  private state:
    CefrPersonalLanguageProfileState =
      createCefrPersonalLanguageProfileState(
        [],
        [],
      );

  load(): CefrPersonalLanguageProfileState {
    return this.state;
  }

  save(
    state: CefrPersonalLanguageProfileState,
  ): void {
    this.state = state;
  }

  hasPersistedProfile(): boolean {
    return false;
  }

  clear(): void {}
}

class MemoryStorage
  implements CefrLanguageEvidenceStorageLike {
  private readonly items =
    new Map<string, string>();

  getItem(
    key: string,
  ): string | null {
    return this.items.get(key) ?? null;
  }

  setItem(
    key: string,
    value: string,
  ): void {
    this.items.set(key, value);
  }

  removeItem(
    key: string,
  ): void {
    this.items.delete(key);
  }
}

describe(
  "A1 DESCRIBE production runtime",
  () => {
    it("writes approved immediate evidence and resolves description-production observational capability", () => {
      const repository =
        new MemoryProfileRepository();

      const platform =
        new CefrProductionRuntimePlatform(
          repository,
          new MemoryStorage(),
        );

      const result =
        platform.recordUserEvidence(
          "a1-describe",
          {
            evidenceDefinitionId:
              "a1-describe-evidence-basic-feature",
            eventId:
              "describe-runtime-001",
            occurredAt:
              new Date(
                "2026-08-12T13:30:00.000Z",
              ),
            languageCode: "hu",
            userActionConfirmed: true,
          },
        );

      expect(result).toMatchObject({
        languageCode: "hu",
        evidencePersisted: true,
        targetLanguageExplicit: true,
        targetLanguageInferred: false,
        masteryAssigned: false,
        competencySuccessAssigned: false,
        cefrLevelAssigned: false,
        progressionPerformed: false,
      });

      expect(
        result.runtime
          .resolvedCapabilityReferences,
      ).toEqual([
        "description-production",
      ]);

      expect(
        repository.load()
          .capabilityObservationRegistry
          .observations,
      ).toEqual([
        {
          capabilityReference:
            "description-production",
          evidenceId:
            "a1-describe-runtime-evidence:a1-describe-evidence-basic-feature:describe-runtime-001",
          source: "learning-studio",
          observationalOnly: true,
        },
      ]);
    });

    it("refuses delayed retrieval runtime writing until a separate policy enables it", () => {
      const platform =
        new CefrProductionRuntimePlatform(
          new MemoryProfileRepository(),
          new MemoryStorage(),
        );

      expect(() =>
        platform.recordUserEvidence(
          "a1-describe",
          {
            evidenceDefinitionId:
              "a1-describe-evidence-delayed-retrieval",
            eventId:
              "describe-delayed-001",
            occurredAt:
              new Date(
                "2026-08-12T13:35:00.000Z",
              ),
            languageCode: "hu",
            userActionConfirmed: true,
          },
        ),
      ).toThrow(
        "Unknown authoritative CEFR evidence definition",
      );
    });
  },
);
