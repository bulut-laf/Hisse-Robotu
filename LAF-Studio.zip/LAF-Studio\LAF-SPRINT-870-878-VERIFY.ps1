$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 870-872 Target Tests: Custodial Resolution ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialResolution.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialResolutionCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialResolutionAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 870-872 target tests failed." }

Write-Host "=== Sprint 873-875 Target Tests: Custodial Finalization ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialFinalization.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialFinalizationCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialFinalizationAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 873-875 target tests failed." }

Write-Host "=== Sprint 876-878 Target Tests: Custodial Closure ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialClosure.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialClosureCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialClosureAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 876-878 target tests failed." }

Write-Host "=== Combined Sprint 870-878 New Tests ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialResolution.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialResolutionCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialResolutionAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialFinalization.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialFinalizationCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialFinalizationAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialClosure.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialClosureCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialClosureAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 870-878 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-870-878 VERIFICATION COMPLETE"
