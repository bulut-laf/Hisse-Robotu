import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrA1ConnectLanguageContentView,
} from "./CefrA1ConnectLanguageContentView";

describe(
  "CefrA1ConnectLanguageContentView",
  () => {
    it("shows selected language content for the selected authoritative lesson", () => {
      expect(
        createCefrA1ConnectLanguageContentView(
          "it",
          "a1-connect-greeting-response",
        ),
      ).toMatchObject({
        languageCode: "it",
        lessonId:
          "a1-connect-greeting-response",
        languageContentAvailable: true,
        executableTaskAvailable: false,
        evidenceCaptureAvailable: false,
      });
    });
  },
);
