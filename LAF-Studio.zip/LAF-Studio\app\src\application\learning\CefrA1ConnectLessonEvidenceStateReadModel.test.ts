import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrA1ConnectLessonEvidenceStateReadModel,
} from "./CefrA1ConnectLessonEvidenceStateReadModel";

describe(
  "CefrA1ConnectLessonEvidenceStateReadModel",
  () => {
    it("turns selected-lesson coverage into an evidence-only current-lesson state", () => {
      expect(
        createCefrA1ConnectLessonEvidenceStateReadModel({
          lessonId:
            "a1-connect-greeting-response",
          items: [
            {
              evidenceDefinitionId:
                "a1-connect-evidence-greeting-comprehension",
              present: true,
            },
            {
              evidenceDefinitionId:
                "a1-connect-evidence-greeting-response",
              present: true,
            },
          ],
          observedEvidenceCount: 2,
          totalEvidenceCount: 2,
          delayedRetrievalPending: false,
          crossLessonEvidenceExcluded: true,
          progressOnly: true,
          masteryInferred: false,
          cefrLevelInferred: false,
          progressionTriggered: false,
        }),
      ).toMatchObject({
        lessonId:
          "a1-connect-greeting-response",
        currentLessonContextOnly: true,
        recommendsAutomaticAdvance: false,
        selectsNextLesson: false,
        evidenceState: {
          status:
            "immediate-evidence-covered",
          allImmediateEvidenceObserved:
            true,
          lessonCompletedClaimed: false,
          masteryClaimed: false,
          cefrLevelClaimed: false,
          progressionTriggered: false,
        },
      });
    });
  },
);
