﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app  = Join-Path $root "app"
$src  = Join-Path $app "src"
$out  = Join-Path $root "LAF_A1_CONNECT_RUNTIME_BINDING_DISCOVERY.txt"

if (-not (Test-Path $src)) {
    throw "Source root not found: $src"
}

$report = New-Object System.Collections.Generic.List[string]

function Add-Line {
    param([string]$Text)
    if ($null -eq $Text) { $Text = "" }
    [void]$report.Add($Text)
}

function Add-Section {
    param([string]$Title)
    Add-Line ""
    Add-Line ("=" * 96)
    Add-Line $Title
    Add-Line ("=" * 96)
}

function Add-File {
    param(
        [string]$Relative,
        [int]$Limit = 1200
    )

    $file = Join-Path $src $Relative
    Add-Section ("FILE: app\src\" + $Relative)

    if (-not (Test-Path $file)) {
        Add-Line "(file not found)"
        return
    }

    $lines = @(Get-Content -Path $file)
    $count = [Math]::Min($lines.Count, $Limit)

    for ($i = 0; $i -lt $count; $i++) {
        Add-Line ("{0,4}: {1}" -f ($i + 1), $lines[$i])
    }

    if ($lines.Count -gt $Limit) {
        Add-Line ("... truncated; total lines: " + $lines.Count)
    }
}

function Rel {
    param([string]$Path)
    $prefix = $root + "\"
    if ($Path.StartsWith($prefix)) {
        return $Path.Substring($prefix.Length)
    }
    return $Path
}

$files = @(
    Get-ChildItem -Path $src -Recurse -File |
    Where-Object {
        $_.Extension -eq ".ts" -or
        $_.Extension -eq ".tsx"
    }
)

Add-Line "LAF STUDIO - A1 CONNECT RUNTIME BINDING DISCOVERY"
Add-Line ("Generated: " + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
Add-Line "READ ONLY - no project source files are modified."
Add-Line "Stable technical baseline expected: Sprint 1298."

Add-Section "1. AUTHORITATIVE A1 CONNECT FOUNDATION"

Add-File "core\learning\CefrAuthoritativeCurriculumCatalog.ts" 900
Add-File "core\learning\CefrAuthoritativeCurriculumRegistry.ts" 700
Add-File "core\learning\CefrA1ConnectPracticeDefinition.ts" 900
Add-File "core\learning\CefrA1ConnectInteractionDefinition.ts" 900
Add-File "core\learning\CefrA1ConnectEvidenceDefinition.ts" 1100
Add-File "core\learning\CefrA1ConnectActivationDefinition.ts" 700
Add-File "core\learning\CefrA1ConnectLearningExperienceCatalog.ts" 700

Add-Section "2. CURRENT PROFILE / EVIDENCE WRITE RUNTIME"

Add-File "application\learning\CefrGuidanceRuntimeProfileService.ts" 1400
Add-File "application\learning\CefrCurriculumCapabilityObservationWriter.ts" 1000
Add-File "application\learning\CefrMappedListeningPracticeCompletionService.ts" 1200
Add-File "core\learning\CefrCurriculumCapabilityObservationWrite.ts" 1400
Add-File "core\learning\CefrPersonalLanguageProfileState.ts" 1200
Add-File "core\learning\CefrCapabilityObservation.ts" 700

Add-Section "3. PROFILE REPOSITORY / LOCAL STORAGE"

$repoCandidates = @(
    $files |
    Where-Object {
        $_.Name -match "Cefr.*Profile.*Repository|GuidanceProfileRepository|LocalStorage.*Cefr|Cefr.*Storage"
    } |
    Sort-Object FullName
)

foreach ($file in $repoCandidates) {
    Add-Line ("CANDIDATE: " + (Rel $file.FullName))
}

foreach ($file in ($repoCandidates | Select-Object -First 20)) {
    $relative = Rel $file.FullName
    $srcRelative = $relative -replace '^app\\src\\', ''
    Add-File $srcRelative 1000
}

Add-Section "4. CURRENT /learning UI AND ROUTER SEAM"

Add-File "App.tsx" 900
Add-File "ui\learning\DailyLearningPathPanel.tsx" 1200
Add-File "pages\LearningPage.tsx" 1600
Add-File "ui\pages\LearningPage.tsx" 1600

Add-Section "5. ALL REAL CALLS TO PROFILE EVIDENCE WRITE METHODS"

$patterns = @(
    "recordLearningSessionCompletion",
    "recordListeningPracticeCompletion",
    "recordReading",
    "recordWriting",
    "recordSpeaking",
    "recordDialogue",
    "recordLearningStudioEvidence",
    "CefrGuidanceRuntimeProfileService",
    "CefrCurriculumCapabilityObservationWriter"
)

foreach ($pattern in $patterns) {
    Add-Line ""
    Add-Line ("PATTERN: " + $pattern)

    $matches = New-Object System.Collections.Generic.List[object]

    foreach ($file in $files) {
        if (
            $file.Name.EndsWith(".test.ts") -or
            $file.Name.EndsWith(".test.tsx")
        ) {
            continue
        }

        $hits = @(
            Select-String `
                -Path $file.FullName `
                -SimpleMatch `
                -Pattern $pattern `
                -ErrorAction SilentlyContinue
        )

        foreach ($hit in $hits) {
            [void]$matches.Add(
                [PSCustomObject]@{
                    File = Rel $hit.Path
                    Line = $hit.LineNumber
                    Text = $hit.Line.Trim()
                }
            )
        }
    }

    if ($matches.Count -eq 0) {
        Add-Line "(no production matches)"
    } else {
        foreach ($m in (
            $matches |
            Sort-Object File, Line |
            Select-Object -First 250
        )) {
            Add-Line (
                "{0}:{1}: {2}" -f
                $m.File,
                $m.Line,
                $m.Text
            )
        }
    }
}

Add-Section "6. LEARNING ROUTE / NAVIGATION OCCURRENCES"

$routePatterns = @(
    'path="/learning"',
    '"/learning"',
    'navigate("/learning',
    'to="/learning',
    'learning/guidance'
)

foreach ($pattern in $routePatterns) {
    Add-Line ""
    Add-Line ("PATTERN: " + $pattern)

    foreach ($file in $files) {
        if (
            $file.Name.EndsWith(".test.ts") -or
            $file.Name.EndsWith(".test.tsx")
        ) {
            continue
        }

        $hits = @(
            Select-String `
                -Path $file.FullName `
                -SimpleMatch `
                -Pattern $pattern `
                -ErrorAction SilentlyContinue
        )

        foreach ($hit in ($hits | Select-Object -First 120)) {
            Add-Line (
                "{0}:{1}: {2}" -f
                (Rel $hit.Path),
                $hit.LineNumber,
                $hit.Line.Trim()
            )
        }
    }
}

Add-Section "7. AUTHORIZED RUNTIME BINDING QUESTIONS"

Add-Line "Determine exact callable persistence API for new A1 CONNECT evidence events."
Add-Line "Determine whether a generic evidence write API already exists or a narrow A1 CONNECT application service is required."
Add-Line "Determine exact profile repository constructor and methods."
Add-Line "Determine safest real UI entry point under existing /learning without inventing a new route unless source supports it."
Add-Line "Determine whether authoritative CEFR lessons already have a render/runtime surface."
Add-Line "Determine exact user-action event boundary for practice, interaction, and activation evidence."
Add-Line ""
Add-Line "Next Sprint 1299-1304 must remain:"
Add-Line "- user-action driven"
Add-Line "- persisted real evidence only"
Add-Line "- observational-only capability observation"
Add-Line "- no mastery assignment"
Add-Line "- no competency success"
Add-Line "- no CEFR-level assignment"
Add-Line "- no automatic progression"
Add-Line "- no automatic Studio launch"

$report | Set-Content -Path $out -Encoding UTF8

Write-Host ""
Write-Host "LAF A1 CONNECT RUNTIME BINDING DISCOVERY COMPLETE"
Write-Host "Report:"
Write-Host $out
