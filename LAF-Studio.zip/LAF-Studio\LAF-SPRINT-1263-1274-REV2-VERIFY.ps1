﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app  = Join-Path $root "app"

$write = Join-Path $app "src\core\learning\CefrCurriculumCapabilityObservationWrite.ts"
$safety = Join-Path $app "src\core\learning\CefrCurriculumCapabilityObservationWriteSafety.ts"
$listening = Join-Path $app "src\application\learning\CefrMappedListeningPracticeCompletionService.ts"

$forbidden = @(
  "authoritative-competency-outcome-id",
  "capabilityReferenceUsesMappedCompetencyOutcomeIdUnchanged",
  "createCefrCapabilityObservation("
)

foreach ($marker in $forbidden) {
  if (Select-String -Path $write -SimpleMatch -Pattern $marker -Quiet) {
    throw "FORBIDDEN MARKER remains in write boundary: $marker"
  }
}

if (
  Select-String -Path $safety -SimpleMatch `
    -Pattern "competencyOutcomeIdIsCapabilityReference: false" -Quiet |
    ForEach-Object { -not $_ }
) {
  throw "Safe competency/capability identity marker missing."
}

if (
  -not (
    Select-String -Path $write -SimpleMatch `
      -Pattern "competencyOutcomeIdUsedAsCapabilityReference: false" -Quiet
  )
) {
  throw "Safe write-boundary marker missing."
}

if (
  -not (
    Select-String -Path $listening -SimpleMatch `
      -Pattern "capabilityReferenceResolved: false" -Quiet
  )
) {
  throw "Safe listening marker missing."
}

Set-Location $app

$targets = @(
  "src/core/learning/CefrCurriculumCapabilityObservationWrite.test.ts",
  "src/application/learning/CefrCurriculumCapabilityObservationWriter.test.ts",
  "src/application/learning/CefrMappedListeningPracticeCompletionService.test.ts",
  "src/core/learning/CefrCurriculumCapabilityObservationWriteSafety.test.ts",
  "src/application/learning/CefrListeningCurriculumObservationBindingSafety.test.ts",
  "src/core/learning/CefrCurriculumCompetencyMapping.test.ts",
  "src/core/learning/CefrCurriculumCapabilityObservationEligibility.test.ts"
)

& npx vitest run $targets
if ($LASTEXITCODE -ne 0) {
  throw "Sprint 1263-1274 Rev2 target tests failed."
}

& npm run test
if ($LASTEXITCODE -ne 0) {
  throw "Full regression failed."
}

& npm run build
if ($LASTEXITCODE -ne 0) {
  throw "Production build failed."
}

Write-Host "SPRINT-1263-1274 REV2 VERIFICATION COMPLETE"
