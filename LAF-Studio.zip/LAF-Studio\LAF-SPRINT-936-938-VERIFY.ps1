$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 936-938 Target Tests: Studio Evidence Adapters ==="
npx vitest run `
  "src/core/learning/CefrLearningStudioEvidenceAdapter.test.ts" `
  "src/core/learning/CefrTranslationStudioEvidenceAdapter.test.ts" `
  "src/core/learning/CefrInterpretingStudioEvidenceAdapter.test.ts"

if ($LASTEXITCODE -ne 0) {
  throw "Sprint 936-938 target tests failed."
}

Write-Host "=== Full Regression ==="
npm run test

if ($LASTEXITCODE -ne 0) {
  throw "Full regression failed."
}

Write-Host "=== Production Build ==="
npm run build

if ($LASTEXITCODE -ne 0) {
  throw "Production build failed."
}

Write-Host "SPRINT-936-938 VERIFICATION COMPLETE"
