﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

Write-Host "=== Install Writing Completion Evidence Binding ==="
Set-Location $root
node ".\LAF-SPRINT-1233-1238-INSTALL.mjs"
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1233-1238 install failed."
}

$writingFile = Join-Path $app "src\ui\writing\WritingStudioPanel.tsx"

$checks = @(
    @{
        Pattern = 'createCefrWritingStudioCompletionEvidenceInput('
        Name = 'Writing evidence input'
    },
    @{
        Pattern = 'recordLearningStudioEvidence('
        Name = 'Writing persistent evidence write'
    }
)

foreach ($check in $checks) {
    $matches = @(
        Select-String `
            -Path $writingFile `
            -SimpleMatch `
            $check.Pattern
    )

    if ($matches.Count -lt 1) {
        throw (
            $check.Name +
            " validation failed."
        )
    }
}

Set-Location $app

Write-Host "=== Sprint 1233-1235 Target Tests: Writing Completion Evidence ==="
npx vitest run `
  "src/application/learning/CefrWritingStudioCompletionEvidence.test.ts"
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1233-1235 target tests failed."
}

Write-Host "=== Sprint 1236-1238 Safety Tests ==="
npx vitest run `
  "src/application/learning/CefrWritingStudioCompletionBindingSafety.test.ts"
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1236-1238 target tests failed."
}

Write-Host "=== Combined Sprint 1233-1238 Tests ==="
npx vitest run `
  "src/application/learning/CefrWritingStudioCompletionEvidence.test.ts" `
  "src/application/learning/CefrWritingStudioCompletionBindingSafety.test.ts" `
  "src/application/learning/CefrGuidanceRuntimeProfileService.test.ts" `
  "src/core/learning/CefrLearningStudioEvidenceAdapter.test.ts" `
  "src/core/learning/CefrPersonalLanguageProfileEvidence.test.ts"
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1233-1238 combined tests failed."
}

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Full regression failed."
}

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Production build failed."
}

Write-Host "SPRINT-1233-1238 VERIFICATION COMPLETE"
