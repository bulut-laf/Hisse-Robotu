import {
  createLafCefrCapabilityTaxonomyRegistry,
  createLafCefrCompetencyCapabilityMappingRegistry,
} from "../../core/learning/CefrAuthoritativeCapabilityRegistry";
import {
  createLafCefrAuthoritativeCurriculumRegistry,
} from "../../core/learning/CefrAuthoritativeCurriculumRegistry";
import {
  LAF_A1_CONNECT_EVIDENCE_DEFINITIONS,
  type CefrA1ConnectEvidenceDefinition,
} from "../../core/learning/CefrA1ConnectEvidenceDefinition";
import type {
  CefrCapabilityTaxonomyRegistry,
} from "../../core/learning/CefrCapabilityTaxonomyRegistry";
import type {
  CefrCompetencyCapabilityMappingRegistry,
} from "../../core/learning/CefrCompetencyCapabilityMappingRegistry";
import type {
  CefrCurriculumCompetencyRegistry,
} from "../../core/learning/CefrCurriculumCompetencyRegistry";
import type {
  CefrCurriculumCapabilityObservationWriteResult,
} from "../../core/learning/CefrCurriculumCapabilityObservationWrite";
import type {
  CefrGuidanceRuntimeProfileRepository,
} from "./CefrGuidanceRuntimeProfileRepository";
import {
  CefrCurriculumCapabilityObservationWriter,
} from "./CefrCurriculumCapabilityObservationWriter";
import {
  CefrGuidanceRuntimeProfileService,
  type CefrLearningStudioEvidenceWriteResult,
} from "./CefrGuidanceRuntimeProfileService";

export interface CefrA1ConnectRuntimeEvidenceEventInput {
  readonly evidenceDefinitionId: string;
  readonly eventId: string;
  readonly occurredAt: Date;
  readonly userActionConfirmed: true;
}

export interface CefrA1ConnectRuntimeEvidenceResult {
  readonly definition:
    CefrA1ConnectEvidenceDefinition;
  readonly evidence:
    CefrLearningStudioEvidenceWriteResult;
  readonly observation:
    CefrCurriculumCapabilityObservationWriteResult;
  readonly sourceLearningItemId: string;
  readonly evidenceDefinitionId: string;
  readonly runtimeEvidenceId: string;
  readonly capabilityObservationWritten: boolean;
  readonly resolvedCapabilityReferences:
    readonly string[];
  readonly masteryAssigned: false;
  readonly competencySuccessAssigned: false;
  readonly cefrLevelAssigned: false;
  readonly progressionPerformed: false;
  readonly automaticStudioLaunchPerformed: false;
}

function requireText(
  value: string,
  fieldName: string,
): string {
  const normalized = value.trim();

  if (normalized.length === 0) {
    throw new Error(
      `${fieldName} is required.`,
    );
  }

  return normalized;
}

function resolveDefinition(
  evidenceDefinitionId: string,
): CefrA1ConnectEvidenceDefinition {
  const normalized =
    requireText(
      evidenceDefinitionId,
      "evidenceDefinitionId",
    );

  const definition =
    LAF_A1_CONNECT_EVIDENCE_DEFINITIONS.find(
      item =>
        item.evidenceDefinitionId ===
        normalized,
    );

  if (!definition) {
    throw new Error(
      `Unknown authoritative A1 CONNECT evidence definition: ${normalized}`,
    );
  }

  return definition;
}

export function createCefrA1ConnectRuntimeEvidenceId(
  evidenceDefinitionId: string,
  eventId: string,
): string {
  return [
    "a1-connect-runtime-evidence",
    requireText(
      evidenceDefinitionId,
      "evidenceDefinitionId",
    ),
    requireText(
      eventId,
      "eventId",
    ),
  ].join(":");
}

export function createCefrA1ConnectRuntimePayloadReference(
  definition:
    CefrA1ConnectEvidenceDefinition,
  eventId: string,
): string {
  return [
    "a1-connect-runtime",
    definition.sourceLearningItemId,
    definition.evidenceDefinitionId,
    requireText(eventId, "eventId"),
  ].join(":");
}

export class CefrA1ConnectRuntimeEvidenceService {
  private readonly evidenceService:
    CefrGuidanceRuntimeProfileService;

  private readonly observationWriter:
    CefrCurriculumCapabilityObservationWriter;

  constructor(
    repository:
      CefrGuidanceRuntimeProfileRepository,
    curriculumRegistry:
      CefrCurriculumCompetencyRegistry =
        createLafCefrAuthoritativeCurriculumRegistry(),
    capabilityTaxonomyRegistry:
      CefrCapabilityTaxonomyRegistry =
        createLafCefrCapabilityTaxonomyRegistry(),
    competencyCapabilityMappingRegistry:
      CefrCompetencyCapabilityMappingRegistry =
        createLafCefrCompetencyCapabilityMappingRegistry(),
  ) {
    this.evidenceService =
      new CefrGuidanceRuntimeProfileService(
        repository,
      );

    this.observationWriter =
      new CefrCurriculumCapabilityObservationWriter(
        repository,
        curriculumRegistry,
        capabilityTaxonomyRegistry,
        competencyCapabilityMappingRegistry,
      );
  }

  recordUserEvidence(
    input:
      CefrA1ConnectRuntimeEvidenceEventInput,
  ): CefrA1ConnectRuntimeEvidenceResult {
    if (input.userActionConfirmed !== true) {
      throw new Error(
        "A1 CONNECT runtime evidence requires an explicit user action.",
      );
    }

    const definition =
      resolveDefinition(
        input.evidenceDefinitionId,
      );

    const runtimeEvidenceId =
      createCefrA1ConnectRuntimeEvidenceId(
        definition.evidenceDefinitionId,
        input.eventId,
      );

    const evidence =
      this.evidenceService
        .recordLearningStudioEvidence({
          evidenceId: runtimeEvidenceId,
          observedAt: input.occurredAt,
          payloadReference:
            createCefrA1ConnectRuntimePayloadReference(
              definition,
              input.eventId,
            ),
        });

    const observation =
      this.observationWriter.write({
        learningItemType: "lesson",
        learningItemId:
          definition.sourceLearningItemId,
        evidenceId: evidence.evidenceId,
      });

    return {
      definition,
      evidence,
      observation,
      sourceLearningItemId:
        definition.sourceLearningItemId,
      evidenceDefinitionId:
        definition.evidenceDefinitionId,
      runtimeEvidenceId,
      capabilityObservationWritten:
        observation.capabilityObservationWritten,
      resolvedCapabilityReferences:
        observation.resolvedCapabilityReferences,
      masteryAssigned: false,
      competencySuccessAssigned: false,
      cefrLevelAssigned: false,
      progressionPerformed: false,
      automaticStudioLaunchPerformed: false,
    };
  }
}
