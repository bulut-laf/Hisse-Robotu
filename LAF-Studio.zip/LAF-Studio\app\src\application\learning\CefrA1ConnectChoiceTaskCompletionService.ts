import type {
  LafLearningLanguageCode,
} from "../../core/language/LafLanguageProfile";
import {
  createCefrA1ConnectGreetingResponseTask,
  createCefrA1ConnectSelfIntroductionTask,
  type CefrA1ConnectExecutableTaskKind,
} from "../../core/learning/CefrA1ConnectAdditionalExecutableTasks";
import {
  CefrA1ConnectEvidenceProvenanceCoordinator,
} from "./CefrA1ConnectEvidenceProvenanceCoordinator";
import {
  CefrA1ConnectLanguageEvidenceProvenanceRepository,
} from "./CefrA1ConnectLanguageEvidenceProvenanceRepository";
import type {
  CefrGuidanceRuntimeProfileRepository,
} from "./CefrGuidanceRuntimeProfileRepository";
import {
  CefrA1ConnectRuntimeEvidenceService,
  type CefrA1ConnectRuntimeEvidenceResult,
} from "./CefrA1ConnectRuntimeEvidenceService";
import {
  evaluateCefrA1ConnectChoiceTask,
  type CefrA1ConnectChoiceTaskEvaluation,
} from "./CefrA1ConnectChoiceTaskEvaluation";

export interface CefrA1ConnectChoiceTaskSubmissionInput {
  readonly taskKind:
    CefrA1ConnectExecutableTaskKind;
  readonly languageCode:
    LafLearningLanguageCode;
  readonly submittedAnswer: string;
  readonly eventId: string;
  readonly occurredAt: Date;
  readonly userActionConfirmed: true;
}

export interface CefrA1ConnectChoiceTaskSubmissionResult {
  readonly evaluation:
    CefrA1ConnectChoiceTaskEvaluation;
  readonly evidence:
    CefrA1ConnectRuntimeEvidenceResult | null;
  readonly evidencePersisted: boolean;
  readonly capabilityObservationWritten:
    boolean;
  readonly masteryAssigned: false;
  readonly competencySuccessAssigned: false;
  readonly cefrLevelAssigned: false;
  readonly progressionPerformed: false;
}

export class CefrA1ConnectChoiceTaskCompletionService {
  private readonly evidenceService:
    CefrA1ConnectRuntimeEvidenceService;

  private readonly provenanceCoordinator:
    CefrA1ConnectEvidenceProvenanceCoordinator;

  constructor(
    repository:
      CefrGuidanceRuntimeProfileRepository,
    provenanceCoordinatorOrRepository:
      | CefrA1ConnectEvidenceProvenanceCoordinator
      | CefrA1ConnectLanguageEvidenceProvenanceRepository =
        new CefrA1ConnectEvidenceProvenanceCoordinator(),
  ) {
    this.evidenceService =
      new CefrA1ConnectRuntimeEvidenceService(
        repository,
      );

    this.provenanceCoordinator =
      "recordPersistedEvidenceLanguage" in
      provenanceCoordinatorOrRepository
        ? provenanceCoordinatorOrRepository
        : new CefrA1ConnectEvidenceProvenanceCoordinator(
            provenanceCoordinatorOrRepository,
          );
  }

  submit(
    input:
      CefrA1ConnectChoiceTaskSubmissionInput,
  ): CefrA1ConnectChoiceTaskSubmissionResult {
    const task =
      input.taskKind === "greeting-response"
        ? createCefrA1ConnectGreetingResponseTask(
            input.languageCode,
          )
        : createCefrA1ConnectSelfIntroductionTask(
            input.languageCode,
          );

    const evaluation =
      evaluateCefrA1ConnectChoiceTask(
        task,
        input.submittedAnswer,
      );

    if (!evaluation.evidenceEligible) {
      return {
        evaluation,
        evidence: null,
        evidencePersisted: false,
        capabilityObservationWritten: false,
        masteryAssigned: false,
        competencySuccessAssigned: false,
        cefrLevelAssigned: false,
        progressionPerformed: false,
      };
    }

    const evidence =
      this.evidenceService.recordUserEvidence({
        evidenceDefinitionId:
          task.evidenceDefinitionId,
        eventId: input.eventId,
        occurredAt: input.occurredAt,
        userActionConfirmed:
          input.userActionConfirmed,
      });

    this.provenanceCoordinator.recordPersistedEvidenceLanguage({
      evidenceId:
        evidence.runtimeEvidenceId,
      languageCode:
        input.languageCode,
      observedAt:
        input.occurredAt,
    });

    return {
      evaluation,
      evidence,
      evidencePersisted:
        evidence.evidence.evidenceAdded,
      capabilityObservationWritten:
        evidence.capabilityObservationWritten,
      masteryAssigned: false,
      competencySuccessAssigned: false,
      cefrLevelAssigned: false,
      progressionPerformed: false,
    };
  }
}
