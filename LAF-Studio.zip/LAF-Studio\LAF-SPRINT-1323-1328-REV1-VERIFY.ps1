﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app  = Join-Path $root "app"

$test = Join-Path $app "src\core\learning\CefrA1ConnectGreetingComprehensionTask.test.ts"
$content = Join-Path $app "src\core\learning\CefrA1ConnectLanguageContentRegistry.ts"
$task = Join-Path $app "src\core\learning\CefrA1ConnectGreetingComprehensionTask.ts"

foreach ($file in @($test, $content, $task)) {
    if (-not (Test-Path $file)) {
        throw "Sprint 1323-1328 Rev1 source missing: $file"
    }
}

if (-not (
    Select-String -Path $test -SimpleMatch `
        -Pattern 'correctAnswer: "İyi günler!"' -Quiet
)) {
    throw "Rev1 corrected Italian expectation missing."
}

if (-not (
    Select-String -Path $content -SimpleMatch `
        -Pattern 'text: "Buongiorno!"' -Quiet
)) {
    throw "Authoritative Italian phrase missing."
}

if (-not (
    Select-String -Path $content -SimpleMatch `
        -Pattern 'meaning: "İyi günler!"' -Quiet
)) {
    throw "Authoritative Italian meaning missing."
}

Write-Host "SPRINT-1323-1328 REV1 SOURCE CHECK PASSED"

Set-Location $app

$targets = @(
    "src/core/learning/CefrA1ConnectGreetingComprehensionTask.test.ts",
    "src/application/learning/CefrA1ConnectGreetingComprehensionEvaluation.test.ts",
    "src/application/learning/CefrA1ConnectGreetingTaskCompletionService.test.ts",
    "src/core/learning/CefrA1ConnectExecutableTaskSafety.test.ts",
    "src/ui/learning/A1ConnectGreetingComprehensionTaskPanel.test.ts",
    "src/application/learning/CefrA1ConnectRuntimeEvidenceService.test.ts",
    "src/core/learning/CefrA1ConnectLanguageContentRegistry.test.ts",
    "src/application/learning/CefrA1ConnectLanguageContentView.test.ts"
)

& npx vitest run $targets
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1323-1328 Rev1 target tests failed."
}

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Full regression failed."
}

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Production build failed."
}

Write-Host "SPRINT-1323-1328 REV1 VERIFICATION COMPLETE"
