import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrAuthoritativeLanguageEvidenceProvenance,
} from "../../core/learning/CefrAuthoritativeLanguageEvidenceProvenance";
import {
  LAF_A1_CONNECT_LANGUAGE_EVIDENCE_PROVENANCE_AUTHORITY,
} from "../../core/learning/CefrLanguageEvidenceProvenanceAuthority";
import {
  CefrAuthoritativeLanguageEvidenceProvenanceRepository,
  type CefrLanguageEvidenceStorageLike,
} from "./CefrAuthoritativeLanguageEvidenceProvenanceRepository";

class MemoryStorage
  implements CefrLanguageEvidenceStorageLike {
  private readonly items =
    new Map<string, string>();

  getItem(
    key: string,
  ): string | null {
    return this.items.get(key) ?? null;
  }

  setItem(
    key: string,
    value: string,
  ): void {
    this.items.set(key, value);
  }

  removeItem(
    key: string,
  ): void {
    this.items.delete(key);
  }
}

describe(
  "CefrAuthoritativeLanguageEvidenceProvenanceRepository",
  () => {
    it("stores target-language provenance under the configured authority", () => {
      const repository =
        new CefrAuthoritativeLanguageEvidenceProvenanceRepository(
          LAF_A1_CONNECT_LANGUAGE_EVIDENCE_PROVENANCE_AUTHORITY,
          new MemoryStorage(),
        );

      repository.save(
        createCefrAuthoritativeLanguageEvidenceProvenance({
          evidenceId: "evidence-1",
          languageCode: "hu",
          observedAt:
            new Date(
              "2026-08-11T21:20:00.000Z",
            ),
          source: "a1-connect-runtime",
        }),
      );

      expect(
        repository.findForLanguage("hu"),
      ).toHaveLength(1);
    });

    it("refuses reassignment of one evidence identity to another language", () => {
      const repository =
        new CefrAuthoritativeLanguageEvidenceProvenanceRepository(
          LAF_A1_CONNECT_LANGUAGE_EVIDENCE_PROVENANCE_AUTHORITY,
          new MemoryStorage(),
        );

      repository.save(
        createCefrAuthoritativeLanguageEvidenceProvenance({
          evidenceId: "evidence-1",
          languageCode: "hu",
          observedAt: new Date(),
          source: "a1-connect-runtime",
        }),
      );

      expect(() =>
        repository.save(
          createCefrAuthoritativeLanguageEvidenceProvenance({
            evidenceId: "evidence-1",
            languageCode: "de",
            observedAt: new Date(),
            source: "a1-connect-runtime",
          }),
        ),
      ).toThrow(
        "Evidence language provenance conflict",
      );
    });
  },
);
