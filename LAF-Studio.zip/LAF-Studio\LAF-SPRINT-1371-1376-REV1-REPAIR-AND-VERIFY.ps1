﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$panel = Join-Path $app "src\ui\learning\A1ConnectNativeLearningPanel.tsx"

if (-not (Test-Path $panel)) {
    throw "A1ConnectNativeLearningPanel.tsx missing."
}

$utf8 =
    New-Object System.Text.UTF8Encoding($false)

$text =
    [System.IO.File]::ReadAllText(
        $panel,
        $utf8
    )

$restoreBlock = @'
  const restoreRememberedSelection = (
    languageCode: LafLearningLanguageCode,
    lessonId: string | null,
  ) => {
    setSelectedLanguageCode(languageCode);

    if (
      lessonId !== null &&
      model.lessonCards.some(
        lesson =>
          lesson.lessonId === lessonId,
      )
    ) {
      setSelectedLessonId(lessonId);
    }
  };

'@

# Remove every copy introduced by the previous broad "return (" replacement.
while ($text.Contains($restoreBlock)) {
    $text = $text.Replace(
        $restoreBlock,
        ""
    )
}

# Insert exactly once before the component-level return.
$mainReturnAnchor = @'
  return (
    <section
      className="a1-connect-native"
'@

if (-not $text.Contains($mainReturnAnchor)) {
    throw "Component-level return anchor not found."
}

$text = $text.Replace(
    $mainReturnAnchor,
    $restoreBlock + $mainReturnAnchor
)

[System.IO.File]::WriteAllText(
    $panel,
    $text,
    $utf8
)

# Structural checks: exactly one declaration, actual usage present,
# and no declaration inside the lesson-card map block.
$declarationCount = (
    Select-String `
        -Path $panel `
        -SimpleMatch `
        -Pattern 'const restoreRememberedSelection = (' `
        -AllMatches
).Matches.Count

if ($declarationCount -ne 1) {
    throw "Expected exactly one restoreRememberedSelection declaration; found $declarationCount."
}

if (-not (
    Select-String `
        -Path $panel `
        -SimpleMatch `
        -Pattern 'restoreRememberedSelection' `
        -Quiet
)) {
    throw "restoreRememberedSelection usage missing."
}

$panelText =
    [System.IO.File]::ReadAllText(
        $panel,
        $utf8
    )

if (-not $panelText.Contains(
    'onRestoreSelection={'
)) {
    throw "Continuity restore callback binding missing."
}

if (-not $panelText.Contains(
    'restoreRememberedSelection'
)) {
    throw "Restore callback identifier missing."
}

$mapStart =
    $panelText.IndexOf(
        '{model.lessonCards.map(lesson => {'
    )

if ($mapStart -ge 0) {
    $mapEnd =
        $panelText.IndexOf(
            '        })}',
            $mapStart
        )

    if ($mapEnd -gt $mapStart) {
        $mapSegment =
            $panelText.Substring(
                $mapStart,
                $mapEnd - $mapStart
            )

        if ($mapSegment.Contains(
            'const restoreRememberedSelection = ('
        )) {
            throw "Nested restoreRememberedSelection declaration still exists inside lesson map."
        }
    }
}

Write-Host "SPRINT-1371-1376 REV1 SOURCE REPAIR PASSED"

Set-Location $app

$targets = @(
    "src/core/learning/CefrA1ConnectSessionRestoreRequest.test.ts",
    "src/application/learning/CefrA1ConnectSessionRestoreBoundary.test.ts",
    "src/core/learning/CefrA1ConnectExplicitRestoreSafety.test.ts",
    "src/ui/learning/A1ConnectContinuityPanel.restore.test.ts",
    "src/core/learning/CefrA1ConnectSessionState.test.ts",
    "src/application/learning/CefrA1ConnectSessionStateRepository.test.ts",
    "src/core/learning/CefrA1ConnectContinuitySafety.test.ts",
    "src/application/learning/CefrA1ConnectLanguageScopedAdvisoryReadModel.test.ts"
)

& npx vitest run $targets
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1371-1376 Rev1 target tests failed."
}

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Full regression failed."
}

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Production build failed."
}

Write-Host "SPRINT-1371-1376 REV1 VERIFICATION COMPLETE"
