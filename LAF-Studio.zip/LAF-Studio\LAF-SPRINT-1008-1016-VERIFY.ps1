$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 1008-1010 Target Tests: Capability Observation Feedback ==="
npx vitest run `
  "src/core/learning/CefrGuidedSessionCapabilityObservation.test.ts" `
  "src/core/learning/CefrCapabilityObservationReturn.test.ts" `
  "src/core/learning/CefrCapabilityObservationFeedbackGateway.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1008-1010 target tests failed." }

Write-Host "=== Sprint 1011-1013 Target Tests: Observation-Aware Profile Refresh ==="
npx vitest run `
  "src/core/learning/CefrCapabilityObservationRegistryRefresh.test.ts" `
  "src/core/learning/CefrObservationAwareProfileRefresh.test.ts" `
  "src/core/learning/CefrObservationAwareLearnerContext.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1011-1013 target tests failed." }

Write-Host "=== Sprint 1014-1016 Target Tests: Safe Learning Focus ==="
npx vitest run `
  "src/core/learning/CefrLearningFocusCandidate.test.ts" `
  "src/core/learning/CefrUserLearningFocusChoice.test.ts" `
  "src/core/learning/CefrSafeLearningFocusOrchestration.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1014-1016 target tests failed." }

Write-Host "=== Combined Sprint 1008-1016 New Tests ==="
npx vitest run `
  "src/core/learning/CefrGuidedSessionCapabilityObservation.test.ts" `
  "src/core/learning/CefrCapabilityObservationReturn.test.ts" `
  "src/core/learning/CefrCapabilityObservationFeedbackGateway.test.ts" `
  "src/core/learning/CefrCapabilityObservationRegistryRefresh.test.ts" `
  "src/core/learning/CefrObservationAwareProfileRefresh.test.ts" `
  "src/core/learning/CefrObservationAwareLearnerContext.test.ts" `
  "src/core/learning/CefrLearningFocusCandidate.test.ts" `
  "src/core/learning/CefrUserLearningFocusChoice.test.ts" `
  "src/core/learning/CefrSafeLearningFocusOrchestration.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1008-1016 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-1008-1016 VERIFICATION COMPLETE"
