import {
  createCefrA1ConnectSessionState,
  isCefrA1ConnectSessionState,
  type CefrA1ConnectSessionState,
} from "../../core/learning/CefrA1ConnectSessionState";
import type {
  LafLearningLanguageCode,
} from "../../core/language/LafLanguageProfile";

interface StorageLike {
  getItem(key: string): string | null;
  setItem(
    key: string,
    value: string,
  ): void;
  removeItem(key: string): void;
}

export const A1_CONNECT_SESSION_STORAGE_KEY =
  "laf.cefr.a1-connect.session.v1";

export class CefrA1ConnectSessionStateRepository {
  private readonly storage:
    StorageLike | null;

  constructor(
    storage:
      StorageLike | null =
        typeof window !== "undefined"
          ? window.localStorage
          : null,
  ) {
    this.storage = storage;
  }

  load(): CefrA1ConnectSessionState | null {
    if (!this.storage) {
      return null;
    }

    const raw =
      this.storage.getItem(
        A1_CONNECT_SESSION_STORAGE_KEY,
      );

    if (!raw) {
      return null;
    }

    try {
      const parsed =
        JSON.parse(raw) as unknown;

      return isCefrA1ConnectSessionState(
        parsed,
      )
        ? parsed
        : null;
    }
    catch {
      return null;
    }
  }

  saveSelection(
    selectedLanguageCode:
      LafLearningLanguageCode | null,
    selectedLessonId:
      string | null,
    updatedAt: Date = new Date(),
  ): CefrA1ConnectSessionState {
    const state =
      createCefrA1ConnectSessionState({
        selectedLanguageCode,
        selectedLessonId,
        updatedAt,
      });

    this.storage?.setItem(
      A1_CONNECT_SESSION_STORAGE_KEY,
      JSON.stringify(state),
    );

    return state;
  }

  clear(): void {
    this.storage?.removeItem(
      A1_CONNECT_SESSION_STORAGE_KEY,
    );
  }
}
