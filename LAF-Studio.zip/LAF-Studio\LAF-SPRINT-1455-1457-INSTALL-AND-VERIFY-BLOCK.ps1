﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$core = Join-Path $app "src\core\learning"

$utf8 = New-Object System.Text.UTF8Encoding($false)

function Read-Utf8([string]$path) {
    return [System.IO.File]::ReadAllText($path, $utf8)
}

function Write-Utf8(
    [string]$path,
    [string]$text
) {
    [System.IO.File]::WriteAllText($path, $text, $utf8)
}

$registryPath =
    Join-Path $core "CefrProductionRuntimeSliceRegistry.ts"

if (-not (Test-Path $registryPath)) {
    throw "CefrProductionRuntimeSliceRegistry.ts missing."
}

$registry = Read-Utf8 $registryPath

# ------------------------------------------------------------
# Add fail-closed production eligibility audit import.
# ------------------------------------------------------------
$auditImportModule =
    'from "./CefrProductionRuntimeEvidenceEligibilityAudit";'

if (-not $registry.Contains($auditImportModule)) {
    $importText = @'
import {
  assertCefrProductionRuntimeEvidenceEligibility,
} from "./CefrProductionRuntimeEvidenceEligibilityAudit";

'@

    $registry =
        $importText + $registry
}

# ------------------------------------------------------------
# Replace direct-return registry factory with audited factory.
# Safe because this file is assistant-owned from Sprint 1431-1439.
# ------------------------------------------------------------
if (-not $registry.Contains(
    'assertCefrProductionRuntimeEvidenceEligibility('
)) {
    $functionPattern =
        'export function createLafCefrProductionRuntimeSliceRegistry\(\):\s*' +
        'CefrRuntimeSliceRegistry\s*\{\s*' +
        'return createCefrRuntimeSliceRegistry\(\[\s*' +
        'createLafA1ConnectRuntimeSliceDefinition\(\),\s*' +
        'createLafA1NavigateRuntimeSliceDefinition\(\),\s*' +
        '\]\);\s*' +
        '\}'

    $replacement = @'
export function createLafCefrProductionRuntimeSliceRegistry():
  CefrRuntimeSliceRegistry {
  const registry =
    createCefrRuntimeSliceRegistry([
      createLafA1ConnectRuntimeSliceDefinition(),
      createLafA1NavigateRuntimeSliceDefinition(),
    ]);

  assertCefrProductionRuntimeEvidenceEligibility(
    registry,
  );

  return registry;
}
'@

    $matches =
        [regex]::Matches(
            $registry,
            $functionPattern
        )

    if ($matches.Count -ne 1) {
        throw "Expected exactly one production registry factory body; found $($matches.Count)."
    }

    $registry =
        [regex]::Replace(
            $registry,
            $functionPattern,
            $replacement,
            1
        )
}

Write-Utf8 $registryPath $registry

# ------------------------------------------------------------
# Fail-closed source checks.
# ------------------------------------------------------------
$required = @(
    "src\core\learning\CefrProductionRuntimeEvidenceEligibilityAudit.ts",
    "src\core\learning\CefrProductionRuntimeEligibilityEnforcementSafety.ts",
    "src\core\learning\CefrProductionRuntimeRegistryEnforcement.test.ts",
    "src\application\learning\CefrProductionRuntimeEligibilityEnforcement.test.ts"
)

foreach ($relative in $required) {
    if (-not (Test-Path (Join-Path $app $relative))) {
        throw "Sprint 1455-1457 required file missing: $relative"
    }
}

$sourceChecks = @(
    @(
      $registryPath,
      'assertCefrProductionRuntimeEvidenceEligibility('
    ),
    @(
      $registryPath,
      'return registry;'
    ),
    @(
      (Join-Path $core "CefrProductionRuntimeEligibilityEnforcementSafety.ts"),
      'policyGatedEvidenceFailsClosed:'
    ),
    @(
      (Join-Path $app "src\application\learning\CefrProductionRuntimeEligibilityEnforcement.test.ts"),
      '"a1-connect-evidence-delayed-retrieval"'
    ),
    @(
      (Join-Path $app "src\application\learning\CefrProductionRuntimeEligibilityEnforcement.test.ts"),
      '"a1-navigate-evidence-delayed-retrieval"'
    )
)

foreach ($check in $sourceChecks) {
    if (-not (
        Select-String `
            -Path $check[0] `
            -SimpleMatch `
            -Pattern $check[1] `
            -Quiet
    )) {
        throw "Sprint 1455-1457 source marker missing: $($check[1])"
    }
}

Write-Host "SPRINT-1455-1457 SOURCE CHECK PASSED"

Set-Location $app

Write-Host ""
Write-Host "CHECKPOINT 3/3 — Sprint 1455-1457 target tests"

& npx vitest run @(
    "src/core/learning/CefrProductionRuntimeEvidenceEligibilityAudit.test.ts",
    "src/core/learning/CefrProductionRuntimeEligibilityEnforcementSafety.test.ts",
    "src/core/learning/CefrProductionRuntimeRegistryEnforcement.test.ts",
    "src/core/learning/CefrProductionRuntimeSliceRegistry.test.ts",
    "src/application/learning/CefrProductionRuntimeEligibilityEnforcement.test.ts",
    "src/application/learning/CefrProductionRuntimeDelayedRetrievalVisibility.test.ts",
    "src/application/learning/CefrA1ConnectDelayedRetrievalGenericRuntime.test.ts",
    "src/application/learning/CefrA1NavigateProductionRuntime.test.ts"
)

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1455-1457 target checkpoint failed."
}

Write-Host "SPRINT-1455-1457 TARGET CHECKPOINT PASSED"

Write-Host ""
Write-Host "FINAL 9-SPRINT BLOCK REGRESSION — one full run only"

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1449-1457 final full regression failed."
}

Write-Host ""
Write-Host "FINAL PRODUCTION BUILD"

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1449-1457 production build failed."
}

Write-Host ""
Write-Host "SPRINT-1449-1457 VERIFICATION COMPLETE"
