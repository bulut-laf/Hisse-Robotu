﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$panel = Join-Path $app "src\ui\learning\A1ConnectNativeLearningPanel.tsx"

if (-not (Test-Path $panel)) {
    throw "A1ConnectNativeLearningPanel.tsx missing."
}

$utf8 =
    New-Object System.Text.UTF8Encoding($false)

$text =
    [System.IO.File]::ReadAllText(
        $panel,
        $utf8
    )

$importLine =
    'import { A1ConnectEvidenceIntegrityPanel } from "./A1ConnectEvidenceIntegrityPanel";'

if (-not $text.Contains($importLine)) {
    $anchor =
        'import { A1ConnectContinuityPanel } from "./A1ConnectContinuityPanel";'

    if (-not $text.Contains($anchor)) {
        throw "Evidence integrity import anchor not found."
    }

    $text = $text.Replace(
        $anchor,
        $anchor +
        [Environment]::NewLine +
        $importLine
    )
}

$renderMarker =
    '<A1ConnectEvidenceIntegrityPanel'

if (-not $text.Contains($renderMarker)) {
    $anchor =
        '      <div className="a1-connect-native-gate">'

    if (-not $text.Contains($anchor)) {
        throw "Evidence integrity render anchor not found."
    }

    $render = @'
      <A1ConnectEvidenceIntegrityPanel />

'@

    $text = $text.Replace(
        $anchor,
        $render + $anchor
    )
}

[System.IO.File]::WriteAllText(
    $panel,
    $text,
    $utf8
)

$coordinator = Join-Path $app "src\application\learning\CefrA1ConnectEvidenceProvenanceCoordinator.ts"
$recovery = Join-Path $app "src\core\learning\CefrA1ConnectEvidenceProvenanceRecoveryRecord.ts"
$recoveryRepo = Join-Path $app "src\application\learning\CefrA1ConnectEvidenceProvenanceRecoveryRepository.ts"
$greeting = Join-Path $app "src\application\learning\CefrA1ConnectGreetingTaskCompletionService.ts"
$choice = Join-Path $app "src\application\learning\CefrA1ConnectChoiceTaskCompletionService.ts"
$extended = Join-Path $app "src\application\learning\CefrA1ConnectExtendedTaskCompletionService.ts"
$integrityPanel = Join-Path $app "src\ui\learning\A1ConnectEvidenceIntegrityPanel.tsx"
$safety = Join-Path $app "src\core\learning\CefrA1ConnectEvidenceConsistencySafety.ts"

foreach ($file in @(
    $coordinator,
    $recovery,
    $recoveryRepo,
    $greeting,
    $choice,
    $extended,
    $integrityPanel,
    $safety
)) {
    if (-not (Test-Path $file)) {
        throw "Sprint 1365-1370 source missing: $file"
    }
}

$checks = @{
    $coordinator = @(
        'recordPersistedEvidenceLanguage(',
        'repairPending()',
        'recoveryQueued: true'
    )
    $recovery = @(
        '"provenance-write-failed"',
        'evidenceAlreadyPersisted: true'
    )
    $recoveryRepo = @(
        'provenance-recovery.v1',
        'remove('
    )
    $greeting = @(
        'provenanceCoordinator.recordPersistedEvidenceLanguage({'
    )
    $choice = @(
        'provenanceCoordinator.recordPersistedEvidenceLanguage({'
    )
    $extended = @(
        'provenanceCoordinator.recordPersistedEvidenceLanguage({'
    )
    $integrityPanel = @(
        'EVIDENCE BÜTÜNLÜĞÜ',
        'repairPending()'
    )
    $safety = @(
        'recoveryInfersLanguageFromEvidenceId:',
        'false',
        'recoveryMayCreateEvidence: false'
    )
    $panel = @(
        'A1ConnectEvidenceIntegrityPanel'
    )
}

foreach ($entry in $checks.GetEnumerator()) {
    foreach ($marker in $entry.Value) {
        if (-not (
            Select-String `
                -Path $entry.Key `
                -SimpleMatch `
                -Pattern $marker `
                -Quiet
        )) {
            throw "Required Sprint 1365-1370 marker missing: $marker"
        }
    }
}

Write-Host "SPRINT-1365-1370 SOURCE CHECK PASSED"

Set-Location $app

$targets = @(
    "src/core/learning/CefrA1ConnectEvidenceProvenanceRecoveryRecord.test.ts",
    "src/application/learning/CefrA1ConnectEvidenceProvenanceRecoveryRepository.test.ts",
    "src/application/learning/CefrA1ConnectEvidenceProvenanceCoordinator.test.ts",
    "src/core/learning/CefrA1ConnectEvidenceConsistencySafety.test.ts",
    "src/application/learning/CefrA1ConnectEvidenceProvenanceConsistencyIntegration.test.ts",
    "src/ui/learning/A1ConnectEvidenceIntegrityPanel.test.ts",
    "src/application/learning/CefrA1ConnectLanguageEvidenceProvenanceRepository.test.ts",
    "src/application/learning/CefrA1ConnectGreetingTaskCompletionService.test.ts",
    "src/application/learning/CefrA1ConnectChoiceTaskCompletionService.test.ts",
    "src/application/learning/CefrA1ConnectExtendedTaskCompletionService.test.ts"
)

& npx vitest run $targets
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1365-1370 target tests failed."
}

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Full regression failed."
}

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Production build failed."
}

Write-Host "SPRINT-1365-1370 VERIFICATION COMPLETE"
