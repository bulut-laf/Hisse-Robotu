﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

Write-Host "=== Install Embedded Studio Completion Evidence Bindings ==="
Set-Location $root
node ".\LAF-SPRINT-1227-1232-INSTALL.mjs"
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1227-1232 install failed."
}

$targets = @(
    @{
        Path = Join-Path $app "src\ui\pages\TextWorkshopPage.tsx"
        Pattern = 'createCefrEmbeddedStudioCompletionEvidenceInput("reading",'
        Name = "Reading"
    },
    @{
        Path = Join-Path $app "src\ui\speaking\SpeakingStudioPanel.tsx"
        Pattern = 'createCefrEmbeddedStudioCompletionEvidenceInput("speaking",'
        Name = "Speaking"
    },
    @{
        Path = Join-Path $app "src\ui\dialogue\DialogueRoleplayPanel.tsx"
        Pattern = 'createCefrEmbeddedStudioCompletionEvidenceInput("dialogue",'
        Name = "Dialogue"
    }
)

foreach ($target in $targets) {
    $matches = @(
        Select-String `
            -Path $target.Path `
            -SimpleMatch `
            $target.Pattern
    )

    if ($matches.Count -ne 1) {
        throw (
            $target.Name +
            " completion evidence binding validation failed. Count=" +
            $matches.Count
        )
    }
}

Set-Location $app

Write-Host "=== Sprint 1227-1230 Target Tests: Embedded Completion Evidence ==="
npx vitest run `
  "src/application/learning/CefrEmbeddedStudioCompletionEvidence.test.ts"
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1227-1230 target tests failed."
}

Write-Host "=== Sprint 1231-1232 Safety Tests ==="
npx vitest run `
  "src/application/learning/CefrEmbeddedStudioCompletionBindingSafety.test.ts"
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1231-1232 target tests failed."
}

Write-Host "=== Combined Sprint 1227-1232 Tests ==="
npx vitest run `
  "src/application/learning/CefrEmbeddedStudioCompletionEvidence.test.ts" `
  "src/application/learning/CefrEmbeddedStudioCompletionBindingSafety.test.ts" `
  "src/application/learning/CefrGuidanceRuntimeProfileService.test.ts" `
  "src/core/learning/CefrLearningStudioEvidenceAdapter.test.ts" `
  "src/core/learning/CefrPersonalLanguageProfileEvidence.test.ts"
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1227-1232 combined tests failed."
}

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Full regression failed."
}

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Production build failed."
}

Write-Host "SPRINT-1227-1232 VERIFICATION COMPLETE"
