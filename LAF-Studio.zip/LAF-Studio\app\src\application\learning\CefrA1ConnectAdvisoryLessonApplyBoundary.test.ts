import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrA1ConnectAdvisoryNextStep,
} from "../../core/learning/CefrA1ConnectAdvisoryNextStep";
import {
  createCefrA1ConnectAdvisoryLessonApplyResult,
} from "./CefrA1ConnectAdvisoryLessonApplyBoundary";

describe(
  "CefrA1ConnectAdvisoryLessonApplyBoundary",
  () => {
    it("permits only an authoritative recommended lesson and still requires user action", () => {
      const nextStep =
        createCefrA1ConnectAdvisoryNextStep(
          [],
        );

      expect(
        createCefrA1ConnectAdvisoryLessonApplyResult(
          nextStep,
          [
            "a1-connect-greeting-response",
            "a1-connect-self-introduction",
            "a1-connect-personal-questions",
            "a1-connect-complete-social-exchange",
          ],
        ),
      ).toEqual({
        request: {
          lessonId:
            "a1-connect-greeting-response",
          userActionConfirmed: true,
          advisoryOnly: true,
          taskExecuted: false,
          evidenceCreated: false,
          masteryAssigned: false,
          cefrLevelAssigned: false,
          progressionPerformed: false,
        },
        applicable: true,
        authoritativeLessonRequired: true,
        automaticSelectionPerformed: false,
      });
    });

    it("refuses a non-authoritative lesson identity", () => {
      const nextStep =
        createCefrA1ConnectAdvisoryNextStep(
          [],
        );

      expect(
        createCefrA1ConnectAdvisoryLessonApplyResult(
          nextStep,
          [],
        ).applicable,
      ).toBe(false);
    });
  },
);
