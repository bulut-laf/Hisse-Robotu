﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

Set-Location $app

Write-Host "=== Sprint 1245-1248 Target Tests: Evidence Provenance Filters ==="
npx vitest run `
  "src/application/learning/CefrGuidanceEvidenceActivityView.test.ts"
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1245-1248 target tests failed."
}

Write-Host "=== Sprint 1249-1250 Safety Tests ==="
npx vitest run `
  "src/application/learning/CefrGuidanceEvidenceProvenanceSafety.test.ts"
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1249-1250 safety tests failed."
}

Write-Host "=== Combined Sprint 1245-1250 Tests ==="
npx vitest run `
  "src/application/learning/CefrGuidanceEvidenceActivityView.test.ts" `
  "src/application/learning/CefrGuidanceEvidenceProvenanceSafety.test.ts" `
  "src/application/learning/CefrGuidanceEvidenceActivityVisibilitySafety.test.ts" `
  "src/application/learning/CefrGuidanceRuntimeProfileService.test.ts"
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1245-1250 combined tests failed."
}

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Full regression failed."
}

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Production build failed."
}

Write-Host "SPRINT-1245-1250 VERIFICATION COMPLETE"
