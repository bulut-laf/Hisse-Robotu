import {
  describe,
  expect,
  it,
} from "vitest";

import type {
  TranslationGrammarObservationItem,
} from "../../ui/grammar/LocalStorageTranslationGrammarObservationStorage";
import {
  createTranslationGrammarStudySupport,
} from "./TranslationGrammarStudySupport";

const observation: TranslationGrammarObservationItem =
  {
    id: "grammar-1",
    sourceLanguage: "hu",
    focusTerm: "busszal",
    contextSentence:
      "A diák busszal megy az iskolába.",
    pattern:
      "-val/-vel araç-birliktelik hâli",
    functionText:
      "Ulaşım aracını belirtir.",
    explanation:
      "-val/-vel Türkçedeki 'ile' anlamına gelir.",
    confidence: "high",
    savedAt: new Date(
      "2026-08-06T12:00:00.000Z",
    ),
  };

describe(
  "createTranslationGrammarStudySupport",
  () => {
    it("creates two staged hints", () => {
      expect(
        createTranslationGrammarStudySupport(
          observation,
        ).hints,
      ).toHaveLength(2);
    });

    it("first hint focuses on the selected expression", () => {
      expect(
        createTranslationGrammarStudySupport(
          observation,
        ).hints[0],
      ).toContain("busszal");
    });

    it("first hint does not expose the Grammar pattern", () => {
      expect(
        createTranslationGrammarStudySupport(
          observation,
        ).hints[0],
      ).not.toContain("-val/-vel");
    });

    it("second hint exposes the sentence function but not the stored rule", () => {
      const secondHint =
        createTranslationGrammarStudySupport(
          observation,
        ).hints[1];

      expect(secondHint).toContain(
        "Ulaşım aracını belirtir.",
      );
      expect(secondHint).not.toContain(
        "Türkçedeki 'ile'",
      );
    });

    it("normalizes extra whitespace in the focus term", () => {
      const result =
        createTranslationGrammarStudySupport({
          ...observation,
          focusTerm: "  busszal   ",
        });

      expect(result.hints[0]).toContain(
        "“busszal”",
      );
    });

    it("normalizes extra whitespace in the function hint", () => {
      const result =
        createTranslationGrammarStudySupport({
          ...observation,
          functionText:
            "  Ulaşım   aracını belirtir.  ",
        });

      expect(result.hints[1]).toContain(
        "Ulaşım aracını belirtir.",
      );
    });
  },
);
