$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 852-854 Target Tests: Custodial Convergence ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialConvergence.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialConvergenceCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialConvergenceAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 852-854 target tests failed." }

Write-Host "=== Sprint 855-857 Target Tests: Custodial Integration ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialIntegration.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialIntegrationCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialIntegrationAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 855-857 target tests failed." }

Write-Host "=== Sprint 858-860 Target Tests: Custodial Synthesis ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialSynthesis.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialSynthesisCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialSynthesisAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 858-860 target tests failed." }

Write-Host "=== Combined Sprint 852-860 New Tests ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialConvergence.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialConvergenceCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialConvergenceAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialIntegration.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialIntegrationCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialIntegrationAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialSynthesis.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialSynthesisCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialSynthesisAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 852-860 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-852-860 VERIFICATION COMPLETE"
