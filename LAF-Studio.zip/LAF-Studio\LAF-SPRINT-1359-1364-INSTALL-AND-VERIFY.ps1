﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

$provenance = Join-Path $app "src\core\learning\CefrA1ConnectLanguageEvidenceProvenance.ts"
$provenanceRepo = Join-Path $app "src\application\learning\CefrA1ConnectLanguageEvidenceProvenanceRepository.ts"
$scopedCoverage = Join-Path $app "src\application\learning\CefrA1ConnectLanguageScopedCoverageReadModel.ts"
$scopedAdvisory = Join-Path $app "src\application\learning\CefrA1ConnectLanguageScopedAdvisoryReadModel.ts"
$greetingService = Join-Path $app "src\application\learning\CefrA1ConnectGreetingTaskCompletionService.ts"
$choiceService = Join-Path $app "src\application\learning\CefrA1ConnectChoiceTaskCompletionService.ts"
$extendedService = Join-Path $app "src\application\learning\CefrA1ConnectExtendedTaskCompletionService.ts"
$unitPanel = Join-Path $app "src\ui\learning\A1ConnectUnitRuntimePanel.tsx"
$continuityPanel = Join-Path $app "src\ui\learning\A1ConnectContinuityPanel.tsx"
$safety = Join-Path $app "src\core\learning\CefrA1ConnectLanguageEvidenceSafety.ts"

foreach ($file in @(
    $provenance,
    $provenanceRepo,
    $scopedCoverage,
    $scopedAdvisory,
    $greetingService,
    $choiceService,
    $extendedService,
    $unitPanel,
    $continuityPanel,
    $safety
)) {
    if (-not (Test-Path $file)) {
        throw "Sprint 1359-1364 source missing: $file"
    }
}

$checks = @{
    $provenance = @(
        'authoritativeLanguageProvenance:',
        'true',
        'masteryClaimed: false'
    )
    $provenanceRepo = @(
        'language-evidence-provenance.v1',
        'Evidence language provenance conflict'
    )
    $scopedCoverage = @(
        'crossLanguageEvidenceExcluded: true',
        'unscopedEvidenceAttributed: false',
        'findForLanguage(languageCode)'
    )
    $scopedAdvisory = @(
        'selectedLanguageRequired:',
        'crossLanguageEvidenceExcluded: true',
        'automaticLessonSelection: false'
    )
    $greetingService = @(
        'createCefrA1ConnectLanguageEvidenceProvenance({',
        'languageCode:',
        'input.languageCode'
    )
    $choiceService = @(
        'createCefrA1ConnectLanguageEvidenceProvenance({'
    )
    $extendedService = @(
        'createCefrA1ConnectLanguageEvidenceProvenance({'
    )
    $unitPanel = @(
        'createCefrA1ConnectLanguageScopedCoverageReadModel(',
        'Başka hedef dildeki evidence'
    )
    $continuityPanel = @(
        'createCefrA1ConnectLanguageScopedAdvisoryReadModel(',
        'Başka dil'
    )
    $safety = @(
        'crossLanguageEvidenceMaySatisfyCoverage:',
        'false',
        'unscopedLegacyEvidenceMayBeAttributed:',
        'false'
    )
}

foreach ($entry in $checks.GetEnumerator()) {
    foreach ($marker in $entry.Value) {
        if (-not (
            Select-String `
                -Path $entry.Key `
                -SimpleMatch `
                -Pattern $marker `
                -Quiet
        )) {
            throw "Required Sprint 1359-1364 marker missing: $marker"
        }
    }
}

Write-Host "SPRINT-1359-1364 SOURCE CHECK PASSED"

Set-Location $app

$targets = @(
    "src/core/learning/CefrA1ConnectLanguageEvidenceProvenance.test.ts",
    "src/application/learning/CefrA1ConnectLanguageEvidenceProvenanceRepository.test.ts",
    "src/application/learning/CefrA1ConnectLanguageScopedCoverageReadModel.test.ts",
    "src/application/learning/CefrA1ConnectLanguageScopedAdvisoryReadModel.test.ts",
    "src/application/learning/CefrA1ConnectLanguageEvidenceProvenanceIntegration.test.ts",
    "src/core/learning/CefrA1ConnectLanguageEvidenceSafety.test.ts",
    "src/ui/learning/A1ConnectLanguageScopedRuntime.test.ts",
    "src/application/learning/CefrA1ConnectGreetingTaskCompletionService.test.ts",
    "src/application/learning/CefrA1ConnectChoiceTaskCompletionService.test.ts",
    "src/application/learning/CefrA1ConnectExtendedTaskCompletionService.test.ts",
    "src/core/learning/CefrA1ConnectEvidenceCoverage.test.ts"
)

& npx vitest run $targets
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1359-1364 target tests failed."
}

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Full regression failed."
}

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Production build failed."
}

Write-Host "SPRINT-1359-1364 VERIFICATION COMPLETE"
