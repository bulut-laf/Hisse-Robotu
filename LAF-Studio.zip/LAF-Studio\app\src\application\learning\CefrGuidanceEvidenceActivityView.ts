import type { CefrPersonalLanguageProfileState } from "../../core/learning/CefrPersonalLanguageProfileState";

export type CefrGuidanceEvidenceActivityKind =
  | "lesson"
  | "listening"
  | "reading"
  | "writing"
  | "speaking"
  | "dialogue"
  | "other";

export type CefrGuidanceEvidenceActivitySource =
  | "learning-studio"
  | "translation-studio"
  | "interpreting-studio";

export type CefrGuidanceEvidenceActivityFilter =
  | "all"
  | CefrGuidanceEvidenceActivityKind;

export type CefrGuidanceEvidenceSourceFilter =
  | "all"
  | CefrGuidanceEvidenceActivitySource;

export interface CefrGuidanceEvidenceActivityItem {
  readonly evidenceId: string;
  readonly kind: CefrGuidanceEvidenceActivityKind;
  readonly label: string;
  readonly source: CefrGuidanceEvidenceActivitySource;
  readonly observedAt: string;
  readonly payloadReference: string;
  readonly masteryClaimed: false;
  readonly cefrLevelClaimed: false;
}

export interface CefrGuidanceEvidenceActivityQuery {
  readonly kind: CefrGuidanceEvidenceActivityFilter;
  readonly source: CefrGuidanceEvidenceSourceFilter;
  readonly limit: number;
}

export interface CefrGuidanceEvidenceActivityView {
  readonly totalEvidenceCount: number;
  readonly learningEvidenceCount: number;
  readonly translationEvidenceCount: number;
  readonly interpretingEvidenceCount: number;
  readonly observationCount: number;
  readonly filteredEvidenceCount: number;
  readonly latestItems:
    readonly CefrGuidanceEvidenceActivityItem[];
  readonly appliedKindFilter:
    CefrGuidanceEvidenceActivityFilter;
  readonly appliedSourceFilter:
    CefrGuidanceEvidenceSourceFilter;
  readonly masteryAssigned: false;
  readonly cefrLevelAssigned: false;
  readonly progressionPerformed: false;
  readonly readOnly: true;
}

function classifyEvidence(
  evidenceId: string,
): Pick<
  CefrGuidanceEvidenceActivityItem,
  "kind" | "label"
> {
  if (
    evidenceId.startsWith(
      "learning-session-completion:",
    )
  ) {
    return {
      kind: "lesson",
      label: "Lesson completion",
    };
  }

  if (
    evidenceId.startsWith(
      "listening-practice-completion:",
    )
  ) {
    return {
      kind: "listening",
      label: "Listening Practice",
    };
  }

  const embeddedPrefix =
    "embedded-studio-completion:";

  if (evidenceId.startsWith(embeddedPrefix)) {
    const studio =
      evidenceId
        .slice(embeddedPrefix.length)
        .split(":")[0];

    if (studio === "reading") {
      return {
        kind: "reading",
        label: "Reading Studio",
      };
    }

    if (studio === "writing") {
      return {
        kind: "writing",
        label: "Writing Studio",
      };
    }

    if (studio === "speaking") {
      return {
        kind: "speaking",
        label: "Speaking Studio",
      };
    }

    if (studio === "dialogue") {
      return {
        kind: "dialogue",
        label: "Dialogue Studio",
      };
    }
  }

  return {
    kind: "other",
    label: "Other evidence",
  };
}

function normalizeLimit(limit: number): number {
  if (!Number.isFinite(limit)) {
    return 0;
  }

  return Math.max(
    0,
    Math.floor(limit),
  );
}

export function createCefrGuidanceEvidenceActivityView(
  state: CefrPersonalLanguageProfileState,
  query: CefrGuidanceEvidenceActivityQuery = {
    kind: "all",
    source: "all",
    limit: 12,
  },
): CefrGuidanceEvidenceActivityView {
  const aggregation =
    state.profileSnapshot.evidenceAggregation;

  const allItems =
    aggregation.evidence.map(item => ({
      ...item,
      ...classifyEvidence(item.evidenceId),
    }));

  const filteredItems =
    allItems.filter(item => {
      const kindMatches =
        query.kind === "all" ||
        item.kind === query.kind;
      const sourceMatches =
        query.source === "all" ||
        item.source === query.source;

      return kindMatches && sourceMatches;
    });

  const latestItems =
    [...filteredItems]
      .sort((a, b) =>
        b.observedAt.localeCompare(a.observedAt),
      )
      .slice(
        0,
        normalizeLimit(query.limit),
      );

  return {
    totalEvidenceCount:
      aggregation.evidence.length,
    learningEvidenceCount:
      aggregation.learningEvidenceCount,
    translationEvidenceCount:
      aggregation.translationEvidenceCount,
    interpretingEvidenceCount:
      aggregation.interpretingEvidenceCount,
    observationCount:
      state.capabilityObservationRegistry
        .observationCount,
    filteredEvidenceCount:
      filteredItems.length,
    latestItems,
    appliedKindFilter: query.kind,
    appliedSourceFilter: query.source,
    masteryAssigned: false,
    cefrLevelAssigned: false,
    progressionPerformed: false,
    readOnly: true,
  };
}
