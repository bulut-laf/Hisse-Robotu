import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrPersonalLanguageProfileState,
  type CefrPersonalLanguageProfileState,
} from "../../core/learning/CefrPersonalLanguageProfileState";
import {
  createCefrA1ConnectGreetingComprehensionTask,
} from "../../core/learning/CefrA1ConnectGreetingComprehensionTask";
import type {
  CefrGuidanceRuntimeProfileRepository,
} from "./CefrGuidanceRuntimeProfileRepository";
import {
  CefrA1ConnectEvidenceProvenanceCoordinator,
} from "./CefrA1ConnectEvidenceProvenanceCoordinator";
import {
  CefrA1ConnectEvidenceProvenanceRecoveryRepository,
} from "./CefrA1ConnectEvidenceProvenanceRecoveryRepository";
import {
  CefrA1ConnectGreetingTaskCompletionService,
} from "./CefrA1ConnectGreetingTaskCompletionService";
import {
  CefrA1ConnectLanguageEvidenceProvenanceRepository,
} from "./CefrA1ConnectLanguageEvidenceProvenanceRepository";

class MemoryStorage {
  private readonly values =
    new Map<string, string>();

  getItem(key: string): string | null {
    return this.values.get(key) ?? null;
  }

  setItem(
    key: string,
    value: string,
  ): void {
    this.values.set(key, value);
  }

  removeItem(key: string): void {
    this.values.delete(key);
  }
}

class MemoryProfileRepository
  implements CefrGuidanceRuntimeProfileRepository {
  private state:
    CefrPersonalLanguageProfileState =
      createCefrPersonalLanguageProfileState(
        [],
        [],
      );

  load(): CefrPersonalLanguageProfileState {
    return this.state;
  }

  save(
    state: CefrPersonalLanguageProfileState,
  ): void {
    this.state = state;
  }

  hasPersistedProfile(): boolean {
    return true;
  }

  clear(): void {
    this.state =
      createCefrPersonalLanguageProfileState(
        [],
        [],
      );
  }
}

describe(
  "A1 CONNECT evidence/provenance consistency integration",
  () => {
    it("keeps correct evidence persistence and language provenance coordinated", () => {
      const provenanceRepository =
        new CefrA1ConnectLanguageEvidenceProvenanceRepository(
          new MemoryStorage(),
        );
      const recoveryRepository =
        new CefrA1ConnectEvidenceProvenanceRecoveryRepository(
          new MemoryStorage(),
        );
      const coordinator =
        new CefrA1ConnectEvidenceProvenanceCoordinator(
          provenanceRepository,
          recoveryRepository,
        );
      const service =
        new CefrA1ConnectGreetingTaskCompletionService(
          new MemoryProfileRepository(),
          coordinator,
        );
      const task =
        createCefrA1ConnectGreetingComprehensionTask(
          "de",
        );

      const result =
        service.submit({
          languageCode: "de",
          submittedAnswer:
            task.correctAnswer,
          eventId:
            "consistency-001",
          occurredAt:
            new Date(
              "2026-08-11T19:20:00.000Z",
            ),
          userActionConfirmed: true,
        });

      expect(result.evidencePersisted).toBe(
        true,
      );
      expect(
        provenanceRepository
          .findByEvidenceId(
            result.evidence?.runtimeEvidenceId ??
              "",
          )
          ?.languageCode,
      ).toBe("de");
      expect(
        recoveryRepository.loadAll(),
      ).toHaveLength(0);
    });
  },
);
