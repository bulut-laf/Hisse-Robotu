$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 1152-1154 Target Tests: Application Router Contract ==="
npx vitest run `
  "src/core/learning/CefrGuidanceApplicationRouteDescriptor.test.ts" `
  "src/core/learning/CefrGuidanceApplicationRouteRegistry.test.ts" `
  "src/core/learning/CefrGuidanceNavigationRouteResolution.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1152-1154 target tests failed." }

Write-Host "=== Sprint 1155-1157 Target Tests: Router Dispatch Handoff ==="
npx vitest run `
  "src/core/learning/CefrGuidanceRouterDispatchRequest.test.ts" `
  "src/core/learning/CefrGuidanceRouterDispatchGate.test.ts" `
  "src/core/learning/CefrGuidanceRouterDispatchHandoff.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1155-1157 target tests failed." }

Write-Host "=== Sprint 1158-1160 Target Tests: Studio Entry Context ==="
npx vitest run `
  "src/core/learning/CefrGuidanceStudioEntryContext.test.ts" `
  "src/core/learning/CefrGuidanceStudioEntryBoundary.test.ts" `
  "src/core/learning/CefrGuidanceStudioEntryPlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1158-1160 target tests failed." }

Write-Host "=== Combined Sprint 1152-1160 New Tests ==="
npx vitest run `
  "src/core/learning/CefrGuidanceApplicationRouteDescriptor.test.ts" `
  "src/core/learning/CefrGuidanceApplicationRouteRegistry.test.ts" `
  "src/core/learning/CefrGuidanceNavigationRouteResolution.test.ts" `
  "src/core/learning/CefrGuidanceRouterDispatchRequest.test.ts" `
  "src/core/learning/CefrGuidanceRouterDispatchGate.test.ts" `
  "src/core/learning/CefrGuidanceRouterDispatchHandoff.test.ts" `
  "src/core/learning/CefrGuidanceStudioEntryContext.test.ts" `
  "src/core/learning/CefrGuidanceStudioEntryBoundary.test.ts" `
  "src/core/learning/CefrGuidanceStudioEntryPlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1152-1160 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-1152-1160 VERIFICATION COMPLETE"
