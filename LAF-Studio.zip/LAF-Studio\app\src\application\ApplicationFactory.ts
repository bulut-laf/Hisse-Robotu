import type {
  TranslationActivity,
} from "../core/activity";
import { TranslationPipeline } from "../core/pipeline";
import {
  LearningRecommendationEngine,
} from "../core/recommendation";
import {
  StaticActivityRepository,
} from "../core/repository";
import {
  LearningSessionController,
} from "../core/session";
import type {
  SessionStorage,
} from "../core/session/SessionStorage";

import {
  LearningApplicationService,
} from "./LearningApplicationService";

export class ApplicationFactory {
  static create(
    activities?: TranslationActivity[],
    storage?: SessionStorage,
  ): LearningApplicationService {
    const repository =
      new StaticActivityRepository(activities);

    const pipeline =
      new TranslationPipeline();

    const recommendationEngine =
      new LearningRecommendationEngine();

    const controller =
      new LearningSessionController(
        repository,
        pipeline,
        recommendationEngine,
        storage,
      );

    return new LearningApplicationService(
      controller,
    );
  }
}
