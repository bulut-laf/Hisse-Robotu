$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

Set-Location $app

Write-Host "=== Sprint 513-515 Target Tests ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceAssurance.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceAssuranceCoordination.test.ts" `
  "src/core/learning/CefrEvidenceAssuranceAwareCefrIntelligencePlatform.test.ts"

if ($LASTEXITCODE -ne 0) {
  throw "Sprint 513-515 target tests failed."
}

Write-Host "=== Full Regression ==="
npm run test

if ($LASTEXITCODE -ne 0) {
  throw "Full regression failed."
}

Write-Host "=== Production Build ==="
npm run build

if ($LASTEXITCODE -ne 0) {
  throw "Production build failed."
}

Write-Host "SPRINT-513-515 VERIFICATION COMPLETE"
