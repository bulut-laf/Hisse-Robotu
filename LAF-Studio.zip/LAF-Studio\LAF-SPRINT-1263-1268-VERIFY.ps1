﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

Set-Location $app

$targets = @(
  "src/core/learning/CefrCurriculumCompetencyMapping.test.ts",
  "src/core/learning/CefrCurriculumCompetencyRegistry.test.ts",
  "src/core/learning/CefrCurriculumCapabilityObservationEligibility.test.ts",
  "src/core/learning/CefrAuthoritativeCurriculumRegistry.test.ts",
  "src/core/learning/CefrAuthoritativeCurriculumCapabilityBindingSafety.test.ts",
  "src/core/learning/CefrCurriculumCapabilityObservationWrite.test.ts",
  "src/application/learning/CefrCurriculumCapabilityObservationWriter.test.ts",
  "src/core/learning/CefrCurriculumCapabilityObservationWriteSafety.test.ts"
)

& npx vitest run $targets
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1263-1268 target tests failed."
}

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Full regression failed."
}

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Production build failed."
}

Write-Host "SPRINT-1263-1268 VERIFICATION COMPLETE"
