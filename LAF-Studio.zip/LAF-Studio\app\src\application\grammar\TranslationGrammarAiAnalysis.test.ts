import {
  describe,
  expect,
  it,
} from "vitest";

import {
  prepareTranslationGrammarAiDraft,
} from "./TranslationGrammarAiAnalysis";

describe(
  "prepareTranslationGrammarAiDraft",
  () => {
    it("accepts a complete Grammar AI draft", () => {
      expect(
        prepareTranslationGrammarAiDraft({
          pattern:
            "-val/-vel araç-birliktelik hâli",
          functionText:
            "Ulaşım aracını belirtir.",
          explanation:
            "-val/-vel Türkçedeki 'ile' anlamına gelir.",
          confidence: "high",
        }),
      ).toEqual({
        status: "ready",
        issues: [],
        draft: {
          pattern:
            "-val/-vel araç-birliktelik hâli",
          functionText:
            "Ulaşım aracını belirtir.",
          explanation:
            "-val/-vel Türkçedeki 'ile' anlamına gelir.",
          confidence: "high",
        },
      });
    });

    it("trims generated text fields", () => {
      const result =
        prepareTranslationGrammarAiDraft({
          pattern: "  -ban/-ben  ",
          functionText:
            "  Bulunulan yeri gösterir. ",
          explanation:
            "  İçinde bulunma hâlidir. ",
          confidence: "medium",
        });

      expect(result).toMatchObject({
        status: "ready",
        draft: {
          pattern: "-ban/-ben",
          functionText:
            "Bulunulan yeri gösterir.",
          explanation:
            "İçinde bulunma hâlidir.",
          confidence: "medium",
        },
      });
    });

    it("blocks a missing pattern", () => {
      const result =
        prepareTranslationGrammarAiDraft({
          pattern: "",
          functionText: "İşlev",
          explanation: "Açıklama",
          confidence: "high",
        });

      expect(result.status).toBe(
        "blocked",
      );
      expect(
        result.status === "blocked"
          ? result.issues
          : [],
      ).toContainEqual({
        code: "missing-pattern",
      });
    });

    it("blocks a missing function", () => {
      const result =
        prepareTranslationGrammarAiDraft({
          pattern: "Yapı",
          functionText: "",
          explanation: "Açıklama",
          confidence: "high",
        });

      expect(result.status).toBe(
        "blocked",
      );
      expect(
        result.status === "blocked"
          ? result.issues
          : [],
      ).toContainEqual({
        code: "missing-function",
      });
    });

    it("blocks a missing explanation", () => {
      const result =
        prepareTranslationGrammarAiDraft({
          pattern: "Yapı",
          functionText: "İşlev",
          explanation: "",
          confidence: "high",
        });

      expect(result.status).toBe(
        "blocked",
      );
      expect(
        result.status === "blocked"
          ? result.issues
          : [],
      ).toContainEqual({
        code: "missing-explanation",
      });
    });

    it("blocks an unsupported confidence value", () => {
      const result =
        prepareTranslationGrammarAiDraft({
          pattern: "Yapı",
          functionText: "İşlev",
          explanation: "Açıklama",
          confidence: "certain",
        });

      expect(result.status).toBe(
        "blocked",
      );
      expect(
        result.status === "blocked"
          ? result.issues
          : [],
      ).toContainEqual({
        code: "invalid-confidence",
      });
    });

    it("blocks non-object provider output", () => {
      expect(
        prepareTranslationGrammarAiDraft(
          "not-an-object",
        ),
      ).toEqual({
        status: "blocked",
        issues: [
          {
            code: "invalid-response",
          },
        ],
      });
    });
  },
);
