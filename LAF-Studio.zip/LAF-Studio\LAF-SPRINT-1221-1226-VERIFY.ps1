﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

Write-Host "=== Install Listening Practice Completion Evidence Binding ==="
Set-Location $root
node ".\LAF-SPRINT-1221-1226-INSTALL.mjs"
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1221-1226 install failed."
}

$listeningPage = Join-Path $app "src\ui\pages\ListeningPracticePage.tsx"

$writeMatches = @(
    Select-String `
        -Path $listeningPage `
        -SimpleMatch `
        'recordListeningPracticeCompletion({'
)

if ($writeMatches.Count -ne 1) {
    throw (
        "Listening Practice completion evidence binding validation failed. Count=" +
        $writeMatches.Count
    )
}

Set-Location $app

Write-Host "=== Sprint 1221-1223 Target Tests ==="
npx vitest run `
  "src/application/learning/CefrGuidanceRuntimeProfileService.test.ts"
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1221-1223 target tests failed."
}

Write-Host "=== Sprint 1224-1226 Safety Tests ==="
npx vitest run `
  "src/application/learning/CefrListeningPracticeEvidenceBindingSafety.test.ts"
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1224-1226 target tests failed."
}

Write-Host "=== Combined Sprint 1221-1226 Tests ==="
npx vitest run `
  "src/application/learning/CefrGuidanceRuntimeProfileService.test.ts" `
  "src/application/learning/CefrListeningPracticeEvidenceBindingSafety.test.ts" `
  "src/core/learning/CefrLearningStudioEvidenceAdapter.test.ts" `
  "src/core/learning/CefrPersonalLanguageProfileEvidence.test.ts"
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1221-1226 combined tests failed."
}

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Full regression failed."
}

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Production build failed."
}

Write-Host "SPRINT-1221-1226 VERIFICATION COMPLETE"
