import {
  describe,
  expect,
  it,
} from "vitest";

import {
  AI_TEACHER_CORE_CONTRACT_V1,
  resolveAiTeacherInteractionPolicy,
} from "./AiTeacherCrossStudioConsistency";

describe("AI Teacher learner-first normalization", () => {
  it("does not allow answer-bearing takeover before a learner attempt in teacher mode", () => {
    const policy =
      resolveAiTeacherInteractionPolicy({
        surfaceId: "writing",
        learnerAttemptAvailable: false,
        authoritativeCefrContextAvailable:
          false,
      });

    expect(
      policy.learnerMustRemainProducer,
    ).toBe(true);
    expect(
      policy
        .answerBearingOutputBeforeAttemptAllowed,
    ).toBe(false);
    expect(
      policy.feedbackAfterAttemptAllowed,
    ).toBe(false);
    expect(
      policy.graduatedSupportPreferred,
    ).toBe(true);
  });

  it("allows feedback after a real learner attempt without transferring authorship", () => {
    const policy =
      resolveAiTeacherInteractionPolicy({
        surfaceId: "dialogue",
        learnerAttemptAvailable: true,
        authoritativeCefrContextAvailable:
          false,
      });

    expect(
      policy.feedbackAfterAttemptAllowed,
    ).toBe(true);
    expect(
      policy.learnerMustRemainProducer,
    ).toBe(true);
    expect(
      policy.mayWriteLearnerEvidenceFromAiOutput,
    ).toBe(false);
  });

  it("preserves legitimate productivity output generation", () => {
    const policy =
      resolveAiTeacherInteractionPolicy({
        surfaceId: "translation-studio",
        learnerAttemptAvailable: false,
        authoritativeCefrContextAvailable:
          false,
      });

    expect(
      policy.legitimateProductivityOutputAllowed,
    ).toBe(true);
    expect(
      policy
        .answerBearingOutputBeforeAttemptAllowed,
    ).toBe(true);
    expect(
      policy.learnerMustRemainProducer,
    ).toBe(false);
  });

  it("keeps the V1 common contract minimal and non-generative", () => {
    expect(
      AI_TEACHER_CORE_CONTRACT_V1
        .newAiRuntimeRequired,
    ).toBe(false);
    expect(
      AI_TEACHER_CORE_CONTRACT_V1
        .newPromptEngineRequired,
    ).toBe(false);
    expect(
      AI_TEACHER_CORE_CONTRACT_V1
        .newEvidenceArchitectureRequired,
    ).toBe(false);
  });
});
