import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrPersonalLanguageProfileState,
  type CefrPersonalLanguageProfileState,
} from "../../core/learning/CefrPersonalLanguageProfileState";
import type {
  CefrLanguageEvidenceStorageLike,
} from "./CefrAuthoritativeLanguageEvidenceProvenanceRepository";
import type {
  CefrGuidanceRuntimeProfileRepository,
} from "./CefrGuidanceRuntimeProfileRepository";
import {
  CefrProductionRuntimePlatform,
} from "./CefrProductionRuntimePlatform";
import {
  CefrA1DescribeSecondWaveExecutableTaskService,
} from "./CefrA1DescribeSecondWaveExecutableTaskService";

class MemoryProfileRepository
  implements CefrGuidanceRuntimeProfileRepository {
  private state:
    CefrPersonalLanguageProfileState =
      createCefrPersonalLanguageProfileState(
        [],
        [],
      );

  load(): CefrPersonalLanguageProfileState {
    return this.state;
  }

  save(
    state: CefrPersonalLanguageProfileState,
  ): void {
    this.state = state;
  }

  hasPersistedProfile(): boolean {
    return false;
  }

  clear(): void {}
}

class MemoryStorage
  implements CefrLanguageEvidenceStorageLike {
  private readonly items =
    new Map<string, string>();

  getItem(key: string): string | null {
    return this.items.get(key) ?? null;
  }

  setItem(
    key: string,
    value: string,
  ): void {
    this.items.set(key, value);
  }

  removeItem(key: string): void {
    this.items.delete(key);
  }
}

function createService() {
  const repository =
    new MemoryProfileRepository();

  const service =
    new CefrA1DescribeSecondWaveExecutableTaskService(
      new CefrProductionRuntimePlatform(
        repository,
        new MemoryStorage(),
      ),
    );

  return {
    repository,
    service,
  };
}

describe(
  "A1 DESCRIBE second-wave executable task service",
  () => {
    it("writes place/thing description evidence only after the complete approved description sequence", () => {
      const {
        repository,
        service,
      } = createService();

      const partial =
        service.executeSequenceTask({
          taskId:
            "a1-describe-task-place-thing-description",
          languageCode: "de",
          selectedPhraseIds: [
            "place-identify",
            "place-small",
          ],
          eventId:
            "describe-place-partial-001",
          occurredAt:
            new Date(
              "2026-08-12T20:00:00.000Z",
            ),
          userActionConfirmed: true,
        });

      expect(partial).toMatchObject({
        correctPrefix: true,
        complete: false,
        evidenceWritten: false,
        runtime: null,
        narrativeSequencingPerformed:
          false,
      });

      expect(
        repository.load()
          .profileSnapshot
          .evidenceAggregation
          .evidence,
      ).toHaveLength(0);

      const complete =
        service.executeSequenceTask({
          taskId:
            "a1-describe-task-place-thing-description",
          languageCode: "de",
          selectedPhraseIds: [
            "place-identify",
            "place-small",
            "place-quiet",
          ],
          eventId:
            "describe-place-complete-001",
          occurredAt:
            new Date(
              "2026-08-12T20:01:00.000Z",
            ),
          userActionConfirmed: true,
        });

      expect(complete).toMatchObject({
        correctPrefix: true,
        complete: true,
        evidenceWritten: true,
        masteryAssigned: false,
        competencySuccessAssigned: false,
        cefrLevelAssigned: false,
        progressionPerformed: false,
        narrativeSequencingPerformed:
          false,
      });

      expect(
        complete.runtime?.runtime
          .resolvedCapabilityReferences,
      ).toEqual([
        "description-production",
      ]);
    });

    it("writes follow-up response evidence after the correct explicit user selection", () => {
      const {
        service,
      } = createService();

      const view =
        service.getFollowUpTaskView("it");

      expect(
        view.promptPhrase.phraseId,
      ).toBe("followup-question");

      const result =
        service.executeFollowUp({
          languageCode: "it",
          selectedPhraseId:
            "followup-answer",
          eventId:
            "describe-followup-001",
          occurredAt:
            new Date(
              "2026-08-12T20:05:00.000Z",
            ),
          userActionConfirmed: true,
        });

      expect(result).toMatchObject({
        correct: true,
        evidenceWritten: true,
        masteryAssigned: false,
        competencySuccessAssigned: false,
        cefrLevelAssigned: false,
        progressionPerformed: false,
        narrativeSequencingPerformed:
          false,
      });

      expect(
        result.runtime?.runtime
          .resolvedCapabilityReferences,
      ).toEqual([
        "description-production",
      ]);
    });

    it("requires the complete reciprocal-description contribution without turning it into narrative sequencing", () => {
      const {
        service,
      } = createService();

      const result =
        service.executeSequenceTask({
          taskId:
            "a1-describe-task-reciprocal-description",
          languageCode: "hu",
          selectedPhraseIds: [
            "complete-identify",
            "complete-feature-one",
            "complete-feature-two",
            "followup-answer",
          ],
          eventId:
            "describe-reciprocal-001",
          occurredAt:
            new Date(
              "2026-08-12T20:10:00.000Z",
            ),
          userActionConfirmed: true,
        });

      expect(result).toMatchObject({
        complete: true,
        evidenceWritten: true,
        masteryAssigned: false,
        competencySuccessAssigned: false,
        cefrLevelAssigned: false,
        progressionPerformed: false,
        narrativeSequencingPerformed:
          false,
      });
    });
  },
);
