import { Route, Routes } from "react-router-dom";
import HomePage from "./pages/HomePage";
import LessonsPage from "./pages/LessonsPage";
import VocabularyPage from "./pages/VocabularyPage";
import ProgressPage from "./pages/ProgressPage";
import FavoriteWordsPage from "./pages/FavoriteWordsPage";
import MainLayout from "./shared/layouts/MainLayout";
import { LessonPage } from "./ui/pages/LessonPage";
import {
  ListeningPracticePage,
} from "./ui/pages/ListeningPracticePage";
import {
  LearningStudioPage,
} from "./ui/pages/LearningStudioPage";
import {
  TranslationStudioPage,
} from "./ui/pages/TranslationStudioPage";
import {
  TerminologyCenterPage,
} from "./ui/pages/TerminologyCenterPage";
import {
  TextWorkshopPage,
} from "./ui/pages/TextWorkshopPage";
import {
  GuidanceCenterPage,
} from "./ui/pages/GuidanceCenterPage";
import {
  NotFoundPage,
} from "./ui/pages/NotFoundPage";

function App() {
  return (
    <MainLayout>
      <Routes>
        <Route path="/" element={<HomePage />} />

        <Route path="/lessons" element={<LessonsPage />} />

        <Route
          path="/lessons/:id"
          element={<LessonPage />}
        />

        <Route
          path="/lessons/:id/listening"
          element={<ListeningPracticePage />}
        />

        <Route
          path="/vocabulary"
          element={<VocabularyPage />}
        />

        <Route
          path="/favorites"
          element={<FavoriteWordsPage />}
        />

        <Route
          path="/progress"
          element={<ProgressPage />}
        />

        <Route
          path="/learning"
          element={<LearningStudioPage />}
        />

        <Route
          path="/learning/guidance"
          element={<GuidanceCenterPage />}
        />

        <Route
          path="/translation"
          element={<TranslationStudioPage />}
        />

        <Route
          path="/terminology"
          element={<TerminologyCenterPage />}
        />

        <Route
          path="/text-workshop"
          element={<TextWorkshopPage />}
        />

        <Route path="*" element={<NotFoundPage />} />
      </Routes>
    </MainLayout>
  );
}

export default App;
