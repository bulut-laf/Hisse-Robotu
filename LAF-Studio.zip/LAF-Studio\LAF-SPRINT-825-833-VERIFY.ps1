$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 825-827 Target Tests: Custodial Dependency ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialDependency.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialDependencyCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialDependencyAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 825-827 target tests failed." }

Write-Host "=== Sprint 828-830 Target Tests: Custodial Interdependence ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialInterdependence.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialInterdependenceCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialInterdependenceAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 828-830 target tests failed." }

Write-Host "=== Sprint 831-833 Target Tests: Custodial Association ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialAssociation.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialAssociationCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialAssociationAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 831-833 target tests failed." }

Write-Host "=== Combined Sprint 825-833 New Tests ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialDependency.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialDependencyCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialDependencyAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialInterdependence.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialInterdependenceCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialInterdependenceAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialAssociation.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialAssociationCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialAssociationAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 825-833 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-825-833 VERIFICATION COMPLETE"
