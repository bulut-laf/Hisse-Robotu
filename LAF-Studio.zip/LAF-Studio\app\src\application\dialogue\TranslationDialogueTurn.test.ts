import {
  describe,
  expect,
  it,
} from "vitest";

import {
  prepareTranslationDialogueTurnResult,
} from "./TranslationDialogueTurn";

describe(
  "prepareTranslationDialogueTurnResult",
  () => {
    it("accepts a complete AI role-play turn", () => {
      expect(
        prepareTranslationDialogueTurnResult({
          partnerReply:
            "Rendben. Még valamit?",
          supportHint:
            "İsterseniz başka bir şey isteyin.",
          goalProgress:
            "progressing",
        }).status,
      ).toBe("ready");
    });

    it("trims generated strings", () => {
      const result =
        prepareTranslationDialogueTurnResult({
          partnerReply: "  Szia!  ",
          supportHint: "  Kısa cevap verin.  ",
          goalProgress:
            "starting",
        });

      expect(result).toMatchObject({
        status: "ready",
        result: {
          partnerReply: "Szia!",
          supportHint:
            "Kısa cevap verin.",
        },
      });
    });

    it("accepts ready-to-close progress", () => {
      const result =
        prepareTranslationDialogueTurnResult({
          partnerReply:
            "Köszönöm, viszontlátásra!",
          supportHint:
            "Kısa bir vedayla tamamlayabilirsiniz.",
          goalProgress:
            "ready-to-close",
        });

      expect(result.status).toBe(
        "ready",
      );
    });

    it("blocks missing partner reply", () => {
      const result =
        prepareTranslationDialogueTurnResult({
          partnerReply: "",
          supportHint: "İpucu",
          goalProgress:
            "starting",
        });

      expect(
        result.status === "blocked"
          ? result.issues
          : [],
      ).toContainEqual({
        code: "missing-partner-reply",
      });
    });

    it("blocks missing support hint", () => {
      const result =
        prepareTranslationDialogueTurnResult({
          partnerReply: "Szia",
          supportHint: "",
          goalProgress:
            "starting",
        });

      expect(
        result.status === "blocked"
          ? result.issues
          : [],
      ).toContainEqual({
        code: "missing-support-hint",
      });
    });

    it("blocks invalid goal progress", () => {
      const result =
        prepareTranslationDialogueTurnResult({
          partnerReply: "Szia",
          supportHint: "İpucu",
          goalProgress: "done",
        });

      expect(
        result.status === "blocked"
          ? result.issues
          : [],
      ).toContainEqual({
        code: "invalid-goal-progress",
      });
    });

    it("collects multiple issues", () => {
      const result =
        prepareTranslationDialogueTurnResult({
          partnerReply: "",
          supportHint: "",
          goalProgress: "x",
        });

      expect(
        result.status === "blocked"
          ? result.issues
          : [],
      ).toHaveLength(3);
    });

    it("blocks arrays", () => {
      expect(
        prepareTranslationDialogueTurnResult(
          [],
        ).status,
      ).toBe("blocked");
    });

    it("blocks primitive output", () => {
      expect(
        prepareTranslationDialogueTurnResult(
          "invalid",
        ).status,
      ).toBe("blocked");
    });
  },
);
