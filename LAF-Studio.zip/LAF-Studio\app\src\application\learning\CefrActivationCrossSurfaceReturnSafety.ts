import type { CefrGuidanceSessionActivationGate } from "../../core/learning/CefrGuidanceSessionActivationGate";
import {
  resolveCefrActivationLearningPathReturnTarget,
  type CefrActivationLearningPathReturnContext,
} from "./CefrActivationLearningPathReturnContextAdapter";

export function isCefrActivationReturnContextSafeForGuidanceSurface(
  context: CefrActivationLearningPathReturnContext,
  gate: CefrGuidanceSessionActivationGate,
): boolean {
  return (
    resolveCefrActivationLearningPathReturnTarget(context) !== null &&
    gate.acceptedForApplicationSessionStart &&
    gate.explicitUserActionRequired === true &&
    gate.sessionStartedByCore === false &&
    gate.masteryMutationAllowed === false &&
    gate.cefrLevelMutationAllowed === false &&
    gate.progressionMutationAllowed === false &&
    gate.request.userInitiated === true &&
    gate.request.activationRequested === true &&
    gate.request.automaticSessionStartAllowed === false
  );
}
