$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$src = Join-Path $app "src"
$out = Join-Path $root "LAF_UI_INTEGRATION_DISCOVERY.txt"

if (-not (Test-Path $app)) {
    throw "App root not found: $app"
}

$lines = New-Object System.Collections.Generic.List[string]

function Add-Line([string]$text = "") {
    $lines.Add($text)
}

function Add-Section([string]$title) {
    Add-Line ""
    Add-Line ("=" * 88)
    Add-Line $title
    Add-Line ("=" * 88)
}

function Add-FilePreview([string]$path, [int]$maxLines = 120) {
    if (-not (Test-Path $path)) { return }
    Add-Line ""
    Add-Line ("FILE: " + $path.Substring($root.Length).TrimStart('\'))
    Add-Line ("-" * 88)
    $content = Get-Content -Path $path -ErrorAction Stop
    $count = [Math]::Min($content.Count, $maxLines)
    for ($i = 0; $i -lt $count; $i++) {
        Add-Line ("{0,4}: {1}" -f ($i + 1), $content[$i])
    }
    if ($content.Count -gt $maxLines) {
        Add-Line ("... truncated; total lines: " + $content.Count)
    }
}

function Add-Matches([string]$title, [string[]]$patterns, [int]$limit = 120) {
    Add-Section $title

    $files = Get-ChildItem -Path $src -Recurse -File -Include *.ts,*.tsx,*.js,*.jsx,*.css -ErrorAction SilentlyContinue
    $matches = foreach ($file in $files) {
        foreach ($pattern in $patterns) {
            Select-String -Path $file.FullName -Pattern $pattern -SimpleMatch -ErrorAction SilentlyContinue |
                ForEach-Object {
                    [PSCustomObject]@{
                        File = $_.Path.Substring($root.Length).TrimStart('\')
                        Line = $_.LineNumber
                        Text = $_.Line.Trim()
                        Pattern = $pattern
                    }
                }
        }
    }

    $matches = $matches |
        Sort-Object File, Line, Pattern -Unique |
        Select-Object -First $limit

    if (-not $matches) {
        Add-Line "(no matches)"
        return
    }

    foreach ($m in $matches) {
        Add-Line ("{0}:{1}  [{2}]  {3}" -f $m.File, $m.Line, $m.Pattern, $m.Text)
    }
}

Add-Line "LAF STUDIO — REAL UI / ROUTER INTEGRATION DISCOVERY"
Add-Line ("Generated: " + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
Add-Line ("Project: " + $root)
Add-Line "READ-ONLY DISCOVERY: no project source files are modified."

Add-Section "1. PACKAGE / BUILD CONFIG"
Add-FilePreview (Join-Path $app "package.json") 180
Add-FilePreview (Join-Path $app "vite.config.ts") 120
Add-FilePreview (Join-Path $app "vite.config.js") 120
Add-FilePreview (Join-Path $app "tsconfig.json") 120

Add-Section "2. TOP-LEVEL SRC FILE TREE"
Get-ChildItem -Path $src -File -ErrorAction SilentlyContinue |
    Sort-Object Name |
    ForEach-Object {
        Add-Line ($_.FullName.Substring($root.Length).TrimStart('\'))
    }

Add-Section "3. LIKELY APP / ROUTER / ENTRY FILES"
$candidates = Get-ChildItem -Path $src -Recurse -File -Include `
    App.tsx,App.ts,main.tsx,main.ts,index.tsx,index.ts,router.tsx,router.ts,routes.tsx,routes.ts,Router.tsx,Routes.tsx `
    -ErrorAction SilentlyContinue |
    Sort-Object FullName -Unique

if (-not $candidates) {
    Add-Line "(no conventional entry/router filenames found)"
} else {
    foreach ($file in $candidates) {
        Add-FilePreview $file.FullName 180
    }
}

Add-Matches "4. ROUTER / NAVIGATION SIGNALS" @(
    "react-router",
    "BrowserRouter",
    "HashRouter",
    "MemoryRouter",
    "Routes",
    "Route",
    "useNavigate",
    "navigate(",
    "router.push",
    "router.replace",
    "location.pathname",
    "window.location"
) 180

Add-Matches "5. CURRENT LEARNING HOME / DASHBOARD SIGNALS" @(
    "Today's Learning Focus",
    "Today’s Learning Focus",
    "Learning Focus",
    "Daily Learning",
    "Learning Path",
    "Continue Learning",
    "CEFR",
    "Language Orbit",
    "Sticky Learning Journey",
    "Hareket Kontrolü"
) 180

Add-Matches "6. STUDIO NAVIGATION / STUDIO COMPONENT SIGNALS" @(
    "grammar-lab",
    "reading-studio",
    "listening-studio",
    "writing-studio",
    "speaking-pronunciation-studio",
    "dialogue-role-play-studio",
    "vocabulary-memory-studio",
    "translation-studio",
    "interpreting-studio",
    "Grammar Lab",
    "Reading Studio",
    "Listening Studio",
    "Writing Studio",
    "Speaking",
    "Dialogue",
    "Vocabulary",
    "Translation Studio"
) 220

Add-Matches "7. STATE / CONTEXT / SERVICE SIGNALS" @(
    "createContext",
    "useContext",
    "useReducer",
    "useState",
    "zustand",
    "redux",
    "localStorage",
    "sessionStorage",
    "service",
    "repository",
    "store"
) 180

Add-Matches "8. EXISTING CEFR GUIDANCE PUBLIC FACADE REFERENCES" @(
    "CefrGuidanceApplicationFacade",
    "cefrGuidanceApplicationFacade",
    "CefrIntegratedGuidancePlatform",
    "CefrApplicationGuidance"
) 160

Add-Section "9. LIKELY UI COMPONENT FILES"
$uiFiles = Get-ChildItem -Path $src -Recurse -File -Include *.tsx -ErrorAction SilentlyContinue |
    Where-Object {
        $_.FullName -match "component|page|screen|view|dashboard|home|learning|studio|cefr"
    } |
    Sort-Object FullName |
    Select-Object -First 120

if (-not $uiFiles) {
    Add-Line "(no likely UI files found by path heuristic)"
} else {
    foreach ($file in $uiFiles) {
        $relative = $file.FullName.Substring($root.Length).TrimStart('\')
        Add-Line ("{0}  ({1} bytes)" -f $relative, $file.Length)
    }
}

Add-Section "10. TEST CONVENTIONS NEAR UI / APP"
$testFiles = Get-ChildItem -Path $src -Recurse -File -Include *.test.ts,*.test.tsx -ErrorAction SilentlyContinue |
    Where-Object {
        $_.FullName -match "component|page|screen|view|dashboard|home|learning|studio|cefr|App"
    } |
    Sort-Object FullName |
    Select-Object -First 100

if (-not $testFiles) {
    Add-Line "(no matching test files found)"
} else {
    foreach ($file in $testFiles) {
        Add-Line ($file.FullName.Substring($root.Length).TrimStart('\'))
    }
}

Add-Section "11. INTEGRATION DECISION INPUT"
Add-Line "Use this report to determine:"
Add-Line "- exact application entry / router file"
Add-Line "- exact Learning Home / CEFR UI insertion point"
Add-Line "- exact Studio route identifiers"
Add-Line "- existing navigation mechanism"
Add-Line "- existing state/service pattern"
Add-Line "- nearby test conventions"
Add-Line "- whether first real UI block should touch 3 or fewer production files"

$lines | Set-Content -Path $out -Encoding UTF8

Write-Host ""
Write-Host "LAF UI INTEGRATION DISCOVERY COMPLETE"
Write-Host "Report:"
Write-Host $out
Write-Host ""
Get-Content -Path $out
