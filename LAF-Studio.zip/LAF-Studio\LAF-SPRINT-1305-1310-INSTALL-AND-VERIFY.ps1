﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app  = Join-Path $root "app"
$page = Join-Path $app "src\ui\pages\LearningStudioPage.tsx"

if (-not (Test-Path $page)) {
    throw "LearningStudioPage.tsx not found."
}

$utf8 = New-Object System.Text.UTF8Encoding($false)
$text = [System.IO.File]::ReadAllText($page, $utf8)

$importLine =
    'import { A1ConnectNativeLearningPanel } from "../learning/A1ConnectNativeLearningPanel";'

if (-not $text.Contains($importLine)) {
    $anchor =
        'import { LearningGuidanceEntryCard } from "../learning/LearningGuidanceEntryCard";'

    if (-not $text.Contains($anchor)) {
        throw "LearningStudioPage import anchor not found. No source change made."
    }

    $text = $text.Replace(
        $anchor,
        $anchor + [Environment]::NewLine + $importLine
    )
}

$panelLine = '      <A1ConnectNativeLearningPanel />'

if (-not $text.Contains($panelLine)) {
    $anchor = '      <LearningGuidanceEntryCard />'

    if (-not $text.Contains($anchor)) {
        throw "LearningStudioPage render anchor not found. No render patch applied."
    }

    $text = $text.Replace(
        $anchor,
        $anchor + [Environment]::NewLine +
        [Environment]::NewLine + $panelLine
    )
}

[System.IO.File]::WriteAllText(
    $page,
    $text,
    $utf8
)

Write-Host "SPRINT-1305-1310 INSTALLATION COMPLETE"

$component = Join-Path $app "src\ui\learning\A1ConnectNativeLearningPanel.tsx"
$model = Join-Path $app "src\application\learning\CefrA1ConnectNativeLearningUiModel.ts"
$safety = Join-Path $app "src\core\learning\CefrA1ConnectNativeLearningUiSafety.ts"

foreach ($file in @($component, $model, $safety)) {
    if (-not (Test-Path $file)) {
        throw "Sprint 1305-1310 source missing: $file"
    }
}

$sourceChecks = @{
    $page = @(
        'import { A1ConnectNativeLearningPanel } from "../learning/A1ConnectNativeLearningPanel";',
        '<LearningGuidanceEntryCard />',
        '<A1ConnectNativeLearningPanel />'
    )
    $component = @(
        'data-cefr-unit={model.unitId}',
        'disabled',
        'Dil Gerçekleştirmesi Bekleniyor'
    )
    $model = @(
        'languageRealizationBound: false',
        'evidenceCaptureEnabled: false',
        'existingLearningQueuePreserved: true'
    )
    $safety = @(
        'fabricatedLearnerEvidenceAllowed: false',
        'evidenceCaptureOnRenderAllowed: false',
        'evidenceCaptureOnLessonSelectionAllowed:',
        'automaticProgressionAllowed: false'
    )
}

foreach ($entry in $sourceChecks.GetEnumerator()) {
    foreach ($marker in $entry.Value) {
        if (-not (
            Select-String -Path $entry.Key -SimpleMatch `
                -Pattern $marker -Quiet
        )) {
            throw "Required Sprint 1305-1310 marker missing: $marker"
        }
    }
}

Write-Host "SPRINT-1305-1310 SOURCE CHECK PASSED"

Set-Location $app

$targets = @(
    "src/application/learning/CefrA1ConnectNativeLearningUiModel.test.ts",
    "src/core/learning/CefrA1ConnectNativeLearningUiSafety.test.ts",
    "src/ui/learning/A1ConnectNativeLearningPanel.test.ts",
    "src/application/learning/CefrA1ConnectRuntimeReadModel.test.ts",
    "src/application/learning/CefrA1ConnectRuntimeExperienceContract.test.ts",
    "src/application/learning/CefrA1ConnectRuntimeEvidenceService.test.ts",
    "src/core/learning/CefrA1ConnectRuntimeBindingSafety.test.ts",
    "src/core/learning/CefrGuidanceLearningStudioEntrySafety.test.ts"
)

& npx vitest run $targets
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1305-1310 target tests failed."
}

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Full regression failed."
}

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Production build failed."
}

Write-Host "SPRINT-1305-1310 VERIFICATION COMPLETE"
