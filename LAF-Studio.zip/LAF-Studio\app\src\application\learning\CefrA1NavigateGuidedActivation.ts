import type {
  LafLearningLanguageCode,
} from "../../core/language/LafLanguageProfile";
import {
  getLafA1NavigateLanguageContentPack,
} from "../../core/learning/CefrA1NavigateLanguageContentRegistry";

export interface CefrA1NavigateGuidedActivationStep {
  readonly stepId:
    | "need-or-request"
    | "essential-question"
    | "understand-response"
    | "acknowledge-or-close";
  readonly sequence: 1 | 2 | 3 | 4;
  readonly goal: string;
  readonly exampleTargetText: string;
  readonly exampleMeaning: string;
  readonly rehearsalOnly: true;
}

export interface CefrA1NavigateGuidedActivation {
  readonly activationId:
    "a1-navigate-activation-immediate-everyday-need";
  readonly languageCode:
    LafLearningLanguageCode;
  readonly scenario:
    "familiar-everyday-service-or-public-setting";
  readonly goal:
    "meet-one-immediate-practical-need";
  readonly steps:
    readonly CefrA1NavigateGuidedActivationStep[];
  readonly supportAvailable: true;
  readonly userStartRequired: true;
  readonly rehearsalOnly: true;
  readonly activationEvidenceWritten: false;
  readonly masteryGate: false;
  readonly automaticProgressionAllowed: false;
  readonly delayedRetrievalRequired: false;
}

export function createCefrA1NavigateGuidedActivation(
  languageCode: LafLearningLanguageCode,
): CefrA1NavigateGuidedActivation {
  const pack =
    getLafA1NavigateLanguageContentPack(
      languageCode,
    );

  const needLesson =
    pack.lessons.find(
      lesson =>
        lesson.lessonId ===
        "a1-navigate-express-immediate-need",
    );
  const questionLesson =
    pack.lessons.find(
      lesson =>
        lesson.lessonId ===
        "a1-navigate-ask-essential-information",
    );
  const answerLesson =
    pack.lessons.find(
      lesson =>
        lesson.lessonId ===
        "a1-navigate-understand-practical-answer",
    );
  const exchangeLesson =
    pack.lessons.find(
      lesson =>
        lesson.lessonId ===
        "a1-navigate-complete-need-exchange",
    );

  const need =
    needLesson?.phrases.find(
      phrase =>
        phrase.phraseId === "need-water",
    );
  const question =
    questionLesson?.phrases.find(
      phrase =>
        phrase.phraseId === "ask-location",
    );
  const answer =
    answerLesson?.phrases.find(
      phrase =>
        phrase.phraseId ===
        "answer-location",
    );
  const close =
    exchangeLesson?.phrases.find(
      phrase =>
        phrase.phraseId ===
        "exchange-close",
    );

  if (
    !need ||
    !question ||
    !answer ||
    !close
  ) {
    throw new Error(
      `A1 NAVIGATE guided activation content incomplete: ${languageCode}`,
    );
  }

  return {
    activationId:
      "a1-navigate-activation-immediate-everyday-need",
    languageCode,
    scenario:
      "familiar-everyday-service-or-public-setting",
    goal:
      "meet-one-immediate-practical-need",
    steps: [
      {
        stepId: "need-or-request",
        sequence: 1,
        goal:
          "Bir temel ihtiyacı veya isteği ifade edin.",
        exampleTargetText: need.text,
        exampleMeaning: need.meaning,
        rehearsalOnly: true,
      },
      {
        stepId: "essential-question",
        sequence: 2,
        goal:
          "Bir gerekli pratik bilgiyi sorun.",
        exampleTargetText: question.text,
        exampleMeaning: question.meaning,
        rehearsalOnly: true,
      },
      {
        stepId: "understand-response",
        sequence: 3,
        goal:
          "Kısa ve açık pratik cevabın ana anlamını gösterin.",
        exampleTargetText: answer.text,
        exampleMeaning: answer.meaning,
        rehearsalOnly: true,
      },
      {
        stepId: "acknowledge-or-close",
        sequence: 4,
        goal:
          "Alışverişi uygun bir teşekkür veya kapanışla bitirin.",
        exampleTargetText: close.text,
        exampleMeaning: close.meaning,
        rehearsalOnly: true,
      },
    ],
    supportAvailable: true,
    userStartRequired: true,
    rehearsalOnly: true,
    activationEvidenceWritten: false,
    masteryGate: false,
    automaticProgressionAllowed: false,
    delayedRetrievalRequired: false,
  };
}
