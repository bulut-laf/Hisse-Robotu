$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 816-818 Target Tests: Custodial Contribution ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialContribution.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialContributionCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialContributionAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 816-818 target tests failed." }

Write-Host "=== Sprint 819-821 Target Tests: Custodial Attribution ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialAttribution.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialAttributionCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialAttributionAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 819-821 target tests failed." }

Write-Host "=== Sprint 822-824 Target Tests: Custodial Causality ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialCausality.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialCausalityCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialCausalityAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 822-824 target tests failed." }

Write-Host "=== Combined Sprint 816-824 New Tests ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialContribution.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialContributionCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialContributionAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialAttribution.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialAttributionCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialAttributionAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialCausality.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialCausalityCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialCausalityAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 816-824 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-816-824 VERIFICATION COMPLETE"
