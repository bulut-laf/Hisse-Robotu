﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$panel = Join-Path $app "src\ui\learning\A1ConnectNativeLearningPanel.tsx"

if (-not (Test-Path $panel)) {
    throw "A1ConnectNativeLearningPanel.tsx missing."
}

$utf8 =
    New-Object System.Text.UTF8Encoding($false)

$text =
    [System.IO.File]::ReadAllText(
        $panel,
        $utf8
    )

$declarationPattern =
    'const\s+restoreRememberedSelection\s*=\s*\('

$declarationCount =
    [regex]::Matches(
        $text,
        $declarationPattern
    ).Count

$restoreBlock = @'
  const restoreRememberedSelection = (
    languageCode: LafLearningLanguageCode,
    lessonId: string | null,
  ) => {
    setSelectedLanguageCode(languageCode);

    if (
      lessonId !== null &&
      model.lessonCards.some(
        lesson =>
          lesson.lessonId === lessonId,
      )
    ) {
      setSelectedLessonId(lessonId);
    }
  };

'@

if ($declarationCount -eq 0) {
    $mainReturnPattern =
        '(?m)^  return \(\r?\n    <section\r?\n      className="a1-connect-native"'

    $mainReturnMatches =
        [regex]::Matches(
            $text,
            $mainReturnPattern
        )

    if ($mainReturnMatches.Count -ne 1) {
        throw "Expected exactly one A1 CONNECT component return anchor; found $($mainReturnMatches.Count)."
    }

    $text =
        [regex]::Replace(
            $text,
            $mainReturnPattern,
            {
                param($match)
                return $restoreBlock + $match.Value
            },
            1
        )

    [System.IO.File]::WriteAllText(
        $panel,
        $text,
        $utf8
    )

    $text =
        [System.IO.File]::ReadAllText(
            $panel,
            $utf8
        )

    $declarationCount =
        [regex]::Matches(
            $text,
            $declarationPattern
        ).Count
}

if ($declarationCount -ne 1) {
    throw "Expected one restoreRememberedSelection declaration after repair; found $declarationCount."
}

$identifierCount =
    [regex]::Matches(
        $text,
        '\brestoreRememberedSelection\b'
    ).Count

if ($identifierCount -lt 2) {
    throw "restoreRememberedSelection is declared but callback usage is missing."
}

if (-not $text.Contains(
    'onRestoreSelection={'
)) {
    throw "Explicit restore callback binding missing."
}

if (-not $text.Contains(
    'authoritativeLessonIds={'
)) {
    throw "Authoritative lesson identity boundary missing."
}

$continuity = Join-Path $app "src\ui\learning\A1ConnectContinuityPanel.tsx"
$boundary = Join-Path $app "src\application\learning\CefrA1ConnectSessionRestoreBoundary.ts"
$safety = Join-Path $app "src\core\learning\CefrA1ConnectExplicitRestoreSafety.ts"

foreach ($file in @(
    $continuity,
    $boundary,
    $safety
)) {
    if (-not (Test-Path $file)) {
        throw "Sprint 1371-1376 Rev2 source missing: $file"
    }
}

foreach ($check in @(
    @{
        Path = $continuity
        Marker = 'Kayıtlı Seçimi Yükle'
    },
    @{
        Path = $continuity
        Marker = 'onRestoreSelection('
    },
    @{
        Path = $boundary
        Marker = 'automaticRestorePerformed: false'
    },
    @{
        Path = $boundary
        Marker = 'authoritativeLessonIds.includes('
    },
    @{
        Path = $safety
        Marker = 'automaticRestoreAllowed: false'
    },
    @{
        Path = $safety
        Marker = 'restoreCreatesEvidence: false'
    }
)) {
    if (-not (
        Select-String `
            -Path $check.Path `
            -SimpleMatch `
            -Pattern $check.Marker `
            -Quiet
    )) {
        throw "Sprint 1371-1376 Rev2 marker missing: $($check.Marker)"
    }
}

Write-Host "SPRINT-1371-1376 REV2 SOURCE CHECK PASSED"

Set-Location $app

$targets = @(
    "src/core/learning/CefrA1ConnectSessionRestoreRequest.test.ts",
    "src/application/learning/CefrA1ConnectSessionRestoreBoundary.test.ts",
    "src/core/learning/CefrA1ConnectExplicitRestoreSafety.test.ts",
    "src/ui/learning/A1ConnectContinuityPanel.restore.test.ts",
    "src/core/learning/CefrA1ConnectSessionState.test.ts",
    "src/application/learning/CefrA1ConnectSessionStateRepository.test.ts",
    "src/core/learning/CefrA1ConnectContinuitySafety.test.ts",
    "src/application/learning/CefrA1ConnectLanguageScopedAdvisoryReadModel.test.ts"
)

& npx vitest run $targets
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1371-1376 Rev2 target tests failed."
}

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Full regression failed."
}

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Production build failed."
}

Write-Host "SPRINT-1371-1376 REV2 VERIFICATION COMPLETE"
