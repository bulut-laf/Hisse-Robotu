$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 735-737 Target Tests: Custodial Integrity ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialIntegrity.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialIntegrityCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialIntegrityAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 735-737 target tests failed." }

Write-Host "=== Sprint 738-740 Target Tests: Custodial Traceability ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialTraceability.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialTraceabilityCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialTraceabilityAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 738-740 target tests failed." }

Write-Host "=== Sprint 741-743 Target Tests: Custodial Accountability ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialAccountability.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialAccountabilityCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialAccountabilityAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 741-743 target tests failed." }

Write-Host "=== Combined Sprint 735-743 New Tests ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialIntegrity.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialIntegrityCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialIntegrityAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialTraceability.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialTraceabilityCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialTraceabilityAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialAccountability.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialAccountabilityCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialAccountabilityAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 735-743 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-735-743 VERIFICATION COMPLETE"
