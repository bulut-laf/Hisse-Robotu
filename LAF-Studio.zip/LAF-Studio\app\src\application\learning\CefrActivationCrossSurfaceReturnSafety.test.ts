import { describe, expect, it } from "vitest";
import { createCefrGuidanceSessionActivationGate } from "../../core/learning/CefrGuidanceSessionActivationGate";
import { LAF_A1_NAVIGATE_REAL_LIFE_ACTIVATION } from "../../core/learning/CefrA1NavigateActivationDefinition";
import { captureA1NavigateActivationLearningPathReturnContext } from "./CefrActivationLearningPathReturnContextAdapter";
import { isCefrActivationReturnContextSafeForGuidanceSurface } from "./CefrActivationCrossSurfaceReturnSafety";

describe("CefrActivation cross-surface return safety", () => {
  const context=captureA1NavigateActivationLearningPathReturnContext({sourceRoutePath:"/learning",sourceUnitId:LAF_A1_NAVIGATE_REAL_LIFE_ACTIVATION.unitId,activationId:LAF_A1_NAVIGATE_REAL_LIFE_ACTIVATION.activationId});

  it.each(["reading-studio","listening-studio","writing-studio","speaking-pronunciation-studio","dialogue-role-play-studio","grammar-lab"] as const)("keeps %s explicit and non-mastering", targetStudio => {
    expect(context).not.toBeNull();
    if(!context) throw new Error("Expected authoritative return context.");
    const gate=createCefrGuidanceSessionActivationGate({confirmation:{entryConfirmed:true} as never,targetStudio,capabilityReference:"existing-authoritative-capability",userInitiated:true,activationRequested:true,automaticSessionStartAllowed:false});
    expect(isCefrActivationReturnContextSafeForGuidanceSurface(context,gate)).toBe(true);
    expect(gate).toMatchObject({explicitUserActionRequired:true,sessionStartedByCore:false,masteryMutationAllowed:false,cefrLevelMutationAllowed:false,progressionMutationAllowed:false});
  });
});
