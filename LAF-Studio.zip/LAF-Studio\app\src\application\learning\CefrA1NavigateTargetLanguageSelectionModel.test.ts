import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrA1NavigateTargetLanguageSelectionModel,
} from "./CefrA1NavigateTargetLanguageSelectionModel";

describe(
  "A1 NAVIGATE target-language selection model",
  () => {
    it("does not fabricate a default target language", () => {
      const result =
        createCefrA1NavigateTargetLanguageSelectionModel(
          null,
        );

      expect(result).toMatchObject({
        selectedLanguageCode: null,
        selectionRequired: true,
        selectedByUser: false,
        realization: null,
        languageContentBound: false,
        executableTaskAvailable: false,
        evidenceCaptureAvailable: false,
        delayedRetrievalRuntimeAvailable:
          false,
        targetLanguageInferred: false,
      });

      expect(result.options).toHaveLength(7);
    });

    it("opens all six immediate tasks only after explicit target-language selection", () => {
      const result =
        createCefrA1NavigateTargetLanguageSelectionModel(
          "hu",
        );

      expect(result).toMatchObject({
        selectedLanguageCode: "hu",
        selectionRequired: false,
        selectedByUser: true,
        languageContentBound: true,
        executableTaskAvailable: true,
        evidenceCaptureAvailable: true,
        delayedRetrievalRuntimeAvailable:
          false,
        targetLanguageInferred: false,
      });

      expect(result.realization).toMatchObject({
        unitId:
          "a1-navigate-immediate-everyday-needs",
        languageCode: "hu",
        executableTaskCount: 6,
        immediateEvidenceCount: 6,
        authoritativeEvidenceIdentityCount:
          7,
        evidenceCaptureRequiresCorrectUserAction:
          true,
        status:
          "immediate-executable-evidence-set-v1",
      });
    });
  },
);
