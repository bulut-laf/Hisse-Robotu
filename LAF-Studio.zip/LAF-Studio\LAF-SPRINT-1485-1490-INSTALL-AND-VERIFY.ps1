﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

$required = @(
    "src\application\learning\CefrA1NavigatePersistedEvidenceView.ts",
    "src\application\learning\CefrA1NavigatePersistedEvidenceView.test.ts",
    "src\core\learning\CefrA1NavigatePersistedEvidenceSafety.ts",
    "src\core\learning\CefrA1NavigatePersistedEvidenceSafety.test.ts",
    "src\ui\learning\A1NavigatePersistedEvidencePanel.tsx",
    "src\ui\learning\A1NavigatePersistedEvidencePanel.css",
    "src\ui\learning\A1NavigateNativeLearningPanel.tsx",
    "src\ui\learning\A1NavigateNativeLearningPanel.css"
)

foreach ($relative in $required) {
    if (-not (Test-Path (Join-Path $app $relative))) {
        throw "Sprint 1485-1490 required file missing: $relative"
    }
}

$positiveChecks = @(
    @(
      "src\application\learning\CefrA1NavigatePersistedEvidenceView.ts",
      'platform.readLanguageEvidence('
    ),
    @(
      "src\application\learning\CefrA1NavigatePersistedEvidenceView.ts",
      '"a1-navigate"'
    ),
    @(
      "src\application\learning\CefrA1NavigatePersistedEvidenceView.ts",
      'immediateEvidenceCount: 6'
    ),
    @(
      "src\application\learning\CefrA1NavigatePersistedEvidenceView.ts",
      'delayedRetrievalIncluded: false'
    ),
    @(
      "src\ui\learning\A1NavigatePersistedEvidencePanel.tsx",
      'KALICI DİL-KAPSAMLI EVIDENCE'
    ),
    @(
      "src\ui\learning\A1NavigatePersistedEvidencePanel.tsx",
      'PERSISTED ADVISORY NEXT STEP'
    ),
    @(
      "src\ui\learning\A1NavigateNativeLearningPanel.tsx",
      'persistedEvidenceRefreshToken'
    ),
    @(
      "src\ui\learning\A1NavigateNativeLearningPanel.tsx",
      '<A1NavigatePersistedEvidencePanel'
    ),
    @(
      "src\ui\learning\A1NavigateNativeLearningPanel.tsx",
      'activation.languageCode'
    )
)

foreach ($check in $positiveChecks) {
    $path = Join-Path $app $check[0]

    if (-not (
        Select-String `
            -Path $path `
            -SimpleMatch `
            -Pattern $check[1] `
            -Quiet
    )) {
        throw "Sprint 1485-1490 source marker missing: $($check[1])"
    }
}

$viewPath =
    Join-Path $app "src\application\learning\CefrA1NavigatePersistedEvidenceView.ts"
$viewText =
    [System.IO.File]::ReadAllText($viewPath)

if ($viewText.Contains(
    '"a1-navigate-evidence-delayed-retrieval"'
)) {
    throw "Delayed retrieval leaked into persisted immediate evidence view."
}

Write-Host "SPRINT-1485-1490 SOURCE CHECK PASSED"

Set-Location $app

Write-Host ""
Write-Host "CHECKPOINT 1/2 — Sprint 1485-1487 persisted language-scoped coverage"

& npx vitest run @(
    "src/application/learning/CefrA1NavigatePersistedEvidenceView.test.ts",
    "src/core/learning/CefrA1NavigatePersistedEvidenceSafety.test.ts",
    "src/application/learning/CefrA1NavigateExecutableTaskService.test.ts",
    "src/application/learning/CefrA1NavigateSecondWaveExecutableTaskService.test.ts",
    "src/core/learning/CefrA1NavigateExecutableTaskCatalog.test.ts"
)

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1485-1487 target checkpoint failed."
}

Write-Host "SPRINT-1485-1487 TARGET CHECKPOINT PASSED"

Write-Host ""
Write-Host "CHECKPOINT 2/2 — Sprint 1488-1490 native persisted advisory + runtime safety"

& npx vitest run @(
    "src/application/learning/CefrA1NavigateGuidedActivation.test.ts",
    "src/core/learning/CefrA1NavigateSessionActivationSafety.test.ts",
    "src/core/learning/CefrA1NavigateRuntimeSliceDefinition.test.ts",
    "src/application/learning/CefrA1NavigateProductionRuntime.test.ts",
    "src/core/learning/CefrProductionRuntimeRegistryEnforcement.test.ts",
    "src/application/learning/CefrProductionRuntimeDelayedRetrievalVisibility.test.ts"
)

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1488-1490 target checkpoint failed."
}

Write-Host "SPRINT-1488-1490 TARGET CHECKPOINT PASSED"

Write-Host ""
Write-Host "FINAL 6-SPRINT BLOCK REGRESSION — one full run only"

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1485-1490 final full regression failed."
}

Write-Host ""
Write-Host "FINAL PRODUCTION BUILD"

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1485-1490 production build failed."
}

Write-Host ""
Write-Host "SPRINT-1485-1490 VERIFICATION COMPLETE"
