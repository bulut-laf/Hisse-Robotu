﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$panelPath =
    Join-Path $app "src\ui\learning\A1NavigateNativeLearningPanel.tsx"

$utf8 =
    New-Object System.Text.UTF8Encoding($false)

if (-not (Test-Path $panelPath)) {
    throw "A1NavigateNativeLearningPanel.tsx bulunamadı."
}

$text =
    [System.IO.File]::ReadAllText(
        $panelPath,
        $utf8
    )

# Compile-only narrowing repair:
# Inside activation.steps.map(), activation is non-null and
# already carries the exact LafLearningLanguageCode.
$pattern =
    '(?ms)(activation\.steps\.map\(step\s*=>\s*\{.*?<p\s+lang=\{\s*getLafLanguageProfile\(\s*)languageCode(\s*,\s*\)\.htmlLanguage)'

$matches =
    [regex]::Matches(
        $text,
        $pattern
    )

if ($matches.Count -ne 1) {
    throw "Expected exactly one activation language narrowing seam; found $($matches.Count)."
}

$updated =
    [regex]::Replace(
        $text,
        $pattern,
        '${1}activation.languageCode${2}',
        1
    )

if ($updated -eq $text) {
    throw "Activation language narrowing repair was not applied."
}

if (-not $updated.Contains(
    "activation.languageCode"
)) {
    throw "activation.languageCode marker missing after repair."
}

# Preserve the ordinary explicitly guarded languageCode use elsewhere.
if (-not $updated.Contains(
    "getLafLanguageProfile(" 
)) {
    throw "Language profile integration unexpectedly missing."
}

[System.IO.File]::WriteAllText(
    $panelPath,
    $updated,
    $utf8
)

Write-Host "SPRINT-1479-1484 REV1 SOURCE CHECK PASSED"

Set-Location $app

Write-Host ""
Write-Host "FOCUSED TARGET VERIFICATION — prior full regression already passed"

& npx vitest run @(
    "src/application/learning/CefrA1NavigateGuidedActivation.test.ts",
    "src/core/learning/CefrA1NavigateSessionActivationSafety.test.ts",
    "src/application/learning/CefrA1NavigateSessionAdvisory.test.ts",
    "src/ui/learning/LocalStorageA1NavigateSessionStorage.test.ts"
)

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1479-1484 Rev1 focused target verification failed."
}

Write-Host "SPRINT-1479-1484 REV1 TARGET CHECK PASSED"

Write-Host ""
Write-Host "PRODUCTION BUILD — no duplicate full regression"

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1479-1484 Rev1 production build failed."
}

Write-Host ""
Write-Host "SPRINT-1479-1484 REV1 VERIFICATION COMPLETE"
