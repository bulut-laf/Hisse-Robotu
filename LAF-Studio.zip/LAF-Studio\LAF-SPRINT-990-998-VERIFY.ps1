$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 990-992 Target Tests: Studio Launch Handoff ==="
npx vitest run `
  "src/core/learning/CefrStudioLaunchDestination.test.ts" `
  "src/core/learning/CefrStudioLaunchPayload.test.ts" `
  "src/core/learning/CefrStudioLaunchHandoffGateway.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 990-992 target tests failed." }

Write-Host "=== Sprint 993-995 Target Tests: Guided Session Activation ==="
npx vitest run `
  "src/core/learning/CefrGuidedSessionActivationRequest.test.ts" `
  "src/core/learning/CefrGuidedSessionActivationBoundary.test.ts" `
  "src/core/learning/CefrUserInitiatedGuidedSession.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 993-995 target tests failed." }

Write-Host "=== Sprint 996-998 Target Tests: Post-Launch Evidence Return ==="
npx vitest run `
  "src/core/learning/CefrGuidedSessionOutcomeReference.test.ts" `
  "src/core/learning/CefrGuidedSessionEvidenceReturn.test.ts" `
  "src/core/learning/CefrGuidanceEvidenceFeedbackLoop.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 996-998 target tests failed." }

Write-Host "=== Combined Sprint 990-998 New Tests ==="
npx vitest run `
  "src/core/learning/CefrStudioLaunchDestination.test.ts" `
  "src/core/learning/CefrStudioLaunchPayload.test.ts" `
  "src/core/learning/CefrStudioLaunchHandoffGateway.test.ts" `
  "src/core/learning/CefrGuidedSessionActivationRequest.test.ts" `
  "src/core/learning/CefrGuidedSessionActivationBoundary.test.ts" `
  "src/core/learning/CefrUserInitiatedGuidedSession.test.ts" `
  "src/core/learning/CefrGuidedSessionOutcomeReference.test.ts" `
  "src/core/learning/CefrGuidedSessionEvidenceReturn.test.ts" `
  "src/core/learning/CefrGuidanceEvidenceFeedbackLoop.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 990-998 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-990-998 VERIFICATION COMPLETE"
