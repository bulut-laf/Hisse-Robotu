import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrA1NavigateSessionState,
} from "./CefrA1NavigateSessionState";

describe(
  "A1 NAVIGATE session state",
  () => {
    it("stores only the explicit current-session task state without claiming mastery", () => {
      expect(
        createCefrA1NavigateSessionState({
          languageCode: "hu",
          selectedTaskId:
            "a1-navigate-task-practical-reading",
          completedTaskIds: [
            "a1-navigate-task-need-comprehension",
            "a1-navigate-task-practical-reading",
            "a1-navigate-task-practical-reading",
          ],
          exchangeSelections: [],
          updatedAt:
            new Date(
              "2026-08-12T12:00:00.000Z",
            ),
        }),
      ).toEqual({
        languageCode: "hu",
        selectedTaskId:
          "a1-navigate-task-practical-reading",
        completedTaskIds: [
          "a1-navigate-task-need-comprehension",
          "a1-navigate-task-practical-reading",
        ],
        exchangeSelections: [],
        updatedAt:
          "2026-08-12T12:00:00.000Z",
        evidenceCoverageScope:
          "current-explicit-session",
        masteryClaimed: false,
        cefrLevelClaimed: false,
      });
    });

    it("fails closed for an unknown task identity", () => {
      expect(() =>
        createCefrA1NavigateSessionState({
          languageCode: "en",
          selectedTaskId:
            "a1-navigate-task-delayed-retrieval" as
              "a1-navigate-task-need-comprehension",
          completedTaskIds: [],
          exchangeSelections: [],
          updatedAt: new Date(),
        }),
      ).toThrow(
        "Unknown A1 NAVIGATE session task",
      );
    });
  },
);
