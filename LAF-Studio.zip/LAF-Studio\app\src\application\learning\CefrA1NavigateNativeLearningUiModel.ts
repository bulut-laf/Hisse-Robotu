import {
  LAF_LEARNING_LANGUAGE_CODES,
  getLafLanguageProfile,
  type LafLearningLanguageCode,
} from "../../core/language/LafLanguageProfile";
import {
  LAF_A1_NAVIGATE_ALL_EXECUTABLE_TASKS,
  type CefrA1NavigateAllExecutableTaskId,
} from "../../core/learning/CefrA1NavigateExecutableTaskCatalog";

export interface CefrA1NavigateNativeLanguageOption {
  readonly code: LafLearningLanguageCode;
  readonly label: string;
  readonly nativeLabel: string;
}

export interface CefrA1NavigateNativeTaskCard {
  readonly taskId:
    CefrA1NavigateAllExecutableTaskId;
  readonly lessonId: string;
  readonly evidenceDefinitionId: string;
  readonly sequence: number;
  readonly wave: 1 | 2;
}

export interface CefrA1NavigateNativeLearningUiModel {
  readonly eyebrow: "A1 · RESPOND · NAVIGATE";
  readonly title: "Immediate Everyday Needs";
  readonly competencyLabel:
    "navigate-a1 · Meet Basic Immediate Needs";
  readonly unitId:
    "a1-navigate-immediate-everyday-needs";
  readonly route: "/learning";
  readonly languageOptions:
    readonly CefrA1NavigateNativeLanguageOption[];
  readonly taskCards:
    readonly CefrA1NavigateNativeTaskCard[];
  readonly immediateEvidenceCount: 6;
  readonly authoritativeEvidenceIdentityCount:
    7;
  readonly explicitTargetLanguageRequired: true;
  readonly correctUserActionRequiredForEvidence:
    true;
  readonly delayedRetrievalRuntimeAvailable:
    false;
  readonly masteryAssignmentAllowed: false;
  readonly cefrLevelAssignmentAllowed: false;
  readonly automaticProgressionAllowed: false;
  readonly automaticTransactionCompletionAllowed:
    false;
}

export function createCefrA1NavigateNativeLearningUiModel():
  CefrA1NavigateNativeLearningUiModel {
  return {
    eyebrow: "A1 · RESPOND · NAVIGATE",
    title: "Immediate Everyday Needs",
    competencyLabel:
      "navigate-a1 · Meet Basic Immediate Needs",
    unitId:
      "a1-navigate-immediate-everyday-needs",
    route: "/learning",
    languageOptions:
      LAF_LEARNING_LANGUAGE_CODES.map(
        code => {
          const profile =
            getLafLanguageProfile(code);

          return {
            code,
            label: profile.label,
            nativeLabel: profile.nativeLabel,
          };
        },
      ),
    taskCards:
      LAF_A1_NAVIGATE_ALL_EXECUTABLE_TASKS.map(
        task => ({
          taskId: task.taskId,
          lessonId: task.lessonId,
          evidenceDefinitionId:
            task.evidenceDefinitionId,
          sequence: task.sequence,
          wave: task.wave,
        }),
      ),
    immediateEvidenceCount: 6,
    authoritativeEvidenceIdentityCount: 7,
    explicitTargetLanguageRequired: true,
    correctUserActionRequiredForEvidence:
      true,
    delayedRetrievalRuntimeAvailable:
      false,
    masteryAssignmentAllowed: false,
    cefrLevelAssignmentAllowed: false,
    automaticProgressionAllowed: false,
    automaticTransactionCompletionAllowed:
      false,
  };
}
