﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$out = Join-Path $root "LAF_UI_BINDING_SNAPSHOT.txt"

$paths = @(
  "app\src\ui\pages\LearningStudioPage.tsx",
  "app\src\ui\learning\LearningFocusHero.tsx",
  "app\src\ui\learning\CefrLearningJourneyPanel.tsx",
  "app\src\ui\learning\LearningStudioDock.tsx",
  "app\src\shared\components\Navigation.tsx"
)

$lines = New-Object System.Collections.Generic.List[string]

foreach ($relative in $paths) {
  $path = Join-Path $root $relative

  [void]$lines.Add("")
  [void]$lines.Add(("=" * 88))
  [void]$lines.Add(("FILE: " + $relative))
  [void]$lines.Add(("=" * 88))

  if (-not (Test-Path $path)) {
    [void]$lines.Add("(missing)")
    continue
  }

  $content = @(Get-Content -Path $path)
  for ($i = 0; $i -lt $content.Count; $i++) {
    [void]$lines.Add(("{0,4}: {1}" -f ($i + 1), $content[$i]))
  }
}

$lines | Set-Content -Path $out -Encoding UTF8
Write-Host ("UI binding snapshot: " + $out)
