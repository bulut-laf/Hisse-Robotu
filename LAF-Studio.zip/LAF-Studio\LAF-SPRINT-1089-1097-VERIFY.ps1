$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 1089-1091 Target Tests: Next-Day Plan Routing ==="
npx vitest run `
  "src/core/learning/CefrNextDayGuidanceRouteAssignment.test.ts" `
  "src/core/learning/CefrNextDayGuidanceRouteRegistry.test.ts" `
  "src/core/learning/CefrNextDayGuidanceRoutingOrchestration.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1089-1091 target tests failed." }

Write-Host "=== Sprint 1092-1094 Target Tests: User-Initiated Next-Day Launch ==="
npx vitest run `
  "src/core/learning/CefrNextDayGuidanceLaunchRequest.test.ts" `
  "src/core/learning/CefrNextDayGuidanceLaunchGate.test.ts" `
  "src/core/learning/CefrUserInitiatedNextDayGuidanceLaunch.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1092-1094 target tests failed." }

Write-Host "=== Sprint 1095-1097 Target Tests: Continuity Completion Record ==="
npx vitest run `
  "src/core/learning/CefrNextDayGuidanceOutcome.test.ts" `
  "src/core/learning/CefrNextDayGuidanceCompletionRecord.test.ts" `
  "src/core/learning/CefrNextDayGuidanceContinuityCycle.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1095-1097 target tests failed." }

Write-Host "=== Combined Sprint 1089-1097 New Tests ==="
npx vitest run `
  "src/core/learning/CefrNextDayGuidanceRouteAssignment.test.ts" `
  "src/core/learning/CefrNextDayGuidanceRouteRegistry.test.ts" `
  "src/core/learning/CefrNextDayGuidanceRoutingOrchestration.test.ts" `
  "src/core/learning/CefrNextDayGuidanceLaunchRequest.test.ts" `
  "src/core/learning/CefrNextDayGuidanceLaunchGate.test.ts" `
  "src/core/learning/CefrUserInitiatedNextDayGuidanceLaunch.test.ts" `
  "src/core/learning/CefrNextDayGuidanceOutcome.test.ts" `
  "src/core/learning/CefrNextDayGuidanceCompletionRecord.test.ts" `
  "src/core/learning/CefrNextDayGuidanceContinuityCycle.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1089-1097 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-1089-1097 VERIFICATION COMPLETE"
