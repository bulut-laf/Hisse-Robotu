$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 771-773 Target Tests: Custodial Substantiation ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialSubstantiation.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialSubstantiationCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialSubstantiationAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 771-773 target tests failed." }

Write-Host "=== Sprint 774-776 Target Tests: Custodial Justification ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialJustification.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialJustificationCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialJustificationAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 774-776 target tests failed." }

Write-Host "=== Sprint 777-779 Target Tests: Custodial Admissibility ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialAdmissibility.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialAdmissibilityCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialAdmissibilityAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 777-779 target tests failed." }

Write-Host "=== Combined Sprint 771-779 New Tests ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialSubstantiation.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialSubstantiationCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialSubstantiationAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialJustification.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialJustificationCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialJustificationAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialAdmissibility.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialAdmissibilityCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialAdmissibilityAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 771-779 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-771-779 VERIFICATION COMPLETE"
