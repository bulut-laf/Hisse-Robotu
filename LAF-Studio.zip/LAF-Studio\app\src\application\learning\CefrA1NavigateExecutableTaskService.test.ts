import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrPersonalLanguageProfileState,
  type CefrPersonalLanguageProfileState,
} from "../../core/learning/CefrPersonalLanguageProfileState";
import type {
  CefrLanguageEvidenceStorageLike,
} from "./CefrAuthoritativeLanguageEvidenceProvenanceRepository";
import type {
  CefrGuidanceRuntimeProfileRepository,
} from "./CefrGuidanceRuntimeProfileRepository";
import {
  CefrProductionRuntimePlatform,
} from "./CefrProductionRuntimePlatform";
import {
  CefrA1NavigateExecutableTaskService,
} from "./CefrA1NavigateExecutableTaskService";

class MemoryProfileRepository
  implements CefrGuidanceRuntimeProfileRepository {
  private state:
    CefrPersonalLanguageProfileState =
      createCefrPersonalLanguageProfileState(
        [],
        [],
      );

  load(): CefrPersonalLanguageProfileState {
    return this.state;
  }

  save(
    state: CefrPersonalLanguageProfileState,
  ): void {
    this.state = state;
  }

  hasPersistedProfile(): boolean {
    return false;
  }

  clear(): void {}
}

class MemoryStorage
  implements CefrLanguageEvidenceStorageLike {
  private readonly items =
    new Map<string, string>();

  getItem(key: string): string | null {
    return this.items.get(key) ?? null;
  }

  setItem(
    key: string,
    value: string,
  ): void {
    this.items.set(key, value);
  }

  removeItem(key: string): void {
    this.items.delete(key);
  }
}

function createService(
  repository:
    MemoryProfileRepository =
      new MemoryProfileRepository(),
) {
  return {
    repository,
    service:
      new CefrA1NavigateExecutableTaskService(
        new CefrProductionRuntimePlatform(
          repository,
          new MemoryStorage(),
        ),
      ),
  };
}

describe(
  "A1 NAVIGATE executable task service",
  () => {
    it("builds the same controlled task from selected target-language content without exposing the answer", () => {
      const { service } = createService();

      const hu =
        service.getTaskView(
          "a1-navigate-task-need-comprehension",
          "hu",
        );

      const de =
        service.getTaskView(
          "a1-navigate-task-need-comprehension",
          "de",
        );

      expect(hu).toMatchObject({
        languageCode: "hu",
        taskKind: "controlled-selection",
        evidenceDefinitionId:
          "a1-navigate-evidence-need-comprehension",
        correctAnswerExposed: false,
        evidenceWritten: false,
        targetLanguageExplicit: true,
        targetLanguageInferred: false,
      });

      expect(
        hu.options.map(
          option => option.text,
        ),
      ).toContain(
        "Szeretnék egy vizet.",
      );

      expect(
        de.options.map(
          option => option.text,
        ),
      ).toContain(
        "Ich möchte ein Wasser.",
      );
    });

    it("writes real language-scoped evidence only after the correct explicit user action", () => {
      const {
        repository,
        service,
      } = createService();

      const result =
        service.executeSelection({
          taskId:
            "a1-navigate-task-need-expression",
          languageCode: "hu",
          selectedPhraseId:
            "request-this",
          eventId:
            "navigate-task-001",
          occurredAt:
            new Date(
              "2026-08-12T10:00:00.000Z",
            ),
          userActionConfirmed: true,
        });

      expect(result).toMatchObject({
        evidenceDefinitionId:
          "a1-navigate-evidence-need-expression",
        languageCode: "hu",
        selectionRecognized: true,
        correct: true,
        evidenceWritten: true,
        targetLanguageExplicit: true,
        targetLanguageInferred: false,
        masteryAssigned: false,
        competencySuccessAssigned: false,
        cefrLevelAssigned: false,
        progressionPerformed: false,
      });

      expect(result.runtime).toMatchObject({
        evidenceId:
          "a1-navigate-runtime-evidence:a1-navigate-evidence-need-expression:navigate-task-001",
        languageCode: "hu",
        evidencePersisted: true,
        targetLanguageExplicit: true,
        targetLanguageInferred: false,
      });

      expect(
        result.runtime?.runtime
          .resolvedCapabilityReferences,
      ).toEqual([
        "needs-expression",
      ]);

      expect(
        repository.load()
          .capabilityObservationRegistry
          .observations,
      ).toEqual([
        {
          capabilityReference:
            "needs-expression",
          evidenceId:
            "a1-navigate-runtime-evidence:a1-navigate-evidence-need-expression:navigate-task-001",
          source: "learning-studio",
          observationalOnly: true,
        },
      ]);
    });

    it("does not write evidence after an incorrect controlled selection", () => {
      const {
        repository,
        service,
      } = createService();

      const result =
        service.executeSelection({
          taskId:
            "a1-navigate-task-need-comprehension",
          languageCode: "en",
          selectedPhraseId:
            "need-help",
          eventId:
            "navigate-task-wrong-001",
          occurredAt:
            new Date(
              "2026-08-12T10:05:00.000Z",
            ),
          userActionConfirmed: true,
        });

      expect(result).toMatchObject({
        correct: false,
        evidenceWritten: false,
        runtime: null,
        masteryAssigned: false,
        cefrLevelAssigned: false,
        progressionPerformed: false,
      });

      expect(
        repository.load()
          .profileSnapshot
          .evidenceAggregation
          .evidence,
      ).toHaveLength(0);
    });

    it("refuses execution without explicit user action confirmation", () => {
      const { service } = createService();

      expect(() =>
        service.executeSelection({
          taskId:
            "a1-navigate-task-information-question",
          languageCode: "it",
          selectedPhraseId:
            "ask-location",
          eventId:
            "navigate-task-no-confirm-001",
          occurredAt:
            new Date(
              "2026-08-12T10:10:00.000Z",
            ),
          userActionConfirmed: false,
        }),
      ).toThrow(
        "Explicit user action confirmation is required",
      );
    });

    it("has no delayed-retrieval executable task path", () => {
      const { service } = createService();

      expect(() =>
        service.getTaskView(
          "a1-navigate-task-delayed-retrieval" as
            "a1-navigate-task-need-comprehension",
          "hu",
        ),
      ).toThrow(
        "Unknown executable A1 NAVIGATE task",
      );
    });
  },
);
