$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 780-782 Target Tests: Custodial Materiality ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialMateriality.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialMaterialityCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialMaterialityAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 780-782 target tests failed." }

Write-Host "=== Sprint 783-785 Target Tests: Custodial Weight ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialWeight.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialWeightCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialWeightAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 783-785 target tests failed." }

Write-Host "=== Sprint 786-788 Target Tests: Custodial Priority ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialPriority.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialPriorityCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialPriorityAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 786-788 target tests failed." }

Write-Host "=== Combined Sprint 780-788 New Tests ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialMateriality.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialMaterialityCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialMaterialityAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialWeight.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialWeightCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialWeightAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialPriority.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialPriorityCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialPriorityAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 780-788 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-780-788 VERIFICATION COMPLETE"
