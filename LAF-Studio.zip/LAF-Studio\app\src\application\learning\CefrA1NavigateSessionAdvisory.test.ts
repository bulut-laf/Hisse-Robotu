import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrA1NavigateSessionAdvisory,
} from "./CefrA1NavigateSessionAdvisory";

describe(
  "A1 NAVIGATE current-session advisory",
  () => {
    it("suggests the first missing immediate task but requires explicit user apply", () => {
      expect(
        createCefrA1NavigateSessionAdvisory([
          "a1-navigate-task-need-comprehension",
          "a1-navigate-task-need-expression",
        ]),
      ).toMatchObject({
        status: "next-immediate-task",
        observedInCurrentSessionCount: 2,
        nextTaskId:
          "a1-navigate-task-information-question",
        guidedActivationAvailable: false,
        userApplyRequired: true,
        delayedRetrievalRecommended: false,
        delayedRetrievalExecutable: false,
        automaticProgressionPerformed:
          false,
      });
    });

    it("offers guided activation after all six immediate tasks without recommending delayed retrieval", () => {
      const result =
        createCefrA1NavigateSessionAdvisory([
          "a1-navigate-task-need-comprehension",
          "a1-navigate-task-need-expression",
          "a1-navigate-task-information-question",
          "a1-navigate-task-practical-answer",
          "a1-navigate-task-practical-reading",
          "a1-navigate-task-reciprocal-exchange",
        ]);

      expect(result).toMatchObject({
        status:
          "guided-activation-available",
        observedInCurrentSessionCount: 6,
        nextTaskId: null,
        guidedActivationAvailable: true,
        userApplyRequired: true,
        delayedRetrievalRecommended: false,
        delayedRetrievalExecutable: false,
        masteryClaimed: false,
        cefrLevelClaimed: false,
        automaticProgressionPerformed:
          false,
      });
    });
  },
);
