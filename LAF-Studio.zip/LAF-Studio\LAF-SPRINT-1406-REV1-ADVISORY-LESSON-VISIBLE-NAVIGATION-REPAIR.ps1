﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$panel = Join-Path $app "src\ui\learning\A1ConnectNativeLearningPanel.tsx"
$css = Join-Path $app "src\ui\learning\A1ConnectNativeLearningPanel.css"

if (-not (Test-Path $panel)) {
    throw "A1ConnectNativeLearningPanel.tsx missing."
}

if (-not (Test-Path $css)) {
    throw "A1ConnectNativeLearningPanel.css missing."
}

$utf8 = New-Object System.Text.UTF8Encoding($false)

$text = [System.IO.File]::ReadAllText(
    $panel,
    $utf8
)

$old = @'
  const applyAdvisoryLesson = (
    lessonId: string,
  ) => {
    if (
      model.lessonCards.some(
        lesson =>
          lesson.lessonId === lessonId,
      )
    ) {
      setSelectedLessonId(lessonId);
    }
  };
'@

$new = @'
  const scrollToSelectedLessonWorkspace = () => {
    window.requestAnimationFrame(() => {
      window.requestAnimationFrame(() => {
        document
          .querySelector<HTMLElement>(
            ".a1-connect-native-detail",
          )
          ?.scrollIntoView({
            behavior: "smooth",
            block: "start",
          });
      });
    });
  };

  const applyAdvisoryLesson = (
    lessonId: string,
  ) => {
    if (
      model.lessonCards.some(
        lesson =>
          lesson.lessonId === lessonId,
      )
    ) {
      setSelectedLessonId(lessonId);
      scrollToSelectedLessonWorkspace();
    }
  };
'@

if (-not $text.Contains(
    'scrollToSelectedLessonWorkspace'
)) {
    if (-not $text.Contains($old)) {
        throw "Advisory lesson apply function anchor not found."
    }

    $text = $text.Replace(
        $old,
        $new
    )
}

[System.IO.File]::WriteAllText(
    $panel,
    $text,
    $utf8
)

$cssText = [System.IO.File]::ReadAllText(
    $css,
    $utf8
)

if (-not $cssText.Contains(
    ".a1-connect-native-detail {"
)) {
    throw "A1 CONNECT detail CSS anchor missing."
}

if (-not $cssText.Contains(
    "scroll-margin-top: 24px;"
)) {
    $cssText = $cssText.Replace(
        ".a1-connect-native-detail {",
        ".a1-connect-native-detail {" +
        [Environment]::NewLine +
        "  scroll-margin-top: 24px;"
    )
}

[System.IO.File]::WriteAllText(
    $css,
    $cssText,
    $utf8
)

$text = [System.IO.File]::ReadAllText(
    $panel,
    $utf8
)

$checks = @(
    'const scrollToSelectedLessonWorkspace = () =>',
    'window.requestAnimationFrame(() =>',
    '.querySelector<HTMLElement>(',
    '".a1-connect-native-detail"',
    '?.scrollIntoView({',
    'behavior: "smooth"',
    'setSelectedLessonId(lessonId);',
    'scrollToSelectedLessonWorkspace();',
    'onApplyAdvisoryLesson={'
)

foreach ($marker in $checks) {
    if (-not (
        Select-String `
            -Path $panel `
            -SimpleMatch `
            -Pattern $marker `
            -Quiet
    )) {
        throw "Sprint 1406 Rev1 source marker missing: $marker"
    }
}

if (-not (
    Select-String `
        -Path $css `
        -SimpleMatch `
        -Pattern 'scroll-margin-top: 24px;' `
        -Quiet
)) {
    throw "Sprint 1406 Rev1 scroll margin marker missing."
}

Write-Host "SPRINT-1406 REV1 SOURCE CHECK PASSED"

Set-Location $app

$targets = @(
    "src/core/learning/CefrA1ConnectAdvisoryLessonApplyRequest.test.ts",
    "src/application/learning/CefrA1ConnectAdvisoryLessonApplyBoundary.test.ts",
    "src/core/learning/CefrA1ConnectAdvisoryApplySafety.test.ts",
    "src/ui/learning/A1ConnectContinuityPanel.advisory.test.ts",
    "src/core/learning/CefrA1ConnectSessionRestoreRequest.test.ts",
    "src/application/learning/CefrA1ConnectSessionRestoreBoundary.test.ts",
    "src/core/learning/CefrA1ConnectLessonEvidenceState.test.ts",
    "src/application/learning/CefrA1ConnectLessonEvidenceStateReadModel.test.ts"
)

& npx vitest run $targets
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1406 Rev1 target tests failed."
}

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Full regression failed."
}

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Production build failed."
}

Write-Host "SPRINT-1406 REV1 VERIFICATION COMPLETE"
