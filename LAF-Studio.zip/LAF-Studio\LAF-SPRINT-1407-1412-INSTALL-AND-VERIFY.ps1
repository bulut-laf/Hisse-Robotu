﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

$files = @(
    (Join-Path $app "src\core\learning\CefrAuthoritativeEvidenceDefinition.ts"),
    (Join-Path $app "src\core\learning\CefrAuthoritativeEvidenceRegistry.ts"),
    (Join-Path $app "src\core\learning\CefrAuthoritativeEvidenceCatalog.ts"),
    (Join-Path $app "src\core\learning\CefrAuthoritativeEvidenceRuntimeAuthority.ts"),
    (Join-Path $app "src\application\learning\CefrAuthoritativeRuntimeEvidenceService.ts"),
    (Join-Path $app "src\core\learning\CefrGenericCurriculumRuntimeFoundationSafety.ts")
)

foreach ($file in $files) {
    if (-not (Test-Path $file)) {
        throw "Sprint 1407-1412 source missing: $file"
    }
}

$checks = @{
    $files[0] = @(
        'runtimeEvidenceNamespace: string',
        'runtimePayloadNamespace: string',
        'masteryClaimed: false',
        'cefrLevelClaimed: false'
    )
    $files[1] = @(
        'createCefrAuthoritativeEvidenceRegistry(',
        'Duplicate authoritative CEFR evidence definition'
    )
    $files[2] = @(
        'LAF_A1_CONNECT_EVIDENCE_DEFINITIONS.map(',
        '"a1-connect-runtime-evidence"',
        '"a1-connect-runtime"'
    )
    $files[3] = @(
        'resolveCefrAuthoritativeEvidenceRuntimeAuthority(',
        'runtimeEvidenceEligible:',
        'resolveCefrAuthoritativeCapabilities('
    )
    $files[4] = @(
        'class CefrAuthoritativeRuntimeEvidenceService',
        'resolveCefrAuthoritativeEvidenceRuntimeAuthority({',
        'Authoritative CEFR runtime evidence authority unresolved',
        'createCefrAuthoritativeRuntimeEvidenceId(',
        'createCefrAuthoritativeRuntimePayloadReference('
    )
    $files[5] = @(
        'authorityPreflightBeforeEvidencePersistence:',
        'true',
        'existingA1RuntimeIdentityPreserved:',
        'targetLanguageInferredByGenericRuntime:',
        'false',
        'automaticProgressionAllowed: false'
    )
}

foreach ($entry in $checks.GetEnumerator()) {
    foreach ($marker in $entry.Value) {
        if (-not (
            Select-String `
                -Path $entry.Key `
                -SimpleMatch `
                -Pattern $marker `
                -Quiet
        )) {
            throw "Required Sprint 1407-1412 marker missing: $marker"
        }
    }
}

Write-Host "SPRINT-1407-1412 SOURCE CHECK PASSED"

Set-Location $app

$targets = @(
    "src/core/learning/CefrAuthoritativeEvidenceDefinition.test.ts",
    "src/core/learning/CefrAuthoritativeEvidenceRegistry.test.ts",
    "src/core/learning/CefrAuthoritativeEvidenceCatalog.test.ts",
    "src/core/learning/CefrAuthoritativeEvidenceRuntimeAuthority.test.ts",
    "src/application/learning/CefrAuthoritativeRuntimeEvidenceService.test.ts",
    "src/application/learning/CefrAuthoritativeRuntimeEvidenceCompatibility.test.ts",
    "src/core/learning/CefrGenericCurriculumRuntimeFoundationSafety.test.ts",
    "src/application/learning/CefrA1ConnectRuntimeEvidenceService.test.ts",
    "src/core/learning/CefrAuthoritativeCurriculumRegistry.test.ts",
    "src/core/learning/CefrAuthoritativeCapabilityRegistry.test.ts",
    "src/application/learning/CefrCurriculumCapabilityObservationWriter.test.ts"
)

& npx vitest run $targets
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1407-1412 target tests failed."
}

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Full regression failed."
}

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Production build failed."
}

Write-Host "SPRINT-1407-1412 VERIFICATION COMPLETE"
