﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

Write-Host "=== Repair / Install Embedded Studio Completion Evidence Bindings ==="
Set-Location $root
node ".\LAF-SPRINT-1227-1232-REV1-INSTALL.mjs"
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1227-1232 Rev1 install failed."
}

$targets = @(
    @{
        Path = Join-Path $app "src\ui\pages\TextWorkshopPage.tsx"
        Studio = '"reading",'
        Name = "Reading"
    },
    @{
        Path = Join-Path $app "src\ui\speaking\SpeakingStudioPanel.tsx"
        Studio = '"speaking",'
        Name = "Speaking"
    },
    @{
        Path = Join-Path $app "src\ui\dialogue\DialogueRoleplayPanel.tsx"
        Studio = '"dialogue",'
        Name = "Dialogue"
    }
)

foreach ($target in $targets) {
    $callMatches = @(
        Select-String `
            -Path $target.Path `
            -SimpleMatch `
            'createCefrEmbeddedStudioCompletionEvidenceInput('
    )

    $studioMatches = @(
        Select-String `
            -Path $target.Path `
            -SimpleMatch `
            $target.Studio
    )

    if ($callMatches.Count -ne 1) {
        throw (
            $target.Name +
            " evidence call validation failed. Count=" +
            $callMatches.Count
        )
    }

    if ($studioMatches.Count -lt 1) {
        throw (
            $target.Name +
            " studio argument validation failed."
        )
    }
}

Set-Location $app

Write-Host "=== Sprint 1227-1230 Target Tests: Embedded Completion Evidence ==="
npx vitest run `
  "src/application/learning/CefrEmbeddedStudioCompletionEvidence.test.ts"
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1227-1230 target tests failed."
}

Write-Host "=== Sprint 1231-1232 Safety Tests ==="
npx vitest run `
  "src/application/learning/CefrEmbeddedStudioCompletionBindingSafety.test.ts"
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1231-1232 target tests failed."
}

Write-Host "=== Combined Sprint 1227-1232 Tests ==="
npx vitest run `
  "src/application/learning/CefrEmbeddedStudioCompletionEvidence.test.ts" `
  "src/application/learning/CefrEmbeddedStudioCompletionBindingSafety.test.ts" `
  "src/application/learning/CefrGuidanceRuntimeProfileService.test.ts" `
  "src/core/learning/CefrLearningStudioEvidenceAdapter.test.ts" `
  "src/core/learning/CefrPersonalLanguageProfileEvidence.test.ts"
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1227-1232 combined tests failed."
}

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Full regression failed."
}

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Production build failed."
}

Write-Host "SPRINT-1227-1232 REV1 VERIFICATION COMPLETE"
