import {
  LAF_A1_CONNECT_REAL_LIFE_ACTIVATION,
} from "../../core/learning/CefrA1ConnectActivationDefinition";
import {
  LAF_A1_CONNECT_EVIDENCE_DEFINITIONS,
} from "../../core/learning/CefrA1ConnectEvidenceDefinition";
import {
  LAF_A1_CONNECT_INTERACTIONS,
} from "../../core/learning/CefrA1ConnectInteractionDefinition";
import {
  LAF_A1_CONNECT_PRACTICE_DEFINITIONS,
} from "../../core/learning/CefrA1ConnectPracticeDefinition";
import {
  LAF_A1_CONNECT_FIRST_SOCIAL_ENCOUNTER_LESSONS,
  LAF_A1_CONNECT_FIRST_SOCIAL_ENCOUNTER_UNIT,
} from "../../core/learning/CefrAuthoritativeCurriculumCatalog";

export interface CefrA1ConnectRuntimeReadModel {
  readonly unit:
    typeof LAF_A1_CONNECT_FIRST_SOCIAL_ENCOUNTER_UNIT;
  readonly lessons:
    typeof LAF_A1_CONNECT_FIRST_SOCIAL_ENCOUNTER_LESSONS;
  readonly practices:
    typeof LAF_A1_CONNECT_PRACTICE_DEFINITIONS;
  readonly interactions:
    typeof LAF_A1_CONNECT_INTERACTIONS;
  readonly evidenceDefinitions:
    typeof LAF_A1_CONNECT_EVIDENCE_DEFINITIONS;
  readonly activation:
    typeof LAF_A1_CONNECT_REAL_LIFE_ACTIVATION;
  readonly evidenceCaptureUserAuthorized: true;
  readonly runtimeUiBindingRequired: true;
  readonly routeCreationRequired: false;
  readonly existingLearningRoute:
    "/learning";
}

export function createCefrA1ConnectRuntimeReadModel():
  CefrA1ConnectRuntimeReadModel {
  return {
    unit:
      LAF_A1_CONNECT_FIRST_SOCIAL_ENCOUNTER_UNIT,
    lessons:
      LAF_A1_CONNECT_FIRST_SOCIAL_ENCOUNTER_LESSONS,
    practices:
      LAF_A1_CONNECT_PRACTICE_DEFINITIONS,
    interactions:
      LAF_A1_CONNECT_INTERACTIONS,
    evidenceDefinitions:
      LAF_A1_CONNECT_EVIDENCE_DEFINITIONS,
    activation:
      LAF_A1_CONNECT_REAL_LIFE_ACTIVATION,
    evidenceCaptureUserAuthorized: true,
    runtimeUiBindingRequired: true,
    routeCreationRequired: false,
    existingLearningRoute: "/learning",
  };
}
