import type {
  LafLearningLanguageCode,
} from "../../core/language/LafLanguageProfile";
import {
  createCefrA1ConnectSessionRestoreRequest,
  type CefrA1ConnectSessionRestoreRequest,
} from "../../core/learning/CefrA1ConnectSessionRestoreRequest";
import type {
  CefrA1ConnectSessionState,
} from "../../core/learning/CefrA1ConnectSessionState";

export interface CefrA1ConnectSessionRestoreResult {
  readonly request:
    CefrA1ConnectSessionRestoreRequest | null;
  readonly restorable: boolean;
  readonly invalidLessonIgnored: boolean;
  readonly automaticRestorePerformed:
    false;
}

export function createCefrA1ConnectSessionRestoreResult(
  state:
    CefrA1ConnectSessionState | null,
  authoritativeLessonIds:
    readonly string[],
): CefrA1ConnectSessionRestoreResult {
  if (
    !state ||
    state.selectedLanguageCode === null
  ) {
    return {
      request: null,
      restorable: false,
      invalidLessonIgnored: false,
      automaticRestorePerformed: false,
    };
  }

  const lessonId =
    state.selectedLessonId !== null &&
    authoritativeLessonIds.includes(
      state.selectedLessonId,
    )
      ? state.selectedLessonId
      : null;

  return {
    request:
      createCefrA1ConnectSessionRestoreRequest({
        selectedLanguageCode:
          state.selectedLanguageCode as LafLearningLanguageCode,
        selectedLessonId: lessonId,
        userActionConfirmed: true,
      }),
    restorable: true,
    invalidLessonIgnored:
      state.selectedLessonId !== null &&
      lessonId === null,
    automaticRestorePerformed: false,
  };
}
