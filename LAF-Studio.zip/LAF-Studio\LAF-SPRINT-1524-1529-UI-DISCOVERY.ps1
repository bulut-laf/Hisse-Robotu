﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

if (-not (Test-Path $app)) {
    throw "LAF Studio app folder missing: $app"
}

Set-Location $app

$outDir =
    Join-Path $root "_discovery\Sprint1524-1529"

if (Test-Path $outDir) {
    Remove-Item -LiteralPath $outDir -Recurse -Force
}

New-Item `
    -ItemType Directory `
    -Path $outDir `
    -Force |
    Out-Null

$wantedNames = @(
    "A1AuthoritativeJourneyPanel.tsx",
    "A1AuthoritativeJourneyPanel.css",
    "CefrA1AuthoritativeJourneyView.ts",
    "CefrA1AuthoritativeJourneyView.test.ts",
    "CefrA1AuthoritativeJourneySafety.ts",
    "CefrA1AuthoritativeJourneySafety.test.ts"
)

$found = @()

foreach ($name in $wantedNames) {
    $matches =
        Get-ChildItem `
            -Path "src" `
            -Recurse `
            -File `
            -Filter $name

    foreach ($match in $matches) {
        $relative =
            $match.FullName.Substring(
                $app.Length
            ).TrimStart(
                [char[]]@("\", "/")
            )

        $found += $relative

        $dest =
            Join-Path $outDir $relative

        New-Item `
            -ItemType Directory `
            -Path (Split-Path $dest -Parent) `
            -Force |
            Out-Null

        Copy-Item `
            -LiteralPath $match.FullName `
            -Destination $dest `
            -Force
    }
}

$patterns = @(
    "data-cefr-unit",
    "a1-navigate",
    "a1-connect",
    "A1AuthoritativeJourneyPanel",
    "createCefrA1AuthoritativeJourney",
    'path="/learning"',
    '"/learning"',
    "CefrProductionRuntimePlatform",
    "readLanguageEvidence"
)

$matchesOut = @()

foreach ($pattern in $patterns) {
    $matches =
        Get-ChildItem `
            -Path "src" `
            -Recurse `
            -File `
            -Include "*.ts","*.tsx" |
        Select-String `
            -SimpleMatch `
            -Pattern $pattern

    foreach ($match in $matches) {
        $relative =
            $match.Path.Substring(
                $app.Length
            ).TrimStart(
                [char[]]@("\", "/")
            )

        $matchesOut +=
            "$relative:$($match.LineNumber): $($match.Line.Trim())"
    }
}

$matchesOut =
    $matchesOut |
    Sort-Object -Unique

[System.IO.File]::WriteAllLines(
    (Join-Path $outDir "MATCHES.txt"),
    $matchesOut,
    (New-Object System.Text.UTF8Encoding($false))
)

[System.IO.File]::WriteAllLines(
    (Join-Path $outDir "FOUND-FILES.txt"),
    ($found | Sort-Object -Unique),
    (New-Object System.Text.UTF8Encoding($false))
)

$zipPath =
    Join-Path $root "LAF-SPRINT-1524-1529-UI-DISCOVERY-SNAPSHOT.zip"

if (Test-Path $zipPath) {
    Remove-Item -LiteralPath $zipPath -Force
}

Compress-Archive `
    -Path (Join-Path $outDir "*") `
    -DestinationPath $zipPath `
    -Force

Write-Host ""
Write-Host "SPRINT-1524-1529 UI DISCOVERY COMPLETE"
Write-Host "Snapshot: $zipPath"
Write-Host ""
Write-Host "Found files:"
Get-Content (Join-Path $outDir "FOUND-FILES.txt")
Write-Host ""
Write-Host "Key matches:"
Get-Content (Join-Path $outDir "MATCHES.txt")
