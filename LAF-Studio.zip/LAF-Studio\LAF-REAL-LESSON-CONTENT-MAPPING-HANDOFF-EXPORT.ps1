﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$src = Join-Path $root "app\src"
$out = Join-Path $root "LAF_REAL_LESSON_CONTENT_MAPPING_HANDOFF.txt"

if (-not (Test-Path $src)) {
    throw "Source root not found: $src"
}

$report = New-Object System.Collections.Generic.List[string]

function Add-Line {
    param([string]$Text)
    if ($null -eq $Text) { $Text = "" }
    [void]$report.Add($Text)
}

function Add-Section {
    param([string]$Title)
    Add-Line ""
    Add-Line ("=" * 96)
    Add-Line $Title
    Add-Line ("=" * 96)
}

function Add-File {
    param(
        [string]$Relative,
        [int]$Limit = 2000
    )

    $file = Join-Path $src $Relative

    Add-Section ("FILE: app\src\" + $Relative)

    if (-not (Test-Path $file)) {
        Add-Line "(file not found)"
        return
    }

    $lines = @(Get-Content -Path $file)
    $count = [Math]::Min(
        $lines.Count,
        $Limit
    )

    for ($i = 0; $i -lt $count; $i++) {
        Add-Line (
            "{0,4}: {1}" -f
            ($i + 1),
            $lines[$i]
        )
    }

    if ($lines.Count -gt $Limit) {
        Add-Line (
            "... truncated; total lines: " +
            $lines.Count
        )
    }
}

Add-Line "LAF STUDIO - REAL LESSON CONTENT MAPPING HANDOFF"
Add-Line ("Generated: " + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
Add-Line "READ ONLY - no project source files are modified."
Add-Line "Stable technical baseline expected: Sprint 1286."

Add-File "features\lessons\data\lessons.ts" 2500
Add-File "features\lessons\types\Lesson.ts" 800
Add-File "core\learning\CefrCompetencyOutcome.ts" 1200
Add-File "core\learning\CefrAuthoritativeCurriculumRegistry.ts" 500
Add-File "core\learning\CefrCurriculumCompetencyMapping.ts" 500

Add-Section "DESIGN STUDIO DECISION REQUIRED"

Add-Line "Determine whether the existing production lessons are authoritative CEFR curriculum items or legacy/demo lesson content."
Add-Line ""
Add-Line "Known real lesson identities:"
Add-Line "- lesson-1 — İtalyanca Selamlaşma — A1"
Add-Line "- lesson-2 — İtalyanca Tanışma — A1"
Add-Line "- lesson-3 — İtalyanca Temel Sorular — A1"
Add-Line ""
Add-Line "For each lesson that IS approved as a CEFR curriculum learning item, return:"
Add-Line ""
Add-Line "learningItemType: lesson"
Add-Line "learningItemId: <exact lesson id>"
Add-Line "competencyOutcomeIds: [1..2 normally]"
Add-Line "mappingVersion: <approved curriculum mapping version>"
Add-Line "exceptionalThirdOutcomeApproved: true  # only if exactly 3"
Add-Line "authoritative: true"
Add-Line ""
Add-Line "If a lesson is NOT part of the authoritative CEFR curriculum, explicitly mark it EXCLUDED."
Add-Line ""
Add-Line "Do not infer mapping from:"
Add-Line "- lesson title alone"
Add-Line "- A1 label alone"
Add-Line "- Studio or route"
Add-Line "- activity type names alone"
Add-Line ""
Add-Line "Use the actual lesson sections, activities, instructions, prompts, examples and communicative task content in this report."
Add-Line ""
Add-Line "Approved cardinality remains:"
Add-Line "- minimum 1 outcome"
Add-Line "- normal maximum 2 outcomes"
Add-Line "- exactly 3 only by explicit exception"
Add-Line ""
Add-Line "Mapping means capability observation eligibility only."
Add-Line "No mastery assignment."
Add-Line "No competency success assignment."
Add-Line "No CEFR-level assignment."
Add-Line "No automatic progression."

$report | Set-Content -Path $out -Encoding UTF8

Write-Host ""
Write-Host "LAF REAL LESSON CONTENT MAPPING HANDOFF EXPORT COMPLETE"
Write-Host "Report:"
Write-Host $out
