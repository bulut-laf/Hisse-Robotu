import {
  LAF_A1_NAVIGATE_ALL_EXECUTABLE_TASKS,
  type CefrA1NavigateAllExecutableTaskId,
} from "../../core/learning/CefrA1NavigateExecutableTaskCatalog";

export type CefrA1NavigateSessionAdvisoryStatus =
  | "next-immediate-task"
  | "guided-activation-available";

export interface CefrA1NavigateSessionAdvisory {
  readonly status:
    CefrA1NavigateSessionAdvisoryStatus;
  readonly immediateEvidenceCount: 6;
  readonly observedInCurrentSessionCount:
    number;
  readonly nextTaskId:
    CefrA1NavigateAllExecutableTaskId | null;
  readonly guidedActivationAvailable:
    boolean;
  readonly userApplyRequired: true;
  readonly delayedRetrievalRecommended:
    false;
  readonly delayedRetrievalExecutable:
    false;
  readonly masteryClaimed: false;
  readonly cefrLevelClaimed: false;
  readonly automaticProgressionPerformed:
    false;
}

export function createCefrA1NavigateSessionAdvisory(
  completedTaskIds:
    readonly CefrA1NavigateAllExecutableTaskId[],
): CefrA1NavigateSessionAdvisory {
  const completed =
    new Set(completedTaskIds);

  const nextTask =
    LAF_A1_NAVIGATE_ALL_EXECUTABLE_TASKS.find(
      task => !completed.has(task.taskId),
    );

  if (nextTask) {
    return {
      status: "next-immediate-task",
      immediateEvidenceCount: 6,
      observedInCurrentSessionCount:
        completed.size,
      nextTaskId: nextTask.taskId,
      guidedActivationAvailable: false,
      userApplyRequired: true,
      delayedRetrievalRecommended: false,
      delayedRetrievalExecutable: false,
      masteryClaimed: false,
      cefrLevelClaimed: false,
      automaticProgressionPerformed:
        false,
    };
  }

  return {
    status: "guided-activation-available",
    immediateEvidenceCount: 6,
    observedInCurrentSessionCount:
      completed.size,
    nextTaskId: null,
    guidedActivationAvailable: true,
    userApplyRequired: true,
    delayedRetrievalRecommended: false,
    delayedRetrievalExecutable: false,
    masteryClaimed: false,
    cefrLevelClaimed: false,
    automaticProgressionPerformed: false,
  };
}
