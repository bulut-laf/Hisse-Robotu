import type {
  LafLearningLanguageCode,
} from "../../core/language/LafLanguageProfile";
import type {
  CefrProductionRuntimePlatform,
} from "./CefrProductionRuntimePlatform";

export type CefrA1AuthoritativeJourneySliceId =
  | "a1-connect"
  | "a1-navigate"
  | "a1-describe";

export type CefrA1AuthoritativeJourneyCoverageStatus =
  | "no-immediate-evidence"
  | "partial-immediate-evidence"
  | "immediate-evidence-covered";

export interface CefrA1AuthoritativeJourneySliceView {
  readonly sliceId:
    CefrA1AuthoritativeJourneySliceId;
  readonly moduleFamily:
    | "CONNECT"
    | "NAVIGATE"
    | "DESCRIBE & NARRATE";
  readonly competencyOutcomeId:
    | "connect-a1"
    | "navigate-a1"
    | "describe-narrate-a1";
  readonly capabilityReference:
    | "social-exchange"
    | "needs-expression"
    | "description-production";
  readonly unitId:
    | "a1-connect-first-social-encounter"
    | "a1-navigate-immediate-everyday-needs"
    | "a1-describe-basic-familiar-world";
  readonly observedImmediateEvidenceCount:
    number;
  readonly immediateEvidenceCount: 6;
  readonly status:
    CefrA1AuthoritativeJourneyCoverageStatus;
  readonly delayedRetrievalIncluded: false;
  readonly targetLanguageScoped: true;
  readonly persistedRealEvidenceOnly: true;
  readonly coverageOnly: true;
  readonly masteryInferred: false;
  readonly cefrLevelInferred: false;
  readonly automaticProgressionPerformed:
    false;
}

export interface CefrA1AuthoritativeJourneyView {
  readonly levelCode: "A1";
  readonly levelIdentity: "RESPOND";
  readonly languageCode:
    LafLearningLanguageCode;
  readonly slices:
    readonly [
      CefrA1AuthoritativeJourneySliceView,
      CefrA1AuthoritativeJourneySliceView,
      CefrA1AuthoritativeJourneySliceView,
    ];
  readonly activeAuthoritativeSliceCount: 3;
  readonly totalObservedImmediateEvidenceCount:
    number;
  readonly totalImmediateEvidenceCount: 18;
  readonly targetLanguageScoped: true;
  readonly crossLanguageEvidenceExcluded:
    true;
  readonly unscopedEvidenceExcluded: true;
  readonly delayedRetrievalIncluded: false;
  readonly coverageOnly: true;
  readonly masteryInferred: false;
  readonly cefrLevelInferred: false;
  readonly automaticProgressionPerformed:
    false;
}

interface SliceMetadata {
  readonly sliceId:
    CefrA1AuthoritativeJourneySliceId;
  readonly moduleFamily:
    | "CONNECT"
    | "NAVIGATE"
    | "DESCRIBE & NARRATE";
  readonly competencyOutcomeId:
    | "connect-a1"
    | "navigate-a1"
    | "describe-narrate-a1";
  readonly capabilityReference:
    | "social-exchange"
    | "needs-expression"
    | "description-production";
  readonly unitId:
    | "a1-connect-first-social-encounter"
    | "a1-navigate-immediate-everyday-needs"
    | "a1-describe-basic-familiar-world";
}

const A1_AUTHORITATIVE_SLICES:
  readonly SliceMetadata[] = [
    {
      sliceId: "a1-connect",
      moduleFamily: "CONNECT",
      competencyOutcomeId: "connect-a1",
      capabilityReference: "social-exchange",
      unitId:
        "a1-connect-first-social-encounter",
    },
    {
      sliceId: "a1-navigate",
      moduleFamily: "NAVIGATE",
      competencyOutcomeId: "navigate-a1",
      capabilityReference:
        "needs-expression",
      unitId:
        "a1-navigate-immediate-everyday-needs",
    },
    {
      sliceId: "a1-describe",
      moduleFamily: "DESCRIBE & NARRATE",
      competencyOutcomeId:
        "describe-narrate-a1",
      capabilityReference:
        "description-production",
      unitId:
        "a1-describe-basic-familiar-world",
    },
  ];

function coverageStatus(
  observed: number,
): CefrA1AuthoritativeJourneyCoverageStatus {
  if (observed === 0) {
    return "no-immediate-evidence";
  }

  if (observed === 6) {
    return "immediate-evidence-covered";
  }

  return "partial-immediate-evidence";
}

export function createCefrA1AuthoritativeJourneyView(
  platform:
    CefrProductionRuntimePlatform,
  languageCode:
    LafLearningLanguageCode,
): CefrA1AuthoritativeJourneyView {
  const slices =
    A1_AUTHORITATIVE_SLICES.map(
      metadata => {
        const read =
          platform.readLanguageEvidence(
            metadata.sliceId,
            languageCode,
          );

        if (
          read.coverage.items.length !== 6
        ) {
          throw new Error(
            `A1 journey runtime slice ${metadata.sliceId} must expose exactly six immediate evidence definitions; received ${read.coverage.items.length}.`,
          );
        }

        if (
          read.coverage.items.some(
            item =>
              item.evidenceDefinitionId.includes(
                "delayed-retrieval",
              ),
          )
        ) {
          throw new Error(
            `Delayed retrieval leaked into A1 journey runtime slice: ${metadata.sliceId}`,
          );
        }

        const observed =
          read.coverage.items.filter(
            item => item.observed,
          ).length;

        return {
          ...metadata,
          observedImmediateEvidenceCount:
            observed,
          immediateEvidenceCount: 6,
          status:
            coverageStatus(observed),
          delayedRetrievalIncluded: false,
          targetLanguageScoped: true,
          persistedRealEvidenceOnly: true,
          coverageOnly: true,
          masteryInferred: false,
          cefrLevelInferred: false,
          automaticProgressionPerformed:
            false,
        } satisfies
          CefrA1AuthoritativeJourneySliceView;
      },
    );

  const connect = slices[0];
  const navigate = slices[1];
  const describe = slices[2];

  if (
    !connect ||
    !navigate ||
    !describe
  ) {
    throw new Error(
      "A1 authoritative journey requires CONNECT, NAVIGATE, and DESCRIBE runtime slices.",
    );
  }

  return {
    levelCode: "A1",
    levelIdentity: "RESPOND",
    languageCode,
    slices: [
      connect,
      navigate,
      describe,
    ],
    activeAuthoritativeSliceCount: 3,
    totalObservedImmediateEvidenceCount:
      connect.observedImmediateEvidenceCount +
      navigate.observedImmediateEvidenceCount +
      describe.observedImmediateEvidenceCount,
    totalImmediateEvidenceCount: 18,
    targetLanguageScoped: true,
    crossLanguageEvidenceExcluded: true,
    unscopedEvidenceExcluded: true,
    delayedRetrievalIncluded: false,
    coverageOnly: true,
    masteryInferred: false,
    cefrLevelInferred: false,
    automaticProgressionPerformed:
      false,
  };
}
