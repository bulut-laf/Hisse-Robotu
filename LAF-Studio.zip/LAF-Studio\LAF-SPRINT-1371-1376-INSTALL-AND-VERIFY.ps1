﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$panel = Join-Path $app "src\ui\learning\A1ConnectNativeLearningPanel.tsx"

if (-not (Test-Path $panel)) {
    throw "A1ConnectNativeLearningPanel.tsx missing."
}

$utf8 =
    New-Object System.Text.UTF8Encoding($false)

$text =
    [System.IO.File]::ReadAllText(
        $panel,
        $utf8
    )

$restoreFunctionMarker =
    'const restoreRememberedSelection = ('

if (-not $text.Contains(
    $restoreFunctionMarker
)) {
    $anchor = '  return ('

    if (-not $text.Contains($anchor)) {
        throw "Restore function anchor not found."
    }

    $restoreFunction = @'
  const restoreRememberedSelection = (
    languageCode: LafLearningLanguageCode,
    lessonId: string | null,
  ) => {
    setSelectedLanguageCode(languageCode);

    if (
      lessonId !== null &&
      model.lessonCards.some(
        lesson =>
          lesson.lessonId === lessonId,
      )
    ) {
      setSelectedLessonId(lessonId);
    }
  };

'@

    $text = $text.Replace(
        $anchor,
        $restoreFunction + $anchor
    )
}

$continuityOld = @'
      <A1ConnectContinuityPanel
        selectedLanguageCode={selectedLanguageCode}
        selectedLessonId={
          selectedLesson?.lessonId ?? null
        }
      />
'@

$continuityNew = @'
      <A1ConnectContinuityPanel
        selectedLanguageCode={selectedLanguageCode}
        selectedLessonId={
          selectedLesson?.lessonId ?? null
        }
        authoritativeLessonIds={
          model.lessonCards.map(
            lesson => lesson.lessonId,
          )
        }
        onRestoreSelection={
          restoreRememberedSelection
        }
      />
'@

if (
    -not $text.Contains(
        'onRestoreSelection={'
    )
) {
    if (-not $text.Contains($continuityOld)) {
        throw "Continuity component prop anchor not found."
    }

    $text = $text.Replace(
        $continuityOld,
        $continuityNew
    )
}

[System.IO.File]::WriteAllText(
    $panel,
    $text,
    $utf8
)

$request = Join-Path $app "src\core\learning\CefrA1ConnectSessionRestoreRequest.ts"
$boundary = Join-Path $app "src\application\learning\CefrA1ConnectSessionRestoreBoundary.ts"
$continuity = Join-Path $app "src\ui\learning\A1ConnectContinuityPanel.tsx"
$safety = Join-Path $app "src\core\learning\CefrA1ConnectExplicitRestoreSafety.ts"

foreach ($file in @(
    $request,
    $boundary,
    $continuity,
    $safety,
    $panel
)) {
    if (-not (Test-Path $file)) {
        throw "Sprint 1371-1376 source missing: $file"
    }
}

$checks = @{
    $request = @(
        'userActionConfirmed: true',
        'evidenceCreated: false',
        'progressionPerformed: false'
    )
    $boundary = @(
        'authoritativeLessonIds.includes(',
        'automaticRestorePerformed: false'
    )
    $continuity = @(
        'Kayıtlı Seçimi Yükle',
        'onRestoreSelection('
    )
    $safety = @(
        'automaticRestoreAllowed: false',
        'restoreCreatesEvidence: false'
    )
    $panel = @(
        'const restoreRememberedSelection = (',
        'authoritativeLessonIds={',
        'onRestoreSelection={'
    )
}

foreach ($entry in $checks.GetEnumerator()) {
    foreach ($marker in $entry.Value) {
        if (-not (
            Select-String `
                -Path $entry.Key `
                -SimpleMatch `
                -Pattern $marker `
                -Quiet
        )) {
            throw "Required Sprint 1371-1376 marker missing: $marker"
        }
    }
}

Write-Host "SPRINT-1371-1376 SOURCE CHECK PASSED"

Set-Location $app

$targets = @(
    "src/core/learning/CefrA1ConnectSessionRestoreRequest.test.ts",
    "src/application/learning/CefrA1ConnectSessionRestoreBoundary.test.ts",
    "src/core/learning/CefrA1ConnectExplicitRestoreSafety.test.ts",
    "src/ui/learning/A1ConnectContinuityPanel.restore.test.ts",
    "src/core/learning/CefrA1ConnectSessionState.test.ts",
    "src/application/learning/CefrA1ConnectSessionStateRepository.test.ts",
    "src/core/learning/CefrA1ConnectContinuitySafety.test.ts",
    "src/application/learning/CefrA1ConnectLanguageScopedAdvisoryReadModel.test.ts"
)

& npx vitest run $targets
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1371-1376 target tests failed."
}

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Full regression failed."
}

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Production build failed."
}

Write-Host "SPRINT-1371-1376 VERIFICATION COMPLETE"
