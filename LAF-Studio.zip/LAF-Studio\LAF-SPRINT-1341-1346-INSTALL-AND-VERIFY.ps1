﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$css = Join-Path $app "src\ui\learning\A1ConnectExtendedTaskPanel.css"
$cssPart = Join-Path $app "src\ui\learning\A1ConnectExtendedTaskPanel.delayed.css"

if (-not (Test-Path $css)) {
    throw "A1ConnectExtendedTaskPanel.css missing."
}

if (-not (Test-Path $cssPart)) {
    throw "Delayed candidate CSS fragment missing."
}

$utf8 =
    New-Object System.Text.UTF8Encoding($false)

$cssText =
    [System.IO.File]::ReadAllText(
        $css,
        $utf8
    )
$extra =
    [System.IO.File]::ReadAllText(
        $cssPart,
        $utf8
    )

if (-not $cssText.Contains(
    ".a1-connect-delayed-candidate {"
)) {
    [System.IO.File]::WriteAllText(
        $css,
        $cssText +
        [Environment]::NewLine +
        $extra,
        $utf8
    )
}

Remove-Item $cssPart -Force

$candidate = Join-Path $app "src\core\learning\CefrA1ConnectDelayedRetrievalCandidate.ts"
$repository = Join-Path $app "src\application\learning\CefrA1ConnectDelayedRetrievalCandidateRepository.ts"
$boundary = Join-Path $app "src\core\learning\CefrA1ConnectDelayedRetrievalTimingBoundary.ts"
$panel = Join-Path $app "src\ui\learning\A1ConnectExtendedTaskPanel.tsx"

foreach ($file in @(
    $candidate,
    $repository,
    $boundary,
    $panel
)) {
    if (-not (Test-Path $file)) {
        throw "Sprint 1341-1346 source missing: $file"
    }
}

$checks = @{
    $candidate = @(
        '"waiting-for-approved-delay-policy"',
        'delayedRetrievalEvidenceWritten:',
        'false'
    )
    $repository = @(
        'laf.cefr.a1-connect.delayed-retrieval.v1',
        'findLatestForLanguage('
    )
    $boundary = @(
        'approvedDelayPolicyPresent:',
        'false',
        'minimumDelayInvented: false',
        'delayedRetrievalEvidenceMayBeWritten:',
        'false'
    )
    $panel = @(
        'createCefrA1ConnectDelayedRetrievalCandidate({',
        'result.evidence.runtimeEvidenceId',
        'DELAYED RETRIEVAL ADAYI',
        '7. kanıtı üretmez'
    )
}

foreach ($entry in $checks.GetEnumerator()) {
    foreach ($marker in $entry.Value) {
        if (-not (
            Select-String `
                -Path $entry.Key `
                -SimpleMatch `
                -Pattern $marker `
                -Quiet
        )) {
            throw "Required Sprint 1341-1346 marker missing: $marker"
        }
    }
}

Write-Host "SPRINT-1341-1346 SOURCE CHECK PASSED"

Set-Location $app

$targets = @(
    "src/core/learning/CefrA1ConnectDelayedRetrievalCandidate.test.ts",
    "src/application/learning/CefrA1ConnectDelayedRetrievalCandidateRepository.test.ts",
    "src/core/learning/CefrA1ConnectDelayedRetrievalTimingBoundary.test.ts",
    "src/ui/learning/A1ConnectDelayedRetrievalCandidateBinding.test.ts",
    "src/core/learning/CefrA1ConnectExtendedExecutableTasks.test.ts",
    "src/application/learning/CefrA1ConnectExtendedTaskCompletionService.test.ts",
    "src/core/learning/CefrA1ConnectImmediateEvidenceCoverageSafety.test.ts",
    "src/application/learning/CefrA1ConnectRuntimeEvidenceService.test.ts"
)

& npx vitest run $targets
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1341-1346 target tests failed."
}

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Full regression failed."
}

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Production build failed."
}

Write-Host "SPRINT-1341-1346 VERIFICATION COMPLETE"
