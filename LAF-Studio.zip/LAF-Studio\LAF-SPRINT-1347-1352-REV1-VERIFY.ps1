﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

$coverage = Join-Path $app "src\core\learning\CefrA1ConnectEvidenceCoverage.ts"
$coverageTest = Join-Path $app "src\core\learning\CefrA1ConnectEvidenceCoverage.test.ts"

foreach ($file in @(
    $coverage,
    $coverageTest
)) {
    if (-not (Test-Path $file)) {
        throw "Sprint 1347-1352 Rev1 source missing: $file"
    }
}

if (
    Select-String `
        -Path $coverage `
        -SimpleMatch `
        -Pattern 'CefrPersonalLanguageProfileEvidence' `
        -Quiet
) {
    throw "Obsolete CefrPersonalLanguageProfileEvidence dependency still exists."
}

if (
    Select-String `
        -Path $coverageTest `
        -SimpleMatch `
        -Pattern 'CefrPersonalLanguageProfileEvidence' `
        -Quiet
) {
    throw "Obsolete test dependency still exists."
}

if (-not (
    Select-String `
        -Path $coverage `
        -SimpleMatch `
        -Pattern 'export interface CefrA1ConnectEvidenceIdentity' `
        -Quiet
)) {
    throw "Structural evidence identity contract missing."
}

Write-Host "SPRINT-1347-1352 REV1 SOURCE CHECK PASSED"

Set-Location $app

$targets = @(
    "src/core/learning/CefrA1ConnectEvidenceCoverage.test.ts",
    "src/application/learning/CefrA1ConnectEvidenceCoverageReadModel.test.ts",
    "src/core/learning/CefrA1ConnectGuidedRealLifeActivation.test.ts",
    "src/core/learning/CefrA1ConnectUnitRuntimeSafety.test.ts",
    "src/ui/learning/A1ConnectUnitRuntimePanel.test.ts",
    "src/core/learning/CefrA1ConnectDelayedRetrievalCandidate.test.ts",
    "src/core/learning/CefrA1ConnectDelayedRetrievalTimingBoundary.test.ts",
    "src/application/learning/CefrA1ConnectRuntimeEvidenceService.test.ts"
)

& npx vitest run $targets
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1347-1352 Rev1 target tests failed."
}

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Full regression failed."
}

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Production build failed."
}

Write-Host "SPRINT-1347-1352 REV1 VERIFICATION COMPLETE"
