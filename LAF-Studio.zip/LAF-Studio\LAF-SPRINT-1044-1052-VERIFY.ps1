$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 1044-1046 Target Tests: Unified Guidance Candidate ==="
npx vitest run `
  "src/core/learning/CefrUnifiedGuidanceCandidate.test.ts" `
  "src/core/learning/CefrUnifiedGuidanceContext.test.ts" `
  "src/core/learning/CefrUnifiedGuidanceOrchestration.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1044-1046 target tests failed." }

Write-Host "=== Sprint 1047-1049 Target Tests: Daily Guidance Queue ==="
npx vitest run `
  "src/core/learning/CefrDailyGuidanceQueueItem.test.ts" `
  "src/core/learning/CefrDailyGuidanceQueue.test.ts" `
  "src/core/learning/CefrDailyGuidanceQueueOrchestration.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1047-1049 target tests failed." }

Write-Host "=== Sprint 1050-1052 Target Tests: User Guidance Plan ==="
npx vitest run `
  "src/core/learning/CefrUserGuidancePlanSelection.test.ts" `
  "src/core/learning/CefrUserGuidancePlan.test.ts" `
  "src/core/learning/CefrUserGuidancePlanGateway.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1050-1052 target tests failed." }

Write-Host "=== Combined Sprint 1044-1052 New Tests ==="
npx vitest run `
  "src/core/learning/CefrUnifiedGuidanceCandidate.test.ts" `
  "src/core/learning/CefrUnifiedGuidanceContext.test.ts" `
  "src/core/learning/CefrUnifiedGuidanceOrchestration.test.ts" `
  "src/core/learning/CefrDailyGuidanceQueueItem.test.ts" `
  "src/core/learning/CefrDailyGuidanceQueue.test.ts" `
  "src/core/learning/CefrDailyGuidanceQueueOrchestration.test.ts" `
  "src/core/learning/CefrUserGuidancePlanSelection.test.ts" `
  "src/core/learning/CefrUserGuidancePlan.test.ts" `
  "src/core/learning/CefrUserGuidancePlanGateway.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1044-1052 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-1044-1052 VERIFICATION COMPLETE"
