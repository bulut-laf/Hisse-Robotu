import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrPersonalLanguageProfileState,
  type CefrPersonalLanguageProfileState,
} from "../../core/learning/CefrPersonalLanguageProfileState";
import type {
  CefrLanguageEvidenceStorageLike,
} from "./CefrAuthoritativeLanguageEvidenceProvenanceRepository";
import type {
  CefrGuidanceRuntimeProfileRepository,
} from "./CefrGuidanceRuntimeProfileRepository";
import {
  CefrProductionRuntimePlatform,
} from "./CefrProductionRuntimePlatform";
import {
  CefrA1DescribeExecutableTaskService,
} from "./CefrA1DescribeExecutableTaskService";

class MemoryProfileRepository
  implements CefrGuidanceRuntimeProfileRepository {
  private state:
    CefrPersonalLanguageProfileState =
      createCefrPersonalLanguageProfileState(
        [],
        [],
      );

  load(): CefrPersonalLanguageProfileState {
    return this.state;
  }

  save(
    state: CefrPersonalLanguageProfileState,
  ): void {
    this.state = state;
  }

  hasPersistedProfile(): boolean {
    return false;
  }

  clear(): void {}
}

class MemoryStorage
  implements CefrLanguageEvidenceStorageLike {
  private readonly items =
    new Map<string, string>();

  getItem(key: string): string | null {
    return this.items.get(key) ?? null;
  }

  setItem(
    key: string,
    value: string,
  ): void {
    this.items.set(key, value);
  }

  removeItem(key: string): void {
    this.items.delete(key);
  }
}

function createService(
  repository:
    MemoryProfileRepository =
      new MemoryProfileRepository(),
) {
  return {
    repository,
    service:
      new CefrA1DescribeExecutableTaskService(
        new CefrProductionRuntimePlatform(
          repository,
          new MemoryStorage(),
        ),
      ),
  };
}

describe(
  "A1 DESCRIBE executable task service",
  () => {
    it("builds deterministic selected-language description tasks without exposing answers", () => {
      const { service } = createService();

      const hu =
        service.getSelectionTaskView(
          "a1-describe-task-basic-feature",
          "hu",
        );

      const de =
        service.getSelectionTaskView(
          "a1-describe-task-basic-feature",
          "de",
        );

      expect(hu).toMatchObject({
        languageCode: "hu",
        taskKind: "controlled-selection",
        evidenceDefinitionId:
          "a1-describe-evidence-basic-feature",
        correctAnswerExposed: false,
        evidenceWritten: false,
        targetLanguageExplicit: true,
        targetLanguageInferred: false,
      });

      expect(
        hu.options.map(
          option => option.text,
        ),
      ).toContain("A macska fehér.");

      expect(
        de.options.map(
          option => option.text,
        ),
      ).toContain("Die Katze ist weiß.");
    });

    it("writes language-scoped observational description-production evidence after a correct explicit selection", () => {
      const {
        repository,
        service,
      } = createService();

      const result =
        service.executeSelection({
          taskId:
            "a1-describe-task-basic-feature",
          languageCode: "hu",
          selectedPhraseId:
            "feature-white",
          eventId:
            "describe-task-001",
          occurredAt:
            new Date(
              "2026-08-12T19:00:00.000Z",
            ),
          userActionConfirmed: true,
        });

      expect(result).toMatchObject({
        evidenceDefinitionId:
          "a1-describe-evidence-basic-feature",
        languageCode: "hu",
        correct: true,
        evidenceWritten: true,
        masteryAssigned: false,
        competencySuccessAssigned: false,
        cefrLevelAssigned: false,
        progressionPerformed: false,
        narrativeSequencingPerformed:
          false,
      });

      expect(result.runtime).toMatchObject({
        evidenceId:
          "a1-describe-runtime-evidence:a1-describe-evidence-basic-feature:describe-task-001",
        languageCode: "hu",
        evidencePersisted: true,
        targetLanguageExplicit: true,
        targetLanguageInferred: false,
      });

      expect(
        result.runtime?.runtime
          .resolvedCapabilityReferences,
      ).toEqual([
        "description-production",
      ]);

      expect(
        repository.load()
          .capabilityObservationRegistry
          .observations,
      ).toEqual([
        {
          capabilityReference:
            "description-production",
          evidenceId:
            "a1-describe-runtime-evidence:a1-describe-evidence-basic-feature:describe-task-001",
          source: "learning-studio",
          observationalOnly: true,
        },
      ]);
    });

    it("requires the complete approved person-description sequence before writing production evidence", () => {
      const {
        repository,
        service,
      } = createService();

      const partial =
        service.executePersonDescription({
          languageCode: "en",
          selectedPhraseIds: [
            "person-identify",
            "person-tall",
          ],
          eventId:
            "describe-person-partial-001",
          occurredAt:
            new Date(
              "2026-08-12T19:05:00.000Z",
            ),
          userActionConfirmed: true,
        });

      expect(partial).toMatchObject({
        correctPrefix: true,
        complete: false,
        evidenceWritten: false,
        runtime: null,
        narrativeSequencingPerformed:
          false,
      });

      expect(
        repository.load()
          .profileSnapshot
          .evidenceAggregation
          .evidence,
      ).toHaveLength(0);

      const complete =
        service.executePersonDescription({
          languageCode: "en",
          selectedPhraseIds: [
            "person-identify",
            "person-tall",
            "person-kind",
          ],
          eventId:
            "describe-person-complete-001",
          occurredAt:
            new Date(
              "2026-08-12T19:06:00.000Z",
            ),
          userActionConfirmed: true,
        });

      expect(complete).toMatchObject({
        correctPrefix: true,
        complete: true,
        evidenceWritten: true,
        masteryAssigned: false,
        competencySuccessAssigned: false,
        cefrLevelAssigned: false,
        progressionPerformed: false,
        narrativeSequencingPerformed:
          false,
      });

      expect(
        complete.runtime?.runtime
          .resolvedCapabilityReferences,
      ).toEqual([
        "description-production",
      ]);
    });

    it("does not write evidence after an incorrect selection", () => {
      const {
        repository,
        service,
      } = createService();

      const result =
        service.executeSelection({
          taskId:
            "a1-describe-task-basic-comprehension",
          languageCode: "tr",
          selectedPhraseId:
            "feature-small",
          eventId:
            "describe-wrong-001",
          occurredAt:
            new Date(
              "2026-08-12T19:10:00.000Z",
            ),
          userActionConfirmed: true,
        });

      expect(result).toMatchObject({
        correct: false,
        evidenceWritten: false,
        runtime: null,
        masteryAssigned: false,
        cefrLevelAssigned: false,
        progressionPerformed: false,
      });

      expect(
        repository.load()
          .profileSnapshot
          .evidenceAggregation
          .evidence,
      ).toHaveLength(0);
    });

    it("refuses execution without explicit user confirmation and has no delayed-retrieval task", () => {
      const { service } = createService();

      expect(() =>
        service.executeSelection({
          taskId:
            "a1-describe-task-basic-feature",
          languageCode: "it",
          selectedPhraseId:
            "feature-white",
          eventId:
            "describe-no-confirm-001",
          occurredAt:
            new Date(
              "2026-08-12T19:15:00.000Z",
            ),
          userActionConfirmed: false,
        }),
      ).toThrow(
        "Explicit user action confirmation is required",
      );

      expect(() =>
        service.getSelectionTaskView(
          "a1-describe-task-delayed-retrieval" as
            "a1-describe-task-basic-feature",
          "hu",
        ),
      ).toThrow(
        "Unknown executable A1 DESCRIBE task",
      );
    });
  },
);
