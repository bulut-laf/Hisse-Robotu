import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrA1ConnectEvidenceProvenanceRecoveryRecord,
} from "../../core/learning/CefrA1ConnectEvidenceProvenanceRecoveryRecord";
import {
  CefrA1ConnectEvidenceProvenanceRecoveryRepository,
} from "./CefrA1ConnectEvidenceProvenanceRecoveryRepository";

class MemoryStorage {
  private readonly values =
    new Map<string, string>();

  getItem(key: string): string | null {
    return this.values.get(key) ?? null;
  }

  setItem(
    key: string,
    value: string,
  ): void {
    this.values.set(key, value);
  }

  removeItem(key: string): void {
    this.values.delete(key);
  }
}

describe(
  "CefrA1ConnectEvidenceProvenanceRecoveryRepository",
  () => {
    it("persists recovery records idempotently", () => {
      const repository =
        new CefrA1ConnectEvidenceProvenanceRecoveryRepository(
          new MemoryStorage(),
        );

      const record =
        createCefrA1ConnectEvidenceProvenanceRecoveryRecord({
          evidenceId:
            "a1-connect-runtime-evidence:item-2",
          languageCode: "it",
          observedAt:
            new Date(
              "2026-08-11T19:16:00.000Z",
            ),
          createdAt:
            new Date(
              "2026-08-11T19:16:01.000Z",
            ),
        });

      repository.save(record);
      repository.save(record);

      expect(
        repository.loadAll(),
      ).toHaveLength(1);

      repository.remove(
        record.recoveryId,
      );

      expect(
        repository.loadAll(),
      ).toHaveLength(0);
    });
  },
);
