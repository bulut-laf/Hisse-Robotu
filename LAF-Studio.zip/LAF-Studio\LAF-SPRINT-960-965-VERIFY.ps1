$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 960-962 Target Tests: Vocabulary / Translation / Interpreting Context Consumers ==="
npx vitest run `
  "src/core/learning/CefrVocabularyAiTeacherContextConsumer.test.ts" `
  "src/core/learning/CefrTranslationAiTeacherContextConsumer.test.ts" `
  "src/core/learning/CefrInterpretingAiTeacherContextConsumer.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 960-962 target tests failed." }

Write-Host "=== Sprint 963-965 Target Tests: Registry / Orchestration / Integrated Platform ==="
npx vitest run `
  "src/core/learning/CefrStudioAiContextRegistry.test.ts" `
  "src/core/learning/CefrStudioAiContextOrchestration.test.ts" `
  "src/core/learning/CefrIntegratedAiLearningContextPlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 963-965 target tests failed." }

Write-Host "=== Combined Sprint 960-965 New Tests ==="
npx vitest run `
  "src/core/learning/CefrVocabularyAiTeacherContextConsumer.test.ts" `
  "src/core/learning/CefrTranslationAiTeacherContextConsumer.test.ts" `
  "src/core/learning/CefrInterpretingAiTeacherContextConsumer.test.ts" `
  "src/core/learning/CefrStudioAiContextRegistry.test.ts" `
  "src/core/learning/CefrStudioAiContextOrchestration.test.ts" `
  "src/core/learning/CefrIntegratedAiLearningContextPlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 960-965 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-960-965 VERIFICATION COMPLETE"
