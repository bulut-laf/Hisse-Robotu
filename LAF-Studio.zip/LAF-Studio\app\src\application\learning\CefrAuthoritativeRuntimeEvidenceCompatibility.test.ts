import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createLafCefrAuthoritativeEvidenceRegistry,
} from "../../core/learning/CefrAuthoritativeEvidenceCatalog";
import {
  findCefrAuthoritativeEvidenceDefinition,
} from "../../core/learning/CefrAuthoritativeEvidenceRegistry";
import {
  createCefrA1ConnectRuntimeEvidenceId,
  createCefrA1ConnectRuntimePayloadReference,
} from "./CefrA1ConnectRuntimeEvidenceService";
import {
  createCefrAuthoritativeRuntimeEvidenceId,
  createCefrAuthoritativeRuntimePayloadReference,
} from "./CefrAuthoritativeRuntimeEvidenceService";

describe(
  "generic CEFR runtime compatibility with stable A1 CONNECT identity",
  () => {
    it("produces exactly the same evidence and payload identities for the approved A1 definition", () => {
      const definition =
        findCefrAuthoritativeEvidenceDefinition(
          createLafCefrAuthoritativeEvidenceRegistry(),
          "a1-connect-evidence-personal-answer",
        );

      expect(definition).not.toBeNull();

      if (!definition) {
        throw new Error(
          "Expected authoritative definition.",
        );
      }

      expect(
        createCefrAuthoritativeRuntimeEvidenceId(
          definition,
          "compat-event",
        ),
      ).toBe(
        createCefrA1ConnectRuntimeEvidenceId(
          "a1-connect-evidence-personal-answer",
          "compat-event",
        ),
      );

      expect(
        createCefrAuthoritativeRuntimePayloadReference(
          definition,
          "compat-event",
        ),
      ).toBe(
        createCefrA1ConnectRuntimePayloadReference(
          {
            evidenceDefinitionId:
              "a1-connect-evidence-personal-answer",
            sourceLearningItemId:
              "a1-connect-personal-questions",
            observableBehavior:
              "Understands and answers a simple familiar personal question.",
            evidenceDirection: "response",
            userActionRequired: true,
            persistedRealEvidenceRequired:
              true,
            authoritative: true,
            masteryClaimed: false,
            competencySuccessClaimed: false,
            cefrLevelClaimed: false,
          },
          "compat-event",
        ),
      );
    });
  },
);
