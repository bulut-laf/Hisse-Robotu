﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

Write-Host "=== Repair / Install Real Lesson Completion Evidence Write Binding ==="
Set-Location $root
node ".\LAF-SPRINT-1215-1220-REV1-INSTALL.mjs"
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1215-1220 Rev1 install failed."
}

$hookFile = Join-Path $app "src\ui\hooks\useLearningSession.ts"
$lessonFile = Join-Path $app "src\ui\pages\LessonPage.tsx"

$checks = @(
    @{
        Path = $hookFile
        Pattern = 'sessionId: sessionResult.session.id,'
        Name = 'useLearningSession sessionId return'
    },
    @{
        Path = $hookFile
        Pattern = 'completedAt: sessionResult.session.completedAt,'
        Name = 'useLearningSession completedAt return'
    },
    @{
        Path = $lessonFile
        Pattern = 'recordLearningSessionCompletion({'
        Name = 'LessonPage completion evidence write'
    }
)

foreach ($check in $checks) {
    $matches = @(
        Select-String `
            -Path $check.Path `
            -SimpleMatch `
            $check.Pattern
    )

    if ($matches.Count -ne 1) {
        throw (
            $check.Name +
            " validation failed. Count=" +
            $matches.Count
        )
    }
}

Set-Location $app

Write-Host "=== Sprint 1215-1216 Target Tests: Real Completion Evidence Writer ==="
npx vitest run `
  "src/application/learning/CefrGuidanceRuntimeProfileService.test.ts"
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1215-1216 target tests failed."
}

Write-Host "=== Sprint 1217-1218 Target Tests: Safety Contract ==="
npx vitest run `
  "src/application/learning/CefrLessonCompletionEvidenceBindingSafety.test.ts"
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1217-1218 target tests failed."
}

Write-Host "=== Sprint 1219-1220 Combined Binding Tests ==="
npx vitest run `
  "src/application/learning/CefrGuidanceRuntimeProfileService.test.ts" `
  "src/application/learning/CefrLessonCompletionEvidenceBindingSafety.test.ts" `
  "src/core/learning/CefrLearningStudioEvidenceAdapter.test.ts" `
  "src/core/learning/CefrPersonalLanguageProfileEvidence.test.ts"
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1219-1220 combined binding tests failed."
}

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Full regression failed."
}

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Production build failed."
}

Write-Host "SPRINT-1215-1220 REV1 VERIFICATION COMPLETE"
