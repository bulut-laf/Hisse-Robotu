$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 1017-1019 Target Tests: Learning Focus Approval ==="
npx vitest run `
  "src/core/learning/CefrLearningFocusChoiceReview.test.ts" `
  "src/core/learning/CefrLearningFocusApprovalBoundary.test.ts" `
  "src/core/learning/CefrLearningFocusActionPlan.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1017-1019 target tests failed." }

Write-Host "=== Sprint 1020-1022 Target Tests: Studio Focus Handoff ==="
npx vitest run `
  "src/core/learning/CefrLearningFocusStudioRoute.test.ts" `
  "src/core/learning/CefrLearningFocusHandoff.test.ts" `
  "src/core/learning/CefrLearningFocusSessionActivation.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1020-1022 target tests failed." }

Write-Host "=== Sprint 1023-1025 Target Tests: Focus Feedback Loop ==="
npx vitest run `
  "src/core/learning/CefrLearningFocusOutcomeObservation.test.ts" `
  "src/core/learning/CefrLearningFocusFeedbackBundle.test.ts" `
  "src/core/learning/CefrLearningFocusClosedLoop.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1023-1025 target tests failed." }

Write-Host "=== Combined Sprint 1017-1025 New Tests ==="
npx vitest run `
  "src/core/learning/CefrLearningFocusChoiceReview.test.ts" `
  "src/core/learning/CefrLearningFocusApprovalBoundary.test.ts" `
  "src/core/learning/CefrLearningFocusActionPlan.test.ts" `
  "src/core/learning/CefrLearningFocusStudioRoute.test.ts" `
  "src/core/learning/CefrLearningFocusHandoff.test.ts" `
  "src/core/learning/CefrLearningFocusSessionActivation.test.ts" `
  "src/core/learning/CefrLearningFocusOutcomeObservation.test.ts" `
  "src/core/learning/CefrLearningFocusFeedbackBundle.test.ts" `
  "src/core/learning/CefrLearningFocusClosedLoop.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1017-1025 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-1017-1025 VERIFICATION COMPLETE"
