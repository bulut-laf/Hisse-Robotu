import { describe, expect, it } from "vitest";
import { inspectTranslationText } from "../text/TranslationTextWordInspector";
import { prepareTranslationContextualMeaningRequest } from "../text/TranslationContextualMeaning";

describe("seven-language text core", () => {
  it("inspects Spanish text with the shared locale", () => {
    const result=inspectTranslationText("Árbol árbol", "es", []);
    expect(result.uniqueWordCount).toBe(1);
  });
  it("inspects Russian Cyrillic words", () => {
    const result=inspectTranslationText("Я изучаю русский язык", "ru", []);
    expect(result.wordCount).toBe(4);
  });
  it("uses Turkish as support language for Spanish contextual meaning", () => {
    const text="Quiero aprender español.";
    const start=text.indexOf("español");
    const result=prepareTranslationContextualMeaningRequest({
      text,
      selectedWord:"español",
      selectionStart:start,
      selectionEnd:start+"español".length,
      sourceLanguage:"es",
    });
    expect(result.status).toBe("ready");
    if (result.status === "ready") expect(result.request.targetLanguage).toBe("tr");
  });
});
