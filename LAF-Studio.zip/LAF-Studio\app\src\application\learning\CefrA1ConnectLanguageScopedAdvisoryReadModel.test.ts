import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrPersonalLanguageProfileState,
  type CefrPersonalLanguageProfileState,
} from "../../core/learning/CefrPersonalLanguageProfileState";
import type {
  CefrGuidanceRuntimeProfileRepository,
} from "./CefrGuidanceRuntimeProfileRepository";
import {
  CefrA1ConnectLanguageEvidenceProvenanceRepository,
} from "./CefrA1ConnectLanguageEvidenceProvenanceRepository";
import {
  createCefrA1ConnectLanguageScopedAdvisoryReadModel,
} from "./CefrA1ConnectLanguageScopedAdvisoryReadModel";

class MemoryStorage {
  getItem(): string | null {
    return null;
  }
  setItem(): void {}
  removeItem(): void {}
}

class MemoryRepository
  implements CefrGuidanceRuntimeProfileRepository {
  private state =
    createCefrPersonalLanguageProfileState(
      [],
      [],
    );

  load(): CefrPersonalLanguageProfileState {
    return this.state;
  }

  save(
    state: CefrPersonalLanguageProfileState,
  ): void {
    this.state = state;
  }

  hasPersistedProfile(): boolean {
    return true;
  }

  clear(): void {
    this.state =
      createCefrPersonalLanguageProfileState(
        [],
        [],
      );
  }
}

describe(
  "CefrA1ConnectLanguageScopedAdvisoryReadModel",
  () => {
    it("requires an explicit target language before offering a scoped next step", () => {
      expect(
        createCefrA1ConnectLanguageScopedAdvisoryReadModel(
          new MemoryRepository(),
          new CefrA1ConnectLanguageEvidenceProvenanceRepository(
            new MemoryStorage(),
          ),
          null,
        ),
      ).toEqual({
        languageCode: null,
        selectedLanguageRequired: true,
        nextStep: null,
        crossLanguageEvidenceExcluded: true,
        automaticLessonSelection: false,
        automaticProgression: false,
      });
    });
  },
);
