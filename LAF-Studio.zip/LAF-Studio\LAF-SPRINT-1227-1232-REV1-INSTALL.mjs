import fs from "node:fs";
import path from "node:path";

const root = "D:\\Projects\\LAF-Studio";

const targets = [
  {
    file: path.join(
      root,
      "app",
      "src",
      "ui",
      "pages",
      "TextWorkshopPage.tsx",
    ),
    studio: "reading",
    functionMarker:
      "const finishReadingMode = () => {",
  },
  {
    file: path.join(
      root,
      "app",
      "src",
      "ui",
      "speaking",
      "SpeakingStudioPanel.tsx",
    ),
    studio: "speaking",
    functionMarker:
      "const completeSpeakingSession =",
  },
  {
    file: path.join(
      root,
      "app",
      "src",
      "ui",
      "dialogue",
      "DialogueRoleplayPanel.tsx",
    ),
    studio: "dialogue",
    functionMarker:
      "const completeDialogueSession = () => {",
  },
];

function eolOf(source) {
  return source.includes("\r\n") ? "\r\n" : "\n";
}

function count(source, needle) {
  return source.split(needle).length - 1;
}

function findMatchingBrace(source, openIndex) {
  let depth = 0;
  let quote = null;
  let escaped = false;
  let lineComment = false;
  let blockComment = false;

  for (let i = openIndex; i < source.length; i++) {
    const char = source[i];
    const next = source[i + 1];

    if (lineComment) {
      if (char === "\n") {
        lineComment = false;
      }
      continue;
    }

    if (blockComment) {
      if (char === "*" && next === "/") {
        blockComment = false;
        i++;
      }
      continue;
    }

    if (quote !== null) {
      if (escaped) {
        escaped = false;
        continue;
      }

      if (char === "\\") {
        escaped = true;
        continue;
      }

      if (char === quote) {
        quote = null;
      }
      continue;
    }

    if (
      char === '"' ||
      char === "'" ||
      char === "`"
    ) {
      quote = char;
      continue;
    }

    if (char === "/" && next === "/") {
      lineComment = true;
      i++;
      continue;
    }

    if (char === "/" && next === "*") {
      blockComment = true;
      i++;
      continue;
    }

    if (char === "{") {
      depth++;
      continue;
    }

    if (char === "}") {
      depth--;

      if (depth === 0) {
        return i;
      }
    }
  }

  return -1;
}

function findFunctionRange(source, marker) {
  const markerIndex = source.indexOf(marker);

  if (markerIndex < 0) {
    throw new Error(
      `completion function marker not found: ${marker}`,
    );
  }

  const openIndex = source.indexOf("{", markerIndex);

  if (openIndex < 0) {
    throw new Error(
      `completion function opening brace not found: ${marker}`,
    );
  }

  const closeIndex =
    findMatchingBrace(source, openIndex);

  if (closeIndex < 0) {
    throw new Error(
      `completion function closing brace not found: ${marker}`,
    );
  }

  return {
    markerIndex,
    openIndex,
    closeIndex,
    body: source.slice(openIndex + 1, closeIndex),
  };
}

function functionIndent(source, markerIndex) {
  const lineStart =
    source.lastIndexOf("\n", markerIndex) + 1;
  const line =
    source.slice(lineStart, markerIndex);

  return line.match(/^\s*/)?.[0] ?? "";
}

function hasStudioEvidenceCall(functionBody, studio) {
  return (
    functionBody.includes(
      "createCefrEmbeddedStudioCompletionEvidenceInput(",
    ) &&
    functionBody.includes(`"${studio}",`)
  );
}

function patchTarget(target) {
  if (!fs.existsSync(target.file)) {
    throw new Error(
      `Required UI file not found: ${target.file}`,
    );
  }

  let source =
    fs.readFileSync(target.file, "utf8");
  const eol = eolOf(source);

  const serviceImport =
    'import { CefrGuidanceRuntimeProfileService } from "../../application/learning/CefrGuidanceRuntimeProfileService";';
  const evidenceImport =
    'import { createCefrEmbeddedStudioCompletionEvidenceInput } from "../../application/learning/CefrEmbeddedStudioCompletionEvidence";';
  const repositoryImport =
    'import { LocalStorageCefrGuidanceProfileRepository } from "../storage/LocalStorageCefrGuidanceProfileRepository";';

  const missingImports = [
    serviceImport,
    evidenceImport,
    repositoryImport,
  ].filter(item => !source.includes(item));

  if (missingImports.length > 0) {
    source =
      missingImports.join(eol) +
      eol +
      source;
  }

  let range =
    findFunctionRange(
      source,
      target.functionMarker,
    );

  if (
    !hasStudioEvidenceCall(
      range.body,
      target.studio,
    )
  ) {
    const indent =
      functionIndent(
        source,
        range.markerIndex,
      );
    const bodyIndent = indent + "  ";

    const block =
      eol +
      bodyIndent +
      "const cefrCompletionAt = new Date();" +
      eol +
      bodyIndent +
      "new CefrGuidanceRuntimeProfileService(" +
      eol +
      bodyIndent +
      "  new LocalStorageCefrGuidanceProfileRepository()," +
      eol +
      bodyIndent +
      ").recordLearningStudioEvidence(" +
      eol +
      bodyIndent +
      "  createCefrEmbeddedStudioCompletionEvidenceInput(" +
      eol +
      bodyIndent +
      `    "${target.studio}",` +
      eol +
      bodyIndent +
      "    cefrCompletionAt," +
      eol +
      bodyIndent +
      "  )," +
      eol +
      bodyIndent +
      ");" +
      eol +
      indent;

    source =
      source.slice(0, range.closeIndex) +
      block +
      source.slice(range.closeIndex);

    range =
      findFunctionRange(
        source,
        target.functionMarker,
      );
  }

  const validation = {
    serviceImport:
      count(source, serviceImport),
    evidenceImport:
      count(source, evidenceImport),
    repositoryImport:
      count(source, repositoryImport),
    genericEvidenceCall:
      count(
        range.body,
        "createCefrEmbeddedStudioCompletionEvidenceInput(",
      ),
    studioArgument:
      count(
        range.body,
        `"${target.studio}",`,
      ),
    persistenceWrite:
      count(
        range.body,
        ").recordLearningStudioEvidence(",
      ),
  };

  for (const [name, value] of Object.entries(
    validation,
  )) {
    if (value !== 1) {
      throw new Error(
        `${target.studio}: validation failed: ${name}=${value}`,
      );
    }
  }

  fs.writeFileSync(
    target.file,
    source,
    "utf8",
  );

  console.log(
    `OK: ${target.studio} completion evidence binding`,
  );
}

try {
  for (const target of targets) {
    patchTarget(target);
  }

  console.log("");
  console.log(
    "SPRINT-1227-1232 REV1 INSTALL COMPLETE",
  );
} catch (error) {
  console.error("");
  console.error(
    "SPRINT-1227-1232 REV1 INSTALL ERROR",
  );
  console.error(
    error instanceof Error
      ? error.message
      : String(error),
  );
  process.exit(1);
}
