import type {
  LafLearningLanguageCode,
} from "../../core/language/LafLanguageProfile";
import {
  getLafA1NavigateLanguageContentPack,
  type CefrA1NavigateRealizedPhrase,
} from "../../core/learning/CefrA1NavigateLanguageContentRegistry";
import {
  getLafA1NavigateSecondWaveTask,
  isLafA1NavigateSecondWaveSingleTask,
  type CefrA1NavigateSecondWaveSingleTaskId,
} from "../../core/learning/CefrA1NavigateSecondWaveExecutableTaskDefinition";
import type {
  CefrAuthoritativeLanguageRuntimeEvidenceResult,
} from "./CefrAuthoritativeLanguageRuntimeEvidenceService";
import {
  CefrProductionRuntimePlatform,
} from "./CefrProductionRuntimePlatform";

export interface CefrA1NavigateSecondWaveSingleTaskView {
  readonly taskId:
    CefrA1NavigateSecondWaveSingleTaskId;
  readonly lessonId: string;
  readonly evidenceDefinitionId: string;
  readonly taskKind:
    | "listening-meaning-selection"
    | "reading-meaning-selection";
  readonly languageCode:
    LafLearningLanguageCode;
  readonly promptPhrase:
    CefrA1NavigateRealizedPhrase;
  readonly options:
    readonly CefrA1NavigateRealizedPhrase[];
  readonly correctAnswerExposed: false;
  readonly evidenceWritten: false;
}

export interface CefrA1NavigateSecondWaveSelectionInput {
  readonly taskId:
    CefrA1NavigateSecondWaveSingleTaskId;
  readonly languageCode:
    LafLearningLanguageCode;
  readonly selectedPhraseId: string;
  readonly eventId: string;
  readonly occurredAt: Date;
  readonly userActionConfirmed: boolean;
}

export interface CefrA1NavigateSecondWaveSelectionResult {
  readonly taskId:
    CefrA1NavigateSecondWaveSingleTaskId;
  readonly evidenceDefinitionId: string;
  readonly correct: boolean;
  readonly evidenceWritten: boolean;
  readonly runtime:
    CefrAuthoritativeLanguageRuntimeEvidenceResult | null;
  readonly masteryAssigned: false;
  readonly competencySuccessAssigned: false;
  readonly cefrLevelAssigned: false;
  readonly progressionPerformed: false;
  readonly automaticTransactionCompletionPerformed:
    false;
}

export interface CefrA1NavigateReciprocalExchangeView {
  readonly taskId:
    "a1-navigate-task-reciprocal-exchange";
  readonly lessonId:
    "a1-navigate-complete-need-exchange";
  readonly evidenceDefinitionId:
    "a1-navigate-evidence-reciprocal-exchange";
  readonly languageCode:
    LafLearningLanguageCode;
  readonly options:
    readonly CefrA1NavigateRealizedPhrase[];
  readonly requiredStepCount: 3;
  readonly correctSequenceExposed: false;
  readonly evidenceWritten: false;
}

export interface CefrA1NavigateReciprocalExchangeInput {
  readonly languageCode:
    LafLearningLanguageCode;
  readonly selectedPhraseIds:
    readonly string[];
  readonly eventId: string;
  readonly occurredAt: Date;
  readonly userActionConfirmed: boolean;
}

export interface CefrA1NavigateReciprocalExchangeResult {
  readonly correctPrefix: boolean;
  readonly complete: boolean;
  readonly evidenceWritten: boolean;
  readonly runtime:
    CefrAuthoritativeLanguageRuntimeEvidenceResult | null;
  readonly masteryAssigned: false;
  readonly competencySuccessAssigned: false;
  readonly cefrLevelAssigned: false;
  readonly progressionPerformed: false;
  readonly automaticTransactionCompletionPerformed:
    false;
}

export class CefrA1NavigateSecondWaveExecutableTaskService {
  private readonly platform:
    CefrProductionRuntimePlatform;

  constructor(
    platform: CefrProductionRuntimePlatform,
  ) {
    this.platform = platform;
  }

  getSingleTaskView(
    taskId:
      CefrA1NavigateSecondWaveSingleTaskId,
    languageCode:
      LafLearningLanguageCode,
  ): CefrA1NavigateSecondWaveSingleTaskView {
    const task =
      getLafA1NavigateSecondWaveTask(
        taskId,
      );

    if (
      !isLafA1NavigateSecondWaveSingleTask(
        task,
      )
    ) {
      throw new Error(
        `A1 NAVIGATE task is not a single selection task: ${taskId}`,
      );
    }

    const pack =
      getLafA1NavigateLanguageContentPack(
        languageCode,
      );
    const lesson =
      pack.lessons.find(
        item =>
          item.lessonId === task.lessonId,
      );

    if (!lesson) {
      throw new Error(
        `A1 NAVIGATE second-wave language content missing: ${taskId}/${languageCode}`,
      );
    }

    const promptPhrase =
      lesson.phrases.find(
        phrase =>
          phrase.phraseId ===
          task.promptPhraseId,
      );

    if (!promptPhrase) {
      throw new Error(
        `A1 NAVIGATE second-wave prompt missing: ${taskId}/${languageCode}`,
      );
    }

    if (
      !lesson.phrases.some(
        phrase =>
          phrase.phraseId ===
          task.correctPhraseId,
      )
    ) {
      throw new Error(
        `A1 NAVIGATE second-wave answer missing: ${taskId}/${languageCode}`,
      );
    }

    return {
      taskId,
      lessonId: task.lessonId,
      evidenceDefinitionId:
        task.evidenceDefinitionId,
      taskKind: task.taskKind,
      languageCode,
      promptPhrase,
      options: lesson.phrases,
      correctAnswerExposed: false,
      evidenceWritten: false,
    };
  }

  executeSingleSelection(
    input:
      CefrA1NavigateSecondWaveSelectionInput,
  ): CefrA1NavigateSecondWaveSelectionResult {
    if (!input.userActionConfirmed) {
      throw new Error(
        "Explicit user action confirmation is required for A1 NAVIGATE evidence.",
      );
    }

    const task =
      getLafA1NavigateSecondWaveTask(
        input.taskId,
      );

    if (
      !isLafA1NavigateSecondWaveSingleTask(
        task,
      )
    ) {
      throw new Error(
        `A1 NAVIGATE task is not a single selection task: ${input.taskId}`,
      );
    }

    const view =
      this.getSingleTaskView(
        input.taskId,
        input.languageCode,
      );

    if (
      !view.options.some(
        option =>
          option.phraseId ===
          input.selectedPhraseId,
      )
    ) {
      throw new Error(
        `Unknown A1 NAVIGATE second-wave option: ${input.selectedPhraseId}`,
      );
    }

    const correct =
      input.selectedPhraseId ===
      task.correctPhraseId;

    if (!correct) {
      return {
        taskId: input.taskId,
        evidenceDefinitionId:
          task.evidenceDefinitionId,
        correct: false,
        evidenceWritten: false,
        runtime: null,
        masteryAssigned: false,
        competencySuccessAssigned: false,
        cefrLevelAssigned: false,
        progressionPerformed: false,
        automaticTransactionCompletionPerformed:
          false,
      };
    }

    const runtime =
      this.platform.recordUserEvidence(
        "a1-navigate",
        {
          evidenceDefinitionId:
            task.evidenceDefinitionId,
          eventId: input.eventId,
          occurredAt: input.occurredAt,
          languageCode:
            input.languageCode,
          userActionConfirmed: true,
        },
      );

    return {
      taskId: input.taskId,
      evidenceDefinitionId:
        task.evidenceDefinitionId,
      correct: true,
      evidenceWritten: true,
      runtime,
      masteryAssigned: false,
      competencySuccessAssigned: false,
      cefrLevelAssigned: false,
      progressionPerformed: false,
      automaticTransactionCompletionPerformed:
        false,
    };
  }

  getReciprocalExchangeView(
    languageCode:
      LafLearningLanguageCode,
  ): CefrA1NavigateReciprocalExchangeView {
    const task =
      getLafA1NavigateSecondWaveTask(
        "a1-navigate-task-reciprocal-exchange",
      );

    if (
      task.taskKind !==
      "controlled-reciprocal-sequence"
    ) {
      throw new Error(
        "A1 NAVIGATE reciprocal task definition is invalid.",
      );
    }

    const pack =
      getLafA1NavigateLanguageContentPack(
        languageCode,
      );
    const lesson =
      pack.lessons.find(
        item =>
          item.lessonId === task.lessonId,
      );

    if (!lesson) {
      throw new Error(
        `A1 NAVIGATE reciprocal language content missing: ${languageCode}`,
      );
    }

    for (
      const phraseId of
      task.expectedPhraseIds
    ) {
      if (
        !lesson.phrases.some(
          phrase =>
            phrase.phraseId === phraseId,
        )
      ) {
        throw new Error(
          `A1 NAVIGATE reciprocal phrase missing: ${phraseId}/${languageCode}`,
        );
      }
    }

    return {
      taskId: task.taskId,
      lessonId: task.lessonId,
      evidenceDefinitionId:
        task.evidenceDefinitionId,
      languageCode,
      options: lesson.phrases,
      requiredStepCount: 3,
      correctSequenceExposed: false,
      evidenceWritten: false,
    };
  }

  executeReciprocalExchange(
    input:
      CefrA1NavigateReciprocalExchangeInput,
  ): CefrA1NavigateReciprocalExchangeResult {
    if (!input.userActionConfirmed) {
      throw new Error(
        "Explicit user action confirmation is required for A1 NAVIGATE evidence.",
      );
    }

    const task =
      getLafA1NavigateSecondWaveTask(
        "a1-navigate-task-reciprocal-exchange",
      );

    if (
      task.taskKind !==
      "controlled-reciprocal-sequence"
    ) {
      throw new Error(
        "A1 NAVIGATE reciprocal task definition is invalid.",
      );
    }

    const view =
      this.getReciprocalExchangeView(
        input.languageCode,
      );

    if (
      input.selectedPhraseIds.length >
      task.expectedPhraseIds.length
    ) {
      throw new Error(
        "A1 NAVIGATE reciprocal sequence exceeds the approved step count.",
      );
    }

    for (
      const phraseId of
      input.selectedPhraseIds
    ) {
      if (
        !view.options.some(
          option =>
            option.phraseId === phraseId,
        )
      ) {
        throw new Error(
          `Unknown A1 NAVIGATE reciprocal option: ${phraseId}`,
        );
      }
    }

    const correctPrefix =
      input.selectedPhraseIds.every(
        (phraseId, index) =>
          phraseId ===
          task.expectedPhraseIds[index],
      );

    const complete =
      correctPrefix &&
      input.selectedPhraseIds.length ===
        task.expectedPhraseIds.length;

    if (!complete) {
      return {
        correctPrefix,
        complete: false,
        evidenceWritten: false,
        runtime: null,
        masteryAssigned: false,
        competencySuccessAssigned: false,
        cefrLevelAssigned: false,
        progressionPerformed: false,
        automaticTransactionCompletionPerformed:
          false,
      };
    }

    const runtime =
      this.platform.recordUserEvidence(
        "a1-navigate",
        {
          evidenceDefinitionId:
            task.evidenceDefinitionId,
          eventId: input.eventId,
          occurredAt: input.occurredAt,
          languageCode:
            input.languageCode,
          userActionConfirmed: true,
        },
      );

    return {
      correctPrefix: true,
      complete: true,
      evidenceWritten: true,
      runtime,
      masteryAssigned: false,
      competencySuccessAssigned: false,
      cefrLevelAssigned: false,
      progressionPerformed: false,
      automaticTransactionCompletionPerformed:
        false,
    };
  }
}
