import type {
  CefrA1ConnectExtendedChoiceTask,
} from "../../core/learning/CefrA1ConnectExtendedExecutableTasks";

export interface CefrA1ConnectExtendedTaskEvaluation {
  readonly submitted: true;
  readonly correct: boolean;
  readonly evidenceEligible: boolean;
  readonly masteryAssigned: false;
  readonly competencySuccessAssigned: false;
  readonly cefrLevelAssigned: false;
  readonly progressionPerformed: false;
}

export function evaluateCefrA1ConnectExtendedChoiceTask(
  task: CefrA1ConnectExtendedChoiceTask,
  submittedAnswer: string,
): CefrA1ConnectExtendedTaskEvaluation {
  const correct =
    submittedAnswer === task.correctAnswer;

  return {
    submitted: true,
    correct,
    evidenceEligible: correct,
    masteryAssigned: false,
    competencySuccessAssigned: false,
    cefrLevelAssigned: false,
    progressionPerformed: false,
  };
}
