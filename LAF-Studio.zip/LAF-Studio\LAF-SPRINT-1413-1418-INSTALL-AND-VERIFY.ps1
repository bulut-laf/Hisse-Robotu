﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

$required = @(
    "src\core\learning\CefrAuthoritativeLanguageEvidenceProvenance.ts",
    "src\core\learning\CefrLanguageEvidenceProvenanceAuthority.ts",
    "src\core\learning\CefrLanguageEvidenceProvenanceRecoveryRecord.ts",
    "src\application\learning\CefrAuthoritativeLanguageEvidenceProvenanceRepository.ts",
    "src\application\learning\CefrLanguageEvidenceProvenanceRecoveryRepository.ts",
    "src\application\learning\CefrLanguageEvidenceProvenanceCoordinator.ts",
    "src\application\learning\CefrAuthoritativeLanguageRuntimeEvidenceService.ts",
    "src\core\learning\CefrGenericLanguageEvidenceProvenanceSafety.ts"
)

foreach ($relative in $required) {
    $path = Join-Path $app $relative

    if (-not (Test-Path $path)) {
        throw "Sprint 1413-1418 source missing: $relative"
    }
}

$markers = @(
    @(
        "src\core\learning\CefrLanguageEvidenceProvenanceAuthority.ts",
        "laf.cefr.a1-connect.language-evidence-provenance.v1"
    ),
    @(
        "src\core\learning\CefrLanguageEvidenceProvenanceAuthority.ts",
        "laf.cefr.a1-connect.provenance-recovery.v1"
    ),
    @(
        "src\core\learning\CefrLanguageEvidenceProvenanceAuthority.ts",
        "targetLanguageInferenceAllowed:"
    ),
    @(
        "src\application\learning\CefrAuthoritativeLanguageRuntimeEvidenceService.ts",
        "CefrAuthoritativeRuntimeEvidenceService"
    ),
    @(
        "src\application\learning\CefrAuthoritativeLanguageRuntimeEvidenceService.ts",
        "recordPersistedEvidenceLanguage"
    ),
    @(
        "src\application\learning\CefrLanguageEvidenceProvenanceCoordinator.ts",
        "recoveryQueued: true"
    ),
    @(
        "src\core\learning\CefrGenericLanguageEvidenceProvenanceSafety.ts",
        "existingA1StorageIdentityPreserved:"
    ),
    @(
        "src\core\learning\CefrGenericLanguageEvidenceProvenanceSafety.ts",
        "automaticProgressionAllowed: false"
    )
)

foreach ($pair in $markers) {
    $path = Join-Path $app $pair[0]

    if (-not (
        Select-String `
            -Path $path `
            -SimpleMatch `
            -Pattern $pair[1] `
            -Quiet
    )) {
        throw "Sprint 1413-1418 marker missing: $($pair[1])"
    }
}

Write-Host "SPRINT-1413-1418 SOURCE CHECK PASSED"

Set-Location $app

$targets = @(
    "src/core/learning/CefrAuthoritativeLanguageEvidenceProvenance.test.ts",
    "src/core/learning/CefrLanguageEvidenceProvenanceAuthority.test.ts",
    "src/core/learning/CefrLanguageEvidenceProvenanceRecoveryRecord.test.ts",
    "src/application/learning/CefrAuthoritativeLanguageEvidenceProvenanceRepository.test.ts",
    "src/application/learning/CefrLanguageEvidenceProvenanceRecoveryRepository.test.ts",
    "src/application/learning/CefrLanguageEvidenceProvenanceCoordinator.test.ts",
    "src/application/learning/CefrAuthoritativeLanguageRuntimeEvidenceService.test.ts",
    "src/application/learning/CefrA1ConnectGenericProvenanceCompatibility.test.ts",
    "src/core/learning/CefrGenericLanguageEvidenceProvenanceSafety.test.ts",
    "src/application/learning/CefrAuthoritativeRuntimeEvidenceService.test.ts",
    "src/application/learning/CefrA1ConnectLanguageEvidenceProvenanceRepository.test.ts",
    "src/application/learning/CefrA1ConnectEvidenceProvenanceCoordinator.test.ts"
)

& npx vitest run $targets
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1413-1418 target tests failed."
}

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Full regression failed."
}

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Production build failed."
}

Write-Host "SPRINT-1413-1418 VERIFICATION COMPLETE"
