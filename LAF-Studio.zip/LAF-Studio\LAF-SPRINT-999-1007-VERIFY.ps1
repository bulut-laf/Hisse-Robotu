$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 999-1001 Target Tests: Evidence Re-entry ==="
npx vitest run `
  "src/core/learning/CefrGuidedEvidenceReentry.test.ts" `
  "src/core/learning/CefrProfileRefreshEvidence.test.ts" `
  "src/core/learning/CefrProfileRefreshPreparation.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 999-1001 target tests failed." }

Write-Host "=== Sprint 1002-1004 Target Tests: Personal Profile and Context Refresh ==="
npx vitest run `
  "src/core/learning/CefrPersonalLanguageProfileRefresh.test.ts" `
  "src/core/learning/CefrLearnerContextRefresh.test.ts" `
  "src/core/learning/CefrAiTeacherContextRefresh.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1002-1004 target tests failed." }

Write-Host "=== Sprint 1005-1007 Target Tests: Recommendation Refresh and Closed Loop ==="
npx vitest run `
  "src/core/learning/CefrRecommendationRefresh.test.ts" `
  "src/core/learning/CefrStudioRecommendationRefresh.test.ts" `
  "src/core/learning/CefrClosedLoopGuidanceCycle.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1005-1007 target tests failed." }

Write-Host "=== Combined Sprint 999-1007 New Tests ==="
npx vitest run `
  "src/core/learning/CefrGuidedEvidenceReentry.test.ts" `
  "src/core/learning/CefrProfileRefreshEvidence.test.ts" `
  "src/core/learning/CefrProfileRefreshPreparation.test.ts" `
  "src/core/learning/CefrPersonalLanguageProfileRefresh.test.ts" `
  "src/core/learning/CefrLearnerContextRefresh.test.ts" `
  "src/core/learning/CefrAiTeacherContextRefresh.test.ts" `
  "src/core/learning/CefrRecommendationRefresh.test.ts" `
  "src/core/learning/CefrStudioRecommendationRefresh.test.ts" `
  "src/core/learning/CefrClosedLoopGuidanceCycle.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 999-1007 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-999-1007 VERIFICATION COMPLETE"
