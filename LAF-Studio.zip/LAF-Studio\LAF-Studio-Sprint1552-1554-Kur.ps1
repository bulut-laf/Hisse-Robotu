
param([string]$ProjectRoot = "D:\Projects\LAF-Studio")
$ErrorActionPreference = "Stop"

function Fail([string]$m){ throw "[SPRINT-1552-1554] $m" }
function ReadText([string]$p){ [IO.File]::ReadAllText($p,[Text.Encoding]::UTF8) }
function WriteText([string]$p,[string]$t){ [IO.File]::WriteAllText($p,$t,(New-Object Text.UTF8Encoding($false))) }
function ReplaceOnce([string]$t,[string]$old,[string]$new,[string]$label){
  $i=$t.IndexOf($old,[StringComparison]::Ordinal); if($i -lt 0){Fail "Anchor yok: $label"}
  $j=$t.IndexOf($old,$i+$old.Length,[StringComparison]::Ordinal); if($j -ge 0){Fail "Anchor coklu: $label"}
  $t.Substring(0,$i)+$new+$t.Substring($i+$old.Length)
}
function InsertBeforeOnce([string]$t,[string]$a,[string]$x,[string]$label){
  $i=$t.IndexOf($a,[StringComparison]::Ordinal); if($i -lt 0){Fail "Anchor yok: $label"}
  $j=$t.IndexOf($a,$i+$a.Length,[StringComparison]::Ordinal); if($j -ge 0){Fail "Anchor coklu: $label"}
  $t.Substring(0,$i)+$x+$t.Substring($i)
}

$app = Join-Path $ProjectRoot "app"
$item = Join-Path $app "src\core\vocabulary\VocabularyItem.ts"
$service = Join-Path $app "src\core\vocabulary\VocabularyService.ts"
$tp = Join-Path $app "src\ui\pages\TranslationStudioPage.tsx"
$tw = Join-Path $app "src\ui\pages\TextWorkshopPage.tsx"
$tc = Join-Path $app "src\ui\pages\TranslationStudioPage.css"
$wc = Join-Path $app "src\ui\pages\TextWorkshopPage.css"
foreach($f in @($item,$service,$tp,$tw,$tc,$wc)){ if(-not(Test-Path $f)){Fail "Dosya yok: $f"} }

$stamp=Get-Date -Format "yyyyMMdd-HHmmss"
$backup=Join-Path $ProjectRoot "_backups\Sprint1552-1554-$stamp"
New-Item -ItemType Directory -Force -Path $backup | Out-Null
foreach($f in @($item,$service,$tp,$tw,$tc,$wc)){ Copy-Item $f (Join-Path $backup ([IO.Path]::GetFileName($f))) -Force }

try {
  # Sprint 1552
  $t=ReadText $item
  $t=ReplaceOnce $t @'
  lessonId: string;
  activityId: string;

  favorite: boolean;
'@ @'
  lessonId?: string;
  activityId?: string;

  sourceLanguage?: string;
  targetLanguage?: string;
  contextSentence?: string;
  sourceStudio?: "translation-studio" | "text-workshop";

  favorite: boolean;
'@ "VocabularyItem"
  WriteText $item $t

  $t=ReadText $service
  $t=ReplaceOnce $t @'
    const exists = items.some(
      (vocabulary) =>
        vocabulary.word === item.word &&
        vocabulary.languageCode ===
          item.languageCode,
    );
'@ @'
    const normalize = (value: string) =>
      value
        .normalize("NFKC")
        .toLocaleLowerCase()
        .replace(/\s+/g, " ")
        .trim();

    const exists = items.some(
      (vocabulary) =>
        normalize(vocabulary.word) === normalize(item.word) &&
        vocabulary.languageCode === item.languageCode &&
        normalize(vocabulary.meaning) === normalize(item.meaning),
    );
'@ "VocabularyService duplicate"
  WriteText $service $t

  $shared=Join-Path $app "src\ui\vocabulary"
  New-Item -ItemType Directory -Force -Path $shared | Out-Null

  WriteText (Join-Path $shared "StudioVocabularyCapture.ts") @'
import type { VocabularyItem } from "../../core/vocabulary/VocabularyItem";
import { VocabularyService } from "../../core/vocabulary/VocabularyService";

export interface StudioVocabularyCaptureInput {
  sourceExpression: string;
  sourceLanguage: string;
  targetMeaning: string;
  targetLanguage: string;
  contextSentence?: string;
  sourceStudio: "translation-studio" | "text-workshop";
}

export type StudioVocabularySaveResult =
  | { status: "added"; item: VocabularyItem }
  | { status: "duplicate"; item: VocabularyItem };

const normalize = (value: string) =>
  value.normalize("NFKC").toLocaleLowerCase().replace(/\s+/g, " ").trim();

export const findStudioVocabularyDuplicate = (
  service: VocabularyService,
  input: StudioVocabularyCaptureInput,
): VocabularyItem | undefined =>
  service.getAll().find(
    item =>
      normalize(item.word) === normalize(input.sourceExpression) &&
      item.languageCode === input.sourceLanguage &&
      normalize(item.meaning) === normalize(input.targetMeaning),
  );

export const saveStudioVocabularyCapture = (
  service: VocabularyService,
  input: StudioVocabularyCaptureInput,
): StudioVocabularySaveResult => {
  const duplicate = findStudioVocabularyDuplicate(service, input);
  if (duplicate) return { status: "duplicate", item: duplicate };

  const now = new Date().toISOString();
  const item: VocabularyItem = {
    id:
      typeof crypto !== "undefined" && typeof crypto.randomUUID === "function"
        ? crypto.randomUUID()
        : `studio-vocabulary-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`,
    word: input.sourceExpression.trim(),
    meaning: input.targetMeaning.trim(),
    languageCode: input.sourceLanguage,
    sourceLanguage: input.sourceLanguage,
    targetLanguage: input.targetLanguage,
    contextSentence: input.contextSentence?.trim() || undefined,
    sourceStudio: input.sourceStudio,
    favorite: false,
    createdAt: now,
    updatedAt: now,
  };

  service.add(item);
  return { status: "added", item };
};
'@

  WriteText (Join-Path $shared "StudioVocabularyCapture.css") @'
.studio-vocabulary-preview{margin-top:.75rem;padding:1rem;border:1px solid rgba(84,96,220,.2);border-radius:14px;background:rgba(84,96,220,.04)}
.studio-vocabulary-preview__grid{display:grid;gap:.75rem;margin-top:.75rem}
.studio-vocabulary-preview label{display:grid;gap:.35rem}
.studio-vocabulary-preview input,.studio-vocabulary-preview textarea{width:100%}
.studio-vocabulary-preview__actions{display:flex;flex-wrap:wrap;gap:.6rem;margin-top:.8rem}
.studio-vocabulary-message{margin-top:.6rem}
@media(max-width:720px){.studio-vocabulary-preview__actions{display:grid;grid-template-columns:1fr}}
'@

  # Sprint 1553 — Text Workshop
  $t=ReadText $tw
  $anchor='import {'+"`n"+'  LocalStorageTranslationLearningVocabularyStorage,'
  if($t.IndexOf($anchor) -lt 0){$anchor='import {'+"`r`n"+'  LocalStorageTranslationLearningVocabularyStorage,'}
  $t=InsertBeforeOnce $t $anchor @'
import { VocabularyService } from "../../core/vocabulary/VocabularyService";
import { saveStudioVocabularyCapture } from "../vocabulary/StudioVocabularyCapture";
import "../vocabulary/StudioVocabularyCapture.css";
'@+"`n" "TW imports"

  $anchor='  const ['+"`n"+'    learningVocabularyMessage,'
  if($t.IndexOf($anchor) -lt 0){$anchor='  const ['+"`r`n"+'    learningVocabularyMessage,'}
  $t=InsertBeforeOnce $t $anchor @'
  const authoritativeVocabularyService = useMemo(
    () => new VocabularyService(),
    [],
  );
  const [studioVocabularyPreviewOpen, setStudioVocabularyPreviewOpen] =
    useState(false);
  const [studioVocabularyMeaning, setStudioVocabularyMeaning] =
    useState("");
  const [studioVocabularyMessage, setStudioVocabularyMessage] =
    useState("");

'@ "TW states"

  $t=InsertBeforeOnce $t '  const addCurrentContextualResultToLearning =' @'
  const openCurrentContextualResultVocabularyPreview = () => {
    if (!selectedToken || !contextualResult) return;
    setStudioVocabularyMeaning(contextualResult.meaning);
    setStudioVocabularyMessage("");
    setStudioVocabularyPreviewOpen(true);
  };

  const saveCurrentContextualResultToVocabulary = () => {
    if (!selectedToken || !contextualResult || !studioVocabularyMeaning.trim()) return;

    const result = saveStudioVocabularyCapture(
      authoritativeVocabularyService,
      {
        sourceExpression: selectedToken.value,
        sourceLanguage: language,
        targetMeaning: studioVocabularyMeaning,
        targetLanguage: getTranslationLearningSupportLanguage(language),
        contextSentence: contextualRequest?.contextSentence ?? "",
        sourceStudio: "text-workshop",
      },
    );

    if (result.status === "duplicate") {
      setStudioVocabularyMessage("Bu kelime Kelime Defterinde zaten var.");
      return;
    }

    setStudioVocabularyMessage("Kelime Defterine eklendi.");
    setStudioVocabularyPreviewOpen(false);
  };

'@ "TW handlers"

  $button=@'
                          <button
                            type="button"
                            onClick={
                              addCurrentContextualResultToLearning
                            }
                          >
'@
  $t=InsertBeforeOnce $t $button @'
                          <button
                            type="button"
                            onClick={openCurrentContextualResultVocabularyPreview}
                          >
                            Kelime Defterine Ekle
                          </button>
'@ "TW add button"

  $needle='openCurrentContextualResultVocabularyPreview'
  $p0=$t.IndexOf($needle,[StringComparison]::Ordinal)
  $end='                        </article>'+"`n"+'                      )}'
  $p1=$t.IndexOf($end,$p0,[StringComparison]::Ordinal)
  if($p1 -lt 0){
    $end='                        </article>'+"`r`n"+'                      )}'
    $p1=$t.IndexOf($end,$p0,[StringComparison]::Ordinal)
  }
  if($p1 -lt 0){Fail "TW contextual card end yok"}

  $preview=@'
                        {studioVocabularyPreviewOpen && selectedToken && (
                          <section className="studio-vocabulary-preview">
                            <strong>Kelime Defterine Ekle</strong>
                            <div className="studio-vocabulary-preview__grid">
                              <label>
                                <span>Kaynak ifade</span>
                                <input value={selectedToken.value} readOnly />
                              </label>
                              <label>
                                <span>Hedef karşılık</span>
                                <input
                                  value={studioVocabularyMeaning}
                                  onChange={event =>
                                    setStudioVocabularyMeaning(event.target.value)
                                  }
                                />
                              </label>
                              {contextualRequest?.contextSentence ? (
                                <label>
                                  <span>Bağlam</span>
                                  <textarea value={contextualRequest.contextSentence} readOnly />
                                </label>
                              ) : null}
                            </div>
                            <div className="studio-vocabulary-preview__actions">
                              <button
                                type="button"
                                disabled={!studioVocabularyMeaning.trim()}
                                onClick={saveCurrentContextualResultToVocabulary}
                              >
                                Kelime Defterine Kaydet
                              </button>
                              <button
                                type="button"
                                onClick={() => setStudioVocabularyPreviewOpen(false)}
                              >
                                Vazgeç
                              </button>
                            </div>
                          </section>
                        )}
                        {studioVocabularyMessage ? (
                          <p className="studio-vocabulary-message" role="status">
                            {studioVocabularyMessage}
                          </p>
                        ) : null}
'@
  $t=$t.Substring(0,$p1)+$preview+$t.Substring($p1)
  WriteText $tw $t

  # Sprint 1554 — Translation Studio
  $t=ReadText $tp
  $t=InsertBeforeOnce $t 'import "./TranslationStudioPage.css";' @'
import { VocabularyService } from "../../core/vocabulary/VocabularyService";
import { saveStudioVocabularyCapture } from "../vocabulary/StudioVocabularyCapture";
import "../vocabulary/StudioVocabularyCapture.css";
'@+"`n" "TP imports"

  $t=InsertBeforeOnce $t '  const [sourceText, setSourceText] =' @'
  const authoritativeVocabularyService = useMemo(
    () => new VocabularyService(),
    [],
  );
  const [vocabularySelection, setVocabularySelection] = useState("");
  const [vocabularyMeaning, setVocabularyMeaning] = useState("");
  const [vocabularyPreviewOpen, setVocabularyPreviewOpen] = useState(false);
  const [vocabularyMessage, setVocabularyMessage] = useState("");

'@ "TP states"

  $t=InsertBeforeOnce $t '  const handleSegmentDraftChange =' @'
  const captureSourceVocabularySelection = (target: HTMLTextAreaElement) => {
    const selected = target.value
      .slice(target.selectionStart, target.selectionEnd)
      .trim();

    setVocabularySelection(selected);
    setVocabularyMessage("");
    if (!selected) setVocabularyPreviewOpen(false);
  };

  const openTranslationVocabularyPreview = () => {
    if (!vocabularySelection.trim()) return;
    setVocabularyMeaning("");
    setVocabularyMessage("");
    setVocabularyPreviewOpen(true);
  };

  const saveTranslationVocabulary = () => {
    if (!vocabularySelection.trim() || !vocabularyMeaning.trim()) return;

    const result = saveStudioVocabularyCapture(
      authoritativeVocabularyService,
      {
        sourceExpression: vocabularySelection,
        sourceLanguage,
        targetMeaning: vocabularyMeaning,
        targetLanguage,
        contextSentence: activeSegment?.text ?? "",
        sourceStudio: "translation-studio",
      },
    );

    if (result.status === "duplicate") {
      setVocabularyMessage("Bu kelime Kelime Defterinde zaten var.");
      return;
    }

    setVocabularyMessage("Kelime Defterine eklendi.");
    setVocabularyPreviewOpen(false);
  };

'@ "TP handlers"

  $t=ReplaceOnce $t @'
            <textarea
              value={sourceText}
'@ @'
            <textarea
              value={sourceText}
              onSelect={event =>
                captureSourceVocabularySelection(event.currentTarget)
              }
              onMouseUp={event =>
                captureSourceVocabularySelection(event.currentTarget)
              }
              onKeyUp={event =>
                captureSourceVocabularySelection(event.currentTarget)
              }
'@ "TP source selection"

  $anchor=@'
        </div>

        {sourceSegments.length > 0 ? (
'@
  $replacement=@'
        </div>

        {vocabularySelection ? (
          <section className="studio-vocabulary-preview">
            <strong>Kelime Defterine Ekle</strong>
            <p>
              Seçili ifade: <strong>{vocabularySelection}</strong>
            </p>
            {!vocabularyPreviewOpen ? (
              <button type="button" onClick={openTranslationVocabularyPreview}>
                Kelime Defterine Ekle
              </button>
            ) : (
              <>
                <div className="studio-vocabulary-preview__grid">
                  <label>
                    <span>Kaynak ifade</span>
                    <input value={vocabularySelection} readOnly />
                  </label>
                  <label>
                    <span>Hedef karşılık</span>
                    <input
                      value={vocabularyMeaning}
                      onChange={event => setVocabularyMeaning(event.target.value)}
                      placeholder="Hedef karşılığı girin"
                    />
                  </label>
                  {activeSegment?.text ? (
                    <label>
                      <span>Bağlam</span>
                      <textarea value={activeSegment.text} readOnly />
                    </label>
                  ) : null}
                </div>
                <div className="studio-vocabulary-preview__actions">
                  <button
                    type="button"
                    disabled={!vocabularyMeaning.trim()}
                    onClick={saveTranslationVocabulary}
                  >
                    Kelime Defterine Kaydet
                  </button>
                  <button
                    type="button"
                    onClick={() => setVocabularyPreviewOpen(false)}
                  >
                    Vazgeç
                  </button>
                </div>
              </>
            )}
            {vocabularyMessage ? (
              <p className="studio-vocabulary-message" role="status">
                {vocabularyMessage}
              </p>
            ) : null}
          </section>
        ) : null}

        {sourceSegments.length > 0 ? (
'@
  $t=ReplaceOnce $t $anchor $replacement "TP preview"
  WriteText $tp $t

  # target tests
  WriteText (Join-Path $shared "StudioVocabularyCapture.test.ts") @'
import { describe, expect, it } from "vitest";
import { VocabularyService } from "../../core/vocabulary/VocabularyService";
import { saveStudioVocabularyCapture } from "./StudioVocabularyCapture";

class MemoryStorage {
  private readonly values = new Map<string, string>();
  getItem(key: string) { return this.values.get(key) ?? null; }
  setItem(key: string, value: string) { this.values.set(key, value); }
  removeItem(key: string) { this.values.delete(key); }
  clear() { this.values.clear(); }
  key(index: number) { return [...this.values.keys()][index] ?? null; }
  get length() { return this.values.size; }
}

describe("StudioVocabularyCapture", () => {
  it("writes through authoritative VocabularyService", () => {
    const old = globalThis.localStorage;
    Object.defineProperty(globalThis, "localStorage", {
      value: new MemoryStorage(),
      configurable: true,
    });
    try {
      const service = new VocabularyService();
      expect(
        saveStudioVocabularyCapture(service, {
          sourceExpression: "diagnózis",
          sourceLanguage: "hu",
          targetMeaning: "teşhis",
          targetLanguage: "tr",
          contextSentence: "Ha igaz a diagnózisom.",
          sourceStudio: "translation-studio",
        }).status,
      ).toBe("added");
      expect(service.getAll()[0]).toMatchObject({
        word: "diagnózis",
        meaning: "teşhis",
        sourceStudio: "translation-studio",
      });
    } finally {
      Object.defineProperty(globalThis, "localStorage", {
        value: old,
        configurable: true,
      });
    }
  });

  it("blocks exact semantic duplicate and allows another meaning", () => {
    const old = globalThis.localStorage;
    Object.defineProperty(globalThis, "localStorage", {
      value: new MemoryStorage(),
      configurable: true,
    });
    try {
      const service = new VocabularyService();
      const base = {
        sourceExpression: "bank",
        sourceLanguage: "en",
        targetMeaning: "banka",
        targetLanguage: "tr",
        contextSentence: "",
        sourceStudio: "text-workshop" as const,
      };

      expect(saveStudioVocabularyCapture(service, base).status).toBe("added");
      expect(
        saveStudioVocabularyCapture(service, {
          ...base,
          sourceExpression: " BANK ",
          targetMeaning: " BANKA ",
        }).status,
      ).toBe("duplicate");
      expect(
        saveStudioVocabularyCapture(service, {
          ...base,
          targetMeaning: "kıyı",
        }).status,
      ).toBe("added");
      expect(service.getAll()).toHaveLength(2);
    } finally {
      Object.defineProperty(globalThis, "localStorage", {
        value: old,
        configurable: true,
      });
    }
  });
});
'@

  Push-Location $app
  try {
    Write-Host "`n=== TARGET TEST ==="
    npm test -- --run "src/ui/vocabulary/StudioVocabularyCapture.test.ts"
    if($LASTEXITCODE -ne 0){Fail "Target test basarisiz"}

    Write-Host "`n=== FULL REGRESSION ==="
    npm test -- --run
    if($LASTEXITCODE -ne 0){Fail "Tam regresyon basarisiz"}

    Write-Host "`n=== PRODUCTION BUILD ==="
    npm run build
    if($LASTEXITCODE -ne 0){Fail "Production build basarisiz"}
  } finally { Pop-Location }

  $result=[ordered]@{
    block="Sprint 1552-1554"
    feature="Studio -> Kelime Defteri Controlled Add Flow V1"
    status="SUCCESS"
    backup=$backup
    completedAt=(Get-Date).ToString("o")
  } | ConvertTo-Json
  WriteText (Join-Path $ProjectRoot "SPRINT1552-1554_BLOCK_RESULT.json") $result

  Write-Host ""
  Write-Host "SPRINT-1552-1554 BASARILI"
  Write-Host "Studio -> Kelime Defteri Controlled Add Flow V1 kuruldu."
  Write-Host "Target test + tam regresyon + production build basarili."
}
catch {
  Write-Host ""
  Write-Host "HATA: $($_.Exception.Message)" -ForegroundColor Red
  foreach($f in @($item,$service,$tp,$tw,$tc,$wc)){
    $b=Join-Path $backup ([IO.Path]::GetFileName($f))
    if(Test-Path $b){Copy-Item $b $f -Force}
  }
  Remove-Item (Join-Path $app "src\ui\vocabulary\StudioVocabularyCapture.ts") -Force -ErrorAction SilentlyContinue
  Remove-Item (Join-Path $app "src\ui\vocabulary\StudioVocabularyCapture.css") -Force -ErrorAction SilentlyContinue
  Remove-Item (Join-Path $app "src\ui\vocabulary\StudioVocabularyCapture.test.ts") -Force -ErrorAction SilentlyContinue
  throw
}
