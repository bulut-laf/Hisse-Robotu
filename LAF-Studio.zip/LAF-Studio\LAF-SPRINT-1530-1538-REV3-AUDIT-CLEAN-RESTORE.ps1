﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$core = Join-Path $app "src\core\learning"

$auditPath =
    Join-Path $core "CefrProductionRuntimeEvidenceEligibilityAudit.ts"

if (-not (Test-Path $auditPath)) {
    throw "Audit source missing: $auditPath"
}

$backupRoot =
    Join-Path $root (
        "_sprint_backups\Sprint1530-1538-Rev3-" +
        (Get-Date -Format "yyyyMMdd-HHmmss")
    )

New-Item `
    -ItemType Directory `
    -Path $backupRoot `
    -Force |
    Out-Null

Copy-Item `
    -LiteralPath $auditPath `
    -Destination (
        Join-Path $backupRoot "CefrProductionRuntimeEvidenceEligibilityAudit.ts"
    ) `
    -Force

$utf8 =
    New-Object System.Text.UTF8Encoding($false)

$cleanSource = @'
import type {
  CefrRuntimeSliceRegistry,
} from "./CefrRuntimeSliceRegistry";

export const LAF_POLICY_GATED_DELAYED_RETRIEVAL_EVIDENCE_IDS =
  [
    "a1-connect-evidence-delayed-retrieval",
    "a1-navigate-evidence-delayed-retrieval",
    "a1-describe-evidence-delayed-retrieval",
    "a1-exchange-evidence-delayed-retrieval",
  ] as const;

export interface CefrProductionRuntimeEvidenceEligibilityAuditResult {
  readonly registeredSliceCount: number;
  readonly executableEvidenceDefinitionCount:
    number;
  readonly policyGatedEvidenceDefinitionIds:
    readonly string[];
  readonly exposedPolicyGatedEvidenceDefinitionIds:
    readonly string[];
  readonly valid: boolean;
  readonly failClosed: true;
  readonly timingPolicyInferred: false;
  readonly masteryAssigned: false;
  readonly cefrLevelAssigned: false;
  readonly progressionPerformed: false;
}

export function auditCefrProductionRuntimeEvidenceEligibility(
  registry: CefrRuntimeSliceRegistry,
): CefrProductionRuntimeEvidenceEligibilityAuditResult {
  const executableIds =
    registry.definitions.flatMap(
      definition =>
        definition.evidenceRegistry
          .definitions.map(
            evidence =>
              evidence.evidenceDefinitionId,
          ),
    );

  const policyGatedIds = [
    ...LAF_POLICY_GATED_DELAYED_RETRIEVAL_EVIDENCE_IDS,
  ];

  const policyGatedSet =
    new Set<string>(policyGatedIds);

  const exposed =
    executableIds.filter(
      evidenceDefinitionId =>
        policyGatedSet.has(
          evidenceDefinitionId,
        ),
    );

  return {
    registeredSliceCount:
      registry.sliceCount,
    executableEvidenceDefinitionCount:
      executableIds.length,
    policyGatedEvidenceDefinitionIds:
      policyGatedIds,
    exposedPolicyGatedEvidenceDefinitionIds:
      exposed,
    valid: exposed.length === 0,
    failClosed: true,
    timingPolicyInferred: false,
    masteryAssigned: false,
    cefrLevelAssigned: false,
    progressionPerformed: false,
  };
}
'@

[System.IO.File]::WriteAllText(
    $auditPath,
    $cleanSource,
    $utf8
)

# ------------------------------------------------------------
# Fail-closed structural verification before any test execution.
# ------------------------------------------------------------

$check =
    [System.IO.File]::ReadAllText(
        $auditPath,
        $utf8
    )

$importCount =
    [regex]::Matches(
        $check,
        [regex]::Escape(
            'import type {'
        )
    ).Count

if ($importCount -ne 1) {
    throw "Rev3 audit import count invalid: $importCount"
}

$constCount =
    [regex]::Matches(
        $check,
        [regex]::Escape(
            'export const LAF_POLICY_GATED_DELAYED_RETRIEVAL_EVIDENCE_IDS'
        )
    ).Count

if ($constCount -ne 1) {
    throw "Rev3 audit const declaration count invalid: $constCount"
}

$requiredDelayedIds = @(
    "a1-connect-evidence-delayed-retrieval",
    "a1-navigate-evidence-delayed-retrieval",
    "a1-describe-evidence-delayed-retrieval",
    "a1-exchange-evidence-delayed-retrieval"
)

foreach ($id in $requiredDelayedIds) {
    $count =
        [regex]::Matches(
            $check,
            [regex]::Escape($id)
        ).Count

    if ($count -ne 1) {
        throw "Rev3 delayed-retrieval identity count invalid for ${id}: $count"
    }
}

Write-Host ""
Write-Host "REV3 AUDIT SOURCE CLEAN RESTORE COMPLETE"

$vitestPath =
    Join-Path $app "node_modules\.bin\vitest.cmd"

if (-not (Test-Path $vitestPath)) {
    throw "Local Vitest command missing: $vitestPath"
}

$npmPath =
    (Get-Command "npm.cmd" -ErrorAction Stop).Source

if (-not $npmPath) {
    throw "npm.cmd path could not be resolved."
}

Set-Location $app

Write-Host ""
Write-Host "============================================================"
Write-Host "SPRINT-1536-1538 REV3 TARGET CHECKPOINT"
Write-Host "============================================================"

$vitestCommandArgs = @(
    "run",
    "src/core/learning/CefrA1ExchangeRuntimeSliceDefinition.test.ts",
    "src/core/learning/CefrProductionRuntimeSliceRegistry.test.ts",
    "src/core/learning/CefrProductionRuntimeRegistryEnforcement.test.ts",
    "src/core/learning/CefrProductionRuntimeSliceRegistryEligibility.test.ts",
    "src/core/learning/CefrProductionRuntimeEvidenceEligibilityAudit.test.ts",
    "src/application/learning/CefrProductionRuntimeDelayedRetrievalVisibility.test.ts",
    "src/application/learning/CefrA1ExchangeProductionRuntime.test.ts",
    "src/application/learning/CefrProductionRuntimePlatform.test.ts",
    "src/application/learning/CefrRuntimeAssemblyFactory.test.ts"
)

& $vitestPath @vitestCommandArgs

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1536-1538 Rev3 target checkpoint failed."
}

Write-Host ""
Write-Host "SPRINT-1536-1538 REV3 TARGET CHECKPOINT PASSED"

Write-Host ""
Write-Host "============================================================"
Write-Host "FINAL 9-SPRINT BLOCK REGRESSION"
Write-Host "============================================================"

& $npmPath run test

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1530-1538 Rev3 final full regression failed."
}

Write-Host ""
Write-Host "============================================================"
Write-Host "FINAL PRODUCTION BUILD"
Write-Host "============================================================"

& $npmPath run build

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1530-1538 Rev3 production build failed."
}

Write-Host ""
Write-Host "SPRINT-1530-1538 REV3 VERIFICATION COMPLETE"
Write-Host "Backup: $backupRoot"
