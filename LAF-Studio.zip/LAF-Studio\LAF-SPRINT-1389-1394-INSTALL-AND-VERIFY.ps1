﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

$greeting = Join-Path $app "src\ui\learning\A1ConnectGreetingComprehensionTaskPanel.tsx"
$additional = Join-Path $app "src\ui\learning\A1ConnectAdditionalTaskPanel.tsx"
$extended = Join-Path $app "src\ui\learning\A1ConnectExtendedTaskPanel.tsx"
$safety = Join-Path $app "src\core\learning\CefrA1ConnectTaskContextIsolationSafety.ts"

foreach ($file in @(
    $greeting,
    $additional,
    $extended,
    $safety
)) {
    if (-not (Test-Path $file)) {
        throw "Sprint 1389-1394 source missing: $file"
    }
}

$checks = @{
    $greeting = @(
        'useEffect,',
        'setSelectedAnswer("");',
        'setStatus("idle");',
        '[languageCode],',
        'onEvidencePersisted?.()'
    )
    $additional = @(
        'useEffect,',
        'setSelectedAnswer("");',
        'setStatus("idle");',
        'languageCode,',
        'taskKind,',
        'onEvidencePersisted?.()'
    )
    $extended = @(
        'useEffect,',
        'setSelectedAnswer("");',
        'setStatus("idle");',
        'setDelayedCandidate(',
        '.findLatestForLanguage(',
        'languageCode,',
        'taskKind,',
        'onEvidencePersisted?.()'
    )
    $safety = @(
        'targetLanguageChangeResetsDraftAnswer:',
        'true',
        'delayedCandidateMustMatchCurrentLanguage:',
        'resetDeletesPersistedEvidence: false',
        'resetDeletesLanguageProvenance: false',
        'resetCreatesEvidence: false',
        'resetAssignsMastery: false',
        'resetAssignsCefrLevel: false',
        'resetPerformsProgression: false'
    )
}

foreach ($entry in $checks.GetEnumerator()) {
    foreach ($marker in $entry.Value) {
        if (-not (
            Select-String `
                -Path $entry.Key `
                -SimpleMatch `
                -Pattern $marker `
                -Quiet
        )) {
            throw "Required Sprint 1389-1394 marker missing: $marker"
        }
    }
}

Write-Host "SPRINT-1389-1394 SOURCE CHECK PASSED"

Set-Location $app

$targets = @(
    "src/core/learning/CefrA1ConnectTaskContextIsolationSafety.test.ts",
    "src/ui/learning/A1ConnectTaskContextIsolation.test.ts",
    "src/ui/learning/A1ConnectGreetingComprehensionTaskPanel.test.ts",
    "src/ui/learning/A1ConnectAdditionalTaskPanel.test.ts",
    "src/ui/learning/A1ConnectDelayedRetrievalCandidateBinding.test.ts",
    "src/core/learning/CefrA1ConnectEvidenceUiRefreshSignal.test.ts",
    "src/core/learning/CefrA1ConnectEvidenceRefreshSafety.test.ts",
    "src/application/learning/CefrA1ConnectLanguageEvidenceProvenanceIntegration.test.ts",
    "src/application/learning/CefrA1ConnectLanguageScopedCoverageReadModel.test.ts"
)

& npx vitest run $targets
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1389-1394 target tests failed."
}

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Full regression failed."
}

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Production build failed."
}

Write-Host "SPRINT-1389-1394 VERIFICATION COMPLETE"
