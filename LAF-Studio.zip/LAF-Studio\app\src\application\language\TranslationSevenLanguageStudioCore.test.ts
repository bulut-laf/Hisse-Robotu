import { describe, expect, it } from "vitest";
import { analyzeTranslationWritingDraft } from "../writing/TranslationWritingSession";
import { createTranslationReadingPassage } from "../reading/TranslationReadingPassage";
import { normalizeTranslationSpeakingText } from "../speaking/TranslationSpeakingPractice";
import { createTranslationDialogueSessionSummary } from "../dialogue/TranslationDialogueSession";

describe("seven-language deterministic studio core", () => {
  it("analyzes Spanish writing", () => {
    expect(analyzeTranslationWritingDraft("es", "single-sentence", "¡Hoy estudio español con mucho gusto!").wordCount).toBeGreaterThanOrEqual(4);
  });
  it("analyzes Russian writing", () => {
    expect(analyzeTranslationWritingDraft("ru", "single-sentence", "Сегодня я изучаю русский язык.").wordCount).toBeGreaterThanOrEqual(4);
  });
  it("creates German reading", () => {
    expect(createTranslationReadingPassage({sourceLanguage:"de", text:"Guten Tag. Ich lerne Deutsch."}).status).toBe("ready");
  });
  it("normalizes Spanish speaking", () => {
    expect(normalizeTranslationSpeakingText("es", "¡BUENOS DÍAS!")).toContain("buenos");
  });
  it("counts Russian dialogue words", () => {
    expect(createTranslationDialogueSessionSummary("ru", [{speaker:"learner", text:"Я изучаю русский язык."}]).learnerWordCount).toBe(4);
  });
});
