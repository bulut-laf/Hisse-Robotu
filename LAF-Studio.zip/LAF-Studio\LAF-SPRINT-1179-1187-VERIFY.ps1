$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 1179-1181 Target Tests: Session Evidence Return ==="
npx vitest run `
  "src/core/learning/CefrGuidanceSessionEvidenceReturn.test.ts" `
  "src/core/learning/CefrGuidanceSessionCapabilityObservationReturn.test.ts" `
  "src/core/learning/CefrGuidanceSessionFeedbackBundle.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1179-1181 target tests failed." }

Write-Host "=== Sprint 1182-1184 Target Tests: Profile Feedback Refresh ==="
npx vitest run `
  "src/core/learning/CefrGuidanceSessionProfileEvidenceRefresh.test.ts" `
  "src/core/learning/CefrGuidanceSessionObservationRefresh.test.ts" `
  "src/core/learning/CefrGuidanceSessionUnifiedProfileRefresh.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1182-1184 target tests failed." }

Write-Host "=== Sprint 1185-1187 Target Tests: Guidance Re-entry ==="
npx vitest run `
  "src/core/learning/CefrGuidanceSessionNextGuidanceContext.test.ts" `
  "src/core/learning/CefrGuidanceApplicationFeedbackClosedLoop.test.ts" `
  "src/core/learning/CefrGuidanceApplicationIntegrationPlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1185-1187 target tests failed." }

Write-Host "=== Combined Sprint 1179-1187 New Tests ==="
npx vitest run `
  "src/core/learning/CefrGuidanceSessionEvidenceReturn.test.ts" `
  "src/core/learning/CefrGuidanceSessionCapabilityObservationReturn.test.ts" `
  "src/core/learning/CefrGuidanceSessionFeedbackBundle.test.ts" `
  "src/core/learning/CefrGuidanceSessionProfileEvidenceRefresh.test.ts" `
  "src/core/learning/CefrGuidanceSessionObservationRefresh.test.ts" `
  "src/core/learning/CefrGuidanceSessionUnifiedProfileRefresh.test.ts" `
  "src/core/learning/CefrGuidanceSessionNextGuidanceContext.test.ts" `
  "src/core/learning/CefrGuidanceApplicationFeedbackClosedLoop.test.ts" `
  "src/core/learning/CefrGuidanceApplicationIntegrationPlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1179-1187 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-1179-1187 VERIFICATION COMPLETE"
