﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$src = Join-Path $root "app\src"
$out = Join-Path $root "LAF_CAPABILITY_BINDING_DISCOVERY.txt"

if (-not (Test-Path $src)) {
    throw "Source root not found: $src"
}

$report = New-Object System.Collections.Generic.List[string]

function Add-Line {
    param([string]$Text)
    if ($null -eq $Text) { $Text = "" }
    [void]$report.Add($Text)
}

function Add-Section {
    param([string]$Title)
    Add-Line ""
    Add-Line ("=" * 92)
    Add-Line $Title
    Add-Line ("=" * 92)
}

function Rel {
    param([string]$Path)
    $prefix = $root + "\"
    if ($Path.StartsWith($prefix)) {
        return $Path.Substring($prefix.Length)
    }
    return $Path
}

$sourceFiles = @(
    Get-ChildItem -Path $src -Recurse -File -ErrorAction SilentlyContinue |
    Where-Object {
        $_.Extension -eq ".ts" -or $_.Extension -eq ".tsx"
    }
)

function Search-Patterns {
    param(
        [string]$Title,
        [string[]]$Patterns,
        [int]$Limit = 300
    )

    Add-Section $Title

    $items = New-Object System.Collections.Generic.List[object]

    foreach ($file in $sourceFiles) {
        foreach ($pattern in $Patterns) {
            $hits = @(
                Select-String `
                    -Path $file.FullName `
                    -SimpleMatch `
                    -Pattern $pattern `
                    -ErrorAction SilentlyContinue
            )

            foreach ($hit in $hits) {
                [void]$items.Add(
                    [PSCustomObject]@{
                        File = Rel $hit.Path
                        Line = $hit.LineNumber
                        Pattern = $pattern
                        Text = $hit.Line.Trim()
                    }
                )
            }
        }
    }

    $matches = @(
        $items |
        Sort-Object File, Line, Pattern -Unique |
        Select-Object -First $Limit
    )

    if ($matches.Count -eq 0) {
        Add-Line "(no matches)"
        return
    }

    foreach ($m in $matches) {
        Add-Line (
            "{0}:{1} [{2}] {3}" -f
            $m.File,
            $m.Line,
            $m.Pattern,
            $m.Text
        )
    }
}

Add-Line "LAF STUDIO - CAPABILITY BINDING DISCOVERY"
Add-Line ("Generated: " + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
Add-Line "READ ONLY - no project source files are modified."

Search-Patterns `
    -Title "1. CAPABILITY / COMPETENCY IDENTIFIERS" `
    -Patterns @(
        "capabilityReference"
        "capabilityId"
        "capability"
        "competencyOutcome"
        "competencyId"
        "competency"
        "outcomeId"
        "learningOutcome"
    ) `
    -Limit 420

Search-Patterns `
    -Title "2. LESSON / ACTIVITY METADATA" `
    -Patterns @(
        "lessonId"
        "activityId"
        "moduleFamily"
        "cefrLevel"
        "lesson:"
        "activities:"
        "lessons:"
        "curriculum"
        "syllabus"
    ) `
    -Limit 420

Search-Patterns `
    -Title "3. EXISTING CEFR OUTCOME REGISTRIES / CATALOGS" `
    -Patterns @(
        "CompetencyOutcome"
        "ModuleFamily"
        "CefrLevel"
        "CEFR"
        "RESPOND"
        "MAINTAIN"
        "MANAGE"
        "DEVELOP"
        "ADAPT"
        "CONTROL"
        "CONNECT"
        "NAVIGATE"
        "DESCRIBE"
        "EXCHANGE"
        "SOLVE"
        "INTERPRET"
    ) `
    -Limit 500

Search-Patterns `
    -Title "4. STUDIO TARGET / LESSON ROUTING METADATA" `
    -Patterns @(
        "targetStudio"
        "studioId"
        "studio:"
        "targetSelector"
        "routeKey"
        "lessonRoute"
        "LessonPage"
        "ListeningPracticePage"
        "WritingStudioPanel"
        "SpeakingStudioPanel"
        "DialogueRoleplayPanel"
    ) `
    -Limit 420

Add-Section "5. CANDIDATE DOMAIN FILE PREVIEWS"

$candidates = @(
    $sourceFiles |
    Where-Object {
        $_.Name -match "Cefr|CEFR|Lesson|Curriculum|Competency|Capability|Module|Outcome|Catalog|Registry"
    } |
    Sort-Object FullName |
    Select-Object -First 35
)

if ($candidates.Count -eq 0) {
    Add-Line "(no candidate files found)"
}
else {
    foreach ($file in $candidates) {
        Add-Line ""
        Add-Line ("FILE: " + (Rel $file.FullName))
        Add-Line ("-" * 92)

        $content = @(Get-Content -Path $file.FullName)
        $limit = [Math]::Min($content.Count, 260)

        for ($i = 0; $i -lt $limit; $i++) {
            Add-Line ("{0,4}: {1}" -f ($i + 1), $content[$i])
        }

        if ($content.Count -gt $limit) {
            Add-Line (
                "... truncated; total lines: " +
                $content.Count
            )
        }
    }
}

Add-Section "6. IMPLEMENTATION DECISION INPUT"
Add-Line "Need authoritative lesson/activity -> capability or competency mapping already present in production data."
Add-Line "Need exact stable identity for each mapped learning item."
Add-Line "Need exact mapping source owner: curriculum, lesson metadata, registry, or catalog."
Add-Line "Need to know whether one item maps to one or multiple competency outcomes."
Add-Line "Do not infer mapping from labels, route names, Studio names, or test fixtures."
Add-Line "Do not fabricate capabilityReference."
Add-Line "Do not assign mastery or CEFR level from a mapping."
Add-Line "Mapping may enable observations only after an authoritative production relation is confirmed."

$report | Set-Content -Path $out -Encoding UTF8

Write-Host ""
Write-Host "LAF CAPABILITY BINDING DISCOVERY COMPLETE"
Write-Host "Report:"
Write-Host $out
Write-Host ""
Get-Content -Path $out
