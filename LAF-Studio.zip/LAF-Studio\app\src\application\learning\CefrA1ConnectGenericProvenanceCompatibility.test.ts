import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrAuthoritativeLanguageEvidenceProvenance,
} from "../../core/learning/CefrAuthoritativeLanguageEvidenceProvenance";
import {
  LAF_A1_CONNECT_LANGUAGE_EVIDENCE_PROVENANCE_AUTHORITY,
} from "../../core/learning/CefrLanguageEvidenceProvenanceAuthority";
import {
  CefrA1ConnectLanguageEvidenceProvenanceRepository,
} from "./CefrA1ConnectLanguageEvidenceProvenanceRepository";
import {
  CefrAuthoritativeLanguageEvidenceProvenanceRepository,
  type CefrLanguageEvidenceStorageLike,
} from "./CefrAuthoritativeLanguageEvidenceProvenanceRepository";

class MemoryStorage
  implements CefrLanguageEvidenceStorageLike {
  private readonly items =
    new Map<string, string>();

  getItem(
    key: string,
  ): string | null {
    return this.items.get(key) ?? null;
  }

  setItem(
    key: string,
    value: string,
  ): void {
    this.items.set(key, value);
  }

  removeItem(
    key: string,
  ): void {
    this.items.delete(key);
  }
}

describe(
  "A1 CONNECT generic provenance compatibility",
  () => {
    it("generic writes remain readable by the stable A1 repository without storage migration", () => {
      const storage =
        new MemoryStorage();

      const genericRepository =
        new CefrAuthoritativeLanguageEvidenceProvenanceRepository(
          LAF_A1_CONNECT_LANGUAGE_EVIDENCE_PROVENANCE_AUTHORITY,
          storage,
        );

      genericRepository.save(
        createCefrAuthoritativeLanguageEvidenceProvenance({
          evidenceId: "compat-evidence",
          languageCode: "hu",
          observedAt:
            new Date(
              "2026-08-11T21:40:00.000Z",
            ),
          source: "a1-connect-runtime",
        }),
      );

      const legacyRepository =
        new CefrA1ConnectLanguageEvidenceProvenanceRepository(
          storage,
        );

      expect(
        legacyRepository.findByEvidenceId(
          "compat-evidence",
        ),
      ).toMatchObject({
        evidenceId: "compat-evidence",
        languageCode: "hu",
        source: "a1-connect-runtime",
        authoritativeLanguageProvenance:
          true,
        masteryClaimed: false,
        cefrLevelClaimed: false,
      });
    });
  },
);
