$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 1080-1082 Target Tests: Continuity Merge ==="
npx vitest run `
  "src/core/learning/CefrContinuityGuidanceCandidate.test.ts" `
  "src/core/learning/CefrNextDayGuidanceMerge.test.ts" `
  "src/core/learning/CefrNextDayGuidanceMergePolicy.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1080-1082 target tests failed." }

Write-Host "=== Sprint 1083-1085 Target Tests: Next-Day Guidance Agenda ==="
npx vitest run `
  "src/core/learning/CefrNextDayGuidanceAgendaItem.test.ts" `
  "src/core/learning/CefrNextDayGuidanceAgenda.test.ts" `
  "src/core/learning/CefrNextDayGuidanceAgendaOrchestration.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1083-1085 target tests failed." }

Write-Host "=== Sprint 1086-1088 Target Tests: User Next-Day Plan ==="
npx vitest run `
  "src/core/learning/CefrUserNextDayGuidanceSelection.test.ts" `
  "src/core/learning/CefrUserNextDayGuidancePlan.test.ts" `
  "src/core/learning/CefrNextDayGuidancePlanGateway.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1086-1088 target tests failed." }

Write-Host "=== Combined Sprint 1080-1088 New Tests ==="
npx vitest run `
  "src/core/learning/CefrContinuityGuidanceCandidate.test.ts" `
  "src/core/learning/CefrNextDayGuidanceMerge.test.ts" `
  "src/core/learning/CefrNextDayGuidanceMergePolicy.test.ts" `
  "src/core/learning/CefrNextDayGuidanceAgendaItem.test.ts" `
  "src/core/learning/CefrNextDayGuidanceAgenda.test.ts" `
  "src/core/learning/CefrNextDayGuidanceAgendaOrchestration.test.ts" `
  "src/core/learning/CefrUserNextDayGuidanceSelection.test.ts" `
  "src/core/learning/CefrUserNextDayGuidancePlan.test.ts" `
  "src/core/learning/CefrNextDayGuidancePlanGateway.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1080-1088 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-1080-1088 VERIFICATION COMPLETE"
