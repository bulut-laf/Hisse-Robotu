﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$panel = Join-Path $app "src\ui\learning\A1ConnectNativeLearningPanel.tsx"

if (-not (Test-Path $panel)) {
    throw "A1ConnectNativeLearningPanel.tsx missing."
}

$utf8 =
    New-Object System.Text.UTF8Encoding($false)

$text =
    [System.IO.File]::ReadAllText(
        $panel,
        $utf8
    )

# Add one parent refresh counter/callback before selectLanguage.
$refreshMarker =
    'const refreshEvidenceViews = () =>'

if (-not $text.Contains($refreshMarker)) {
    $anchor =
        '  const selectLanguage = ('

    $anchorIndex =
        $text.IndexOf($anchor)

    if ($anchorIndex -lt 0) {
        throw "Evidence refresh state anchor not found."
    }

    $insert = @'
  const [
    evidenceRefreshToken,
    setEvidenceRefreshToken,
  ] = useState(0);

  const refreshEvidenceViews = () => {
    setEvidenceRefreshToken(
      value => value + 1,
    );
  };

'@

    $text =
        $text.Insert(
            $anchorIndex,
            $insert
        )
}

# Bind callback to each real task panel.
$bindings = @(
    @{
        Old = @'
        <A1ConnectGreetingComprehensionTaskPanel
          languageCode={selectedLanguageCode}
        />
'@
        New = @'
        <A1ConnectGreetingComprehensionTaskPanel
          languageCode={selectedLanguageCode}
          onEvidencePersisted={
            refreshEvidenceViews
          }
        />
'@
        Marker =
            'onEvidencePersisted={' +
            [Environment]::NewLine +
            '            refreshEvidenceViews'
    },
    @{
        Old = @'
        <A1ConnectAdditionalTaskPanel
          languageCode={selectedLanguageCode}
          taskKind="greeting-response"
        />
'@
        New = @'
        <A1ConnectAdditionalTaskPanel
          languageCode={selectedLanguageCode}
          taskKind="greeting-response"
          onEvidencePersisted={
            refreshEvidenceViews
          }
        />
'@
        Marker =
            'taskKind="greeting-response"'
    },
    @{
        Old = @'
        <A1ConnectAdditionalTaskPanel
          languageCode={selectedLanguageCode}
          taskKind="self-introduction"
        />
'@
        New = @'
        <A1ConnectAdditionalTaskPanel
          languageCode={selectedLanguageCode}
          taskKind="self-introduction"
          onEvidencePersisted={
            refreshEvidenceViews
          }
        />
'@
        Marker =
            'taskKind="self-introduction"'
    },
    @{
        Old = @'
          <A1ConnectExtendedTaskPanel
            languageCode={selectedLanguageCode}
            taskKind="personal-answer"
          />
'@
        New = @'
          <A1ConnectExtendedTaskPanel
            languageCode={selectedLanguageCode}
            taskKind="personal-answer"
            onEvidencePersisted={
              refreshEvidenceViews
            }
          />
'@
        Marker =
            'taskKind="personal-answer"'
    },
    @{
        Old = @'
          <A1ConnectExtendedTaskPanel
            languageCode={selectedLanguageCode}
            taskKind="personal-question"
          />
'@
        New = @'
          <A1ConnectExtendedTaskPanel
            languageCode={selectedLanguageCode}
            taskKind="personal-question"
            onEvidencePersisted={
              refreshEvidenceViews
            }
          />
'@
        Marker =
            'taskKind="personal-question"'
    },
    @{
        Old = @'
        <A1ConnectExtendedTaskPanel
          languageCode={selectedLanguageCode}
          taskKind="reciprocal-exchange"
        />
'@
        New = @'
        <A1ConnectExtendedTaskPanel
          languageCode={selectedLanguageCode}
          taskKind="reciprocal-exchange"
          onEvidencePersisted={
            refreshEvidenceViews
          }
        />
'@
        Marker =
            'taskKind="reciprocal-exchange"'
    }
)

foreach ($binding in $bindings) {
    $taskIndex =
        $text.IndexOf(
            $binding.Marker
        )

    if ($taskIndex -lt 0) {
        throw "Task panel marker missing before evidence refresh binding: $($binding.Marker)"
    }

    $nearEnd =
        [Math]::Min(
            $text.Length,
            $taskIndex + 420
        )

    $near =
        $text.Substring(
            $taskIndex,
            $nearEnd - $taskIndex
        )

    if (-not $near.Contains(
        'onEvidencePersisted={'
    )) {
        if (-not $text.Contains(
            $binding.Old
        )) {
            throw "Task panel exact binding anchor missing: $($binding.Marker)"
        }

        $text =
            $text.Replace(
                $binding.Old,
                $binding.New
            )
    }
}

# Give coverage panel the parent refresh token.
if (-not $text.Contains(
    'evidenceRefreshToken={evidenceRefreshToken}'
)) {
    $oldUnit = @'
        <A1ConnectUnitRuntimePanel
          languageCode={selectedLanguageCode}
        />
'@

    $newUnit = @'
        <A1ConnectUnitRuntimePanel
          languageCode={selectedLanguageCode}
          evidenceRefreshToken={
            evidenceRefreshToken
          }
        />
'@

    if (-not $text.Contains($oldUnit)) {
        throw "Unit runtime refresh prop anchor missing."
    }

    $text =
        $text.Replace(
            $oldUnit,
            $newUnit
        )
}

# Give advisory/continuity panel the same refresh token.
if (-not $text.Contains(
    'evidenceRefreshToken={' +
    [Environment]::NewLine +
    '          evidenceRefreshToken'
)) {
    $oldContinuityTail = @'
        onApplyAdvisoryLesson={
          applyAdvisoryLesson
        }
      />
'@

    $newContinuityTail = @'
        onApplyAdvisoryLesson={
          applyAdvisoryLesson
        }
        evidenceRefreshToken={
          evidenceRefreshToken
        }
      />
'@

    if (-not $text.Contains(
        $oldContinuityTail
    )) {
        throw "Continuity refresh prop anchor missing."
    }

    $text =
        $text.Replace(
            $oldContinuityTail,
            $newContinuityTail
        )
}

[System.IO.File]::WriteAllText(
    $panel,
    $text,
    $utf8
)

$greeting = Join-Path $app "src\ui\learning\A1ConnectGreetingComprehensionTaskPanel.tsx"
$additional = Join-Path $app "src\ui\learning\A1ConnectAdditionalTaskPanel.tsx"
$extended = Join-Path $app "src\ui\learning\A1ConnectExtendedTaskPanel.tsx"
$unit = Join-Path $app "src\ui\learning\A1ConnectUnitRuntimePanel.tsx"
$continuity = Join-Path $app "src\ui\learning\A1ConnectContinuityPanel.tsx"
$signal = Join-Path $app "src\core\learning\CefrA1ConnectEvidenceUiRefreshSignal.ts"
$safety = Join-Path $app "src\core\learning\CefrA1ConnectEvidenceRefreshSafety.ts"

foreach ($file in @(
    $greeting,
    $additional,
    $extended,
    $unit,
    $continuity,
    $signal,
    $safety,
    $panel
)) {
    if (-not (Test-Path $file)) {
        throw "Sprint 1383-1388 source missing: $file"
    }
}

$checks = @{
    $greeting = @(
        'onEvidencePersisted?: () => void',
        'if (result.evidencePersisted)',
        'onEvidencePersisted?.()'
    )
    $additional = @(
        'onEvidencePersisted?: () => void',
        'if (result.evidencePersisted)'
    )
    $extended = @(
        'onEvidencePersisted?: () => void',
        'if (result.evidencePersisted)'
    )
    $unit = @(
        'evidenceRefreshToken?: number',
        'evidenceRefreshToken,'
    )
    $continuity = @(
        'evidenceRefreshToken?: number',
        'evidenceRefreshToken,'
    )
    $signal = @(
        'refreshCoverageRequested:',
        'refreshAdvisoryRequested:',
        'automaticLessonSelection: false'
    )
    $safety = @(
        'uiRefreshCreatesEvidence: false',
        'uiRefreshSelectsLesson: false',
        'uiRefreshPerformsProgression: false'
    )
    $panel = @(
        'const refreshEvidenceViews = () =>',
        'evidenceRefreshToken',
        'onEvidencePersisted={'
    )
}

foreach ($entry in $checks.GetEnumerator()) {
    foreach ($marker in $entry.Value) {
        if (-not (
            Select-String `
                -Path $entry.Key `
                -SimpleMatch `
                -Pattern $marker `
                -Quiet
        )) {
            throw "Required Sprint 1383-1388 marker missing: $marker"
        }
    }
}

Write-Host "SPRINT-1383-1388 SOURCE CHECK PASSED"

Set-Location $app

$targets = @(
    "src/core/learning/CefrA1ConnectEvidenceUiRefreshSignal.test.ts",
    "src/core/learning/CefrA1ConnectEvidenceRefreshSafety.test.ts",
    "src/ui/learning/A1ConnectEvidenceUiRefreshBinding.test.ts",
    "src/ui/learning/A1ConnectGreetingComprehensionTaskPanel.test.ts",
    "src/ui/learning/A1ConnectAdditionalTaskPanel.test.ts",
    "src/ui/learning/A1ConnectDelayedRetrievalCandidateBinding.test.ts",
    "src/ui/learning/A1ConnectUnitRuntimePanel.test.ts",
    "src/ui/learning/A1ConnectContinuityPanel.advisory.test.ts",
    "src/application/learning/CefrA1ConnectLanguageScopedCoverageReadModel.test.ts",
    "src/application/learning/CefrA1ConnectLanguageScopedAdvisoryReadModel.test.ts"
)

& npx vitest run $targets
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1383-1388 target tests failed."
}

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Full regression failed."
}

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Production build failed."
}

Write-Host "SPRINT-1383-1388 VERIFICATION COMPLETE"
