import type {
  LafLearningLanguageCode,
} from "../../core/language/LafLanguageProfile";
import {
  createCefrA1ConnectAdvisoryNextStep,
  type CefrA1ConnectAdvisoryNextStep,
} from "../../core/learning/CefrA1ConnectAdvisoryNextStep";
import type {
  CefrGuidanceRuntimeProfileRepository,
} from "./CefrGuidanceRuntimeProfileRepository";
import type {
  CefrA1ConnectLanguageEvidenceProvenanceRepository,
} from "./CefrA1ConnectLanguageEvidenceProvenanceRepository";
import {
  filterCefrA1ConnectEvidenceForLanguage,
} from "./CefrA1ConnectLanguageScopedCoverageReadModel";

export interface CefrA1ConnectLanguageScopedAdvisoryReadModel {
  readonly languageCode:
    LafLearningLanguageCode | null;
  readonly selectedLanguageRequired:
    boolean;
  readonly nextStep:
    CefrA1ConnectAdvisoryNextStep | null;
  readonly crossLanguageEvidenceExcluded:
    true;
  readonly automaticLessonSelection: false;
  readonly automaticProgression: false;
}

export function createCefrA1ConnectLanguageScopedAdvisoryReadModel(
  repository:
    CefrGuidanceRuntimeProfileRepository,
  provenanceRepository:
    CefrA1ConnectLanguageEvidenceProvenanceRepository,
  languageCode:
    LafLearningLanguageCode | null,
): CefrA1ConnectLanguageScopedAdvisoryReadModel {
  if (languageCode === null) {
    return {
      languageCode: null,
      selectedLanguageRequired: true,
      nextStep: null,
      crossLanguageEvidenceExcluded: true,
      automaticLessonSelection: false,
      automaticProgression: false,
    };
  }

  const evidence =
    repository.load()
      .profileSnapshot
      .evidenceAggregation.evidence;

  const scopedEvidence =
    filterCefrA1ConnectEvidenceForLanguage(
      evidence,
      provenanceRepository,
      languageCode,
    );

  return {
    languageCode,
    selectedLanguageRequired: false,
    nextStep:
      createCefrA1ConnectAdvisoryNextStep(
        scopedEvidence,
      ),
    crossLanguageEvidenceExcluded: true,
    automaticLessonSelection: false,
    automaticProgression: false,
  };
}
