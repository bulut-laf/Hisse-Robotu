﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

Write-Host "=== Install Native Learning Studio Guidance Entry ==="
Set-Location $root
node ".\LAF-SPRINT-1203-1208-INSTALL.mjs"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1203-1208 install failed." }

$learningPage = Join-Path $app "src\ui\pages\LearningStudioPage.tsx"
$importMatches = @(
  Select-String -Path $learningPage -SimpleMatch `
    'LearningGuidanceEntryCard } from "../learning/LearningGuidanceEntryCard";'
)
$renderMatches = @(
  Select-String -Path $learningPage -SimpleMatch `
    '<LearningGuidanceEntryCard />'
)

if ($importMatches.Count -ne 1) {
  throw "LearningStudioPage guidance import validation failed."
}

if ($renderMatches.Count -ne 1) {
  throw "LearningStudioPage guidance render validation failed."
}

Set-Location $app

Write-Host "=== Sprint 1203-1205 Target Tests: Native Entry Model + Safety ==="
npx vitest run `
  "src/core/learning/CefrGuidanceLearningStudioEntryModel.test.ts" `
  "src/core/learning/CefrGuidanceLearningStudioEntrySafety.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1203-1205 target tests failed." }

Write-Host "=== Sprint 1206-1208 Target Tests: Native Integration ==="
npx vitest run `
  "src/core/learning/CefrGuidanceLearningStudioEntryIntegration.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1206-1208 target tests failed." }

Write-Host "=== Combined Sprint 1203-1208 New Tests ==="
npx vitest run `
  "src/core/learning/CefrGuidanceLearningStudioEntryModel.test.ts" `
  "src/core/learning/CefrGuidanceLearningStudioEntrySafety.test.ts" `
  "src/core/learning/CefrGuidanceLearningStudioEntryIntegration.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1203-1208 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-1203-1208 VERIFICATION COMPLETE"
