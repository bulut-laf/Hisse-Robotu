LAF Studio — Project Notes

Bu dosya LAF Studio geliştirme çalışmalarının kalıcı teknik hafızasıdır. Dosya, çalışma sırasında değil; gün sonunda test, build ve tarayıcı doğrulamaları tamamlandıktan sonra topluca güncellenir.

1. Proje bilgileri

Proje adı: LAF Studio

Açılımı: Language Architecture Framework

Proje türü: Yapay zekâ destekli Language Intelligence Platform

Yerel proje yolu: D:\Projects\LAF-Studio

Geliştirme durumu: Aktif

Son güncelleme: 8 Ağustos 2026 — Sprint 137–139 CEFR Learning Path Foundation bloğu tamamlandı

Son tamamlanan sprint: Sprint 139 — CEFR Learning Journey V1

Sıradaki çalışma: CEFR Learning Path V1 — sonraki onaylı öğrenme mimarisi bloğunun teknik planlanması

2. Projenin amacı

LAF Studio; dil öğrenmeyi, yazılı çeviriyi, sözlü tercümanlığı ve profesyonel dil kullanımını tek bir kişisel dil zekâsında birleştiren, farklı dillere uyarlanabilir yapay zekâ destekli bir Language Intelligence Platform’dur.

Ürün yalnızca hazır içerik veya hazır çeviri sunmaz. Kullanıcının dili anlamasını, üretmesini, gerçek yaşamda kullanmasını ve gerektiğinde profesyonel çeviri veya tercümanlık çalışmalarında güvenilir destek almasını sağlar.

Ana ürün alanları:

Learning Studio

Dil öğrenme, aktif hatırlama, dinleme, konuşma, okuma, yazma, telaffuz ve kişiselleştirilmiş öğrenme.

Translation Studio

Yazılı çeviri, alternatif çeviri önerileri, anlam ve üslup analizi, terminoloji yönetimi, tutarlılık ve kalite kontrolü.

Interpreting Studio

Ardıl ve simultane tercümanlık eğitimi, mesleki senaryolar, not alma, hızlı hatırlama ve performans analizi.

LAF Intelligence Core

Üç stüdyodan gelen kelimeleri, hataları, güçlü ve zayıf alanları ve mesleki terminolojiyi ortak bir kişisel dil profili altında birleştiren sistem.

Temel ürün farklılaştırıcısı:

Bir stüdyoda ortaya çıkan öğrenme ihtiyacı diğer stüdyolara aktarılır. Çeviride zorlanılan ifadeler öğrenme programına, öğrenilen terminoloji çeviri desteğine, tercümanlık hataları ise hedefli alıştırmalara dönüştürülür.

Platformun temel yaklaşımı:

Mikro öğrenme

Aktif hatırlama

Bağlam içinde öğrenme

Doğal dil kullanımı

Kişiselleştirilmiş geri bildirim

Kullanıcı ilerlemesine göre öneri üretme

Profesyonel çeviri ve tercümanlık desteği

AI tarafından desteklenen fakat kullanıcı kontrolünü koruyan çalışma düzeni

3. Çalışma ayrımı

LAF Studio — Design Studio

Bu çalışma alanında yalnızca aşağıdaki konular ele alınır:

Ürün vizyonu

Öğrenme mimarisi

UX/UI kararları

AI öğretmen davranışları

Gamification

Roadmap

Ürün dokümantasyonu

Yeni özellik değerlendirmeleri

Bu alanda kod yazılmaz. Geliştirmeye aktarılacak kararlar Development Brief olarak hazırlanır.

LAF Studio — Development

Bu çalışma alanında onaylanan ürün kararları uygulanır.

Temel kurallar:

Aynı anda yalnızca bir sprint üzerinde çalışılır.

Mevcut katmanlı mimari korunur.

Gereksiz abstraction eklenmez.

Gereksiz özellik eklenmez.

Her sprint çalışan bir özellik teslim eder.

Her sprint sonunda npm run test başarılı olmalıdır.

Her sprint sonunda npm run build başarılı olmalıdır.

Gün içindeki doğrulamalar tamamlandıktan sonra bu dosya çalışma gününün sonunda topluca güncellenmelidir.

4. Ana proje yapısı

LAF-Studio/
├── app/
├── backend/
├── docs/
├── PROJECT_NOTES.md
└── ...

Frontend uygulamasının güncel hedef yapısı:

app/src/
├── application/
├── core/
├── features/
├── pages/
├── shared/
├── styles/
├── ui/
│   ├── audio/
│   ├── hooks/
│   ├── pages/
│   └── storage/
├── App.tsx
└── main.tsx

5. Kullanılan teknolojiler

Frontend

React

TypeScript

Vite

React Router

CSS

Tarayıcı Web Speech API

Tarayıcı MediaRecorder API

Local Storage

Test ve kalite

Vitest

TypeScript compiler

Vite production build

Geliştirme ortamı

Windows

Visual Studio Code

PowerShell

Git

Node.js

npm

6. Mimari

Güncel öğrenme akışı:

React UI
  → useLearningSession
  → LearningApplicationService
  → LearningSessionController
  → TranslationPipeline
  → Evaluation / Recommendation / Repository

Katmanların sorumlulukları:

Core

Öğrenme oturumu kuralları

Etkinlik modelleri

Cevap değerlendirme

Translation pipeline

Öğrenme önerileri

Repository sözleşmeleri ve uygulamaları

Core katmanı React bileşenlerine bağımlı değildir.

Application

UI ile Core arasında kullanım senaryosu sınırı oluşturur.

LearningApplicationService öğrenme oturumu işlemlerini sunar.

ApplicationFactory gerekli bağımlılıkları oluşturur ve bağlar.

UI

Kullanıcı etkileşimini yönetir.

Core nesnelerini doğrudan oluşturmamalıdır.

Öğrenme işlemlerine useLearningSession ve Application Layer üzerindenerişmelidir.

7. Önemli teknik kararlar

Karar 1 — Merkezi composition root

Bağımlılıkların kurulması ApplicationFactory içerisinde yapılır.

Gerekçe: React bileşenlerinin Core sınıflarını doğrudan oluşturmasınıönlemek ve bağımlılık kurulumunu tek noktada toplamak.

Karar 2 — UI için özel hook

React ekranları öğrenme oturumuna useLearningSession üzerinden bağlanır.

Gerekçe: UI state yönetimini Application Layer çağrılarından ayırmak vebileşenleri sade tutmak.

Karar 3 — Katmanlı geçiş

Eski UI parçaları tek seferde silinmez. Yeni Application Layer tabanlı akışçalışır hâle getirildikçe eski bağlantılar kontrollü biçimde değiştirilir.

Gerekçe: Çalışan sistemi bozmadan aşamalı geçiş yapmak.

Karar 4 — Sprint doğrulama standardı

Bir sprint yalnızca aşağıdaki koşullar birlikte sağlandığında tamamlanmış kabuledilir:

Özellik kullanıcı tarafından çalıştırılabilir.

npm run test başarılıdır.

npm run build başarılıdır.

PROJECT_NOTES.md güncellenmiştir.

8. Tamamlanan ana çalışmalar

Temel frontend

Vite + React + TypeScript uygulaması oluşturuldu.

Ana sayfalar ve React Router yapısı oluşturuldu.

MainLayout oluşturuldu.

Ana navigasyon rotaları bağlandı.

Core Engine

Etkinlik modelleri oluşturuldu.

Translation evaluation akışı oluşturuldu.

TranslationChecker oluşturuldu.

TranslationPipeline oluşturuldu.

ActivityEvaluationEngine oluşturuldu.

LearningRecommendationEngine oluşturuldu.

Öğrenme oturumu ve controller akışı oluşturuldu.

Memory session storage oluşturuldu.

Static activity repository oluşturuldu.

Application Layer

LearningApplicationService oluşturuldu.

ApplicationFactory oluşturuldu.

Core bağımlılıkları factory içerisinde bağlandı.

Application Layer testleri oluşturuldu.

React entegrasyonu

useLearningSession hook'u oluşturuldu.

Hook üzerinden oturum başlatma eklendi.

Cevap gönderme eklendi.

Geri bildirim state'i eklendi.

Sonraki etkinliğe geçme eklendi.

Önceki etkinliğe geçme desteği hook'a eklendi.

Önceki doğrulama durumu

Test paketi başarılı çalıştı.

Production build başarılı çalıştı.

Sprint 13 test sonucu: 7 test dosyası ve 44 test başarılı.

Sprint 13 build sonucu: Başarılı — Vite production build 2.82 saniye.

9. Sprint 13 — İlk çalışan LessonPage

Amaç

Application Layer üzerinden çalışan ilk gerçek ders ekranını tamamlamak.

Kabul kriterleri

Etkinlik sorusu ekranda gösterilir.

Kullanıcı cevap yazabilir.

Boş cevap gönderilemez.

Cevap yalnızca bir kez değerlendirilebilir.

Doğru veya yanlış geri bildirimi gösterilir.

Geri bildirimden sonra sonraki etkinliğe geçilebilir.

Son etkinlikten sonra dersin tamamlandığı gösterilir.

Enter tuşu ile cevap gönderilebilir.

Testler başarılıdır.

Production build başarılıdır.

Yapılan değişiklikler

LessonPage.tsx, useLearningSession hook'una bağlandı.

Soru, cevap alanı, gönderme işlemi, geri bildirim ve sonraki etkinlik akışıhazırlandı.

/lessons/:id rotasının eski LessonDetailPage yerine yeni LessonPagebileşenini açması için App.tsx güncellendi.

Tarihsel not: ContinueLessonCard.tsx dosyasının sonuna yanlışlıkla eklenen S karakteri TypeScript build hatasına neden oldu. Karakter kaldırıldı; test, build ve tarayıcı akışı daha sonra başarıyla doğrulandı.

10. Sprint 14–49 — Ana geliştirme özeti

Sprint 14–49 arasında aşağıdaki ana çalışmalar tamamlandı:

Ders oturumları tarayıcı Local Storage üzerinde kalıcı hâle getirildi.

Dersi yeniden başlatma ve mevcut aktiviteyi tekrar deneme akışları tamamlandı.

Çoklu ders desteği ve ders bazlı çeviri etkinlikleri oluşturuldu.

İtalyanca A1 seviyesinde üç ders ve her ders için üç çeviri etkinliği eklendi.

Dersler, Ana Sayfa ve İlerleme ekranları gerçek oturum verilerine bağlandı.

Ders ve genel ilerleme yüzdeleri ayrı ayrı hesaplanır hâle getirildi.

Haftalık çalışma grafiği ve gerçek çalışma serisi eklendi.

Günlük çalışma serisi ve çalışma günü serisi hesaplamaları eklendi.

Çeviri cevaplarında noktalama, büyük-küçük harf ve normalizasyon desteği geliştirildi.

Tarayıcı seslendirme servisi oluşturuldu.

Kelime ve örnek cümle seslendirmeleri eklendi.

Ana ders oturumundan ayrı çalışan dinleme pratiği rotası oluşturuldu:

/lessons/:id/listening

Dinleme pratiği sonuç özeti, doğru cevap sayısı, başarı yüzdesi ve ilk denemede doğru metriği eklendi.

Ders bazında en iyi dinleme sonucu Local Storage üzerinde saklanır hâle getirildi.

Kullanıcının kendi sesini kaydedip tekrar dinleyebilmesi için tarayıcı MediaRecorder desteği eklendi.

11. Sprint 50–57 — Gün sonu geliştirme kaydı

Kayıt dönemi: 24–27 Temmuz 2026

Sprint 50 — Genel dinleme ilerlemesi

İlerleme ekranına Ortalama dinleme başarısı kartı eklendi.

Dinleme çalışması yapılan ders sayısı toplam ders sayısından ayrı gösterildi.

Dinleme başarısı ana ders ilerleme yüzdesine katılmadı.

Genel dinleme özeti saf ve test edilebilir bir servis fonksiyonu olarak oluşturuldu.

Sprint 51 — Ders bazlı dinleme durumu

İlerleme ekranındaki her ders kartına en iyi dinleme puanı eklendi.

Dinleme kaydı olmayan derslerde Henüz yapılmadı bilgisi gösterildi.

Her ders kartına Dinleme Çalış veya Tekrar Dinle bağlantısı eklendi.

Sprint 52 — Ana Sayfada dinlemeye devam

Ana Sayfaya Dinlemeye Devam Et kartı eklendi.

En son tamamlanan dinleme çalışması tarih üzerinden belirlenir hâle getirildi.

Kartta ders adı, en iyi başarı yüzdesi ve son çalışma tarihi gösterildi.

Kart ilgili dersin dinleme pratiği rotasına bağlandı.

Sprint 53 — Kişisel dinleme rekoru

Dinleme sonucu önceki en iyi puanla karşılaştırılır hâle getirildi.

İlk sonuç, yeni kişisel rekor, eşit rekor ve rekor altı sonuç durumları oluşturuldu.

Tamamlanma ekranına kişisel rekor geri bildirimi eklendi.

Sprint 54 — Öğretici sesli geri bildirim

Dinleme cevabından sonra doğru yabancı ifade ve örnek cümle için ayrı seslendirme düğmeleri eklendi.

İlk yanlış cevapta doğru bilginin gizli kalması davranışı korundu.

Doğru cevapta veya ikinci denemeden sonra öğretici geri bildirim ve seslendirme açıldı.

Sprint 55 — Dinleme tekrar sayacı

Her sorunun çözüm sırasında kaç kez dinlendiği oturum içinde sayılır hâle getirildi.

Normal ve yavaş dinleme işlemleri sayaca dâhil edildi.

Geri bildirim alanındaki ifade ve örnek seslendirmeleri sayaç dışında bırakıldı.

Tamamlanma ekranına Toplam dinleme metriği eklendi.

Eski dinleme sonuçları için geriye uyumluluk korundu; listenCount bulunmayan kayıtlar sıfır kabul edildi.

Sprint 56 — Soru bazlı dinleme özeti

Dinleme çalışması tamamlanma ekranına soru bazlı dinleme özeti eklendi.

Her ifade için kaç kez dinleme yapıldığı ayrı ayrı gösterilir hâle getirildi.

Toplam dinleme metriği ve eski dinleme kayıtlarıyla geriye uyumluluk korundu.

Sprint 57 — Dinleme tekrar önerisi

Dinleme sonuçları kullanılarak öğrenciye ifade bazlı tekrar önerisi üretilir hâle getirildi.

Tamamlanma ekranına Tekrar Önerisi kartı eklendi.

Öneride tekrar edilmesi yararlı olan ifade ve yapılan dinleme sayısı gösterildi.

Soru bazlı özet, toplam dinleme sayısı ve tekrar önerisi aynı tamamlanma ekranında birlikte doğrulandı.

Sprint 58 — Tamamlanma ekranında ifadeyi dinleme

Dinleme pratiği tamamlanma ekranındaki Tekrar Önerisi kartına “İfadeyi Dinle” düğmesi eklendi.

Düğme, önerilen yabancı ifadeyi mevcut tarayıcı seslendirme servisiyle seslendirir hâle getirildi.

Tamamlanma ekranındaki seslendirme toplam dinleme sayacına dâhil edilmedi.

Mevcut Local Storage yapısı, dinleme sayaçları ve katmanlı mimari değiştirilmedi.

Sprint 59 — Translation Studio ilk çalışan çalışma alanı

Translation Studio için /translation rotası ve navigasyon bağlantısı eklendi.

Macarca ↔ Türkçe dil yönü ve aynı kaynak-hedef dil seçimini engelleyen seçim davranışı oluşturuldu.

Genel, hukuk, sağlık, ekonomi, akademik ve kurumsal uzmanlık alanları eklendi.

“Ben Çevireceğim” ve “Çeviri Yardımı” çalışma biçimleri oluşturuldu.

Kaynak metin ve çeviri taslağı alanları, karakter sayaçları ve çalışma alanı durum göstergesi eklendi.

Mobil uyumlu Translation Studio arayüzü teslim edildi.

Sprint 60 — Translation Studio taslak kaydı

Translation Studio için aktif taslak veri modeli oluşturuldu.

Dil yönü, uzmanlık alanı, çalışma biçimi, kaynak metin ve çeviri taslağı Local Storage üzerinde otomatik kaydedilir hâle getirildi.

Sayfa yeniden açıldığında veya yenilendiğinde kayıtlı taslağın geri yüklenmesi sağlandı.

Bozuk veya mevcut modelle uyumsuz kayıtların uygulamayı etkilemeden yok sayılması sağlandı.

Taslağın son kaydedilme saati çalışma alanında görünür hâle getirildi.

Storage adaptörü için boş kayıt, kayıt/geri yükleme, boş metinler, bozuk veri ve uyumsuz veri senaryolarını kapsayan 5 test eklendi.

Sprint 61 — Translation Studio taslak yönetimi

Translation Studio başlığına “Yeni Çalışma” düğmesi eklendi.

Kaynak metin veya çeviri taslağı doluyken yeni çalışma başlatılmadan önce kullanıcı onayı alınır hâle getirildi.

Kullanıcı işlemi iptal ettiğinde mevcut taslağın ve ayarların korunması sağlandı.

Kullanıcı işlemi onayladığında kaynak metin, çeviri taslağı ve kayıtlı Local Storage verisi temizlenir hâle getirildi.

Yeni çalışmanın Macarca → Türkçe, Genel ve “Ben Çevireceğim” varsayılan ayarlarıyla başlaması sağlandı.

Storage adaptörüne yalnızca aktif çeviri taslağı anahtarını kaldıran clear işlemi ve bu davranışı doğrulayan test eklendi.

Sprint 62 — Kaynak metni çalışma bölümlerine ayırma

Kaynak metni cümle sonu işaretleri ve satır sınırlarına göre çalışma bölümlerine ayıran saf Core fonksiyonu eklendi.

Boş parçaların elenmesi, bölüm sırasının korunması ve her bölümün karakter sayısının hesaplanması sağlandı.

Translation Studio çalışma alanına “Kaynak metin bölümleri” görünümü eklendi.

Her bölümün sıra numarası, metni ve karakter sayısı kullanıcıya gösterilir hâle getirildi.

Kaynak metin boşaltıldığında bölüm görünümünün otomatik olarak kaldırılması sağlandı.

Boş metin, tek cümle, farklı noktalama işaretleri, satır sınırları ve boşluk normalizasyonunu kapsayan 5 Core testi eklendi.

Sprint 63 — Bölüm seçimi ve odaklı çeviri

Kaynak metin bölüm kartları tıklanabilir hâle getirildi.

İlk bölümün çalışma başladığında otomatik olarak seçilmesi sağlandı.

Seçilen bölüm kartı görsel olarak vurgulanır hâle getirildi.

Çalışma alanına seçilen kaynak metni gösteren “Odaklanan bölüm” alanı eklendi.

Odaklanan bölümün sıra numarası ve toplam bölüm sayısı birlikte gösterilir hâle getirildi.

Kaynak metin değiştiğinde artık bulunmayan bir seçimin güvenli biçimde ilk geçerli bölüme dönmesi sağlandı.

Sprint 64 — Bölüm bazlı çeviri taslakları

Her kaynak metin bölümü için ayrı çeviri taslağı oluşturulabilir hâle getirildi.

Sağdaki çeviri alanı yalnızca seçili kaynak bölümün taslağını düzenler hâle getirildi.

Bölümler arasında geçiş yapıldığında daha önce yazılan taslakların korunması sağlandı.

Bölüm kartlarına “Taslak hazır” ve “Taslak bekliyor” durumları eklendi.

Tamamlanan bölüm taslağı sayısı “1 / 3 çevrildi” biçiminde gösterilir hâle getirildi.

Bölüm bazlı taslaklar mevcut otomatik Local Storage kaydına dâhil edildi.

Eski tek parça çeviri taslaklarının ilk bölüme aktarılması ve eski kayıtların geriye uyumlu açılması sağlandı.

Eski kayıt ve geçersiz bölüm taslağı senaryolarını kapsayan 2 yeni storage testi eklendi.

Sprint 65 — Birleştirilmiş çeviri önizlemesi

Bölüm taslaklarını kaynak bölüm sırasına göre birleştiren saf Core servisi eklendi.

Translation Studio çalışma alanına “Tam çeviri önizlemesi” bölümü eklendi.

Tamamlanan bölüm taslakları iki satır arayla tek bir çeviri metninde birleştirilir hâle getirildi.

Eksik çalışma durumunda bekleyen bölüm sayısının gösterilmesi sağlandı.

Bütün bölümler tamamlandığında “Tüm bölümler hazır” durumu eklendi.

Artık kaynak metinde bulunmayan eski bölüm taslaklarının önizlemeye dâhil edilmemesi sağlandı.

Boş çalışma, kaynak sırası, boş taslak, tamamlanma ve eski taslak senaryolarını kapsayan 5 Core testi eklendi.

Sprint 66 — Tam çeviriyi panoya kopyalama

Tam veya kısmi çeviri önizlemesini tarayıcı panosuna kopyalayan UI katmanı servisi eklendi.

“Tam çeviri önizlemesi” başlığına “Çeviriyi Kopyala” düğmesi eklendi.

Kopyalama devam ederken, başarıyla tamamlandığında ve başarısız olduğunda kullanıcıya ayrı durum geri bildirimleri gösterilir hâle getirildi.

Boş çeviri önizlemesinde kopyalama düğmesinin pasif kalması sağlandı.

Pano erişiminin bulunmaması, boş metin ve tarayıcı izin hataları güvenli biçimde ele alındı.

Pano servisi için başarılı kopyalama, boş metin, kullanılamayan pano ve yazma hatası senaryolarını kapsayan 4 test eklendi.

İlk teslim paketindeki fazladan app klasörü düzeltildi; Sprint 66 Rev2 paketi proje köküne göre src klasöründen başlayacak biçimde hazırlandı.

Sprint 67 — Çeviri çalışmasını UTF-8 metin dosyası olarak indirme

Tarayıcıya özgü dosya üretimi ve indirme işlemleri için UI katmanında BrowserTextDownloadService eklendi.

“Tam çeviri önizlemesi” alanına “Çalışmayı İndir” düğmesi eklendi.

İndirilen UTF-8 metin dosyasına LAF Studio başlığı, dil yönü, uzmanlık alanı ve çalışma biçimi bilgileri eklendi.

Kaynak metin “KAYNAK METİN”, tamamlanan çeviri ise “ÇEVİRİ” başlığı altında aynı dosyada birlikte sunulur hâle getirildi.

Türkçe ve Macarca karakterlerin, bölüm sırasının ve satır aralıklarının korunması sağlandı.

İndirme başarı ve hata durumları kullanıcıya ayrı geri bildirimlerle gösterilir hâle getirildi.

İlk sürümde yalnızca hedef çevirinin indirilmesi tarayıcı doğrulamasında tespit edildi; Sprint 67 Rev1 ile iki dilli çalışma belgesi biçimine geçirildi.

İndirme servisi için UTF-8 içerik, boş metin, desteklenmeyen tarayıcı ve indirme hatası sonrası kaynak temizliği senaryolarını kapsayan 4 test eklendi.

12. Güncel doğrulama durumu

Tarihsel kayıt (28 Temmuz 2026): Son tamamlanan sprint Sprint 67

Doğrulama tarihi: 28 Temmuz 2026

Sprint 67 doğrulama saati: 01:02

Test sonucu: 20 test dosyası ve 173 test başarılı.

Production build: Başarılı.

Vite build: 97 modül dönüştürüldü.

Son build çıktısı:

CSS: 39.09 kB — gzip 7.12 kB

JavaScript: 321.05 kB — gzip 94.67 kB

Sprint 67 Rev1 son build süresi: 750 ms

Tarayıcı doğrulaması: Olumlu.

Sprint 67 için tarayıcıda doğrulanan özellikler:

“Çalışmayı İndir” düğmesinin “Tam çeviri önizlemesi” alanında görünmesi

UTF-8 metin dosyasının tarayıcı üzerinden indirilmesi

Kaynak metin ve çevirinin aynı dosyada ayrı başlıklarla bulunması

Türkçe ve Macarca karakterlerin korunması

Başarılı indirme sonrasında kullanıcı geri bildiriminin görünmesi

13. Güncel teknik kararlar

Dinleme pratiği ana LearningSession oturumundan ayrı tutulur.

Dinleme metrikleri ana ders tamamlanma yüzdesini değiştirmez.

Tarayıcıya özgü seslendirme, kayıt ve Local Storage uygulamaları UI katmanında tutulur.

Dinleme hesaplamaları features/lessons servisleri içerisinde saf fonksiyonlarla yapılır.

Ses kaydı geçici tarayıcı URL'si kullanır; sunucuya veya kalıcı depoya ses dosyası gönderilmez.

Ders ve dinleme kayıtları ders kimliğine göre ayrı Local Storage anahtarlarında tutulur.

Kod teslimleri klasör yapısını koruyan LAF-Studio-Sprint-XX.zip değişiklik paketleriyle yapılır.

Bir sprint yalnızca test, build ve tarayıcı doğrulaması olumlu olduğunda tamamlanır.

Her tamamlanan ve doğrulanan sprintten sonra PROJECT_NOTES.md dosyasına kısa bir kontrol noktası eklenir.

Çalışma gününün sonunda kısa kontrol noktaları tarih, saat ve toplam çalışma bilgileriyle topluca düzenlenir.

14. Devam eden işler

Aktif ve yarım kalmış bir sprint bulunmuyor.

Sprint 67 tamamen doğrulandı ve kapatıldı.

Translation Studio’nun ilk çalışma alanı, taslak sürekliliği, yeni çalışma akışı, kaynak metin bölümleme, odaklı bölüm seçimi, bölüm bazlı taslaklar, tam çeviri önizlemesi, panoya kopyalama ve iki dilli metin dosyası indirme akışı çalışır durumdadır.

15. Bir sonraki adımlar

Ana ürün mimarisi Learning Studio, Translation Studio, Interpreting Studio ve LAF Intelligence Core olarak onaylandı.

Translation Studio V1 kapsamı ve temel kullanıcı akışı onaylandı.

Translation Studio Development Brief hazırlandı ve onaylandı:

TRANSLATION_STUDIO_V1_DEVELOPMENT_BRIEF.md

Sprint 67 hedefi tamamen teslim edildi.

Sprint 68 hedefi, “Ben Çevireceğim” modunda kaynak metin ve kullanıcı çevirisinden doğrulanabilir bir değerlendirme isteği oluşturabilmektir.

Sprint 68’de sahte AI değerlendirme sonucu üretilmeyecek; değerlendirme isteği modeli, hazırlık doğrulaması ve kullanıcı akışı kurulacaktır.

Sprint 1–58 arasında tamamlanan çalışmalar Learning Studio temel prototipi; Sprint 59–67 ise Translation Studio’nun ilk çalışan temeli, taslak sürekliliği, yeni çalışma akışı, kaynak metin bölümleme, odaklı bölüm seçimi, bölüm bazlı taslaklar, birleşik önizleme, panoya kopyalama ve iki dilli dosya indirme olarak kabul edilir.

Geliştirme sırasında mevcut katmanlı mimari, Local Storage uyumluluğu ve ana ders ilerleme hesapları korunacaktır.

16. Çalışma sonu güncelleme şablonu

Her çalışma gününün sonunda aşağıdaki kayıt belgenin güncel durum bölümüne eklenir:

## Çalışma Kaydı — DD.MM.YYYY, SS:DD–SS:DD

- Başlangıç saati:
- Bitiş saati:
- Toplam çalışma süresi:
- Tamamlanan sprintler:
- Amaç:
- Yapılan değişiklikler:
- Değiştirilen dosyalar:
- Alınan kararlar:
- Test sonucu:
- Build sonucu:
- Tarayıcı doğrulaması:
- Çalışan özellikler:
- Açık sorunlar:
- Sonraki adım:

17. Yeni sohbet başlangıç talimatı

Yeni bir LAF Studio — Development sohbetinde aşağıdaki mesaj kullanılmalıdır:

LAF Studio — Development projesine devam ediyoruz.

Önce proje kökündeki PROJECT_NOTES.md dosyasını oku.

Mevcut durumu, mimari kararları, tamamlanan işleri, devam eden sprinti ve bir sonraki adımı bu dosyaya göre belirle.

Mevcut katmanlı mimariyi ve çalışma kurallarını koru.

Aynı anda yalnızca bir sprint üzerinde çalış.

Her sprint sonunda npm run test, npm run build ve tarayıcı doğrulaması yap.

Kod teslimlerini klasör yapısını koruyan ZIP değişiklik paketleriyle hazırla.

Her tamamlanan sprintten sonra PROJECT_NOTES.md dosyasına kısa bir kontrol noktası ekle.

Çalışma gününün sonunda bu kayıtları tarih, saat ve toplam çalışma süresiyle topluca düzenle.

---

## Sprint 85 — Bağlamsal anlam isteği ve manuel sonuç kaydı

Durum: TAMAMLANDI ve TARAYICIDA DOĞRULANDI

Amaç:
Metin ve Kelime Atölyesi içinde seçilen bir kelime için bağlama özel anlam inceleme akışını kurmak; ilgili cümleyi ve dil yönünü belirlemek, yapılandırılmış AI isteği üretmek, sonucu kullanıcı tarafından karşılık + gerekçe + güven düzeyi ile kaydetmek ve kullanıcı onayı olmadan Terminoloji Merkezi'ne otomatik kayıt yapmamak.

Doğrulanan akış:
- Kaynak dili Macarca seçildi.
- Test metni: "Az egészségügy új intézkedéseket vezetett be. Az intézkedéseket sokan vitatják."
- "vitatják" kelimesi seçildi.
- İlgili cümle doğru bulundu: "Az intézkedéseket sokan vitatják."
- Çeviri yönü doğru belirlendi: Macarca → Türkçe.
- Bağlamsal anlam için yapılandırılmış AI isteği oluşturuldu.
- "Panoya Kopyala" işlevi çalıştı.
- Ana karşılık alanına "eleştiriyorlar" yazılabildi.
- Gerekçe alanına "Bu bağlamda alınan önlemlere karşı çıkılması anlatılıyor." yazılabildi.
- Güven düzeyi seçilebildi.
- Sonuç başarıyla kaydedilebildi.
- Sonuç kullanıcı onayı olmadan Terminoloji Merkezi'ne otomatik eklenmedi.

Teknik doğrulama:
- Test dosyası: 42 passed
- Test: 290 passed / 0 failed
- Production build: başarılı
- Vite: 125 modül dönüştürüldü
- Build süresi: 719 ms
- Tarayıcı doğrulaması: OLUMLU

Kararlı taban:
Sprint 85 / 290 passed / 0 failed

Sıradaki sprint:
Sprint 86 — Bağlamsal anlamın sistem tarafından otomatik üretilmesi.

LAF Studio geliştirme çalışma standardı:
- Aynı anda yalnızca tek sprint yürütülür.
- Önce hedef test, ardından tam regresyon çalıştırılır.
- Kararlı taban korunur.
- Teslim mümkün olduğunca tek ZIP + tek PowerShell ile yapılır.
- Parçalı yama yerine mümkün olduğunca tam dosya değişikliği kullanılır.
- Test, build ve tarayıcı doğrulaması tamamlanmadan sonraki sprinte geçilmez.
- Kullanıcı onayı olmadan Terminoloji Merkezi'ne otomatik aktarım yapılmaz.

Not:
Proje kökündeki PROJECT_NOTES.md kaydı Sprint 67'de kalmıştı. Kaynak kod incelemesi ve doğrulama geçmişi Sprint 85'in tamamlandığını gösterdi. Bu kontrol noktası gerçek kararlı geliştirme durumunu yeniden senkronize eder.

---

## Sprint 86 — Bağlamsal anlamın sistem tarafından otomatik üretilmesi

Durum: TAMAMLANDI ve TARAYICIDA DOĞRULANDI

Amaç:
Metin ve Kelime Atölyesi içinde seçilen bir kelime için bağlama özel anlamın yapay zekâ tarafından otomatik üretilmesini sağlamak; Sprint 85'teki manuel inceleme ve kullanıcı onayı güvenlik davranışını korumak.

Uygulanan davranış:
- Seçilen kelime ve bağlam cümlesinden yapılandırılmış AI isteği hazırlanır.
- AI sonucu ana karşılık, bağlam gerekçesi ve güven düzeyi alanlarına otomatik getirilir.
- Kullanıcı AI sonucunu kaydetmeden önce düzenleyebilir.
- Sonuç kullanıcı eylemi olmadan kesinleştirilmez.
- Terminoloji Merkezi'ne otomatik kayıt yapılmaz.
- Terminolojiye aktarım yalnızca açık kullanıcı eylemiyle gerçekleşir.
- API anahtarı tarayıcı tarafına taşınmaz; yerel backend/provider sınırı kullanılır.

Teknik doğrulama:
- Sprint 86 hedef testleri: 3 test dosyası / 18 test başarılı
- Tam regresyon: 44 test dosyası / 299 test başarılı
- Hata: 0
- Production build: başarılı
- Vite: 127 modül dönüştürüldü
- Build süresi: 6.32 sn
- Başlangıç kararlı tabanı: Sprint 85 / 290 passed / 0 failed
- Sprint 85 yedeği: D:\Projects\LAF-Studio\_sprint_backups\Sprint86-20260805-211104

Tarayıcı doğrulaması:
- Kaynak dil: Macarca
- Test metni: "Az egészségügy új intézkedéseket vezetett be. Az intézkedéseket sokan vitatják."
- Seçilen kelime: "vitatják"
- Bağlam cümlesi doğru bulundu: "Az intézkedéseket sokan vitatják."
- AI otomatik sonuç üretti.
- Ana karşılık örneği: "tartışıyorlar"
- Bağlam gerekçesi otomatik üretildi.
- Güven düzeyi otomatik üretildi: Yüksek
- Sonuç kullanıcı tarafından kaydedilebilir durumda doğrulandı.
- Terminoloji Merkezi'ne kendiliğinden eklenmediği doğrulandı.
- Tarayıcı doğrulaması: OLUMLU

Yeni kararlı taban:
Sprint 86 / 299 passed / 0 failed

Çalışma kuralı:
Sprint 86 tamamen kapanmıştır. Yeni sprint, kapsamı belirlenip onaylanmadan başlatılmayacaktır.

---

## Sprint 87 — Bağlamsal Anlam İnceleme Geçmişi

Durum: TAMAMLANDI ve TARAYICIDA DOĞRULANDI

Amaç:
Kaydedilen bağlamsal anlam sonuçlarını kalıcı inceleme geçmişi olarak saklamak; aynı kelime tekrar seçildiğinde önceki incelemeleri göstermek; birebir aynı kaydın çoğalmasını engellemek ve Sprint 86'daki kullanıcı onayı güvenlik davranışını korumak.

Uygulanan davranış:
- "Anlamı İncelemeye Ekle" ile kaydedilen sonuçlar Local Storage üzerinde kalıcı tutulur.
- Aynı kelime yeniden seçildiğinde önceki bağlamsal anlam incelemeleri gösterilir.
- Birebir aynı inceleme sonucu tekrar kaydedildiğinde yeni kopya oluşturulmaz.
- Düzenlenmiş veya farklı sonuçlar ayrı tarihsel kayıt olarak saklanabilir.
- AI otomatik üretim akışı korunur.
- Terminoloji Merkezi'ne otomatik aktarım yapılmaz.
- Terminolojiye aktarım yalnızca açık kullanıcı eylemiyle gerçekleşir.

Teknik doğrulama:
- Tam regresyon: 45 test dosyası / 307 test başarılı
- Hata: 0
- Production build: başarılı
- Vite: 128 modül dönüştürüldü
- Build süresi: 2.85 sn
- Başlangıç kararlı tabanı: Sprint 86 / 299 passed / 0 failed
- Sprint 86 yedeği: D:\Projects\LAF-Studio\_sprint_backups\Sprint87-20260805-214009

Tarayıcı doğrulaması:
- Kaynak dil: Macarca
- Test kelimesi: "vitatják"
- AI sonucu oluşturuldu ve "Anlamı İncelemeye Ekle" ile kaydedildi.
- "İNCELEME GEÇMİŞİ / Kaydedilen bağlamsal anlamlar" bölümü görüntülendi.
- Kayıtta karşılık, bağlam cümlesi, gerekçe, güven düzeyi ve kayıt zamanı görüntülendi.
- Ctrl + F5 sonrasında geçmiş kaydı yeniden göründü.
- Aynı sonuç ikinci kez kaydedildiğinde kayıt sayısı çoğalmadı.
- Terminoloji Merkezi'ne kendiliğinden kayıt yapılmadı.
- Tarayıcı doğrulaması: OLUMLU

Yeni kararlı taban:
Sprint 87 / 307 passed / 0 failed

Çalışma kuralı:
Sprint 87 tamamen kapanmıştır. Yeni sprint kapsamı belirlenmeden ve onaylanmadan sonraki geliştirmeye geçilmeyecektir.

---

## Sprint 88 — İnceleme Geçmişinden Yeniden Kullanım

Durum: TAMAMLANDI ve TARAYICIDA DOĞRULANDI

Amaç:
Bağlamsal anlam inceleme geçmişindeki bir kaydı yeniden düzenleme alanlarına yükleyebilmek; kullanıcının eski karşılık, gerekçe ve güven düzeyini düzenleyip yeniden kaydedebilmesini sağlamak ve Sprint 87 tekrar-kayıt korumasını sürdürmek.

Uygulanan davranış:
- İnceleme geçmişindeki kayıtlara "Düzenlemeye Yükle" eylemi eklendi.
- Geçmiş kaydı ana karşılık, bağlam gerekçesi ve güven düzeyi alanlarına geri yüklenir.
- Kullanıcı yüklenen alanları düzenleyebilir.
- Birebir aynı içerik değiştirilmeden yeniden kaydedildiğinde yeni kopya oluşturulmaz.
- Düzenlenmiş/farklı sonuç ayrı tarihsel kayıt olarak saklanır.
- AI otomatik üretim akışı korunur.
- Terminoloji Merkezi'ne otomatik aktarım yapılmaz.
- Terminolojiye aktarım yalnızca açık kullanıcı eylemiyle gerçekleşir.

Teknik doğrulama:
- Tam regresyon: 45 test dosyası / 309 test başarılı
- Hata: 0
- Production build: başarılı
- Vite: 128 modül dönüştürüldü
- Build süresi: 963 ms
- Başlangıç kararlı tabanı: Sprint 87 / 307 passed / 0 failed
- Sprint 87 yedeği: D:\Projects\LAF-Studio\_sprint_backups\Sprint88-20260805-215158

Tarayıcı doğrulaması:
- Geçmiş kaydındaki "Düzenlemeye Yükle" eylemi çalıştı.
- Ana karşılık yeniden düzenleme alanına geldi.
- Bağlam gerekçesi yeniden düzenleme alanına geldi.
- Güven düzeyi yeniden yüklendi.
- Alanlar kullanıcı tarafından düzenlenebildi.
- Değiştirilmeden yeniden kaydedilen aynı sonuç geçmişte çoğalmadı.
- Düzenlenmiş farklı sonuç ayrı geçmiş kaydı oluşturdu.
- Terminoloji Merkezi'ne otomatik kayıt yapılmadı.
- Tarayıcı doğrulaması: OLUMLU

Yeni kararlı taban:
Sprint 88 / 309 passed / 0 failed

Çalışma kuralı:
Sprint 88 tamamen kapanmıştır. Yeni sprint kapsamı belirlenmeden ve onaylanmadan sonraki geliştirmeye geçilmeyecektir.

---

## Sprint 89 — İnceleme Geçmişi Kayıt Silme

Durum: TAMAMLANDI ve TARAYICIDA DOĞRULANDI

Uygulanan davranış:
- Tek bir bağlamsal anlam geçmiş kaydı "Kaydı Sil" eylemiyle kaldırılabilir.
- Silmeden önce kullanıcı onayı alınır.
- İptal edilirse kayıt korunur.
- Onaylanırsa yalnız seçilen kayıt silinir.
- Ctrl + F5 sonrasında silinen kayıt geri gelmez.
- Diğer geçmiş kayıtları korunur.
- Terminoloji Merkezi etkilenmez.

Teknik doğrulama:
- Başlangıç kararlı tabanı: Sprint 88 / 309 passed / 0 failed
- Sprint 89 hedef testleri başarılı
- Tam regresyon başarılı
- Production build başarılı
- Sprint 89 paketi üç yeni regresyon testi ekledi.
- Kararlı test tabanı: Sprint 89 / 312 passed / 0 failed

Tarayıcı doğrulaması: OLUMLU

Yeni kararlı taban:
Sprint 89 / 312 passed / 0 failed

---

## Sprint 90 — Bağlamsal Anlam Geçmişi Arama ve Sıralama

Durum: TAMAMLANDI ve TARAYICIDA DOĞRULANDI

Amaç:
Bağlamsal anlam inceleme geçmişini daha büyük ve kullanışlı bir çalışma alanına dönüştürmek; geçmiş kayıtlarında arama, sıralama ve tüm eşleşen kayıtlara erişim sağlamak.

Uygulanan davranış:
- Geçmişte karşılık, gerekçe ve bağlam metnine göre arama yapılabilir.
- Geçmiş "En yeni önce" ve "En eski önce" olarak sıralanabilir.
- Önceki 5 kayıt görünüm sınırı kaldırıldı; eşleşen tüm geçmiş kayıtları görüntülenebilir.
- Filtrelenen / toplam kayıt sayısı gösterilir.
- Filtre tek eylemle temizlenebilir.
- Önceki "Düzenlemeye Yükle" davranışı korunur.
- Tek kayıt silme ve kullanıcı onayı davranışı korunur.
- Birebir aynı kaydın çoğalmasını engelleyen koruma sürer.
- Terminoloji Merkezi'ne otomatik aktarım yapılmaz.

Teknik doğrulama:
- Başlangıç kararlı tabanı: Sprint 89 / 312 passed / 0 failed
- Sprint 90 hedef testleri başarılı
- Tam regresyon: 46 test dosyası / 319 test başarılı
- Hata: 0
- Production build: başarılı

Tarayıcı doğrulaması:
- Geçmiş arama alanı çalıştı.
- Karşılık, gerekçe veya bağlam metnine göre filtreleme çalıştı.
- En yeni / en eski sıralama çalıştı.
- Filtrelenen / toplam kayıt sayısı doğru gösterildi.
- Filtreyi temizleme çalıştı.
- Önceki geçmiş yönetimi işlevleri bozulmadı.
- Terminoloji Merkezi'ne otomatik aktarım yapılmadı.
- Tarayıcı doğrulaması: OLUMLU

Yeni kararlı taban:
Sprint 90 / 319 passed / 0 failed

Çalışma modeli:
Sprint 90'dan itibaren kalite ve güvenlik kapıları azaltılmadan daha orta büyüklükte sprintler uygulanır:
- tek sprint,
- hedef test,
- tam regresyon,
- production build,
- tarayıcı doğrulaması,
- kararlı taban yedeği,
- başarısızlıkta geri dönüş,
- tek ZIP + tek PowerShell,
- mümkün olduğunca tam dosya değişikliği,
- doğrulanmadan sonraki sprinte geçmeme.

---

## Sprint 91 — Bağlamsal Anlam Geçmişi Akıllı Filtreleme ve Özet

Durum: TAMAMLANDI ve TARAYICIDA DOĞRULANDI

Amaç:
Bağlamsal anlam inceleme geçmişini güven düzeyi ve bağlam kapsamı ile daha hızlı süzülebilir hâle getirmek; görünür geçmiş için özet sayaçları sunmak ve mevcut arama/sıralama davranışlarıyla birlikte çalışmasını sağlamak.

Uygulanan davranış:
- Güven filtresi: Tümü / Yüksek / Orta / Düşük.
- Bağlam kapsamı: Tüm bağlamlar / Yalnız bu cümle.
- Eşleşen kayıt sayısı gösterilir.
- Yüksek / Orta / Düşük güven dağılımı özetlenir.
- Arama, sıralama, güven filtresi ve bağlam filtresi birlikte çalışır.
- Tüm aktif filtreler tek eylemle temizlenebilir.
- Geçmişten düzenlemeye yükleme korunur.
- Tek kayıt silme ve kullanıcı onayı korunur.
- Birebir aynı kaydın çoğalmasını engelleyen koruma sürer.
- AI otomatik üretimi korunur.
- Terminoloji Merkezi'ne otomatik aktarım yapılmaz.

Teknik doğrulama:
- Başlangıç kararlı tabanı: Sprint 90 / 319 passed / 0 failed
- Sprint 91 hedef testleri başarılı
- Tam regresyon başarılı
- Sprint 91 paketinde 6 yeni test
- Yeni kararlı test tabanı: Sprint 91 / 325 passed / 0 failed
- Production build başarılı

Tarayıcı doğrulaması:
- Güven filtresi görüntülendi ve çalıştı.
- Bağlam kapsamı filtresi görüntülendi ve çalıştı.
- Eşleşen / Yüksek / Orta / Düşük özet sayaçları doğru davrandı.
- Arama + güven filtresi + bağlam filtresi birlikte çalıştı.
- Filtreleri Temizle varsayılan duruma döndürdü.
- Önceki sıralama, Düzenlemeye Yükle ve Kaydı Sil işlevleri korunmuş durumda.
- Terminoloji Merkezi'ne otomatik kayıt yapılmadı.
- Tarayıcı doğrulaması: OLUMLU

Yeni kararlı taban:
Sprint 91 / 325 passed / 0 failed

Çalışma modeli:
Kalite ve güvenlik kapıları korunarak orta büyüklükte sprintlerle ilerleme sürdürülür.

---

## Sprint 92–94 Blok Kapanışı

Durum: TAMAMLANDI ve TOPLU TARAYICI DOĞRULAMASI OLUMLU

Başlangıç kararlı tabanı:
Sprint 91 / 325 passed / 0 failed

### Sprint 92 Rev1 — Bağlamsal Anlam Geçmişi Dışa Aktarma
- Görünen / filtrelenmiş geçmiş panoya kopyalanabilir.
- Görünen / filtrelenmiş geçmiş UTF-8 TXT dosyası olarak indirilebilir.
- Dışa aktarılan içerikte kelime, dil yönü, aktif filtreler, sıralama, bağlam kapsamı ve kayıt sayıları bulunur.
- İlk Sprint 92 denemesinde test dosyasındaki iki TypeScript strict-build hatası nedeniyle production build başarısız oldu.
- Kurucu Sprint 91 tabanını otomatik geri yükledi.
- Sprint 92 Rev1'de yalnız test tipi uyumluluğu düzeltildi ve teknik doğrulama başarıyla tamamlandı.

### Sprint 93 — İki Kaydı Karşılaştırma
- Geçmişten en fazla iki inceleme kaydı seçilebilir.
- Kayıt A ve Kayıt B yan yana karşılaştırılabilir.
- Karşılık, Güven, Bağlam ve Gerekçe alanları için Aynı / Farklı özeti gösterilir.
- İki kayıt seçiliyken üçüncü seçim engellenir.
- Seçim temizlenebilir.
- Silinen kayıt karşılaştırma seçiminden otomatik çıkarılır.

### Sprint 94 — Karşılaştırma Sonucunu Kullanma ve Özetleme
- Tüm alanlar / Yalnız farklı alanlar görünümü vardır.
- Kayıt A ve B karşılaştırma tablosunda yan yana gösterilir.
- Farklı alanlar görsel olarak ayrıştırılır.
- Kayıt A veya Kayıt B doğrudan düzenleme alanına yüklenebilir.
- Karşılaştırma özeti panoya kopyalanabilir.
- Fark bulunmayan karşılaştırma açıkça gösterilir.

Teknik doğrulama:
- Sprint 92 Rev1: başarılı
- Sprint 93: başarılı
- Sprint 94: başarılı
- Yeni kararlı test tabanı: Sprint 94 / 349 passed / 0 failed
- Production build: başarılı
- Otomatik yedek / geri dönüş koruması: aktif

Toplu tarayıcı doğrulaması:
- Sprint 92 dışa aktarma davranışları: OLUMLU
- Sprint 93 iki kayıt karşılaştırma davranışları: OLUMLU
- Sprint 94 karşılaştırma sonucu kullanma ve özetleme davranışları: OLUMLU
- Önceki arama, sıralama, filtreleme, Düzenlemeye Yükle ve Kaydı Sil işlevleri korunuyor.
- Terminoloji Merkezi'ne otomatik aktarım yapılmıyor.
- Toplu tarayıcı doğrulaması: OLUMLU

Risk sınırları:
- Local Storage şeması değiştirilmedi.
- AI/backend değiştirilmedi.
- Routing değiştirilmedi.
- Terminoloji Merkezi güvenlik davranışı değiştirilmedi.

Yeni kararlı taban:
Sprint 94 / 349 passed / 0 failed

Çalışma modeli:
- İlişkili geliştirmeler 3 sprintlik bloklar hâlinde ilerletilir.
- Her sprintte hedef test + tam regresyon + production build + yedek/geri dönüş korunur.
- Manuel tarayıcı doğrulaması ve PROJECT_NOTES kapanışı blok sonunda toplu yapılır.
- Yüksek riskli değişikliklerde ara manuel doğrulama zorunludur.

Planlanan sonraki bağımsız geliştirme alanı:
Belge ve Görsel Çeviri Girdisi
- PDF
- JPG
- JPEG
- PNG
- Metin tabanlı PDF'de doğrudan metin katmanı
- Taranmış PDF/görsellerde gerektiğinde OCR
- Çıkarılan metni kullanıcıya gösterme ve düzeltme
- Kullanıcı onayından sonra mevcut çeviri ve Metin/Kelime Atölyesi zincirine aktarma
- Sessiz otomatik çeviri yapılmaması

---

## Sprint 95–97 Blok Kapanışı — Belge ve Görsel Çeviri Girdisi

Durum: TAMAMLANDI ve TOPLU TARAYICI DOĞRULAMASI OLUMLU

Başlangıç kararlı tabanı:
Sprint 94 / 349 passed / 0 failed

### Sprint 95 — Güvenli Dosya Kabulü ve Önizleme
- PDF / JPG / JPEG / PNG dosyası seçme.
- Sürükleyip bırakma.
- Dosya türü, boş dosya ve 20 MB boyut sınırı doğrulaması.
- Yerel görsel / PDF önizleme.
- Dosya adı, türü, boyutu ve son değişiklik bilgisi.
- Dosyayı Kaldır davranışı.
- Dosya bu aşamada backend, AI veya OCR işlemine gönderilmez.

### Sprint 96 Rev4 — PDF Metin Katmanı ve OCR Hazırlık Mimarisi
- Metin tabanlı PDF'lerde yerel PDF.js metin çıkarımı.
- Sayfa bazlı metin birleştirme.
- Metin katmanı bulundu / OCR gerekli / çıkarım hatası ayrımı.
- Görsel ve taranmış PDF için OCR gerekli sınıflandırması.
- PDF.js TypeScript uyumluluk düzeltmeleri.
- Windows PowerShell 5.1 native stderr / exit code build doğrulaması düzeltildi.
- Teknik doğrulama Rev4'te başarıyla tamamlandı.

### Sprint 97 Rev1 — OCR, Kullanıcı Kontrolü ve Çalışma Alanına Aktarım
- JPG / JPEG / PNG için kullanıcı başlatmalı tarayıcı içi OCR.
- Taranmış PDF sayfalarının yerel rasterizasyonu ve OCR akışı.
- Macarca OCR modeli: hun.
- Türkçe OCR modeli: tur.
- Sayfa bazlı OCR ilerleme göstergesi.
- OCR/PDF çıkarım sonucunu düzenlenebilir kullanıcı kontrol alanında gösterme.
- Düzeltmeleri Sıfırla.
- Açık kullanıcı onayıyla Metni Çalışma Alanına Aktar.
- Aktarım otomatik çeviri başlatmaz.
- Terminoloji Merkezi'ne otomatik kayıt yapılmaz.
- İlk Sprint 97 denemesinde Node/Vitest ortamındaki DOM/canvas bağımlı test hatası nedeniyle rollback çalıştı.
- Rev1 testleri DOM bağımsız hâle getirildi ve teknik doğrulama başarıyla tamamlandı.

Toplu tarayıcı doğrulaması:
- PDF/JPG/PNG dosya kabulü ve önizleme: OLUMLU
- Dosyayı Kaldır: OLUMLU
- PDF metin katmanı çıkarımı: OLUMLU
- OCR gerekli sınıflandırması: OLUMLU
- Kullanıcı başlatmalı OCR: OLUMLU
- Düzenlenebilir çıkarılan metin: OLUMLU
- Düzeltmeleri Sıfırla: OLUMLU
- Metni Çalışma Alanına Aktar: OLUMLU
- Otomatik çeviri başlatılmaması: OLUMLU
- Terminoloji Merkezi'ne otomatik kayıt yapılmaması: OLUMLU
- Önceki manuel metin ve kelime/bağlamsal anlam akışları: OLUMLU

Teknik durum:
- Sprint 95 teknik doğrulaması: başarılı
- Sprint 96 Rev4 teknik doğrulaması: başarılı
- Sprint 97 Rev1 teknik doğrulaması: başarılı
- Tam regresyon ve production build Sprint 97 Rev1 kurulumunda başarıyla geçti
- Son manuel doğrulanmış ürün durumu: Sprint 97 Rev1

UX notu:
"Dosyayı Kaldır" yalnız belgeyi ve önizlemeyi kaldırır.
Daha önce çalışma alanına aktarılmış metin otomatik silinmez.
Gelecekte ayrı ve açık bir "Belgeyi ve Aktarılan Metni Temizle" eylemi eklenmesi planlanmalıdır.

Yeni kararlı checkpoint:
Sprint 97 Rev1 — Belge ve Görsel Çeviri Girdisi tamamlandı

Sıradaki planlanan geliştirme bloğu:
Sprint 98–100 — Kelime & Hafıza Studio

---

## Sprint 98–100 Blok Kapanışı — Kelime & Hafıza Studio

Durum: TAMAMLANDI ve TOPLU TARAYICI DOĞRULAMASI OLUMLU

Başlangıç kararlı tabanı:
Sprint 97 Rev1 — Belge ve Görsel Çeviri Girdisi

### Sprint 98 — Öğrenme Adayı Havuzu
- Bağlamsal anlam sonucundan “Öğrenmeye Ekle”.
- İnceleme geçmişindeki kayıttan “Öğrenmeye Ekle”.
- Terminoloji karşılığından “Öğrenmeye Ekle”.
- Aynı kelime + aynı anlam + aynı bağlamın tekrar kaydedilmesini engelleme.
- Aynı kelimenin farklı anlamını veya farklı bağlamını ayrı öğrenme adayı olarak kabul etme.
- Seçili kelime için öğrenme adaylarını gösterme.
- “Öğrenmeden Çıkar”.
- Öğrenme havuzu, Terminoloji ve bağlamsal anlam verilerinden ayrı Local Storage katmanında tutulur.

### Sprint 99 Rev1 — Aktif Hatırlama ve Kelime Çalışma Kartları
- Öğrenme adayından “Çalış” ile aktif hatırlama kartı.
- Cevap kullanıcı “Cevabı Göster” demeden görünmez.
- “Bilemedim / Zorlandım / Hatırladım” öz değerlendirmeleri.
- Tekrar sayısı, hatırlama sayısı ve lapse/bilemedim sayısı.
- Basit sonraki çalışma zamanı:
  - Bilemedim: yaklaşık 10 dakika
  - Zorlandım: yaklaşık 1 gün
  - Hatırladım: yaklaşık 3 gün, sonraki olumlu değerlendirmelerde artan aralık
- Öğrenme içeriği ile çalışma ilerlemesi ayrı saklanır.
- İlk Sprint 99 denemesinde find() metodundaki TypeScript parse hatası nedeniyle hedef test durdu.
- Otomatik rollback Sprint 98 tabanını geri yükledi.
- Rev1 parse düzeltmesiyle teknik doğrulama başarıyla tamamlandı.

### Sprint 100 — Günlük Tekrar Kuyruğu ve Çalışma Planı
- Dil yönüne göre kişisel günlük çalışma planı.
- Zamanı gelen tekrarlar önce, yeni kartlar sonra.
- Varsayılan günlük üst sınır: 20 kart.
- Varsayılan yeni kart üst sınırı: 10 kart.
- “Bugün Hazır / Tekrar / Yeni / Bugün Çalışılan / İleri Tarihli” özetleri.
- “Günlük Çalışmayı Başlat”.
- “Sıradaki Kartı Aç”.
- “Planı Yenile”.
- Kuyruktaki kartı doğrudan “Çalış”.
- Bugünkü sıra tamamlandığında sonraki planlı tekrar zamanını gösterme.
- Günlük plan türetilmiş görünüm katmanıdır; ayrı kalıcı plan verisi yazmaz.
- Arka planda polling veya otomatik çalışma başlatılmaz.

Toplu tarayıcı doğrulaması:
- “Öğrenmeye Ekle” görünürlüğü ve kayıt oluşturma: OLUMLU
- Aynı anlam/bağlam için duplicate engeli: OLUMLU
- Öğrenme adayı havuzu: OLUMLU
- “Çalış” çalışma kartı: OLUMLU
- “Cevabı Göster”: OLUMLU
- Bilemedim / Zorlandım / Hatırladım değerlendirmeleri: OLUMLU
- Günlük çalışma planı: OLUMLU
- Bugün Hazır / Tekrar / Yeni / Bugün Çalışılan / İleri Tarihli özetleri: OLUMLU
- Günlük Çalışmayı Başlat / Planı Yenile / kuyruktan Çalış: OLUMLU
- Önceki PDF/OCR, bilinmeyen kelimeler, bağlamsal anlam ve Terminoloji akışları: OLUMLU

Teknik durum:
- Sprint 98 teknik doğrulaması: başarılı
- Sprint 99 Rev1 teknik doğrulaması: başarılı
- Sprint 100 teknik doğrulaması: başarılı
- Tam regresyon: 473 passed / 0 failed (71 test dosyası)
- Production build: başarılı
- Son manuel doğrulanmış ürün durumu: Sprint 100

Yeni kararlı checkpoint:
Sprint 100 — Kelime & Hafıza Studio günlük çalışma planı tamamlandı

Sıradaki planlanan geliştirme bloğu:
Sprint 101–103 — Grammar Lab

---

## Sprint 101–103 Blok Kapanışı — Grammar Lab

Durum: TAMAMLANDI ve TOPLU TARAYICI DOĞRULAMASI OLUMLU

Başlangıç kararlı tabanı:
Sprint 100 — Kelime & Hafıza Studio günlük çalışma planı

### Sprint 101 — Yapı Gözlemi ve Dilbilgisi Not Havuzu
- Metinden seçilen kelimenin bulunduğu cümleyi Grammar Lab bağlamı olarak alma.
- Yapı / dilbilgisi konusu.
- Yapının cümledeki işlevi.
- Kısa kural / açıklama.
- Yüksek / Orta / Düşük güven düzeyi.
- Aynı cümle + aynı yapı duplicate koruması.
- Aynı cümlede farklı yapıları ayrı gözlem olarak kaydetme.
- Tek gözlem silme.
- Grammar verisini ayrı Local Storage katmanında saklama.

### Sprint 102 — Aktif Grammar Alıştırmaları
- Grammar gözleminden “Çalış”.
- Cevap kullanıcı “Cevabı Göster” demeden görünmez.
- Yapı, işlev ve kuralın birlikte gösterilmesi.
- Bilemedim / Zorlandım / Bildim öz değerlendirmeleri.
- Tekrar, başarı ve lapse/bilemedim sayıları.
- Basit sonraki çalışma zamanı ve artan tekrar aralığı.
- Grammar gözlemi silinince bağlı ilerleme kaydını temizleme.

### Sprint 103 — Grammar Günlük Tekrar Kuyruğu
- Zamanı gelen tekrarlar önce, yeni yapılar sonra.
- Varsayılan günlük üst sınır: 15 Grammar kartı.
- Varsayılan yeni yapı üst sınırı: 6.
- Bugün Hazır / Tekrar / Yeni / Bugün Çalışılan / İleri Tarihli özetleri.
- Grammar Çalışmasını Başlat.
- Sıradaki Grammar Kartını Aç.
- Planı Yenile.
- Kuyruktaki kartı doğrudan Çalış.
- Günlük plan tamamlanınca sonraki planlı tekrar zamanını gösterme.
- Günlük plan türetilmiş görünüm; ayrı kalıcı plan verisi yazmaz.

Toplu tarayıcı doğrulaması:
- Grammar Lab görünürlüğü ve cümle bağlamı: OLUMLU
- Manuel yapı / işlev / kural / güven kaydı: OLUMLU
- Duplicate koruması: OLUMLU
- Aktif Grammar çalışma kartı: OLUMLU
- Cevabı Göster: OLUMLU
- Bilemedim / Zorlandım / Bildim: OLUMLU
- Tekrar ve sonraki çalışma bilgileri: OLUMLU
- Grammar günlük çalışma planı: OLUMLU
- Bugün Çalışılan / İleri Tarihli güncellemesi: OLUMLU
- Önceki Kelime & Hafıza Studio ve Bilinmeyen Kelimeler akışları: OLUMLU

Teknik durum:
- Sprint 101 teknik doğrulaması: başarılı
- Sprint 102 teknik doğrulaması: başarılı
- Sprint 103 teknik doğrulaması: başarılı
- Tam regresyon: 473 passed / 0 failed (71 test dosyası)
- Production build: başarılı
- Son manuel doğrulanmış ürün durumu: Sprint 103

### Ürün yönü kararı — Beginner-first Grammar Lab
LAF Studio özellikle yeni başlayanların da kullanabileceği bir dil öğrenme platformu olacaktır.
Kullanıcıdan bilmediği gramer yapısını, işlevini ve kuralını önceden bilerek manuel doldurması beklenmemelidir.

Bu nedenle:
- Sistem AI destekli Grammar analizi önerebilir.
- AI önerisi yapı / işlev / kısa kural / güven alanlarını doldurabilir.
- Öneri doğrudan kalıcı kayda dönüşmez.
- Kullanıcı öneriyi görür, kontrol eder ve gerekirse düzenler.
- Kalıcı kayıt yalnız açık kullanıcı onayıyla yapılır.
- Sistem “öğretmen yardımcısı” gibi davranır; kullanıcı kontrolünü kaldırmaz.

Yol haritası güncellemesi:
- Sprint 104–106: AI Grammar Teacher
- Reading Studio bu blok sonrasına kaydırıldı.

Yeni kararlı checkpoint:
Sprint 103 — Grammar Lab günlük çalışma planı tamamlandı

Sıradaki geliştirme bloğu:
Sprint 104–106 — AI Grammar Teacher

---

## Sprint 104–106 Blok Kapanışı — AI Grammar Teacher

Durum: TAMAMLANDI ve TOPLU TARAYICI DOĞRULAMASI OLUMLU

Başlangıç kararlı tabanı:
Sprint 103 — Grammar Lab günlük çalışma planı

### Sprint 104 Rev2 — Kontrollü AI Grammar Analizi
- Metinden seçilen kelime ve bağlam cümlesi AI Grammar analizine gönderilir.
- Sistem şu alanları öneri olarak doldurur:
  - Yapı / dilbilgisi konusu
  - Bu cümledeki işlevi
  - Kısa kural / açıklama
  - Güven düzeyi
- AI önerisi otomatik kaydedilmez.
- Kullanıcı öneriyi kontrol edebilir ve değiştirebilir.
- Kalıcı kayıt yalnız “Yapıyı Grammar Lab'e Ekle” açık kullanıcı onayıyla oluşur.
- Hatalı/eksik AI JSON yanıtı uygulama katmanında bloke edilir.
- Backend endpoint: POST /api/grammar-analysis

Revizyon notu:
- Rev1 production build sırasında test mock typing sorunu verdi.
- Rev2 bu test tipini güvenli hale getirdi.
- Ürün davranışı değiştirilmedi.

### Sprint 105 Rev1 — Başlangıç Seviyesi AI Grammar Öğretmeni
- “Bunu Bana Öğret” akışı.
- AI şu öğrenme desteğini üretir:
  - Basit anlatım
  - Bu cümlede neden kullanıldığı
  - Kaynak dil örnekleri + Türkçe karşılıkları
  - Yaygın hata / dikkat noktası
- Öğretmen açıklaması geçici ekrandır.
- Local Storage'a veya Grammar kaydına otomatik yazılmaz.
- Form değişirse eski öğretmen açıklaması temizlenir.
- Backend endpoint: POST /api/grammar-teacher-guide

Revizyon notu:
- İlk Sprint 105 hedef testlerinde tek hatalı test beklentisi vardı.
- Rev1 yalnız test beklentisini düzeltti.
- AI Grammar Teacher ürün kodu ve davranışı değiştirilmedi.

### Sprint 106 — Kademeli Grammar Çalışma Desteği
Grammar çalışma kartı akışı:
1. Öğrenci önce kendi başına hatırlamaya çalışır.
2. İpucu Göster.
3. Bir İpucu Daha.
4. Cevabı Göster.
5. Gerekirse AI ile Açıkla.
6. Bilemedim / Zorlandım / Bildim.

Özellikler:
- İlk ipucu seçili öğenin cümledeki anlam ilişkisine odaklanır.
- İkinci ipucu yapının cümledeki işlevini söyler; yapının adını doğrudan vermez.
- AI çalışma açıklaması kayıtlı Grammar gözlemini değiştirmez.
- İpuçları ve AI çalışma açıklaması Local Storage'a yazılmaz.
- Mevcut Sprint 102 tekrar/ilerleme sistemi kullanılmaya devam eder.
- Günlük Grammar planı değerlendirme sonrası anında güncellenir.

### Toplu tarayıcı doğrulaması
- iskolában seçimi ve bağlam cümlesi: OLUMLU
- AI ile Grammar Analizi: OLUMLU
- -ban/-ben bulunma hâli analizi: OLUMLU
- AI önerisinin otomatik kaydedilmemesi: OLUMLU
- Bunu Bana Öğret: OLUMLU
- Basit anlatım / bağlam nedeni / örnekler / dikkat: OLUMLU
- Kullanıcı onayıyla Grammar Lab kaydı: OLUMLU
- İpucu Göster: OLUMLU
- Bir İpucu Daha: OLUMLU
- Cevabı Göster: OLUMLU
- Cevap sonrası AI ile Açıkla: OLUMLU
- Bilemedim / Zorlandım / Bildim: OLUMLU
- Günlük plan güncellemesi: OLUMLU
- Önceki Kelime & Hafıza ve Bilinmeyen Kelimeler akışları: OLUMLU

Teknik durum:
- Sprint 104 Rev2 teknik doğrulaması: başarılı
- Sprint 105 Rev1 teknik doğrulaması: başarılı
- Sprint 106 teknik doğrulaması: başarılı
- Tam regresyon: 473 passed / 0 failed (71 test dosyası)
- Production build: başarılı
- Son manuel doğrulanmış ürün durumu: Sprint 106

### Ürün ilkesi — Beginner-first AI Teacher
LAF Studio özellikle yeni başlayanların da kullanabileceği bir dil öğrenme platformudur.
Kullanıcıdan bilmediği Grammar yapısını önceden bilerek manuel doldurması beklenmez.

Kalıcı ilke:
- Sistem bilmediği alanları AI ile önerebilir.
- AI öğretmen gibi açıklayabilir.
- Kullanıcı kontrolü korunur.
- AI önerisi açık kullanıcı onayı olmadan kalıcı kayda dönüşmez.
- Öğrenme desteği mümkün olduğunca önce ipucu, sonra cevap, sonra AI açıklama şeklinde kademeli verilir.

### UX bakım notu
AI açıklamalarında zaman zaman Markdown işaretleri (**...**) düz metin olarak görünebiliyor.
Bu kritik hata değildir; sonraki uygun UX bakımında güvenli biçimde temizlenmelidir.

Yeni kararlı checkpoint:
Sprint 106 — AI Grammar Teacher kademeli çalışma desteği tamamlandı

Sıradaki geliştirme bloğu:
Sprint 107–109 — Reading Studio

---

## Sprint 107–109 Blok Kapanışı — Reading Studio

Durum: TAMAMLANDI ve TOPLU TARAYICI DOĞRULAMASI OLUMLU

Başlangıç kararlı tabanı:
Sprint 106 — AI Grammar Teacher
71 test dosyası / 473 passed / 0 failed

### Sprint 107 — Odaklı Okuma Temeli
- Metni cümlelere ayırma.
- Cümle sayısı.
- Toplam kelime sayısı.
- Farklı kelime sayısı.
- Tahmini okuma süresi.
- Okuma Modunu Başlat.
- Tek cümle odak kartı.
- Cümle sıra göstergesi ve progress.
- Önceki Cümle / Sonraki Cümle.
- Son cümlede Okumayı Tamamla.
- Metin veya dil değişince aktif Reading oturumunu güvenli sıfırlama.
- Kalıcı Reading verisi yok.

### Sprint 108 — AI Reading Coach
- Kullanıcı tarafından başlatılan “Reading Coach'u Aç”.
- Aktif cümle için:
  - Genel anlam
  - 1–3 önemli kelime/ifade ve kısa Türkçe ipucu
  - Okuma ipucu
  - Kısa anlama sorusu
- Cümle değişince eski AI açıklamasını temizleme.
- Metni veya başka öğrenme kayıtlarını değiştirmeme.
- Otomatik AI çağrısı yok.
- Backend endpoint: POST /api/reading-coach

### Sprint 109 — Okuduğunu Anlama Kontrolü ve Oturum Özeti
- Öğrenci Reading Coach sorusuna kısa Türkçe cevap yazar.
- “Yanıtımı Kontrol Et” kullanıcı tarafından başlatılır.
- AI değerlendirme sonuçları:
  - Doğru
  - Kısmen doğru
  - Tekrar bak
- Kısa öğretici geri bildirim.
- Örnek doğru cevap.
- Kısa cevaplarda gereksiz ayrıntı beklenmez.
- Türkçe yazım/dilbilgisi kusuru anlamı bozmuyorsa değerlendirme düşürülmez.
- Canlı oturum sayacı.
- Okuma tamamlanınca geçici oturum özeti:
  - Kontrol edildi
  - Doğru
  - Kısmen
  - Tekrar bak
  - Kontrol edilmedi
- Yeni Okuma Oturumu Başlat.
- Aynı cümlede Reading Coach yeniden üretilirse eski soru/değerlendirme eşleşmesi temizlenir.
- Backend endpoint: POST /api/reading-comprehension

### Toplu tarayıcı doğrulaması
- Reading Studio görünürlüğü: OLUMLU
- 3 cümle / 17 kelime / 17 farklı kelime / ~1 dk özeti: OLUMLU
- Odaklı okuma ve cümle navigasyonu: OLUMLU
- AI Reading Coach: OLUMLU
- Genel anlam / önemli ifadeler / okuma ipucu / anlama sorusu: OLUMLU
- Yanıtımı Kontrol Et: OLUMLU
- Doğru / Kısmen doğru / Tekrar bak değerlendirmesi: OLUMLU
- Geri bildirim ve örnek doğru cevap: OLUMLU
- Okuma Oturumu Özeti: OLUMLU
- Yeni Okuma Oturumu Başlat: OLUMLU
- Önceki Bağlamsal Anlam akışı: OLUMLU
- Grammar Lab: OLUMLU
- Kelime & Hafıza Studio: OLUMLU
- Bilinmeyen Kelimeler: OLUMLU

Tarayıcı örnek doğrulaması:
- 3 cümlelik Macarca metin doğru ayrıştırıldı.
- Oturum sonunda 1 kontrol edildi / 1 doğru / 0 kısmen / 0 tekrar bak / 2 kontrol edilmedi sonucu doğru gösterildi.

Teknik durum:
- Sprint 107 teknik doğrulaması: başarılı
- Sprint 108 teknik doğrulaması: başarılı
- Sprint 109 teknik doğrulaması: başarılı
- Tam regresyon: 563 passed / 0 failed (84 test dosyası)
- Production build: başarılı
- Son manuel doğrulanmış ürün durumu: Sprint 109

### Reading Studio ürün ilkesi
- Öğrenci önce kendi başına okumaya çalışır.
- AI yardım isteğe bağlıdır.
- AI açıklama yerine öğrencinin anlam kurmasını destekler.
- Okuduğunu anlama kontrolü kısa ve öğretici geri bildirim vermelidir.
- İlk Reading Studio bloğunda performans ve cevap geçmişi kalıcı değildir.
- Kalıcı Reading ilerleme mimarisi ancak ayrı bir ürün kararıyla eklenmelidir.

Yeni kararlı checkpoint:
Sprint 109 — Reading Studio Okuduğunu Anlama ve Oturum Özeti tamamlandı

Sıradaki geliştirme bloğu:
Sprint 110–112 — Listening Studio

---

## Sprint 110–112 Blok Kapanışı — Listening Studio

Durum: TAMAMLANDI ve TOPLU TARAYICI DOĞRULAMASI OLUMLU

Başlangıç kararlı tabanı:
Sprint 109 — Reading Studio Okuduğunu Anlama ve Oturum Özeti

### Sprint 110 — Cümle Bazlı Dinleme Temeli
- Metin başlangıçta gizli tutulur.
- Dinle / Yavaş Dinle / Durdur.
- Tarayıcı SpeechSynthesis kullanılır.
- Macarca hu-HU / Türkçe tr-TR.
- Normal hız 0.9.
- Yavaş hız 0.65.
- Yeni ses başlamadan önce önceki ses durdurulur.
- Metni Göster / Metni Gizle.
- Önceki Parça / Sonraki Parça.
- Son parçada Dinlemeyi Tamamla.
- Parça değişince transkript tekrar gizlenir.
- Metin veya dil değişince Listening oturumu temizlenir.
- Geçici dinleme sayacı: farklı parça, toplam dinleme, mevcut parça.
- Geçici oturum özeti.
- Kalıcı Listening verisi yok.

### Sprint 111 — AI Listening Coach
- Listening Coach yalnız parça en az bir kez dinlendikten sonra açılır.
- Kullanıcı tarafından başlatılır.
- AI desteği:
  - Dinleme hedefi
  - 1–3 kritik ses/ifade ipucu
  - Yapı/ses birleşmesi ipucu
  - Kısa anlama sorusu
- Tam kaynak cümle otomatik yeniden yazılmaz.
- Tam Türkçe çeviri otomatik verilmez.
- Parça değişince eski Listening Coach içeriği temizlenir.
- İçerik geçicidir.
- Backend endpoint: POST /api/listening-coach

### Sprint 112 — Dinlediğini Yazma ve Kontrollü AI Değerlendirme
- Öğrenci duyduğunu kaynak dilde yazar.
- “Yazdığımı Kontrol Et” kullanıcı tarafından başlatılır.
- AI sonucu:
  - Çok iyi yakaladın
  - Yaklaştın
  - Bir kez daha dinle
- Küçük yazım, noktalama, büyük/küçük harf ve aksan/diakritik hataları başlangıç seviyesinde aşırı cezalandırılmaz.
- Kısa öğretici geri bildirim verilir.
- Gerçek cümle kontrol sonucunda gösterilir.
- Öğrenci yazdığı metni değiştirirse eski değerlendirme geçersiz olur.
- Canlı yazma kontrol sayacı.
- Oturum sonunda dinlediğini yazma özeti:
  - Kontrol edilen
  - Çok iyi
  - Yaklaştın
  - Tekrar dinle
  - Kontrol edilmedi
- Sprint 110 dinleme oturum özeti ayrıca korunur.
- Backend endpoint: POST /api/listening-dictation

### Toplu tarayıcı doğrulaması
- Listening Studio görünürlüğü: OLUMLU
- Metin başlangıçta gizli: OLUMLU
- Dinle / Yavaş Dinle / Durdur: OLUMLU
- Metni Göster / Metni Gizle: OLUMLU
- Parça navigasyonu: OLUMLU
- Listening Coach ilk dinlemeden sonra açılıyor: OLUMLU
- Dinleme hedefi / kritik ifadeler / yapı ipucu / anlama sorusu: OLUMLU
- Tam metin/tam çeviri otomatik açılmıyor: OLUMLU
- Dinlediğini Yaz: OLUMLU
- Yazdığımı Kontrol Et: OLUMLU
- Çok iyi / Yaklaştın / Bir kez daha dinle değerlendirmesi: OLUMLU
- Öğretici geri bildirim ve gerçek cümle: OLUMLU
- Dinleme oturumu özeti: OLUMLU
- Dinlediğini yazma özeti: OLUMLU
- Yeni Dinleme Oturumu Başlat: OLUMLU
- Reading Studio / Bağlamsal Anlam / Grammar Lab / Kelime & Hafıza / Terminoloji: OLUMLU

Teknik durum:
- Sprint 110 teknik doğrulaması: başarılı
- Sprint 111 teknik doğrulaması: başarılı
- Sprint 112 teknik doğrulaması: başarılı
- Tam regresyon: 563 passed / 0 failed (84 test dosyası)
- Production build: başarılı
- Son manuel doğrulanmış ürün durumu: Sprint 112

### Listening Studio ürün ilkesi
- Öğrenci önce dinler; metin başlangıçta gizli kalır.
- AI ilk eylem değil, gerektiğinde kullanılan öğretmen desteğidir.
- AI tam transkript veya tam çeviriyle görevi öğrencinin yerine yapmaz.
- Öğrenci duyduğunu kaynak dilde üretmeye çalışır.
- Başlangıç seviyesinde küçük yazım ve diakritik hatalar ana dinleme başarısını gölgelememelidir.
- İlk Listening Studio bloğunda performans ve cevap geçmişi kalıcı değildir.
- Kalıcı Listening ilerleme mimarisi ayrı bir ürün kararıyla eklenmelidir.

Yeni kararlı checkpoint:
Sprint 112 — Listening Studio Dinlediğini Yazma ve Kontrollü AI Değerlendirme tamamlandı

Sıradaki geliştirme bloğu:
Sprint 113–115 — Writing Studio

---

## Sprint 113–115 Blok Kapanışı — Writing Studio

Durum: TAMAMLANDI ve TOPLU TARAYICI DOĞRULAMASI OLUMLU

Başlangıç kararlı tabanı:
Sprint 112 — Listening Studio

### Sprint 113 — Guided Writing Foundation
- Writing Studio temel katmanı oluşturuldu.
- Üç başlangıç seviyesi görevi:
  - Tek cümle kur
  - Mini paragraf
  - Günlük rutin
- Öğrenci hedef dilde kendi metnini yazar.
- Sistem yalnız anlık ilerleme ölçer:
  - Kelime sayısı
  - Cümle sayısı
  - Farklı kelime sayısı
  - Hedefe kalan kelime/cümle miktarı
- Minimum görev hedefi tamamlandığında Writing Coach aşamasına hazır durumu gösterilir.
- Taslak geçicidir.
- Sprint 113'te AI çağrısı yoktur.

### Sprint 114 — Controlled AI Writing Coach
- Writing Coach yalnız minimum görev hedefi tamamlandıktan sonra açılır.
- Kullanıcı tarafından başlatılır.
- AI yalnız dört kontrollü öğe üretir:
  - Güçlü taraf
  - Önce bunu geliştir
  - Neden?
  - Revizyon ipucu
- AI öğrencinin yerine metin yazmaz.
- Tam düzeltilmiş cümle/paragraf üretmez.
- Bütün hataları listelemek yerine tek yüksek öğrenme değerli öncelik seçer.
- Taslak değişirse eski AI geri bildirimi temizlenir.
- Geri bildirim geçicidir.
- Backend endpoint: POST /api/writing-coach

### Sprint 115 — Learner Revision ve AI Revision Check
- Writing Coach sonrası “Revizyona Başla” akışı eklendi.
- İlk taslak dondurulur ve görünür kalır.
- Öğrenci revizyonu ayrı alanda kendisi yazar.
- İlk taslak ve revizyon kelime/cümle sayıları karşılaştırılır.
- “Revizyonumu Kontrol Et” kullanıcı tarafından başlatılır.
- AI yalnız önceki Writing Coach önceliğine göre değerlendirir:
  - Revizyon hedefi karşılandı
  - Kısmen gelişti
  - Bir tur daha dene
- Sonuç alanları:
  - Ne değişti?
  - Değerlendirme
  - Sonraki adım
- Yeni geniş hata listesi açılmaz.
- Tam düzeltilmiş alternatif metin üretilmez.
- Yazma Oturumunu Tamamla akışı eklendi.
- Geçici Writing oturum özeti:
  - İlk taslak kelime
  - Revizyon kelime
  - İlk taslak cümle
  - Revizyon cümle
  - Sonuç
- “Yeni Yazma Oturumu Başlat” eklendi.
- Backend endpoint: POST /api/writing-revision

### Sprint 115 Rev1 — Macarca Karakter Paleti
Tarayıcı doğrulaması sırasında fiziksel klavyede Macarca alfabenin tüm karakterlerinin bulunmaması UX sorunu olarak tespit edildi.

Çözüm:
- İlk taslak alanında Macarca karakter paleti.
- Revizyon alanında aynı karakter paleti.
- Desteklenen karakterler:
  á é í ó ö ő ú ü ű
  Á É Í Ó Ö Ő Ú Ü Ű
- Seçilen karakter imlecin bulunduğu konuma eklenir.
- Seçili metin varsa seçimin yerini alır.
- Macarca dışındaki dil modlarında gösterilmez.

### Toplu tarayıcı doğrulaması
- Writing Studio görünürlüğü: OLUMLU
- Tek cümle kur görevi: OLUMLU
- Mini paragraf seçimi: OLUMLU
- Günlük rutin seçimi: OLUMLU
- Kelime / cümle / farklı kelime sayaçları: OLUMLU
- Hedefe kalan miktar: OLUMLU
- Writing Coach minimum hedef sonrası açılıyor: OLUMLU
- Güçlü taraf / Önce bunu geliştir / Neden? / Revizyon ipucu: OLUMLU
- AI öğrencinin yerine tam metin yazmıyor: OLUMLU
- Revizyona Başla: OLUMLU
- İlk taslak korunuyor: OLUMLU
- Revizyon ayrı alanda öğrenci tarafından yapılıyor: OLUMLU
- Revizyon karşılaştırması: OLUMLU
- Revizyonumu Kontrol Et: OLUMLU
- Revizyon hedefi karşılandı / Kısmen gelişti / Bir tur daha dene akışı: OLUMLU
- Ne değişti? / Değerlendirme / Sonraki adım: OLUMLU
- Yazma Oturumunu Tamamla: OLUMLU
- YAZMA OTURUMU özeti: OLUMLU
- Yeni Yazma Oturumu Başlat: OLUMLU
- Macarca karakter paleti ilk taslakta: OLUMLU
- Macarca karakter paleti revizyonda: OLUMLU
- Listening Studio korunuyor: OLUMLU
- Reading Studio korunuyor: OLUMLU
- Grammar Lab korunuyor: OLUMLU
- Kelime & Hafıza Studio korunuyor: OLUMLU
- Terminoloji / Bilinmeyen Kelimeler korunuyor: OLUMLU

Teknik durum:
- Sprint 113 teknik doğrulaması: başarılı
- Sprint 114 teknik doğrulaması: 87 test dosyası / 588 passed / 0 failed
- Sprint 115 teknik doğrulaması: 90 test dosyası / 609 passed / 0 failed
- Sprint 115 Rev1 teknik doğrulaması: başarılı
- Tam regresyon: 615 passed / 0 failed (91 test dosyası)
- Production build: başarılı
- Son manuel doğrulanmış ürün durumu: Sprint 115 Rev1

### Writing Studio ürün ilkesi
- Öğrenci önce kendi metnini üretir.
- AI ancak kullanıcı isterse ve görev hedefi tamamlandıysa devreye girer.
- AI öğrencinin yerine yazmaz.
- AI geri bildirimi tek odaklı ve öğrenme amaçlıdır.
- Revizyonu öğrenci kendisi yapar.
- AI revizyonu yalnız önceki öğrenme önceliğine göre değerlendirir.
- İlk Writing Studio bloğunda taslak, geri bildirim, revizyon ve performans geçmişi kalıcı değildir.
- Kalıcı Writing ilerleme mimarisi ayrı bir ürün kararıyla ele alınmalıdır.

Yeni kararlı checkpoint:
Sprint 115 Rev1 — Writing Studio Revizyon Akışı ve Macarca Karakter Paleti tamamlandı

Sıradaki geliştirme bloğu:
Sprint 116–118 — Speaking & Pronunciation Studio

---

## Sprint 116–118 Blok Kapanışı — Speaking & Pronunciation Studio

Durum: KAPATILDI

Teknik doğrulama:
- 96 test dosyası
- 654 test
- 654 passed
- 0 failed
- Production build: başarılı

### Sprint 116 — Speaking Foundation
- Kaynak metin cümle bazında konuşma parçalarına ayrılır.
- Referans cümle normal ve yavaş hızda dinlenebilir.
- Tarayıcı Web Speech Recognition katmanı hazırlandı.
- Macarca: hu-HU
- Türkçe: tr-TR
- Kullanıcı “Mikrofonla Söyle” ile konuşma tanımayı kendisi başlatır.
- Tarayıcının duyduğu metin görünür.
- Deterministik metin eşleşme yüzdesi hesaplanır.
- Tarayıcı konuşma tanıma güveni gösterilir.
- Metin eşleşmesi açıkça “telaffuz notu” olarak sunulmaz.
- Sonuçlar geçicidir; Local Storage kullanılmaz.

### Sprint 117 — AI Speaking Coach
- Speaking Coach yalnız kullanıcı tarafından başlatılır.
- AI gerçek ses kaydını doğrudan dinlediğini iddia etmez.
- AI girdileri:
  - Hedef cümle
  - Tarayıcının duyduğu metin
  - Metin eşleşme yüzdesi
  - Tarayıcı tanıma güveni
- AI çıktıları:
  - Anlaşılabilirlik
  - Telaffuz odağı
  - Pratik ipucu
  - Tekrar görevi
- Prompt kesin akustik teşhis ve uydurma fonetik hata iddiasını yasaklar.
- Düşük güven değerlerinde mikrofon, ortam gürültüsü ve tarayıcı belirsizliği dikkate alınır.
- Endpoint: POST /api/speaking-coach
- Geri bildirim geçicidir.

### Sprint 118 — Repeat Loop & Session Summary
- Aynı konuşma parçası birden fazla kez denenebilir.
- Her başarılı konuşma tanıma deneme olarak tutulur.
- Oturum özeti her parça için en iyi metin eşleşmesini kullanır.
- Özet alanları:
  - Çalışılan parça
  - Toplam deneme
  - Ortalama en iyi eşleşme
  - En iyi eşleşme
  - Tekrar çalışılacak parça
- “Konuşma Oturumunu Tamamla” akışı eklendi.
- “Yeni Konuşma Oturumu Başlat” eklendi.
- Sonuçlar geçicidir; Local Storage kullanılmaz.

### Toplu tarayıcı doğrulaması
Mikrofonsuz doğrulanan alanlar:
- Speaking & Pronunciation Studio görünürlüğü: OLUMLU
- Referans cümle görünümü: OLUMLU
- Dinle: OLUMLU
- Yavaş Dinle: OLUMLU
- Önceki / Sonraki parça geçişleri: OLUMLU
- Writing Studio korunuyor: OLUMLU
- Listening Studio korunuyor: OLUMLU
- Reading Studio korunuyor: OLUMLU
- Grammar Lab korunuyor: OLUMLU
- Kelime & Hafıza Studio korunuyor: OLUMLU

Donanım nedeniyle ertelenen manuel doğrulama:
- Mikrofonla Söyle
- Tarayıcının duyduğu metin
- Metin eşleşmesi / tarayıcı güveni canlı sonucu
- Speaking Coach canlı sonucu
- Tekrar Söyle
- Konuşma Oturumunu Tamamla
- KONUŞMA OTURUMU canlı özeti

Not:
Kullanıcının kısa sürede mikrofon donanımına erişemeyecek olması nedeniyle yukarıdaki mikrofon bağımlı manuel doğrulama kullanıcı kararıyla blok kapanışını engellemeyecek şekilde ertelendi.
Bu alanların teknik testleri ve production build doğrulaması başarılıdır.
Mikrofon bağlandığında canlı donanım doğrulaması ayrıca yapılabilir.

### Ürün ilkesi
- Mikrofon yalnız kullanıcı açıkça başlattığında kullanılır.
- AI gerçek sesi dinlemediği durumda bunu açıkça belirtir.
- Tarayıcı konuşma tanıma sonucu telaffuz doğruluğu ile eşitlenmez.
- Belirsizlik kullanıcıya görünür tutulur.
- Konuşma performansı ilk blokta kalıcı olarak saklanmaz.

Yeni kararlı checkpoint:
Sprint 118 — Speaking & Pronunciation Studio

Sıradaki geliştirme bloğu:
Sprint 119–121 — Dialogue & Role-play Studio

---

## Sprint 119–121 Blok Kapanışı — Dialogue & Role-play Studio

Durum: TAMAMLANDI ve TOPLU TARAYICI DOĞRULAMASI OLUMLU

Teknik doğrulama:
- 102 test dosyası
- 698 test
- 698 passed
- 0 failed
- Production build: başarılı

### Sprint 119 — Guided Dialogue & Role-play Foundation
- Dialogue & Role-play Studio temel katmanı oluşturuldu.
- Başlangıç seviyesi üç rehberli senaryo:
  - Kafede sipariş
  - Tanışma
  - Yol sorma
- Her senaryoda üç kontrollü tur.
- Öğrenci cevabı kendisi üretir.
- Sistem yalnız iletişim hedefini ve kısa destek ipucunu gösterir.
- Partner cümlesi normal ve yavaş hızda dinlenebilir.
- Macarca modunda karakter paleti kullanılabilir.
- AI yoktur.
- Diyalog geçicidir; Local Storage kullanılmaz.

### Sprint 120 — AI Role-play Partner
- Rehberli role-play korunarak ayrı “AI ile Doğaçlama” modu eklendi.
- Öğrenci cevabını kendisi yazar ve gönderir.
- AI yalnız partnerin bir sonraki kısa hedef dil turunu üretir.
- AI öğrencinin cevabını onun yerine yazmaz.
- Türkçe kısa destek ipucu verir ancak sonraki cevabı doğrudan vermez.
- İletişim hedefi ilerlemesi:
  - Başlangıç
  - İlerliyor
  - Kapanışa hazır
- AI partner cevabı normal ve yavaş hızda dinlenebilir.
- Endpoint: POST /api/dialogue-turn
- Diyalog geçicidir.

### Sprint 121 — Role-play Session Summary & AI Reflection
- Rehberli ve AI role-play için geçici oturum özeti eklendi.
- Özet alanları:
  - Senin turun
  - Ürettiğin kelime
  - Farklı kelime
  - Toplam diyalog turu
- “Role-play Oturumunu Tamamla” eklendi.
- “Yeni Role-play Oturumu Başlat” eklendi.
- Kullanıcı başlatmalı Role-play Coach değerlendirmesi eklendi.
- Role-play Coach çıktıları:
  - Güçlü taraf
  - Sonraki odak
  - Yeniden kullanılabilir kalıp ipucu
  - Sonraki pratik
- AI tüm diyaloğu yeniden yazmaz ve geniş hata listesi çıkarmaz.
- Endpoint: POST /api/dialogue-review
- Kalıcı performans kaydı yoktur.

### Toplu tarayıcı doğrulaması
- Dialogue & Role-play Studio görünürlüğü: OLUMLU
- Kafede sipariş senaryosu: OLUMLU
- Tanışma senaryosu: OLUMLU
- Yol sorma senaryosu: OLUMLU
- Rehberli partner cümlesi: OLUMLU
- Dinle / Yavaş Dinle: OLUMLU
- Öğrenci yanıtı ve tur ilerlemesi: OLUMLU
- Macarca karakter paleti: OLUMLU
- AI ile Doğaçlama: OLUMLU
- AI partner kısa hedef dil yanıtı: OLUMLU
- Sonraki cevap için ipucu: OLUMLU
- AI öğrencinin yerine cevap yazmıyor: OLUMLU
- Son Partneri Dinle / Yavaş Dinle: OLUMLU
- Hedef ilerlemesi: OLUMLU
- Role-play Coach ile Değerlendir: OLUMLU
- Güçlü taraf / Sonraki odak / Kalıp ipucu / Sonraki pratik: OLUMLU
- Role-play Oturumunu Tamamla: OLUMLU
- ROLE-PLAY OTURUMU özeti: OLUMLU
- Yeni Role-play Oturumu Başlat: OLUMLU
- Writing Studio korunuyor: OLUMLU
- Speaking & Pronunciation Studio korunuyor: OLUMLU
- Listening Studio korunuyor: OLUMLU
- Reading Studio korunuyor: OLUMLU
- Grammar Lab korunuyor: OLUMLU
- Kelime & Hafıza Studio korunuyor: OLUMLU

### Ürün ilkesi
- Öğrenci önce kendi cevabını üretir.
- AI yalnız partner rolünü veya kullanıcı tarafından istenen kısa değerlendirmeyi üstlenir.
- AI öğrencinin yerine cevap üretmez.
- Diyalog koçluğu tek odaklı ve başlangıç seviyesi dostudur.
- İlk Role-play bloğunda konuşma/diyalog geçmişi kalıcı olarak saklanmaz.

Yeni kararlı checkpoint:
Sprint 121 — Dialogue & Role-play Studio

### Sıradaki mimari karar — Multi-Language Core
LAF Studio yalnız Macarca için tasarlanmayacaktır.
Mevcut çalışan tabanda dil altyapısı ağırlıklı olarak Macarca (hu) ve Türkçe (tr) üzerinden ilerlemektedir.
Yeni eğitim özelliklerine devam etmeden önce ortak dil çekirdeği kurulacaktır.

Amaç:
- Writing, Listening, Reading, Grammar, Speaking ve Dialogue/Role-play modüllerini tek ortak dil profili üzerinden çalıştırmak.
- Dile özel davranışları modül kodlarına gömmemek.
- Macarca karakter paletini dile özel profil yaklaşımına taşımak.
- Seslendirme / konuşma tanıma locale bilgisini dil profiline taşımak.
- AI öğretmen promptlarında dil bilgisini ortak profil üzerinden yönetmek.
- Almanca, İtalyanca, İngilizce ve sonraki dilleri mevcut stüdyo mimarisine eklenebilir hale getirmek.

Sıradaki geliştirme bloğu:
Sprint 122–124 — Multi-Language Core

---

## Sprint 122–124 Blok Kapanışı — Multi-Language Core

Durum: TAMAMLANDI ve TOPLU TARAYICI DOĞRULAMASI OLUMLU

Teknik doğrulama:
- 105 test dosyası
- 730 test
- 730 passed
- 0 failed
- Production build: başarılı

### Sprint 122 — Shared Language Profile Core
İlk ortak dil profili çekirdeği oluşturuldu.

Çekirdekte teknik olarak tanımlanan ilk diller:
- Macarca — hu / hu-HU
- Türkçe — tr / tr-TR
- Almanca — de / de-DE
- İtalyanca — it / it-IT
- İngilizce — en / en-US

Her dil profili:
- dil kodu
- Türkçe dil etiketi
- yerel dil etiketi
- locale
- HTML language
- text-to-speech locale
- speech-recognition locale
- dile özel karakter listesi

### Sprint 123 — Multi-Language Runtime Adapters
- Ortak locale-aware metin normalizasyonu eklendi.
- Ortak kelime tokenizasyonu ve farklı kelime sayımı eklendi.
- BrowserListeningSpeechService sabit hu/tr kontrolünden Language Profile kullanımına geçirildi.
- BrowserSpeakingRecognitionService sabit hu/tr kontrolünden Language Profile kullanımına geçirildi.
- Almanca de-DE runtime testleri eklendi.
- İtalyanca it-IT runtime testleri eklendi.
- İngilizce en-US runtime testleri eklendi.
- Mevcut Macarca/Türkçe davranışı korundu.

### Sprint 124 — User-visible Multi-Language Core Verification
Text Workshop içine bağımsız MULTI-LANGUAGE CORE doğrulama paneli eklendi.

Panelde doğrulanan:
- Macarca
- Türkçe
- Almanca
- İtalyanca
- İngilizce

Görünür profil alanları:
- Locale
- TTS locale
- SpeechRecognition locale

Dile özel karakter paletleri:
- Macarca karakterleri
- Türkçe karakterleri
- Almanca karakterleri
- İtalyanca karakterleri
- İngilizce için gereksiz ek karakter paleti yok

Ses:
- Dinle
- Yavaş Dinle
- Seçili dilin örnek cümlesi seçili locale ile okunur

### Sprint 124 Rev1 — UX Etiket Tutarlılığı
Manuel doğrulama sırasında modül adı tutarsızlığı tespit edildi.

Düzeltme:
- KELİME & HAFIZA STUDIO
  → VOCABULARY & MEMORY STUDIO

Karar:
- Resmî modül/stüdyo adları İngilizce ürün adı olarak tutarlı tutulacak.
- Türkçe açıklama ve öğretim metinleri Türkçe kalacak.
- Ürün davranışı değişmedi.
- Rev1 tam regresyon ve production build başarılı oldu.

### Toplu tarayıcı doğrulaması
- MULTI-LANGUAGE CORE görünürlüğü: OLUMLU
- Macarca profil seçimi: OLUMLU
- Türkçe profil seçimi: OLUMLU
- Almanca profil seçimi: OLUMLU
- İtalyanca profil seçimi: OLUMLU
- İngilizce profil seçimi: OLUMLU
- Locale değerleri: OLUMLU
- Dil bazlı karakter paletleri: OLUMLU
- Karakterin imleç konumuna eklenmesi: OLUMLU
- Dinle: OLUMLU
- Yavaş Dinle: OLUMLU
- Seçili dile uygun seslendirme: OLUMLU
- WRITING STUDIO korunuyor: OLUMLU
- DIALOGUE & ROLE-PLAY STUDIO korunuyor: OLUMLU
- SPEAKING & PRONUNCIATION STUDIO korunuyor: OLUMLU
- LISTENING STUDIO korunuyor: OLUMLU
- READING STUDIO korunuyor: OLUMLU
- GRAMMAR LAB korunuyor: OLUMLU
- VOCABULARY & MEMORY STUDIO korunuyor: OLUMLU

### Ürün kararı — İlk ana dil paketi 7 dil
Multi-Language rollout yalnız ilk 5 dille sınırlı kalmayacaktır.

İlk ana dil paketi:
- Macarca — hu-HU
- Türkçe — tr-TR
- Almanca — de-DE
- İtalyanca — it-IT
- İngilizce — en-US
- İspanyolca — es-ES
- Rusça — ru-RU

İspanyolca için:
- á é í ñ ó ú ü ¿ ¡ ve gerekli büyük harfler
- es-ES TTS / SpeechRecognition

Rusça için:
- ru-RU TTS / SpeechRecognition
- Kiril alfabesi desteği
- Kullanıcıda Rusça klavye bulunmayabileceği için uygun ekran klavyesi / karakter paleti yaklaşımı

### Mimari sınır
Sprint 122–124 ortak çekirdeği kurmuştur.
Writing, Listening, Reading, Grammar, Speaking ve Dialogue & Role-play stüdyolarının tamamında 7 dilli kullanıcı seçimi henüz yaygınlaştırılmış sayılmaz.

Yeni kararlı checkpoint:
Sprint 124 Rev1 — Multi-Language Core

Sıradaki geliştirme bloğu:
Sprint 125–127 — 7-Dilli Multi-Language Rollout

Ana hedef:
- İspanyolca ve Rusçayı ortak çekirdeğe eklemek
- 7 dili kullanıcı tarafından seçilebilir ortak hedef dil modeli altında birleştirmek
- Mevcut stüdyoları ortak Language Profile katmanına geçirmek
- Dile özel sabitleri modül kodlarından çıkarmaya devam etmek
- Rusça için Kiril yazma desteğini kullanıcı açısından erişilebilir hale getirmek

---

## Sprint 125-127 Blok Kapanisi — 7-Dilli Multi-Language Rollout

Durum: TAMAMLANDI ve TOPLU TARAYICI DOGRULAMASI OLUMLU

Teknik dogrulama:
- Final revision: Rev3
- 110 test dosyasi
- 756 test
- 756 passed
- 0 failed
- Production build: basarili

### Sprint 125 — Seven-Language Core Expansion
Ana dil paketi 7 dile cikarildi:
- Macarca — hu-HU
- Turkce — tr-TR
- Almanca — de-DE
- Italyanca — it-IT
- Ingilizce — en-US
- Ispanyolca — es-ES
- Rusca — ru-RU

Eklenen temel destek:
- Ispanyolca ozel karakterleri
- Rusca ru-RU runtime profili
- Rusca Kiril ekran klavyesi
- Multi-Language Core panelinde 7 dil
- Backend dil etiketlerinde 7 dil

### Sprint 126 — Seven-Language Studio Core Migration
- TranslationLanguageCode 7 dile genisletildi.
- Writing, Reading, Speaking ve Dialogue locale islemleri ortak Language Profile katmanina tasindi.
- Rehberli Dialogue senaryolari 7 dile genislendi.
- Writing Studio dil-bazli karakter yardimina gecirildi.
- Dialogue & Role-play Studio dil-bazli karakter yardimina gecirildi.
- Rusca Kiril ekran klavyesi Writing ve Dialogue alanlarinda kullanilabilir hale geldi.
- Grammar observation storage 7 dili kabul edecek sekilde genislendi.
- Vocabulary storage 7 dili kabul edecek sekilde genislendi.
- Contextual Meaning review storage locale normalizasyonu 7 dile genislendi.
- Turkce disindaki diller icin ogrenme destek dili Turkce olarak korundu.

### Sprint 127 — Seven-Language User Rollout
Text Workshop ust dil secicisi 7 dile genislendi:
- Macarca
- Turkce
- Almanca
- Italyanca
- Ingilizce
- Ispanyolca
- Rusca

Yayilim:
- Writing Studio
- Dialogue & Role-play Studio
- Speaking & Pronunciation Studio
- Listening Studio
- Reading Studio
- Grammar Lab
- Vocabulary & Memory Studio

AI katmani:
- Mevcut AI endpoint validator'lari 7 dili kabul edecek sekilde genislendi.
- Grammar AI promptundaki Macarca'ya ozel ifade dil-notr hale getirildi.
- Dil etiketleri ortak 7-dil yapisina genislendi.

### Revizyon zinciri
#### Rev1
Ilk kurucuda Windows PowerShell parser / encoding problemi goruldu.
Parser seviyesinde durdu.

#### Rev2
TranslationDraft 7-dil patch islemi strict UTF-8 ve BOM korumali hale getirildi.
Sprint 126 regresyonu 749/749 basarili oldu.
Production build hu/tr-only kalan tip haritalari nedeniyle durdu.

#### Rev3
Kalan eski hu/tr-only compatibility map'leri 7 dile genislendi:
- TranslationLearningQueue
- LanguageWritingAssistant
- TranslationAssistancePrompt
- TranslationEvaluationPrompt
- BrowserTerminologySpeechService

Rev3 sonucu:
- 110 test dosyasi
- 756 passed
- 0 failed
- Production build: basarili

### Sprint 127 Rev1 — Character Palette Readability Improvement
Manuel tarayici dogrulamasinda karakter paleti ve Rusca Kiril klavyesinin okunabilirligi iyilestirildi.

Degisiklikler:
- Karakter buton fontu buyutuldu.
- Font agirligi artirildi.
- Segoe UI / Noto Sans / Arial fallback zinciri eklendi.
- Minimum buton boyutu artirildi.
- Ic bosluk artirildi.
- Kiril klavyesinde butonlar arasi bosluk iyilestirildi.
- Davranis degismedi.

Rev1 teknik dogrulama:
- Full regression: basarili
- Production build: basarili

### Toplu tarayici dogrulamasi
- Ust dil secicisinde 7 dil: OLUMLU
- Ispanyolca es-ES profili: OLUMLU
- Ispanyolca ozel karakter paleti: OLUMLU
- Ispanyolca karakter ekleme: OLUMLU
- Rusca ru-RU profili: OLUMLU
- Rusca Kiril ekran klavyesi: OLUMLU
- Kiril karakter ekleme: OLUMLU
- Writing Studio Rusca: OLUMLU
- Dialogue & Role-play Studio Rusca: OLUMLU
- Writing Studio Ispanyolca: OLUMLU
- Dialogue & Role-play Studio Ispanyolca: OLUMLU
- Almanca ses/language gecisi: OLUMLU
- Italyanca ses/language gecisi: OLUMLU
- Ingilizce ses/language gecisi: OLUMLU
- Ispanyolca ses/language gecisi: OLUMLU
- Rusca ses/language gecisi: OLUMLU
- Speaking & Pronunciation Studio secili dil/locale gecisi: OLUMLU
- Reading Studio 7-dil yayilimi: OLUMLU
- Grammar Lab 7-dil yayilimi: OLUMLU
- Grammar AI secili yeni dilleri kabul ediyor: OLUMLU
- Vocabulary & Memory Studio dil degisiminde calisiyor: OLUMLU
- Character Palette Readability Rev1: OLUMLU

### Donanim-bagimli not
- Mikrofon bulunmadigi icin SpeechRecognition canli kayit zinciri tekrar edilmedi.
- Dil/locale gecisi arayuzde olumlu dogrulandi.
- SpeechRecognition locale davranisi otomatik testlerle korunuyor.
- Bu donanim bagimli kontrol urun blok kapanisini engellemiyor.

### Kalici urun karari
LAF Studio ana dil paketi:
1. Macarca
2. Turkce
3. Almanca
4. Italyanca
5. Ingilizce
6. Ispanyolca
7. Rusca

Mimari ilke:
- Study/Studio modulleri tek dile gomulmeyecek.
- Dil secimi ortak Language Profile katmanindan yonetilecek.
- Dil-bazli TTS, SpeechRecognition, HTML lang ve klavye/karakter yardimi profil uzerinden gelecektir.
- Resmi Studio/modul adlari Ingilizce urun adi olarak tutarli kalacaktir.
- Turkce aciklama ve ogrenme destek metinleri Turkce kalacaktir.
- Rusca icin Kiril ekran klavyesi korunacaktir.

Yeni kararli checkpoint:
Sprint 127 Rev1 — 7-Dilli Multi-Language Rollout

Siradaki gelistirme:
Sprint 128-130 — Multi-Language sonrasi bir sonraki ogrenme gelistirme blogu

---

## Sprint 128-130 Blok Kapanisi — Daily Learning Path

Durum: TAMAMLANDI ve TOPLU TARAYICI DOGRULAMASI OLUMLU

Teknik dogrulama:
- Final revision: Sprint 130 Rev4
- 114 test dosyasi
- 779 test
- 779 passed
- 0 failed
- Production build: basarili

### Sprint 128 — Daily Learning Path
- 15 / 25 / 40 dakikalik gunluk calisma planlari eklendi.
- 7 dilin tamami destekleniyor.
- Vocabulary, Grammar, Reading, Listening, Writing, Speaking ve Dialogue becerileri ortak plana baglandi.
- Kaynak metin gerektiren adimlar metin yokken acikca isaretleniyor.
- Speaking adiminda mikrofon zorunlu degil.
- AI cevap uretmiyor.
- Bu sprintte kalici kayit yok.

### Sprint 129 — Guided Daily Session Runner
- Gunluk oturum kullanici tarafindan acikca baslatiliyor.
- Her adim tamamlandi / geri al durumuna getirilebiliyor.
- Tamamlanan adim sayisi, dakika ve ilerleme yuzdesi hesaplanıyor.
- "Studyoya Git" eylemi uygun mevcut Studyoya otomatik kaydiriyor.
- Vocabulary alani henuz olusmadiysa aciklayici mesaj veriliyor.
- Kaynak metin gerektiren adimlar metin yokken kilitli.
- Kalici kayit yok.

### Sprint 130 — Explicit Save & Session Summary
- Oturum yalniz kullanici "Oturumu Kaydet" dediginde Local Storage'a yaziliyor.
- Kayitli oturum yuklenebiliyor.
- Kayitli oturum silinebiliyor.
- Gunluk oturum ozeti:
  - tamamlanan adim
  - tamamlanan dakika
  - kalan dakika
  - ilerleme yuzdesi
  - tamamlandi / devam ediyor durumu
- 7 dil storage restore dogrulamasinda destekleniyor.
- Ogrenci calismasi otomatik tamamlanmis sayilmiyor.

### Revizyon zinciri
#### Sprint 128-130 Rev1
- Self-contained paket akisi kullanildi.
- Sprint 128 production build TypeScript literal-union tip genislemesi nedeniyle durdu.
- Rollback basarili.

#### Sprint 128-130 Rev2
- TranslationDailyLearningStep availability tipi acikca sabitlendi.
- Sprint 128 ve 129 ilerledi.
- Sprint 130 production build erasableSyntaxOnly / parameter-property nedeniyle durdu.
- Sprint 130 rollback basarili.

#### Sprint 130 Rev3
- Constructor parameter-property kaldirildi.
- Acik class field + constructor assignment kullanildi.
- Paket dosya yolu eslesme problemi nedeniyle uygulanamadi.

#### Sprint 130 Rev4
- Embedded ZIP proje-relative app\src\... dosya yolu ile uyumlu hale getirildi.
- Son teknik sonuc:
  - 114 test dosyasi
  - 779 passed
  - 0 failed
  - Production build basarili

### Toplu tarayici dogrulamasi
- DAILY LEARNING PATH ana gorunumu: OLUMLU
- 15 / 25 / 40 dakika secenekleri: OLUMLU
- Secili hedef dil gorunumu: OLUMLU
- Calisma metni durumu: OLUMLU
- Gunluk Oturumu Baslat: OLUMLU
- Baslangic ilerlemesi 0% / 0 adim: OLUMLU
- Adim bazli "Studyoya Git": OLUMLU
- Adim bazli "Adimi Tamamladim": OLUMLU
- Tamamlanan dakika ve yuzde artisi: OLUMLU
- "Tamamlamayi Geri Al": OLUMLU
- Writing / Dialogue navigasyonu: OLUMLU
- Kaynak metin gerektiren adim kilidi: OLUMLU
- Oturumu Kaydet: OLUMLU
- Ctrl+F5 sonrasi Kayitli Oturumu Yukle: OLUMLU
- Kayitli ilerlemenin geri gelmesi: OLUMLU
- Kayitli Oturumu Sil: OLUMLU
- Silme sonrasi yukle/sil eylemlerinin pasiflesmesi: OLUMLU

### Kalici urun karari
Daily Learning Path:
- Ogrencinin yerine cevap uretmeyecek.
- Ogrencinin yerine bir adimi otomatik tamamlamayacak.
- Studyolar arasinda gunluk calisma rotasi kuracak.
- Kalici oturum kaydi yalniz acik kullanici eylemiyle yapilacak.
- 7 dilin tamaminda ortak Language Profile yapisiyla calisacak.
- Mikrofon bulunmadiginda Speaking adimi tamamen engellenmeyecek.

Yeni kararli checkpoint:
Sprint 130 Rev4 — Daily Learning Path

Siradaki gelistirme:
Sprint 131-133 — UI/UX Visual Refresh Phase 1

Visual Refresh hedefi:
- Today’s Learning Focus hero alani
- Daha canli Learning Studio kartlari
- Daily Learning Path'in daha gorsel sunumu
- Kontrollu micro-animation / motion sistemi
- Hafif gradient, derinlik ve daha modern sayfa hiyerarsisi
- Animasyon dekoratif degil, durum ve etkileşim geri bildirimi odakli olacak

---

## Sprint 131-133 Blok Kapanisi — UI/UX Visual Refresh Phase 1

Durum: TAMAMLANDI ve MANUEL TARAYICI DOGRULAMASI OLUMLU

Teknik dogrulama:
- Final checkpoint: Sprint 133
- 117 test dosyasi
- 795 test
- 795 passed
- 0 failed
- Production build: basarili

### Sprint 131 — Today's Learning Focus + Motion Foundation
- Eski statik hero alani islevsel Today's Learning Focus hero ile degistirildi.
- Secili hedef dil, native label, locale ve metin durumu gorunur hale geldi.
- "Bugunku Plani Ac" Daily Learning Path'e kaydiriyor.
- "Metin Ekle / Metne Don" metin alanina kaydiriyor.
- 7 dili temsil eden hafif hareketli Language Orbit eklendi.
- Aktif dil orbit uzerinde vurgulaniyor.
- prefers-reduced-motion destegi eklendi.

### Sprint 132 — Learning Studio Dock + Visual Card System
- 7 Studyolu Learning Studio Dock eklendi.
- Vocabulary, Grammar, Reading, Listening, Writing, Speaking ve Dialogue alanlarina hizli gecis eklendi.
- Her Studyoya kontrollu renk kimligi verildi.
- Hover lift, yumusak golge ve kart giris micro-motion davranislari eklendi.
- Duz beyaz sayfa zemini hafif ambient gradient derinlige tasindi.
- Mevcut Studio islevleri korunarak yalniz gorsel katman guclendirildi.

### Sprint 133 — Daily Learning Path Visual Route + Progress Motion
- Daily Learning Path daha gorsel bir rota yapisina donusturuldu.
- Adimlar arasina dikey baglanti cizgisi eklendi.
- Ilerleme yuzdesi akici progress bar ile gorunur hale geldi.
- Aktif / tamamlanmis oturum durumlari gorsel olarak ayrildi.
- Tamamlanan adimlarda check / vurgu geri bildirimi iyilestirildi.
- Ambient gradient hareketi dusuk yogunlukta kullanildi.
- Summary ve completion alanlarina yumusak giris motion'u eklendi.
- Sprint 130 kaydet / yukle / sil davranislari korunuyor.

### Teknik sonuc
- Sprint 131 hedef testleri: basarili
- Sprint 131 tam regresyon: basarili
- Sprint 131 production build: basarili
- Sprint 132 hedef testleri: basarili
- Sprint 132 tam regresyon: 116 test dosyasi / 789 passed
- Sprint 132 production build: basarili
- Sprint 133 hedef testleri: basarili
- Sprint 133 final tam regresyon: 117 test dosyasi / 795 passed / 0 failed
- Sprint 133 production build: basarili

### Manuel tarayici dogrulamasi
Today's Learning Focus:
- Yeni hero gorunumu: OLUMLU
- Secili dil ve native ad: OLUMLU
- Locale bilgisi: OLUMLU
- Calisma metni durumu: OLUMLU
- Language Orbit animasyonu: OLUMLU
- "Bugunku Plani Ac" navigasyonu: OLUMLU
- "Metin Ekle / Metne Don" navigasyonu: OLUMLU

Learning Studios:
- 7 Studio karti gorunumu: OLUMLU
- Farkli renk vurgulari: OLUMLU
- Hover lift / derinlik etkisi: OLUMLU
- Studio kartindan ilgili bolume navigasyon: OLUMLU
- Ambient gradient / sayfa derinligi: OLUMLU

Daily Learning Path:
- Dikey rota / baglanti cizgisi: OLUMLU
- Progress bar gorunumu: OLUMLU
- Progress bar akici ilerleme: OLUMLU
- Tamamlanan adim check vurgusu: OLUMLU
- Kart hover micro-motion: OLUMLU
- Ambient hareket: OLUMLU
- Hareketlerin dikkat dagitmamasi: OLUMLU

### Kalici UX kararlari
- LAF Studio duz "kitap sayfasi" hissinden cikarilarak canli fakat profesyonel bir Language Intelligence Workspace yonune tasinacak.
- Animasyonlar dekorasyon amacli degil; aktif dil, ilerleme, navigasyon ve durum geri bildirimi amacli kullanilacak.
- Surekli veya dikkat dagitici hareketlerden kacinilacak.
- prefers-reduced-motion destegi yeni motion katmanlarinda korunacak.
- Learning Studio'lar kontrollu renk kimliklerine sahip olacak.
- Daily Learning Path sayfanin ana aktif ogrenme rotalarindan biri olarak gorsel olarak guclendirilmeye devam edecek.

Yeni kararli checkpoint:
Sprint 133 — UI/UX Visual Refresh Phase 1

Siradaki gelistirme:
Sprint 134-136 — UI/UX Visual Refresh Phase 2

---

## Sprint 134–136 Blok Kapanışı — UI/UX Visual Refresh Phase 2

Durum: TAMAMLANDI ve MANUEL TARAYICI DOĞRULAMASI OLUMLU

Başlangıç kararlı checkpoint:
Sprint 133 — UI/UX Visual Refresh Phase 1 / 117 test dosyası / 795 passed / 0 failed

Final teknik checkpoint:
Sprint 136 Rev1 / 120 test dosyası / 805 passed / 0 failed

Production build: başarılı
Final build doğrulaması: başarılı (1.58 s)

### Uygulanan ana davranışlar
- Sticky Learning Journey navigasyonu tamamlandı ve kaydırma sırasında görünürlük/hizalama doğrulandı.
- Learning Journey içindeki Odak / Plan / Stüdyolar / Metin navigasyonu doğrulandı.
- Hareket Kontrolü görünürlüğü iyileştirildi.
- Canlı / Sakin hareket tercihi eklendi ve geçiş davranışı doğrulandı.
- Hareket tercihi tarayıcı yenilemesinden sonra korunur hale getirildi.
- Görsel canlılık korunurken düşük maliyetli motion yaklaşımı benimsendi.
- Gereksiz sürekli animasyon, yoğun blur/backdrop-filter, büyük gölgeler ve yüksek GPU yükü oluşturan efektlerden kaçınılması kalıcı UX/performance kararı olarak korundu.

### Manuel tarayıcı doğrulaması
- Sticky Learning Journey: OLUMLU
- Hareket Kontrolü görünürlüğü: OLUMLU
- Canlı / Sakin geçişi: OLUMLU
- Hareket tercihi kalıcılığı: OLUMLU
- Belirgin titreme / sıçrama / performans problemi: YOK

### Teknik not
Vite production build sırasında 500 kB üzerindeki bazı chunk'lar için optimizasyon uyarısı verdi. Bu bir build hatası değildir. İhtiyaç oluşursa dynamic import / code splitting ayrı bir performans optimizasyon çalışması olarak ele alınacaktır.

Yeni kararlı checkpoint:
Sprint 136 Rev1 — UI/UX Visual Refresh Phase 2
---

## Sprint 137–139 Blok Kapanışı — CEFR Learning Path Foundation

Durum: TAMAMLANDI ve MANUEL TARAYICI DOĞRULAMASI OLUMLU

Başlangıç kararlı checkpoint:
Sprint 136 Rev1 / 120 test dosyası / 805 passed / 0 failed

### Design Studio kararı — CEFR Learning Path Ana Öğrenme Mimarisi V1
Ana yol:
A1 RESPOND → A2 MAINTAIN → B1 MANAGE → B2 DEVELOP → C1 ADAPT → C2 CONTROL

Ana pedagojik yaklaşım:
Communication-First, Form-Informed Learning

Temel hiyerarşi:
CEFR Level → Module → Unit → Lesson

Kalıcı mimari kararlar:
- Progress ve Mastery birbirinden ayrı tutulur.
- CEFR yalnız içerik tamamlama etiketi değildir; performans, retention ve transfer kanıtı gerekir.
- Studio'lar Learning Path'in alternatifi değildir; learning evidence üretir.
- Placement doğrulanmadan kullanıcıya sahte mevcut CEFR seviyesi atanmaz.
- Sayısal mastery eşikleri ve otomatik gate algoritmaları ilgili Design Studio kararı olmadan tanımlanmaz.

### Sprint 137 Rev1 — CEFR Learning Path Domain Foundation
- A1–C2 CEFR ana yolu domain seviyesinde tanımlandı.
- Seviye kimlikleri Respond / Maintain / Manage / Develop / Adapt / Control olarak bağlandı.
- Level → Module → Unit → Lesson hiyerarşisinin temel domain desteği kuruldu.
- Gerçek curriculum, modül/ünite/ders sayıları ve içerikler bu sprintte tanımlanmadı.
- Mevcut UI, Studio davranışları ve Local Storage değiştirilmedi.

Teknik doğrulama:
- Başlangıç: 120 test dosyası / 805 passed / 0 failed
- Hedef test: 8 passed / 0 failed
- Yeni taban: 121 test dosyası / 813 passed / 0 failed
- Production build: başarılı
- Yedek: D:\Projects\LAF-Studio\_sprint_backups\Sprint137-Rev1-20260807-223941
- Regresyon logu: D:\Projects\LAF-Studio\Sprint137-Rev1-regression-20260807-223941.log
- Build logu: D:\Projects\LAF-Studio\Sprint137-Rev1-build-20260807-223941.log

### Sprint 138 — Learning Path Progress State
- Progress, Mastery ve Module Gate durumları domain seviyesinde ayrı tutuldu.
- General Competency State: New → Developing → Functional → Secure.
- Module Gate durumları: Ready / Ready + Strengthen / Reinforcement Needed.
- Sayısal mastery eşiği veya otomatik gate algoritması eklenmedi.
- Mevcut UI, Studio davranışları ve Local Storage değiştirilmedi.

Teknik doğrulama:
- Başlangıç: 121 test dosyası / 813 passed / 0 failed
- Hedef test: 8 passed / 0 failed
- Yeni taban: 122 test dosyası / 821 passed / 0 failed
- Production build: başarılı
- Yedek: D:\Projects\LAF-Studio\_sprint_backups\Sprint138-20260807-233317
- Regresyon logu: D:\Projects\LAF-Studio\Sprint138-regression-20260807-233317.log
- Build logu: D:\Projects\LAF-Studio\Sprint138-build-20260807-233317.log

### Sprint 139 — CEFR Learning Journey V1
- A1 → A2 → B1 → B2 → C1 → C2 yolu kullanıcıya görünür hale getirildi.
- Placement olmadığı için kullanıcıya sahte mevcut CEFR seviyesi atanmadı.
- “CEFR seviyesi henüz doğrulanmadı” durumu kullanıcı yüzeyinde açıkça korunuyor.
- Continue Learning Path mevcut günlük öğrenme planına bağlandı.
- Progress / Mastery ayrımı görünür dilde korunuyor.
- Mevcut Studio davranışları ve Local Storage değiştirilmedi.

Teknik doğrulama:
- Başlangıç: 122 test dosyası / 821 passed / 0 failed
- Hedef test: 8 passed / 0 failed
- Final taban: 123 test dosyası / 829 passed / 0 failed
- Production build: başarılı
- Yedek: D:\Projects\LAF-Studio\_sprint_backups\Sprint139-20260807-234756
- Regresyon logu: D:\Projects\LAF-Studio\Sprint139-regression-20260807-234756.log
- Build logu: D:\Projects\LAF-Studio\Sprint139-build-20260807-234756.log

### Sprint 137–139 manuel tarayıcı doğrulaması
- A1 → C2 CEFR sıra görünümü: OLUMLU
- Respond / Maintain / Manage / Develop / Adapt / Control kimlikleri: OLUMLU
- Sahte mevcut CEFR seviyesi atanmaması: OLUMLU
- “CEFR seviyesi henüz doğrulanmadı” görünümü: OLUMLU
- Progress ≠ Mastery açıklaması: OLUMLU
- Continue Learning Path navigasyonu: OLUMLU
- Learning Journey genel bütünlük / hizalama: OLUMLU
- Belirgin performans ağırlaşması: YOK

### Blok sonucu
- Sprint 137–139 teknik geliştirmesi tamamlandı.
- Toplu manuel tarayıcı doğrulaması olumlu tamamlandı.
- Açık kritik sorun yok.
- Yeni kararlı checkpoint: Sprint 139 — CEFR Learning Journey V1 / 123 test dosyası / 829 passed / 0 failed.
- Sonraki CEFR geliştirme bloğu yalnız onaylı Design Studio kararı üzerinden açılacaktır.
---

## Sprint 140–142 Blok Kapanışı — CEFR Competency Outcomes & Learning Journey Integration

Durum: TAMAMLANDI ve MANUEL TARAYICI DOĞRULAMASI OLUMLU

Başlangıç kararlı checkpoint:
Sprint 139 / 123 test dosyası / 829 passed / 0 failed

Final kararlı checkpoint:
Sprint 142 Rev4 / 126 test dosyası / 862 passed / 0 failed

Production build: başarılı

### Sprint 140 — CEFR Competency Outcome Domain Foundation
- Onaylı 6 Module Family domain seviyesinde tanımlandı:
  1. CONNECT
  2. NAVIGATE
  3. DESCRIBE & NARRATE
  4. EXCHANGE IDEAS
  5. SOLVE & NEGOTIATE
  6. INTERPRET & TRANSFORM
- 6 CEFR seviyesi × 6 Module Family = 36 level-specific competency outcome eksiksiz tanımlandı.
- Her outcome için level, module family, outcome adı, can-do ifadesi, dominant skills ve independence bilgisi korundu.
- Outcome sözleşmesi Progress, Mastery, Module Gate, Unit ve Lesson yapılarından ayrı tutuldu.
- Sayısal mastery eşiği, placement veya otomatik progression algoritması eklenmedi.
- Mevcut UI, Studio davranışları ve Local Storage değiştirilmedi.

Teknik doğrulama:
- Başlangıç: 123 test dosyası / 829 passed / 0 failed
- Hedef test: 8 passed / 0 failed
- Yeni taban: 124 test dosyası / 837 passed / 0 failed
- Production build: başarılı
- Yedek: D:\Projects\LAF-Studio\_sprint_backups\Sprint140-20260808-010204

### Sprint 141 — Competency Outcome Query & Progression Layer
- Level + Module Family → Competency Outcome sorgusu eklendi.
- Belirli bir CEFR seviyesinin 6 competency outcome görünümü eklendi.
- Aynı Module Family içinde previous / next CEFR outcome gezinmesi eklendi.
- A1 öncesi ve C2 sonrası null olarak korunur; hayali seviye üretilmez.
- Bu katman yalnız sorgulama/gezinme sağlar; progression kararı üretmez.
- Placement, mastery eşiği veya otomatik level advancement eklenmedi.
- Mevcut UI, Studio davranışları ve Local Storage değiştirilmedi.

Teknik doğrulama:
- Başlangıç: 124 test dosyası / 837 passed / 0 failed
- Hedef test: 8 passed / 0 failed
- Yeni taban: 125 test dosyası / 845 passed / 0 failed
- Production build: başarılı
- Yedek: D:\Projects\LAF-Studio\_sprint_backups\Sprint141-20260808-103453

### Sprint 142 — Learning Journey Competency Integration V1
- Sprint 140–141 domain katmanındaki competency outcome'lar Learning Journey'e kontrollü biçimde bağlandı.
- A1–C2 seviyelerinin her biri için 6 Module Family outcome'u kullanıcıya inceleme görünümünde gösterildi.
- Seviye seçimi yalnız competency inceleme görünümünü değiştirir; current CEFR level veya placement verisi üretmez.
- Outcome metni, dominant skills ve independence bilgisi domain katmanından okunur.
- Progress, Mastery, Module Gate ve Local Storage davranışları değiştirilmedi.

Teknik doğrulama:
- Başlangıç: 125 test dosyası / 845 passed / 0 failed
- Hedef test: 8 passed / 0 failed
- İlk Sprint 142 tabanı: 126 test dosyası / 853 passed / 0 failed
- Production build: başarılı
- Yedek: D:\Projects\LAF-Studio\_sprint_backups\Sprint142-20260808-104322

### Sprint 142 Rev1 — Competency Inspector UX Düzeltmesi
- A1–C2 Learning Path kartları competency inceleme seviyesini doğrudan değiştirecek hale getirildi.
- Kart seçimi current CEFR level, placement, Progress veya Mastery verisi üretmez.
- Competency kartlarında Dominant Skills ve Independence etiketleri görünür hale getirildi.
- Mevcut Studio davranışları ve Local Storage değiştirilmedi.

Teknik doğrulama:
- Yeni taban: 126 test dosyası / 855 passed / 0 failed
- Hedef test: 10 passed / 0 failed
- Production build: başarılı
- Yedek: D:\Projects\LAF-Studio\_sprint_backups\Sprint142-Rev1-20260808-110441

### Sprint 142 Rev2 — Learning Journey Dil Tutarlılığı
- Türkçe Learning Journey panelindeki kullanıcıya görünen CEFR sunum metinleri Türkçeleştirildi.
- Level identity, module family, outcome, beceri ve bağımsızlık etiketleri Türkçe arayüz standardına çekildi.
- Teknik domain anahtarları ve CEFR sözleşmesi değiştirilmedi.

Teknik doğrulama:
- Yeni taban: 126 test dosyası / 857 passed / 0 failed
- Hedef test: 20 passed / 0 failed
- Production build: başarılı
- Yedek: D:\Projects\LAF-Studio\_sprint_backups\Sprint142-Rev2-20260808-113906

### Sprint 142 Rev3 — Current Workspace Localization Consistency
- Learning Journey dışındaki ana workspace başlıkları ve Studio sunum metinleri mevcut Türkçe arayüzle tutarlı hale getirildi.
- Arayüz dili ile hedef dil birbirinden ayrıldı.
- HU/TR/DE/IT/ES/EN/RU hedef dil seçimi arayüz dilini değiştirmez.
- Magyar, Deutsch, Italiano, English, Español, Русский gibi hedef dilin doğal/native adları korunur.
- Genel TR/EN arayüz dili seçicisi bu revizyonda eklenmedi.

Teknik doğrulama:
- Yeni taban: 126 test dosyası / 859 passed / 0 failed
- Hedef test: 16 passed / 0 failed
- Production build: başarılı
- Yedek: D:\Projects\LAF-Studio\_sprint_backups\Sprint142-Rev3-20260808-120403

### Sprint 142 Rev4 — Sticky Target Language Selector
- Hedef Dil seçimi sayfanın üstünde kompakt ve sticky kontrol olarak eklendi.
- Kullanıcı sayfaya girer girmez seçili hedef dili görebilir ve değiştirebilir.
- Üst Hedef Dil seçicisi ile Ortak Dil Profili aynı target-language state'i kullanır; iki ayrı hedef dil durumu tutulmaz.
- Hedef dil değişikliği arayüz dilini değiştirmez.
- CEFR domaini, current level, placement, Progress, Mastery ve Local Storage davranışları değiştirilmedi.

Teknik doğrulama:
- Başlangıç: Sprint 142 Rev3 / 126 test dosyası / 859 passed / 0 failed
- Hedef test: 8 passed / 0 failed
- Final taban: 126 test dosyası / 862 passed / 0 failed
- Production build: başarılı
- Yedek: D:\Projects\LAF-Studio\_sprint_backups\Sprint142-Rev4-20260808-122744

### Sprint 140–142 manuel tarayıcı doğrulaması
- A1–C2 competency inceleme görünümü: OLUMLU
- 6 Module Family outcome görünümü: OLUMLU
- A1–C2 kartları ile competency seviyesi değiştirme: OLUMLU
- Seviye incelemenin current CEFR level üretmemesi: OLUMLU
- Baskın Beceriler / Bağımsızlık Düzeyi görünümü: OLUMLU
- Türkçe Learning Journey dil tutarlılığı: OLUMLU
- Workspace kullanıcı arayüzü dil tutarlılığı: OLUMLU
- Arayüz dili / hedef dil ayrımı: OLUMLU
- Sticky Hedef Dil seçicisi: OLUMLU
- Üst Hedef Dil ile Ortak Dil Profili senkronizasyonu: OLUMLU
- Hedef dil değişirken Türkçe arayüzün Türkçe kalması: OLUMLU
- Hedef dil native adlarının korunması: OLUMLU
- Belirgin taşma / hizalama / performans problemi: YOK

### Kalıcı localization / UX kararı
- Arayüz dili (UI Language) ile öğrenilen hedef dil (Target Language) birbirinden bağımsız kavramlardır.
- Hedef dil değiştirilmesi arayüz dilini otomatik olarak değiştirmez.
- Tek panel / çalışma alanı, tek arayüz dili kullanır; kullanıcıya ait arayüz metinleri aynı panel içinde Türkçe–İngilizce karışık gösterilmez.
- Hedef dilin kendi içeriği, örnek cümleleri ve native dil adları doğal olarak hedef dilde kalabilir.
- Genel arayüz dili seçicisi ileride ayrı bir localization/i18n kararı ve sprinti olarak ele alınacaktır.
- Hedef Dil seçimi kullanıcının aramak zorunda kalmayacağı şekilde üstte görünür ve kompakt tutulur.

### Blok sonucu
- Sprint 140–142 teknik geliştirmesi tamamlandı.
- Sprint 142 Rev1–Rev4 UX/localization düzeltmeleri tamamlandı.
- Toplu manuel tarayıcı doğrulaması olumlu tamamlandı.
- Açık kritik sorun yok.
- Yeni kararlı checkpoint: Sprint 142 Rev4 — CEFR Competency Integration + Localization Consistency / 126 test dosyası / 862 passed / 0 failed.
- Sonraki CEFR geliştirme bloğu yalnız onaylı Design Studio kararı üzerinden açılacaktır.

---

## Sprint 1552–1554 — Studio → Kelime Defteri Controlled Add Flow V1

**Status:** COMPLETED  
**Stable Checkpoint:** Sprint 1554

### Kapsam

Translation Studio ve Metin Atölyesi'nden kullanıcının açık eylemiyle mevcut Kelime Defteri sistemine kelime/ifade ekleme akışı tamamlandı.

### Tamamlananlar

- Mevcut `laf-vocabulary` Kelime Defteri persistence yapısı korundu.
- Paralel vocabulary store oluşturulmadı.
- Mevcut ders → Kelime Defteri yazma akışı korundu.
- `VocabularyItem` Studio kaynaklı kayıtları destekleyecek biçimde genişletildi.
- Aynı kelimenin farklı anlamlarının ayrı kayıt olarak tutulabilmesi sağlandı.
- Metin Atölyesi:
  - Bağlamsal anlam sonucu içinden `Kelime Defterine Ekle`
  - Düzenlenebilir hedef karşılık önizlemesi
  - Açık `Kelime Defterine Kaydet` eylemi
- Translation Studio:
  - Kaynak metinden kelime/ifade seçimi
  - `Kelime Defterine Ekle`
  - Kullanıcının hedef karşılığı girmesi/düzenlemesi
  - Açık kayıt eylemi
- Mevcut `ğrenmeye Ekle` ve `Terminolojiye Ekle` akışları korunarak birbirinden ayrıldı.

### Runtime Doğrulama

- Metin Atölyesi → Bağlamsal anlam → Kelime Defterine Ekle: olumlu
- Translation Studio → kaynak seçim → Kelime Defterine Ekle: olumlu
- Kelime Defteri'nde gerçek kayıt görünürlüğü: olumlu

### Teknik Doğrulama

- Hedef testler başarılı.
- Tam regresyon başarılı.
- Production build başarılı.
- Recovery sırasında görülen iki history testi timeout'u izole çalıştırmada başarılı bulundu; gerçek feature hatası olmadığı doğrulandı.
- Full-suite timeout toleransı artırılarak regresyon güvenliği korunmuştur.

### Sonuç

Studio → Kelime Defteri Controlled Add Flow V1 tamamlandı.

**Yeni kararlı checkpoint: Sprint 1554**

---


================================================================================
2026-08-14 — SPRINT 1555–1557
CEFR LEARNING PATH — A1 INTERPRET & TRANSFORM
================================================================================

STATUS:
COMPLETED — STABLE CHECKPOINT: SPRINT 1557

TOPIC:
A1 INTERPRET & TRANSFORM
YORUMLA & DNŞTR

APPROVED OUTCOME:
ok kısa ve açık bir mesajın temel anlamını anlayabilir
ve bunu çok basit sözlü, yazılı veya işaret destekli biçimde
başka kişiye aktarabilir.

COMPETENCY:
interpret-transform-a1
ok Basit Anlamı Aktarma

CAPABILITY:
meaning-relay
Basic Meaning Relay

UNIT:
a1-interpret-transform-basic-meaning-relay
Relay a Simple Message

IMPLEMENTED LEARNING STRUCTURE:
- 6 lesson foundation
- Recognition Practice
- Guided Relay Practice
- Open Simple Relay
- Listen → Relay
- Read → Relay
- Person-to-Person Relay
- Pass the Message real-life activation

AUTHORITATIVE MAPPING:
interpret-transform-a1
→ meaning-relay

Curriculum mapping:
curriculum-map-a1-interpret-transform-v1

PRODUCTION RUNTIME:
a1-interpret-transform

RUNTIME EVIDENCE:
6 executable immediate evidence definitions

DELAYED RETRIEVAL:
Authoritative identity preserved.
Runtime writing DISABLED.
No timing/delay policy inferred.

SAFETY INVARIANTS:
- Progress ≠ Mastery
- Evidence ≠ Mastery
- Completion ≠ Mastery
- Evidence ≠ CEFR certification
- No automatic CEFR assignment
- No automatic mastery assignment
- No automatic competency success assignment
- No automatic progression
- No A2 unlock / level promotion
- Real learner action required for evidence
- Passive rendering does not create evidence

ARCHITECTURE:
Existing authoritative CEFR curriculum registry reused.
Existing capability registry reused.
Existing meaning-relay capability reused.
Existing generic production runtime platform reused.
Existing evidence persistence/runtime chain reused.
No parallel capability, evidence, mastery or progression system created.

VALIDATION:
Sprint 1555 target checkpoint: PASSED
Sprint 1556 target checkpoint: PASSED
Sprint 1557 target checkpoint: PASSED
Full regression: PASSED
Production build: PASSED
Final build time: 6.20s

FINAL RESULT:
SPRINT-1555-1557 BASARILI

NEW STABLE CHECKPOINT:
SPRINT 1557

================================================================================

2026-08-14 - SPRINT 1555-1557
STABLE CHECKPOINT: SPRINT 1557
FINAL RESULT: SPRINT-1555-1557 BASARILI
================================================================================
2026-08-14 - SPRINT 1558-1560 - A2 CONNECT / MAINTAIN
================================================================================

STATUS:
COMPLETED - STABLE CHECKPOINT: SPRINT 1560

FEATURE:
CEFR Learning Path - A2 CONNECT

AUTHORITATIVE COMPETENCY:
connect-a2
Maintain Everyday Social Exchange

AUTHORITATIVE CAPABILITY MAPPING:
connect-a2
-> social-exchange
-> interaction-management

CURRICULUM:
Unit: a2-connect-simple-conversation
Curriculum mapping: curriculum-map-a2-connect-v1
Production runtime slice: a2-connect

RUNTIME EVIDENCE:
6 immediate executable evidence definitions.
Delayed retrieval authoritative identity preserved; runtime writing disabled.

SAFETY:
Progress != Mastery
Evidence != Mastery
Completion != Mastery
No automatic CEFR assignment.
No automatic mastery assignment.
No automatic competency success assignment.
No automatic progression or level unlock.
Real learner interaction required for evidence.

VALIDATION:
Sprint 1558 target checkpoint: PASSED
Sprint 1559 target checkpoint: PASSED
Sprint 1560 target checkpoint: PASSED
Full regression: PASSED
Production build: PASSED

RECOVERY NOTE:
Repository-level RCA proved CefrRuntimeAssemblyFactory implementation was correct.
The stale negative-control test used a2-connect as an unknown slice before A2 runtime registration.
Negative-control identity was safely changed to unknown-production-slice without weakening fail-closed behavior.

FINAL RESULT:
SPRINT-1558-1560 BASARILI

NEW STABLE CHECKPOINT:
SPRINT 1560


2026-08-14 - SPRINT 1564-1566 - A2 DESCRIBE & NARRATE
STABLE CHECKPOINT: SPRINT 1566
COMPETENCY: describe-narrate-a2
CAPABILITIES: description-production + narrative-sequencing
PRODUCTION SLICE: a2-describe-narrate
RUNTIME EVIDENCE: 6 immediate; delayed retrieval DISABLED
SAFETY: no mastery / CEFR / competency-success / automatic progression
FINAL RESULT: SPRINT-1564-1566 BASARILI

2026-08-14 - SPRINT 1567-1569 - A2 EXCHANGE IDEAS
STABLE CHECKPOINT: SPRINT 1569
COMPETENCY: exchange-ideas-a2
CAPABILITIES: preference-opinion-expression + reason-support
PRODUCTION SLICE: a2-exchange-ideas
RUNTIME EVIDENCE: 6 immediate; delayed retrieval DISABLED
SAFETY: no mastery / CEFR / competency-success / automatic progression
FINAL RESULT: SPRINT-1567-1569 BASARILI

2026-08-14 - SPRINT 1570-1572 - A2 SOLVE & NEGOTIATE
STABLE CHECKPOINT: SPRINT 1572
COMPETENCY: solve-negotiate-a2
CAPABILITIES: help-clarification-seeking + communication-repair
PRODUCTION SLICE: a2-solve-negotiate
RUNTIME EVIDENCE: 6 immediate; delayed retrieval DISABLED
SAFETY: no mastery / CEFR / competency-success / automatic progression
FINAL RESULT: SPRINT-1570-1572 BASARILI

2026-08-14 - SPRINT 1573-1575 - A2 INTERPRET & TRANSFORM
STABLE CHECKPOINT: SPRINT 1575
COMPETENCY: interpret-transform-a2
CAPABILITIES: meaning-relay + information-selection
PRODUCTION SLICE: a2-interpret-transform
RUNTIME EVIDENCE: 6 immediate; delayed retrieval DISABLED
SAFETY: no mastery / CEFR / competency-success / automatic progression
A2 MAINTAIN: SIX MODULE FAMILIES COMPLETE
FINAL RESULT: SPRINT-1573-1575 BASARILI

2026-08-15 - SPRINT 1576-1578 - B1 CONNECT
STABLE CHECKPOINT: SPRINT 1578
COMPETENCY: connect-b1
CAPABILITIES: social-exchange + interaction-management
PRODUCTION SLICE: b1-connect
RUNTIME EVIDENCE: 6 immediate; delayed retrieval DISABLED
PERFORMANCE: functional independence; reduced/strategic support
SAFETY: no mastery / CEFR / competency-success / automatic progression
FINAL RESULT: SPRINT-1576-1578 BASARILI

2026-08-15 - SPRINT 1579-1581 - B1 NAVIGATE
STABLE CHECKPOINT: SPRINT 1581
COMPETENCY: navigate-b1
CAPABILITIES: transaction-management + communication-repair
CAPABILITY MAPPING: capability-map-v1
PRODUCTION SLICE: b1-navigate
RUNTIME EVIDENCE: 6 immediate; delayed retrieval DISABLED
PERFORMANCE: functional independence; reduced/strategic support
SAFETY: no mastery / CEFR / competency-success / automatic progression
FINAL RESULT: SPRINT-1579-1581 BASARILI

2026-08-15 - SPRINT 1582-1584 - B1 DESCRIBE & NARRATE
STABLE CHECKPOINT: SPRINT 1584
COMPETENCY: describe-narrate-b1
CAPABILITIES: narrative-sequencing + explanation-development
CAPABILITY MAPPING: capability-map-v1
PRODUCTION SLICE: b1-describe-narrate
RUNTIME EVIDENCE: 6 immediate; delayed retrieval DISABLED
PERFORMANCE: functional independence; reduced/strategic support
SAFETY: no mastery / CEFR / competency-success / automatic progression
FINAL RESULT: SPRINT-1582-1584 BASARILI

2026-08-15 - SPRINT 1585-1587 - B1 EXCHANGE IDEAS
STABLE CHECKPOINT: SPRINT 1587
COMPETENCY: exchange-ideas-b1
CAPABILITIES: preference-opinion-expression + reason-support + argumentation
CAPABILITY MAPPING: capability-map-v1
PRODUCTION SLICE: b1-exchange-ideas
RUNTIME EVIDENCE: 6 immediate; delayed retrieval DISABLED
PERFORMANCE: functional independence; reduced/strategic support
SAFETY: no mastery / CEFR / competency-success / automatic progression
FINAL RESULT: SPRINT-1585-1587 BASARILI

2026-08-15 - SPRINT 1588-1590 - B1 SOLVE & NEGOTIATE
STABLE CHECKPOINT: SPRINT 1590
COMPETENCY: solve-negotiate-b1
CAPABILITIES: communication-repair + interaction-management
CAPABILITY MAPPING: capability-map-v1
PRODUCTION SLICE: b1-solve-negotiate
RUNTIME EVIDENCE: 6 immediate; delayed retrieval DISABLED
PERFORMANCE: functional independence; reduced/strategic support
SAFETY: no mastery / CEFR / competency-success / automatic progression
FINAL RESULT: SPRINT-1588-1590 BASARILI

2026-08-15 - SPRINT 1591-1593 - B1 INTERPRET & TRANSFORM
STABLE CHECKPOINT: SPRINT 1593
COMPETENCY: interpret-transform-b1
CAPABILITIES: information-selection + summarization-reformulation
CAPABILITY MAPPING: capability-map-v1
PRODUCTION SLICE: b1-interpret-transform
RUNTIME EVIDENCE: 6 immediate; delayed retrieval DISABLED
PERFORMANCE: functional independence; reduced/strategic support
SAFETY: no mastery / CEFR / competency-success / automatic progression
B1 MODULE FAMILY STATUS: 6/6 COMPLETE
FINAL RESULT: SPRINT-1591-1593 BASARILI

2026-08-15 - SPRINT 1594-1596 - B2 CONNECT
STABLE CHECKPOINT: SPRINT 1596
COMPETENCY: connect-b2
CAPABILITIES: interaction-management + reason-support + idea-comparison-development
CAPABILITY MAPPING: capability-map-v1
PRODUCTION SLICE: b2-connect
RUNTIME EVIDENCE: 6 immediate; delayed retrieval DISABLED
PERFORMANCE: B2 DEVELOP; light/selective strategic support
SAFETY: no mastery / CEFR / competency-success / automatic progression
FINAL RESULT: SPRINT-1594-1596 BASARILI

2026-08-15 - SPRINT 1597-1599 - B2 NAVIGATE
STABLE CHECKPOINT: SPRINT 1599
COMPETENCY: navigate-b2
CAPABILITIES: transaction-management + option-evaluation + solution-negotiation
CAPABILITY MAPPING: capability-map-v1
PRODUCTION SLICE: b2-navigate
RUNTIME EVIDENCE: 6 immediate; delayed retrieval DISABLED
PERFORMANCE: B2 DEVELOP; light/selective strategic support
SAFETY: no mastery / CEFR / competency-success / automatic progression
FINAL RESULT: SPRINT-1597-1599 BASARILI

2026-08-15 - SPRINT 1600-1602 - B2 DESCRIBE & NARRATE
STABLE CHECKPOINT: SPRINT 1602
COMPETENCY: describe-narrate-b2
CAPABILITIES: description-production + narrative-sequencing + explanation-development
CAPABILITY MAPPING: capability-map-v1
PRODUCTION SLICE: b2-describe-narrate
RUNTIME EVIDENCE: 6 immediate; delayed retrieval DISABLED
PERFORMANCE: B2 DEVELOP; light/selective strategic support
SAFETY: no mastery / CEFR / competency-success / automatic progression
FINAL RESULT: SPRINT-1600-1602 BASARILI

2026-08-15 - SPRINT 1603-1605 - B2 EXCHANGE IDEAS
STABLE CHECKPOINT: SPRINT 1605
COMPETENCY: exchange-ideas-b2
CAPABILITIES: idea-comparison-development + reason-support + argumentation
CAPABILITY MAPPING: capability-map-v1
PRODUCTION SLICE: b2-exchange-ideas
RUNTIME EVIDENCE: 6 immediate; delayed retrieval DISABLED
PERFORMANCE: B2 DEVELOP; light/selective strategic support
SAFETY: no mastery / CEFR / competency-success / automatic progression
FINAL RESULT: SPRINT-1603-1605 BASARILI
2026-08-15 - SPRINT 1606-1608 - B2 SOLVE & NEGOTIATE
STABLE CHECKPOINT: SPRINT 1608
COMPETENCY: solve-negotiate-b2
CAPABILITIES: solution-negotiation + option-evaluation + interaction-management
CAPABILITY MAPPING: capability-map-v1
PRODUCTION SLICE: b2-solve-negotiate
RUNTIME EVIDENCE: 6 immediate; delayed retrieval DISABLED
PERFORMANCE: B2 DEVELOP; light/selective strategic support
SAFETY: no mastery / CEFR / competency-success / automatic progression
FINAL RESULT: SPRINT-1606-1608 BASARILI
2026-08-15 - SPRINT 1609-1611 - B2 INTERPRET & TRANSFORM
STABLE CHECKPOINT: SPRINT 1611
COMPETENCY: interpret-transform-b2
CAPABILITIES: summarization-reformulation + information-synthesis + meaning-context-adaptation
CAPABILITY MAPPING: capability-map-v1
PRODUCTION SLICE: b2-interpret-transform
RUNTIME EVIDENCE: 6 immediate; delayed retrieval DISABLED
PERFORMANCE: B2 DEVELOP; light/selective strategic support
BOUNDARY: meaning mediation/reformulation; Translation Studio remains separate authoritative workflow
SAFETY: no mastery / CEFR / competency-success / automatic progression
B2 STATUS: all six module families development complete
FINAL RESULT: SPRINT-1609-1611 BASARILI
2026-08-15 - SPRINT 1612-1614 - C1 CONNECT
STABLE CHECKPOINT: SPRINT 1614
COMPETENCY: connect-c1
PRODUCT LABEL: Adapt to Relationship & Register
CAPABILITIES: interaction-management + register-adaptation + audience-purpose-adaptation
CAPABILITY MAPPING: capability-map-v1
PRODUCTION SLICE: c1-connect
RUNTIME EVIDENCE: 6 immediate; delayed retrieval DISABLED
PERFORMANCE: C1 ADAPT; minimal/context-adaptive strategic support
C1 SIGNATURE: same/similar communicative goal + changed relationship/context -> adapted learner performance
BOUNDARY: no C2 precision/control; no professional diplomacy/networking/conflict-mediation engine
SAFETY: no mastery / CEFR / competency-success / automatic progression
C1 STATUS: 1/6 module family development complete
FINAL RESULT: SPRINT-1612-1614 BASARILI
2026-08-15 - SPRINT 1615-1617 - C1 NAVIGATE
STABLE CHECKPOINT: SPRINT 1617
COMPETENCY: navigate-c1
PRODUCT LABEL: Adapt Complex Real-World Transactions
CAPABILITIES: transaction-management + option-evaluation + audience-purpose-adaptation
CAPABILITY MAPPING: capability-map-v1
PRODUCTION SLICE: c1-navigate
RUNTIME EVIDENCE: 6 immediate; delayed retrieval DISABLED
PERFORMANCE: C1 ADAPT; minimal/context-adaptive strategic support
C1 SIGNATURE: same/similar practical goal + changed stakeholder/condition/context -> adapted learner performance
BOUNDARY: no professional project/operational/legal/financial/crisis engine; no C2 precision/control
SAFETY: no mastery / CEFR / competency-success / automatic progression
C1 STATUS: 2/6 module family development complete
FINAL RESULT: SPRINT-1615-1617 BASARILI
2026-08-15 - SPRINT 1618-1620 - C1 DESCRIBE & NARRATE
STABLE CHECKPOINT: SPRINT 1620
COMPETENCY: describe-narrate-c1
LABEL: Adapt Narrative to Audience & Purpose
CAPABILITIES: explanation-development + audience-purpose-adaptation + register-adaptation
CAPABILITY MAPPING: capability-map-v1
PRODUCTION SLICE: c1-describe-narrate
RUNTIME EVIDENCE: 6 immediate; delayed retrieval DISABLED
PERFORMANCE: C1 ADAPT; minimal/context-adaptive strategic support
SIGNATURE: same/similar narrative + changed audience/purpose/register -> adapted learner performance
SAFETY: no mastery / CEFR / competency-success / automatic progression
FINAL RESULT: SPRINT-1618-1620 BASARILI
2026-08-16 - SPRINT 1621-1623 - C1 EXCHANGE IDEAS
STABLE CHECKPOINT: SPRINT 1623
COMPETENCY: exchange-ideas-c1
LABEL: Adapt Argument to Audience & Context
CAPABILITIES: argumentation + audience-purpose-adaptation + register-adaptation
CAPABILITY MAPPING: capability-map-v1
PRODUCTION SLICE: c1-exchange-ideas
RUNTIME EVIDENCE: 6 immediate; delayed retrieval DISABLED
PERFORMANCE: C1 ADAPT; minimal/context-adaptive strategic support
SIGNATURE: same/similar position + changed audience/relationship/purpose/context -> adapted learner discussion behavior
BOUNDARY: no debate/argument/persuasion/C1 discussion engine; existing Studios and generic runtime reused
SAFETY: no mastery / CEFR / competency-success / automatic progression
FINAL RESULT: SPRINT-1621-1623 BASARILI
2026-08-16 - SPRINT 1624-1626 - C1 SOLVE & NEGOTIATE
STABLE CHECKPOINT: SPRINT 1626
COMPETENCY: solve-negotiate-c1
LABEL: Adapt Sensitive Problem-Solving
CAPABILITIES: solution-negotiation + audience-purpose-adaptation + sensitive-diplomatic-management
CAPABILITY MAPPING: capability-map-v1
PRODUCTION SLICE: c1-solve-negotiate
RUNTIME EVIDENCE: 6 immediate; delayed retrieval DISABLED
PERFORMANCE: C1 ADAPT; minimal/context-adaptive strategic support
SIGNATURE: same/similar problem + changed relationship/social distance/sensitivity/context -> adapted learner resolution behavior
BOUNDARY: no negotiation/diplomacy/bargaining/concession engine; existing Studios and generic runtime reused
SAFETY: no mastery / CEFR / competency-success / automatic progression
FINAL RESULT: SPRINT-1624-1626 BASARILI
2026-08-16 - SPRINT 1627-1629 - C1 INTERPRET & TRANSFORM
STABLE CHECKPOINT: SPRINT 1629
COMPETENCY: interpret-transform-c1
LABEL: Adapt Meaning Across Audience & Context
CAPABILITIES: information-synthesis + meaning-context-adaptation + audience-purpose-adaptation
CAPABILITY MAPPING: capability-map-v1
PRODUCTION SLICE: c1-interpret-transform
RUNTIME EVIDENCE: 6 immediate; delayed retrieval DISABLED
PERFORMANCE: C1 ADAPT; minimal/context-adaptive strategic support
SIGNATURE: same/similar underlying meaning + changed audience/knowledge-level/purpose/register/context -> adapted learner presentation + preserved necessary meaning
TRANSLATION BOUNDARY: professional translation/interpreting workflow not created; Translation Studio remains separate
BOUNDARY: no mediation/translation/summarization/reformulation/audience-adaptation engine; generic runtime reused
SAFETY: no mastery / CEFR / competency-success / automatic progression
C1 STATUS: 6/6 module family development complete
FINAL RESULT: SPRINT-1627-1629 BASARILI
2026-08-16 - SPRINT 1630-1632 - C2 CONNECT
STABLE CHECKPOINT: SPRINT 1632
COMPETENCY: connect-c2
LABEL: Control Social Nuance & Effect
CAPABILITIES: register-adaptation + pragmatic-effect-control + perspective-style-control
CAPABILITY MAPPING: capability-map-v1
PRODUCTION SLICE: c2-connect
RUNTIME EVIDENCE: 6 immediate; delayed retrieval DISABLED
PERFORMANCE: C2 CONTROL; independent performance + reflective/precision feedback
SIGNATURE: same/similar intent + different desired pragmatic effect -> deliberately different learner formulation
BOUNDARY: no nuance/social-effect/register/C2 runtime engine; generic runtime reused
SAFETY: no mastery / CEFR / competency-success / automatic progression
C2 STATUS: CONNECT 1/6 complete
FINAL RESULT: SPRINT-1630-1632 BASARILI
2026-08-16 - SPRINT 1633-1635 - C2 NAVIGATE
STABLE CHECKPOINT: SPRINT 1635
COMPETENCY: navigate-c2
LABEL: Control Strategic & Sensitive Transactions
CAPABILITIES: option-evaluation + solution-negotiation + sensitive-diplomatic-management
CAPABILITY MAPPING: capability-map-v1
PRODUCTION SLICE: c2-navigate
RUNTIME EVIDENCE: 6 immediate; delayed retrieval DISABLED
PERFORMANCE: C2 CONTROL; independent performance + reflective precision feedback
SIGNATURE: multiple plausible options + competing constraints/stakeholder effects -> deliberately controlled learner decision communication
BOUNDARY: no transaction/negotiation/diplomacy/C2 runtime engine; generic runtime reused
SAFETY: no mastery / CEFR / competency-success / automatic progression
C2 STATUS: NAVIGATE 2/6 complete
FINAL RESULT: SPRINT-1633-1635 BASARILI
2026-08-16 - SPRINT 1636-1638 - C2 DESCRIBE & NARRATE
STABLE CHECKPOINT: SPRINT 1638
COMPETENCY: describe-narrate-c2
LABEL: Control Perspective, Style & Narrative Effect
CAPABILITIES: perspective-style-control + pragmatic-effect-control + audience-purpose-adaptation
CAPABILITY MAPPING: capability-map-v1
PRODUCTION SLICE: c2-describe-narrate
RUNTIME EVIDENCE: 6 immediate; delayed retrieval DISABLED
PERFORMANCE: C2 CONTROL; independent performance + reflective precision feedback
SIGNATURE: same underlying event + different intended narrative effect -> controlled perspective/style/emphasis change + preserved core meaning
BOUNDARY: no narrative-style/C2 narrative runtime engine; generic runtime reused
SAFETY: no mastery / CEFR / competency-success / automatic progression
C2 STATUS: DESCRIBE & NARRATE 3/6 complete
FINAL RESULT: SPRINT-1636-1638 BASARILI
2026-08-16 - SPRINT 1639-1641 - C2 EXCHANGE IDEAS
STABLE CHECKPOINT: SPRINT 1641
COMPETENCY: exchange-ideas-c2
LABEL: Control Rhetoric, Persuasion & Nuance
CAPABILITIES: argumentation + persuasion-rhetorical-control + pragmatic-effect-control
CAPABILITY MAPPING: capability-map-v1
PRODUCTION SLICE: c2-exchange-ideas
RUNTIME EVIDENCE: 6 immediate; delayed retrieval DISABLED
PERFORMANCE: C2 CONTROL; independent performance + reflective rhetorical precision feedback
SIGNATURE: same/similar position + different intended rhetorical/persuasive effect -> deliberately controlled argument form without meaning distortion
BOUNDARY: no rhetoric/persuasion/debate/C2 discussion runtime engine; generic runtime reused
SAFETY: no mastery / CEFR / competency-success / automatic progression
C2 STATUS: EXCHANGE IDEAS 4/6 complete
FINAL RESULT: SPRINT-1639-1641 BASARILI
2026-08-16 - SPRINT 1642-1644 - C2 SOLVE & NEGOTIATE
STABLE CHECKPOINT: SPRINT 1644
COMPETENCY: solve-negotiate-c2
LABEL: Control Negotiation & Diplomatic Effect
CAPABILITIES: solution-negotiation + sensitive-diplomatic-management + pragmatic-effect-control
CAPABILITY MAPPING: capability-map-v1
PRODUCTION SLICE: c2-solve-negotiate
RUNTIME EVIDENCE: 6 immediate; delayed retrieval DISABLED
PERFORMANCE: C2 CONTROL; independent performance + reflective diplomatic precision feedback
SIGNATURE: same/similar negotiation goal + different desired relationship/pragmatic effect -> deliberately controlled negotiation language + preserved practical position
BOUNDARY: no negotiation/diplomacy/concession/C2 resolution runtime engine; generic runtime reused
SAFETY: no mastery / CEFR / competency-success / automatic progression
C2 STATUS: SOLVE & NEGOTIATE 5/6 complete
FINAL RESULT: SPRINT-1642-1644 BASARILI
2026-08-16 - SPRINT 1645-1647 - C2 INTERPRET & TRANSFORM
STABLE CHECKPOINT: SPRINT 1647
COMPETENCY: interpret-transform-c2
LABEL: Preserve & Control Nuance in Transformation
CAPABILITIES: meaning-context-adaptation + nuance-preservation + perspective-style-control
CAPABILITY MAPPING: capability-map-v1
PRODUCTION SLICE: c2-interpret-transform
RUNTIME EVIDENCE: 6 immediate; delayed retrieval DISABLED
PERFORMANCE: C2 CONTROL; independent performance + reflective precision/meaning-preservation feedback
SIGNATURE: complex source meaning + required presentation/perspective/style change -> transformed learner output + essential meaning preserved + relevant nuance/qualification/effect controlled
BOUNDARY: Translation Studio remains separate; no mediation/translation/interpreting/summarization/reformulation/nuance/C2 transform runtime engine
SAFETY: no mastery / CEFR / competency-success / automatic progression
C2 STATUS: 6/6 module family development complete
CEFR PRODUCTION STATUS: A1-A2-B1-B2-C1-C2 six-family spine complete
FINAL RESULT: SPRINT-1645-1647 BASARILI
2026-08-16 - SPRINT 1648-1650 - STUDIO -> KELIME DEFTERI CONTROLLED ADD FLOW V1
STABLE CHECKPOINT: SPRINT 1650
FLOW: Translation Studio + Text Workshop -> preview -> explicit user save -> existing Kelime Defteri
PERSISTENCE: existing laf-vocabulary; no parallel vocabulary store
DUPLICATE IDENTITY: normalized source expression + source language + target language + meaning + context
MULTIPLE SENSE/CONTEXT: same expression with different meaning or context may remain separate
TRANSLATION STUDIO: existing selection / preview / save flow reused
TEXT WORKSHOP: existing contextual-result / preview / save flow reused
TERMINOLOGY: separate specialist persistence/action preserved
CEFR PRODUCTION STATUS: 36 slices / 216 immediate evidence / 36 delayed identities unchanged
DELAYED RETRIEVAL RUNTIME WRITING: DISABLED
SAFETY: no automatic CEFR / mastery / competency-success / progression side effect
FINAL RESULT: SPRINT-1648-1650 BASARILI
2026-08-16 - SPRINT 1651-1653 - CEFR DELAYED RETRIEVAL SESSION-BOUND POLICY V1
STABLE CHECKPOINT: SPRINT 1653
DESIGN AUTHORITY: MINIMAL TECHNICAL SESSION/EVIDENCE ADAPTER APPROVED
CURRENT-SIDE BINDING: existing LearningSession + current activity + real submit action + existing immediate CEFR evidence authority
SESSION ORIGIN: fresh/restored/restarted is a transient controller-derived projection; it is not persisted and is not a new lifecycle authority
BINDING TRANSPORT: existing eventId/provenance path carries derived session/activity/attempt/time identity; evidence event schema is unchanged
PRIOR-SIDE BINDING: existing session completion evidence + existing persisted session-bound occurrence + existing capability observations; no inferred historical association
ELIGIBILITY: FAIL CLOSED on UNKNOWN / restore / restart / retry / task mismatch / hint assistance / capability mismatch / invalid provenance / missing delayed identity
DELAYED WRITE: enabled only through the session-bound policy-gated API after all authoritative conditions PASS
NORMAL EXECUTABLE DELAYED PATH: remains closed; direct recordUserEvidence still rejects delayed identities
CEFR PRODUCTION STATUS: 36 slices / 216 immediate evidence definitions / 36 existing delayed identities
PERSISTENCE: existing generic evidence + existing provenance only; no new delayed store / session-evidence store / bridge store
SAFETY: no automatic mastery / competency success / CEFR assignment / progression; activation remains non-evidence
FINAL RESULT: SPRINT-1651-1653 BASARILI
2026-08-16 - SPRINT 1654-1656 - REAL-LIFE ACTIVATION SOURCE-CONTEXT RETURN V1
STABLE CHECKPOINT: SPRINT 1656
DESIGN AUTHORITY: MINIMAL LEARNING PATH RETURN-CONTEXT ADAPTER APPROVED
RECOVERY RCA: prior installer stopped before mutation on a false feedback-class UI anchor; Recovery1 uses the proven existing a1-navigate-native-session-actions seam
SOURCE CAPTURE: existing /learning route + authoritative A1 NAVIGATE activation/unit context captured only at explicit activation start
SOURCE AUTHORITY: a1-navigate / NAVIGATE / navigate-a1 / a1-navigate-immediate-everyday-needs; no guessed destination and sourceLearningItemId is not navigation authority
RETENTION: transient component state only; no new persistence store or navigation state architecture
COMPLETION: all existing Guided Real-Life Activation steps are required before the explicit return action is available
ACTIVATION SAFETY: rehearsal-only; activation completion creates no evidence, mastery, CEFR assignment or progression
RETURN: explicit "Öğrenme Yoluna Dön" reuses the existing /learning surface, data-cefr-unit selector and scrollIntoView mechanism to the same originating A1 NAVIGATE unit
DELAYED BRIDGE: Sprint 1651-1653 session-bound policy-gated delayed retrieval bridge unchanged
CEFR PRODUCTION STATUS: 36 slices / 216 immediate evidence definitions / 36 existing delayed identities unchanged
NAVIGATION: no new route hierarchy / route resolver authority / Learning Path runtime / Activation runtime
SAFETY: no automatic mastery / competency success / CEFR assignment / progression / Studio launch
FINAL RESULT: SPRINT-1654-1656 BASARILI
2026-08-16 - SPRINT 1657-1659 - REAL-LIFE ACTIVATION PROGRESS & EVIDENCE FEEDBACK INTEGRATION V1
STABLE CHECKPOINT: SPRINT 1659
STATUS UX: existing repository vocabulary reused as not-started / in-progress / complete; user labels Baslamadi / Devam Ediyor / Tamamlandi
STATUS SOURCE: existing activation transient start/completion facts; no new progress engine or persistence
FEEDBACK LANGUAGE: completion, observed evidence and mastery/CEFR semantics separated; automatic Mastered language is not emitted
EVIDENCE SAFETY: activation completion creates no competency evidence; only existing authoritative evidence may be acknowledged
CROSS-SURFACE SAFETY: existing guidance activation gate explicit-user-action and no-mastery/no-CEFR/no-progression contracts reused; no new Studio integration architecture
RETURN: Sprint 1656 exact originating Learning Path return context and explicit Oğrenme Yoluna Don behavior preserved
DELAYED BRIDGE: Sprint 1651-1653 session-bound delayed retrieval bridge unchanged
CEFR PRODUCTION STATUS: 36 slices / 216 immediate evidence definitions / 36 existing delayed identities unchanged
SAFETY: Progress != Mastery; Evidence != Mastery; Activation Completion != Mastery; no auto mastery / CEFR / progression / Studio launch
FINAL RESULT: SPRINT-1657-1659 BASARILI
2026-08-16 - SPRINT 1660-1662 - DAILY LEARNING PATH <-> CEFR CONTINUE-LEARNING BRIDGE V1
STABLE CHECKPOINT: SPRINT 1662
DESIGN AUTHORITY: Product Completion Audit approved Daily Learning Path <-> CEFR Continue-Learning Continuity V1
RECOVERY PREFLIGHT: Sprint 1659 stable; all 14 critical contracts present; MissingCriticalCount=0
RECOVERY1 RCA: prior installer stopped before mutation on a brittle one-line ctaSelector formatting guard; authoritative CefrLearningJourneyView behavior test is now the guard
SPRINT 1660: Daily and CEFR read models connected through a minimal orientation bridge; existing Daily state and existing CEFR journey view reused
SPRINT 1661: primary Continue action uses only concrete existing Daily state - saved Daily session first, then active Daily session, otherwise explicit new Daily action
SPRINT 1661 SAFETY: no guessed next lesson; existing LearningRecommendationEngine is not used by this bridge
SPRINT 1662: existing CEFR -> Daily selector .translation-daily-learning-path preserved; Daily -> CEFR reuses existing .cefr-learning-journey surface and scroll navigation
CEFR POSITION: Daily surface does not promote inspected/default level to authority; unknown current CEFR level remains unknown
DAILY PERSISTENCE: existing explicit save/load/delete semantics unchanged; no automatic persistence
STUDIO SAFETY: existing Studio navigation remains explicit; no automatic Studio launch
LEARNING AUTHORITY: Continue/Resume are navigation-orientation only; no evidence/mastery/CEFR/progression authority added
DELAYED BRIDGE: Sprint 1651-1653 session-bound delayed retrieval bridge unchanged
ACTIVATION LOOP: Sprint 1654-1659 activation completion/progress/return loop unchanged
CEFR PRODUCTION STATUS: 36 slices / 216 immediate evidence definitions / 36 existing delayed identities unchanged
ARCHITECTURE: no new planner / progress engine / recommendation engine / persistence system / progression authority
SAFETY: Continue != Progression; Resume != Mastery; Daily Completion != CEFR Completion; Evidence != Mastery
FINAL RESULT: SPRINT-1660-1662 BASARILI
2026-08-16 - SPRINT 1663-1665 - DAILY RETURN / RESUME EXPERIENCE V1
STABLE CHECKPOINT: SPRINT 1665
DESIGN AUTHORITY: conditionally pre-approved by Product Completion Audit; Sprint 1660-1662 success satisfied the condition
RECOVERY1 RCA: initial installer rolled back after PowerShell C:\Users\user collided with read-only C:\Users\user; local source variable renamed to import {
  createDailyReturnResumeExperience,
} from "../application/learning/DailyReturnResumeExperience";
import {
  LocalStorageTranslationDailyLearningSessionStorage,
} from "../ui/learning/LocalStorageTranslationDailyLearningSessionStorage";
import { useNavigate } from "react-router-dom";
import {
  calculateCurrentStudyStreak,
  calculateDailyCompletedActivities,
  calculateOverallLearningProgress,
  calculateLearningSessionProgress,
  findMostRecentLearningSession,
  ProgressService,
} from "../core/progress/ProgressService";
import {
  createTranslationActivitiesForLesson,
  findMostRecentListeningPractice,
  getLessons,
} from "../features/lessons";
import {
  Button,
  Card,
  ContinueLessonCard,
  DailyStudyCard,
  ProgressSummaryCard,
  VocabularySummaryCard,
} from "../shared/components";
import {
  createListeningPracticeStorageKey,
  LocalStorageListeningPracticeStorage,
} from "../ui/storage/LocalStorageListeningPracticeStorage";
import {
  createLearningSessionStorageKey,
  LocalStorageSessionStorage,
} from "../ui/storage/LocalStorageSessionStorage";

const progressService = new ProgressService();
const DAILY_ACTIVITY_GOAL = 10;

const LANGUAGE_NAMES:
  Record<string, string> = {
    it: "İtalyanca",
  };

const formatListeningDate = (
  date: Date,
): string =>
  new Intl.DateTimeFormat("tr-TR", {
    dateStyle: "medium",
  }).format(date);

function HomePage() {
  const navigate = useNavigate();
  const lessons = getLessons();

  const lessonStates = lessons.map(lesson => {
    const totalActivities =
      createTranslationActivitiesForLesson(
        lesson.id,
      ).length;

    const storage =
      new LocalStorageSessionStorage(
        createLearningSessionStorageKey(
          lesson.id,
        ),
      );

    const session = storage.load();
    const isCompatible =
      session?.totalActivities ===
      totalActivities;

    const compatibleSession =
      isCompatible
        ? session
        : undefined;

    const progress =
      calculateLearningSessionProgress({
        session: compatibleSession,
        totalActivities,
      });

    return {
      lesson,
      session: compatibleSession,
      progress,
    };
  });

  const activeLessonState =
    findMostRecentLearningSession(
      lessonStates,
      "in-progress",
    );

  const focusLessonState =
    findMostRecentLearningSession(
      lessonStates,
    ) ??
    lessonStates[0];

  const progressSources =
    lessonStates.map(lessonState => ({
      session: lessonState.session,
      totalActivities:
        lessonState.progress.totalActivities,
    }));

  const overallProgress =
    calculateOverallLearningProgress(
      progressSources,
    );

  const dailyCompletedActivities =
    calculateDailyCompletedActivities(
      progressSources,
    );

  const studyStreak =
    calculateCurrentStudyStreak(
      progressSources,
    );

  const summary = progressService.getSummary({
    session: focusLessonState?.session,
    totalActivities:
      focusLessonState?.progress
        .totalActivities ?? 0,
  });

  const continuePath = activeLessonState
    ? `/lessons/${activeLessonState.lesson.id}`
    : "/lessons";
  const savedDailySession =
    new LocalStorageTranslationDailyLearningSessionStorage(
      window.localStorage,
    ).load();

  const returnResume =
    createDailyReturnResumeExperience({
      savedDailySessionAvailable:
        Boolean(savedDailySession),
      savedDailySessionLanguage:
        savedDailySession?.language ?? null,
      existingActiveLessonPath:
        activeLessonState
          ? continuePath
          : null,
    });

  const focusLessonPath = focusLessonState
    ? `/lessons/${focusLessonState.lesson.id}`
    : "/lessons";

  const lessonActionLabel =
    focusLessonState?.progress.lessonCompleted
      ? "Tekrar Çalış"
      : focusLessonState?.session
        ? "Derse Devam Et"
        : "Derse Başla";

  const mostRecentListeningPractice =
    findMostRecentListeningPractice(
      lessons.flatMap(lesson => {
        const record =
          new LocalStorageListeningPracticeStorage(
            createListeningPracticeStorageKey(
              lesson.id,
            ),
          ).load();

        return record
          ? [
              {
                lesson,
                ...record,
              },
            ]
          : [];
      }),
    );

  const listeningPracticePath =
    mostRecentListeningPractice
      ? `/lessons/${mostRecentListeningPractice.lesson.id}/listening`
      : "/lessons";

  return (
    <main className="app-shell">
      <section className="hero">
        <p className="eyebrow">Language Architecture Framework</p>

        <h1>LAF Studio</h1>

        <p className="description">
          Yapay zekâ destekli, yapılandırılmış ve kişiselleştirilebilir dil
          öğrenme platformu.
        </p>

        <div className="actions">
          <Button
            variant="primary"
            onClick={() => navigate("/lessons")}
          >
            Yeni Ders
          </Button>

          <Button
            variant="secondary"
            onClick={() => navigate(returnResume.destination)}
          >
            {activeLessonState
              ? "Öğrenmeye Devam Et"
              : "Dersleri Keşfet"}
          </Button>
        </div>
        <p className="description">
          {returnResume.statusLabel}
        </p>
      </section>

      <section className="feature-grid">
        <DailyStudyCard
          completed={dailyCompletedActivities}
          goal={DAILY_ACTIVITY_GOAL}
          streakDays={studyStreak}
          actionLabel={lessonActionLabel}
          onStart={() =>
            navigate(focusLessonPath)
          }
        />

        <ContinueLessonCard
          language={
            activeLessonState
              ? (
                  LANGUAGE_NAMES[
                    activeLessonState.lesson
                      .languageCode
                  ] ??
                  activeLessonState.lesson
                    .languageCode.toUpperCase()
                )
              : undefined
          }
          lessonTitle={
            activeLessonState?.lesson.title
          }
          progress={
            activeLessonState?.progress
              .progressPercentage ?? 0
          }
          onContinue={() =>
            navigate(continuePath)
          }
        />

        <Card>
          <h2>🎧 Dinlemeye Devam Et</h2>

          {mostRecentListeningPractice ? (
            <>
              <p>
                {
                  LANGUAGE_NAMES[
                    mostRecentListeningPractice
                      .lesson.languageCode
                  ] ??
                  mostRecentListeningPractice
                    .lesson.languageCode.toUpperCase()
                }
              </p>

              <h3>
                {
                  mostRecentListeningPractice
                    .lesson.title
                }
              </h3>

              <p>
                En iyi dinleme başarısı:{" "}
                <strong>
                  %
                  {
                    mostRecentListeningPractice
                      .bestSuccessPercentage
                  }
                </strong>
              </p>

              <p>
                Son çalışma:{" "}
                {formatListeningDate(
                  mostRecentListeningPractice
                    .lastCompletedAt,
                )}
              </p>
            </>
          ) : (
            <p>
              Henüz tamamlanmış bir dinleme
              çalışmanız bulunmuyor.
            </p>
          )}

          <Button
            variant="primary"
            onClick={() =>
              navigate(listeningPracticePath)
            }
          >
            {mostRecentListeningPractice
              ? "Dinlemeye Devam Et"
              : "Dinleme Dersi Seç"}
          </Button>
        </Card>

        <VocabularySummaryCard
          totalWords={summary.totalWords}
          favoriteWords={summary.favoriteWords}
          newWordsToday={0}
          onOpen={() => navigate("/vocabulary")}
        />

        <ProgressSummaryCard
          totalLessons={
            overallProgress.totalLessons
          }
          completedLessons={
            overallProgress.completedLessons
          }
          completedActivities={
            overallProgress.completedActivities
          }
          progressRate={
            overallProgress.progressPercentage
          }
          onOpen={() => navigate("/progress")}
        />
      </section>
    </main>
  );
}

export default HomePage;

SPRINT 1663: app reopen reads existing explicitly saved Daily Learning record and existing active lesson continuation without creating new persistence
SPRINT 1664: Home primary Continue action uses deterministic authority order - saved Daily session -> existing active lesson -> existing /learning orientation surface
SPRINT 1664 SAFETY: saved Daily continuation opens existing Learning Path; actual Daily load remains explicit under existing Daily panel authority
SPRINT 1665: invalid/unknown lesson path is not promoted to continuation authority; safe existing /learning orientation is used instead
RECOMMENDATION: existing LearningRecommendationEngine is not used or changed
PERSISTENCE: no new store and no automatic save/load policy added
NAVIGATION: explicit user action only; no automatic redirect and no automatic Studio launch
LEARNING AUTHORITY: Resume is navigation/orientation only; no mastery / CEFR / progression authority added
CEFR PRODUCTION STATUS: 36 slices / 216 immediate evidence definitions / 36 existing delayed identities unchanged
DELAYED BRIDGE: unchanged
ACTIVATION LOOP: unchanged
FINAL RESULT: SPRINT-1663-1665 BASARILI
============================================================
2026-08-16 — LAF STUDIO — SPRINT 1666–1668 CLOSURE
============================================================

STABLE CHECKPOINT: SPRINT 1668
FINAL RESULT: SPRINT-1666-1668 BASARILI

FEATURE:
First-Run Learning Entry & First Successful Session Continuity V1

SUBFEATURE:
Minimal First-Run Target-Language Context Adapter V1

CLOSED PRODUCT LOOP:
FIRST OPEN
→ EXPLICIT TARGET-LANGUAGE SELECTION
→ EXISTING /learning
→ EXISTING DAILY LEARNING
→ EXPLICIT LEARNING START
→ EXISTING COMPLETION
→ NORMAL CONTINUE-LEARNING LIFECYCLE

PRESERVED:
- returning learner uses existing authoritative state
- saved Daily language remains authoritative
- existing lesson/session history remains authoritative
- existing CEFR persisted profile remains authoritative
- existing Continue / Resume remains authoritative
- existing Daily completion remains authoritative
- existing LafLearningLanguageCode / LafLanguageProfile reused
- no language inference
- no default language
- no new profile architecture
- no new onboarding persistence
- no new onboarding runtime
- no new learning runtime
- no recommendation engine
- no automatic placement
- no automatic Studio launch
- no automatic mastery
- no automatic CEFR
- no automatic progression

Language Selection ≠ CEFR Placement
Language Selection ≠ Learning Completion
First Session Completion ≠ Mastery
Daily Completion ≠ Competency Mastery
Evidence ≠ Mastery

============================================================
============================================================
2026-08-16 — LAF STUDIO — SPRINT 1669–1671 CLOSURE
============================================================

STABLE CHECKPOINT: SPRINT 1671
FINAL RESULT: SPRINT-1669-1671 BASARILI

FEATURE:
AI Teacher Cross-Studio Consistency V1

AUTHORITATIVE COMMON CONTRACT:
TASK
→ LEARNER ATTEMPTS FIRST
→ MINIMUM USEFUL SUPPORT
→ LEARNER RETRIES / CONTINUES
→ FEEDBACK
→ LEARNER REMAINS THE PRODUCER

SURFACE BINDING:
- Grammar Lab: AI_TEACHER
- Reading: AI_TEACHER
- Listening: AI_TEACHER
- Writing: AI_TEACHER
- Speaking: AI_TEACHER
- Dialogue: AI_TEACHER
- CEFR Learning Path: MIXED_WITH_AUTHORITATIVE_CONTEXT
- Translation Studio: AI_PRODUCTIVITY_TOOL
- Text Workshop: AI_PRODUCTIVITY_TOOL

PRESERVED:
- task-specific Studio behavior
- legitimate Translation output generation
- legitimate Text Workshop productivity behavior
- existing AI provider/integration seams
- existing learner-action provenance
- existing evidence safety
- delayed-retrieval assistance safety
- Real-Life Activation safety
- CEFR adaptation only from authoritative context

NO NEW:
- AI platform
- AI runtime
- AI Teacher product
- universal prompt engine
- evidence store
- learner-action system
- mastery system
- CEFR assignment engine
- recommendation system
- Studio family

AI Assistance ≠ Learner Evidence
AI Feedback ≠ Mastery
Correct Answer ≠ CEFR Verification
AI Evaluation ≠ CEFR Assignment
AI Support ≠ Automatic Progression

NO AUTO MASTERY.
NO AUTO CEFR.
NO AUTO PROGRESSION.
NO AUTO STUDIO LAUNCH.

============================================================
============================================================
2026-08-16 — LAF STUDIO — SPRINT 1672–1674 CLOSURE
============================================================

STABLE CHECKPOINT: SPRINT 1674
FINAL RESULT: SPRINT-1672-1674 BASARILI

FEATURE:
Spoken-Language Continuity V1

SPRINT 1672:
Listening -> Speaking continuity is active only inside the already-existing
Text Workshop shared language + source-text context and only after the
existing Listening session summary is available.

The learner must explicitly choose:
KONUSARAK DEVAM ET

The action only moves focus to the already-existing Speaking presentation.
It creates no completion, evidence, mastery, CEFR, progression, persistence,
recommendation, or automatic Studio launch.

SPRINT 1673:
Speaking -> Dialogue continuity is FAIL CLOSED in V1.

Verified repository state contains no approved exact/static mapping from an
existing Speaking identity to an existing Dialogue scenario identity.

Therefore:
NO HANDOFF.
NO semantic guessing.
NO recommendation engine.
NO invented mapping.

SPRINT 1674:
Dialogue -> Real-Life Activation continuity is FAIL CLOSED in V1.

Verified repository state contains no authoritative Dialogue -> CEFR unit ->
activation identity relationship.

Therefore:
NO HANDOFF.
NO new activation mapping.
Existing Activation authority and explicit-start safety remain unchanged.

PRESENTATION:
Existing Text Workshop Speaking and Dialogue presentation surfaces reused.
No new Speaking route.
No new Dialogue route.
No duplicate presentation shell.

PRESERVED:
- Listening standalone behavior
- Speaking standalone behavior
- Dialogue standalone behavior
- existing Speaking attempt/session behavior
- existing Dialogue scenario/session behavior
- Sprint 1669-1671 AI Teacher contract
- existing evidence/provenance boundaries
- existing Real-Life Activation safety

NO NEW:
- spoken runtime
- speech engine
- Speaking runtime
- Dialogue runtime
- recommendation engine
- semantic/fuzzy/AI mapping
- persistence
- evidence architecture
- mastery
- CEFR assignment
- progression engine

CONTINUITY:
PARTIAL BUT AUTHORITATIVE.

Listening -> Speaking: ACTIVE
Speaking -> Dialogue: NO HANDOFF
Dialogue -> Activation: NO HANDOFF

NO AUTO STUDIO LAUNCH.
NO AUTO MASTERY.
NO AUTO CEFR.
NO AUTO PROGRESSION.

============================================================
============================================================
2026-08-16 — LAF STUDIO — SPRINT 1675–1677 CLOSURE
============================================================

STABLE CHECKPOINT: SPRINT 1677
FINAL RESULT: SPRINT-1675-1677 BASARILI

FEATURE:
Vocabulary Active Reuse Continuity V1

FLOW:
VocabularyPage
→ explicit Kullanarak Pratik Yap
→ existing /text-workshop
→ transient Vocabulary context
→ existing SpeakingStudioPanel
→ real learner Speaking flow

SEMANTIC:
GUIDED REUSE ONLY
INDEPENDENT RECALL CLAIM: NO

PERSISTENCE:
Existing laf-vocabulary unchanged.
New persistent reuse tracking: NONE.
VocabularyItem -> SpeakingAttempt persistence: NONE.

PRACTICE CONTEXT:
Existing contextSentence preferred.
Existing word/expression fallback.
AI-generated practice sentence: NONE.

AUTHORITY:
Speaking attempts / recognition / completion remain under existing Speaking authority.
Existing Speaking evidence rules remain unchanged.
Opening Text Workshop / Speaking is not learner reuse.
AI output is not learner reuse.

EXPANSION:
Vocabulary -> Writing: NONE.
Vocabulary -> Dialogue: NONE.
Vocabulary -> CEFR production: NONE.

SAFETY:
New Vocabulary evidence: NONE.
New mastery: NONE.
Automatic CEFR: NONE.
Automatic progression: NONE.
Automatic Studio launch: NONE.
New Speaking runtime: NONE.

VALIDATION:
Target tests: PASSED.
Full regression: PASSED.
Production build: PASSED.

RCA RECOVERY:
Multiline exact-anchor dependency removed.
Single-line bounded seams used under exact Sprint 1674 hash guards.

============================================================
============================================================
2026-08-17 — LAF STUDIO — SPRINT 1678–1680 CLOSURE
============================================================

STABLE CHECKPOINT: SPRINT 1680
FINAL RESULT: SPRINT-1678-1680 BASARILI

FEATURE:
Learning Workspace Primary-Action & Section Hierarchy Cleanup V1

SPRINT 1678:
Existing /learning current action visually grouped as primary.
First-Run and Learning Guidance authorities preserved.
Existing Learning Journey alternatives remain mounted and available.
Learning queue remains available as support.

SPRINT 1679:
Text Workshop active source/work context is presented as primary.
Existing Studio Dock remains the discovery/focus mechanism.
Writing, Dialogue, Speaking, Listening, Reading and Grammar remain mounted.
No Studio capability removed.

SPRINT 1680:
Responsive hierarchy rules added using existing responsive model.
Vocabulary -> Speaking guided reuse preserved.
Listening -> Speaking continuity preserved.
No automatic navigation.
No feature removal.
No new route/navigation architecture.
No new persistence.
No recommendation engine.
No new learning authority.
No evidence/mastery/CEFR/progression mutation.

PROGRESSIVE DISCLOSURE:
VISUAL HIERARCHY ONLY.
NO STUDIO UNMOUNT.
NO LAZY RUNTIME.
NO DISPLAY:NONE.

VALIDATION:
Target tests: PASSED.
Full regression: PASSED.
Production build: PASSED.

============================================================
============================================================
2026-08-17 — LAF STUDIO — SPRINT 1681–1683 CLOSURE
============================================================

STABLE CHECKPOINT: SPRINT 1686
FINAL RESULT: SPRINT-1681-1683 BASARILI

WHOLE-PRODUCT UX / BROWSER QA V1
TRACK 2 CORRECTION

FEATURE:
Home Continue / Resume Hierarchy Fix V2

METHOD:
TypeScript AST-position deterministic Node codemod.
PowerShell performed orchestration, stable hash validation,
rollback, tests and build only.

PROVEN QA GAP:
Home had the correct return/resume destination authority,
but visual priority promoted Yeni Ders above Continue / Resume.

CORRECTION:
Existing DailyReturnResumeExperience remains authoritative.

Home primary:
returnResume.primaryLabel
→ returnResume.destination

Home secondary:
Yeni Ders
→ /lessons

DUPLICATE CONTINUATION:
ContinueLessonCard is suppressed only when the exact active lesson
continuation is already the Home hero primary action.
If Saved Daily is primary, the lesson card remains available.

PRIORITY:
Saved Daily > Active Lesson > /learning orientation
UNCHANGED.

NO:
- new persistence
- recommendation engine
- navigation architecture
- automatic navigation
- feature removal
- mastery mutation
- CEFR mutation
- progression mutation

VALIDATION:
Target tests: PASSED.
Full regression: PASSED.
Production build: PASSED.

BROWSER QA:
Track 2 Home recheck required.

============================================================

## 2026-08-17 — Sprint 1684-1686 — QA Track 4

FINAL RESULT: SPRINT-1684-1686 BASARILI

- QA Track 4 primary-task hierarchy corrected.
- With no working text, "Metin Ekle" is the primary hero action.
- With a working text, the existing "Metne Dön" action remains secondary and "Bugünkü Planı Aç" remains primary.
- Existing source-input and Daily Learning Path scroll seams are reused.
- Active Work PDF/print fragmentation is corrected with print-only CSS; runtime/browser hero layout is unchanged by that correction.
- Daily Learning Path, CEFR Learning Journey, all Studio mounts, Vocabulary -> Speaking and Listening -> Speaking continuity are preserved.
- No new persistence, recommendation engine, mastery, CEFR, progression, or automatic navigation authority was introduced.

============================================================
2026-08-17 — LAF STUDIO — SPRINT 1687–1689 CLOSURE
============================================================

STABLE CHECKPOINT: SPRINT 1689
FINAL RESULT: SPRINT-1687-1689 BASARILI

WHOLE-PRODUCT UX / BROWSER QA V1
TRACK 5 CORRECTION

FEATURE:
Text Workshop Vocabulary Controlled Add Visibility Fix V1

PROVEN QA GAP:
Word selection and inspection worked, but the approved
"Kelime Defterine Ekle" controlled-add action was nested under
contextualResult. The learner therefore had to create an AI/contextual
meaning result before the Vocabulary preview could even be opened.

CORRECTION:
- selected word alone can explicitly open "Kelime Defterine Ekle"
- target meaning remains editable and required before save
- existing sentence context is reused when available
- contextual-result flow remains available and may still prefill meaning
- changing selected word resets stale Vocabulary preview state
- existing explicit "Kelime Defterine Kaydet" remains the only save action
- existing saveStudioVocabularyCapture / VocabularyService seam is reused
- existing duplicate identity remains unchanged
- controlled-add visibility is governed by a pure TypeScript policy seam
- target tests do not require Node runtime typings
- Turkish controlled-add preview labels corrected

PERSISTENCE:
existing laf-vocabulary only.

TERMINOLOGY:
separate Terminology action/persistence preserved.

NO:
- automatic Vocabulary save
- new vocabulary store
- new persistence
- automatic AI generation
- new recommendation authority
- mastery mutation
- CEFR mutation
- progression mutation
- automatic Studio launch

BROWSER QA:
Track 5 controlled-add recheck required after installation.

============================================================

============================================================
2026-08-17 — LAF STUDIO — SPRINT 1690–1692 CLOSURE
============================================================

STABLE CHECKPOINT: SPRINT 1692
FINAL RESULT: SPRINT-1690-1692 BASARILI

WHOLE-PRODUCT UX / BROWSER QA V1
VISUAL POLISH CORRECTION

FEATURE:
Text Workshop ACTIVE WORK Marker Alignment Fix V1

PROVEN GAP:
The Text Workshop "AKTİF ÇALIŞMA / Metin ve mevcut çalışma bağlamı"
marker began at the outer page edge while the immediately following
LearningFocusHero content used clamp(28px, 5vw, 54px) horizontal padding.
The marker therefore appeared visually too far left relative to its
primary workspace.

CORRECTION:
- only the Text Workshop ACTIVE WORK marker receives a page-specific class
- marker text now uses the same clamp(28px, 5vw, 54px) horizontal inset
  as LearningFocusHero inner content
- shared learning-workspace-hierarchy-marker CSS remains unchanged
- hero layout remains unchanged
- all Studio panels remain mounted
- browser behavior and learning continuity remain unchanged

NO:
- navigation change
- runtime change
- persistence change
- new state
- mastery mutation
- CEFR mutation
- progression mutation
- Studio auto-launch
- global hierarchy redesign

BROWSER QA:
Visual recheck required after installation.

============================================================

