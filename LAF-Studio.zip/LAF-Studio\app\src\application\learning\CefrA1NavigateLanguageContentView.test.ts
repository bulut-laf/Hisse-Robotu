import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrA1NavigateLanguageContentView,
} from "./CefrA1NavigateLanguageContentView";

describe(
  "A1 NAVIGATE language content view",
  () => {
    it("shows selected language content with the six immediate executable tasks now available", () => {
      const result =
        createCefrA1NavigateLanguageContentView(
          "it",
          "a1-navigate-ask-essential-information",
        );

      expect(result).toMatchObject({
        languageCode: "it",
        lessonId:
          "a1-navigate-ask-essential-information",
        languageContentAvailable: true,
        assistantAuthoredV1: true,
        nativeReviewValidated: false,
        executableTaskAvailable: true,
        executableImmediateTaskCount: 6,
        evidenceCaptureAvailable: true,
        evidenceRequiresUserAction: true,
        delayedRetrievalRuntimeAvailable:
          false,
      });

      expect(result.phrases).toHaveLength(3);
    });

    it("fails closed for a lesson outside the approved A1 NAVIGATE slice", () => {
      expect(() =>
        createCefrA1NavigateLanguageContentView(
          "en",
          "a2-navigate-transaction",
        ),
      ).toThrow(
        "A1 NAVIGATE realized lesson not found",
      );
    });
  },
);
