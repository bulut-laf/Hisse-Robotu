$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 942-944 Target Tests: Personal Language Profile Foundation ==="
npx vitest run `
  "src/core/learning/CefrPersonalLanguageProfileEvidence.test.ts" `
  "src/core/learning/CefrPersonalLanguageProfileEvidenceAggregation.test.ts" `
  "src/core/learning/CefrPersonalLanguageProfileSnapshot.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 942-944 target tests failed." }

Write-Host "=== Sprint 945-947 Target Tests: Capability Observation Bridge ==="
npx vitest run `
  "src/core/learning/CefrCapabilityObservation.test.ts" `
  "src/core/learning/CefrCapabilityObservationRegistry.test.ts" `
  "src/core/learning/CefrPersonalLanguageProfileState.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 945-947 target tests failed." }

Write-Host "=== Combined Sprint 942-947 New Tests ==="
npx vitest run `
  "src/core/learning/CefrPersonalLanguageProfileEvidence.test.ts" `
  "src/core/learning/CefrPersonalLanguageProfileEvidenceAggregation.test.ts" `
  "src/core/learning/CefrPersonalLanguageProfileSnapshot.test.ts" `
  "src/core/learning/CefrCapabilityObservation.test.ts" `
  "src/core/learning/CefrCapabilityObservationRegistry.test.ts" `
  "src/core/learning/CefrPersonalLanguageProfileState.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 942-947 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-942-947 VERIFICATION COMPLETE"
