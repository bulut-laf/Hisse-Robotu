﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$src = Join-Path $root "app\src"
$out = Join-Path $root "LAF_EMBEDDED_STUDIO_COMPLETION_DISCOVERY.txt"

if (-not (Test-Path $src)) {
    throw "Source root not found: $src"
}

$report = New-Object System.Collections.Generic.List[string]

function Add-Line {
    param([string]$Text)
    if ($null -eq $Text) { $Text = "" }
    [void]$report.Add($Text)
}

function Add-Section {
    param([string]$Title)
    Add-Line ""
    Add-Line ("=" * 92)
    Add-Line $Title
    Add-Line ("=" * 92)
}

function Rel {
    param([string]$Path)
    $prefix = $root + "\"
    if ($Path.StartsWith($prefix)) {
        return $Path.Substring($prefix.Length)
    }
    return $Path
}

$sourceFiles = @(
    Get-ChildItem -Path $src -Recurse -File -ErrorAction SilentlyContinue |
    Where-Object {
        $_.Extension -eq ".ts" -or $_.Extension -eq ".tsx"
    }
)

function Search-Patterns {
    param(
        [string]$Title,
        [string[]]$Patterns,
        [int]$Limit = 260
    )

    Add-Section $Title

    $items = New-Object System.Collections.Generic.List[object]

    foreach ($file in $sourceFiles) {
        foreach ($pattern in $Patterns) {
            $hits = @(
                Select-String `
                    -Path $file.FullName `
                    -SimpleMatch `
                    -Pattern $pattern `
                    -ErrorAction SilentlyContinue
            )

            foreach ($hit in $hits) {
                $obj = [PSCustomObject]@{
                    File = Rel $hit.Path
                    Line = $hit.LineNumber
                    Pattern = $pattern
                    Text = $hit.Line.Trim()
                }
                [void]$items.Add($obj)
            }
        }
    }

    $matches = @(
        $items |
        Sort-Object File, Line, Pattern -Unique |
        Select-Object -First $Limit
    )

    if ($matches.Count -eq 0) {
        Add-Line "(no matches)"
        return
    }

    foreach ($m in $matches) {
        Add-Line (
            "{0}:{1} [{2}] {3}" -f
            $m.File,
            $m.Line,
            $m.Pattern,
            $m.Text
        )
    }
}

Search-Patterns `
    -Title "1. EMBEDDED STUDIO ROOT SELECTORS" `
    -Patterns @(
        "translation-reading-studio"
        "translation-writing-studio"
        "translation-speaking-studio"
        "translation-dialogue-studio"
        "reading-studio"
        "writing-studio"
        "speaking-studio"
        "dialogue-studio"
    ) `
    -Limit 240

Search-Patterns `
    -Title "2. READING COMPLETION SIGNALS" `
    -Patterns @(
        "TranslationReading"
        "readingSession"
        "readingSummary"
        "readingResult"
        "completeReading"
        "finishReading"
        "handleReading"
        "setReading"
    ) `
    -Limit 260

Search-Patterns `
    -Title "3. WRITING COMPLETION SIGNALS" `
    -Patterns @(
        "TranslationWriting"
        "writingSession"
        "writingSummary"
        "writingResult"
        "completeWriting"
        "finishWriting"
        "handleWriting"
        "setWriting"
    ) `
    -Limit 260

Search-Patterns `
    -Title "4. SPEAKING COMPLETION SIGNALS" `
    -Patterns @(
        "TranslationSpeaking"
        "speakingSession"
        "speakingSummary"
        "speakingResult"
        "completeSpeaking"
        "finishSpeaking"
        "handleSpeaking"
        "setSpeaking"
    ) `
    -Limit 260

Search-Patterns `
    -Title "5. DIALOGUE COMPLETION SIGNALS" `
    -Patterns @(
        "TranslationDialogue"
        "dialogueSession"
        "dialogueSummary"
        "dialogueResult"
        "completeDialogue"
        "finishDialogue"
        "handleDialogue"
        "setDialogue"
    ) `
    -Limit 260

Search-Patterns `
    -Title "6. GENERIC USER-AUTHORIZED COMPLETION / SAVE SIGNALS" `
    -Patterns @(
        "onComplete"
        "isCompleted"
        "completed"
        "handleComplete"
        "handleFinish"
        "saveResult"
        "saveSession"
        "record("
        "replace("
        "localStorage"
        "LocalStorage"
    ) `
    -Limit 320

Add-Section "7. CANDIDATE UI FILE PREVIEWS"

$candidateFiles = New-Object System.Collections.Generic.List[string]

foreach ($file in $sourceFiles) {
    $text = Get-Content -Path $file.FullName -Raw -ErrorAction SilentlyContinue

    if (
        $text -match "translation-(reading|writing|speaking|dialogue)-studio" -or
        $file.Name -match "Reading|Writing|Speaking|Dialogue"
    ) {
        [void]$candidateFiles.Add($file.FullName)
    }
}

$uniqueCandidates = @(
    $candidateFiles |
    Sort-Object -Unique |
    Select-Object -First 30
)

if ($uniqueCandidates.Count -eq 0) {
    Add-Line "(no candidate UI/application files found)"
}
else {
    foreach ($filePath in $uniqueCandidates) {
        Add-Line ""
        Add-Line ("FILE: " + (Rel $filePath))
        Add-Line ("-" * 92)

        $content = @(Get-Content -Path $filePath)
        $limit = [Math]::Min($content.Count, 360)

        for ($i = 0; $i -lt $limit; $i++) {
            Add-Line ("{0,4}: {1}" -f ($i + 1), $content[$i])
        }

        if ($content.Count -gt $limit) {
            Add-Line (
                "... truncated; total lines: " +
                $content.Count
            )
        }
    }
}

Add-Section "8. IMPLEMENTATION DECISION INPUT"
Add-Line "Need exact completion callback for each real Studio."
Add-Line "Need exact identity already available at completion time."
Add-Line "Need exact completion timestamp or safe point to create it."
Add-Line "Need existing persistence seam, if any."
Add-Line "Do not fabricate capabilityReference if no real mapping exists."
Add-Line "Do not assign mastery, CEFR level, or progression automatically."
Add-Line "Preserve existing Studio behavior and user-authorized actions."

$report | Set-Content -Path $out -Encoding UTF8

Write-Host ""
Write-Host "LAF EMBEDDED STUDIO COMPLETION DISCOVERY COMPLETE"
Write-Host "Report:"
Write-Host $out
Write-Host ""
Get-Content -Path $out
