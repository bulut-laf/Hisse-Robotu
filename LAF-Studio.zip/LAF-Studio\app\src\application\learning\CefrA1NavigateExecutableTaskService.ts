import type {
  LafLearningLanguageCode,
} from "../../core/language/LafLanguageProfile";
import {
  getLafA1NavigateExecutableTask,
  type CefrA1NavigateExecutableTaskId,
} from "../../core/learning/CefrA1NavigateExecutableTaskDefinition";
import {
  getLafA1NavigateLanguageContentPack,
  type CefrA1NavigateRealizedPhrase,
} from "../../core/learning/CefrA1NavigateLanguageContentRegistry";
import type {
  CefrAuthoritativeLanguageRuntimeEvidenceResult,
} from "./CefrAuthoritativeLanguageRuntimeEvidenceService";
import {
  CefrProductionRuntimePlatform,
} from "./CefrProductionRuntimePlatform";

export interface CefrA1NavigateExecutableTaskView {
  readonly taskId:
    CefrA1NavigateExecutableTaskId;
  readonly lessonId: string;
  readonly languageCode:
    LafLearningLanguageCode;
  readonly instructionKey: string;
  readonly taskKind: "controlled-selection";
  readonly options:
    readonly CefrA1NavigateRealizedPhrase[];
  readonly evidenceDefinitionId: string;
  readonly correctAnswerExposed: false;
  readonly evidenceWritten: false;
  readonly targetLanguageExplicit: true;
  readonly targetLanguageInferred: false;
}

export interface CefrA1NavigateTaskSelectionInput {
  readonly taskId:
    CefrA1NavigateExecutableTaskId;
  readonly languageCode:
    LafLearningLanguageCode;
  readonly selectedPhraseId: string;
  readonly eventId: string;
  readonly occurredAt: Date;
  readonly userActionConfirmed: boolean;
}

export interface CefrA1NavigateTaskSelectionResult {
  readonly taskId:
    CefrA1NavigateExecutableTaskId;
  readonly lessonId: string;
  readonly evidenceDefinitionId: string;
  readonly languageCode:
    LafLearningLanguageCode;
  readonly selectedPhraseId: string;
  readonly selectionRecognized: boolean;
  readonly correct: boolean;
  readonly evidenceWritten: boolean;
  readonly runtime:
    CefrAuthoritativeLanguageRuntimeEvidenceResult | null;
  readonly targetLanguageExplicit: true;
  readonly targetLanguageInferred: false;
  readonly masteryAssigned: false;
  readonly competencySuccessAssigned: false;
  readonly cefrLevelAssigned: false;
  readonly progressionPerformed: false;
  readonly automaticStudioLaunchPerformed:
    false;
  readonly automaticTransactionCompletionPerformed:
    false;
}

export class CefrA1NavigateExecutableTaskService {
  private readonly platform:
    CefrProductionRuntimePlatform;

  constructor(
    platform: CefrProductionRuntimePlatform,
  ) {
    this.platform = platform;
  }

  getTaskView(
    taskId:
      CefrA1NavigateExecutableTaskId,
    languageCode:
      LafLearningLanguageCode,
  ): CefrA1NavigateExecutableTaskView {
    const task =
      getLafA1NavigateExecutableTask(taskId);
    const pack =
      getLafA1NavigateLanguageContentPack(
        languageCode,
      );
    const lesson =
      pack.lessons.find(
        item =>
          item.lessonId === task.lessonId,
      );

    if (!lesson) {
      throw new Error(
        `A1 NAVIGATE task language content missing: ${task.taskId}/${languageCode}`,
      );
    }

    if (
      !lesson.phrases.some(
        phrase =>
          phrase.phraseId ===
          task.correctPhraseId,
      )
    ) {
      throw new Error(
        `A1 NAVIGATE task answer phrase missing: ${task.taskId}/${languageCode}`,
      );
    }

    return {
      taskId: task.taskId,
      lessonId: task.lessonId,
      languageCode,
      instructionKey:
        task.instructionKey,
      taskKind: task.taskKind,
      options: lesson.phrases,
      evidenceDefinitionId:
        task.evidenceDefinitionId,
      correctAnswerExposed: false,
      evidenceWritten: false,
      targetLanguageExplicit: true,
      targetLanguageInferred: false,
    };
  }

  executeSelection(
    input:
      CefrA1NavigateTaskSelectionInput,
  ): CefrA1NavigateTaskSelectionResult {
    if (!input.userActionConfirmed) {
      throw new Error(
        "Explicit user action confirmation is required for A1 NAVIGATE evidence.",
      );
    }

    const task =
      getLafA1NavigateExecutableTask(
        input.taskId,
      );

    const view =
      this.getTaskView(
        input.taskId,
        input.languageCode,
      );

    const selectionRecognized =
      view.options.some(
        phrase =>
          phrase.phraseId ===
          input.selectedPhraseId,
      );

    if (!selectionRecognized) {
      throw new Error(
        `Unknown A1 NAVIGATE task option: ${input.selectedPhraseId}`,
      );
    }

    const correct =
      input.selectedPhraseId ===
      task.correctPhraseId;

    if (!correct) {
      return {
        taskId: task.taskId,
        lessonId: task.lessonId,
        evidenceDefinitionId:
          task.evidenceDefinitionId,
        languageCode:
          input.languageCode,
        selectedPhraseId:
          input.selectedPhraseId,
        selectionRecognized: true,
        correct: false,
        evidenceWritten: false,
        runtime: null,
        targetLanguageExplicit: true,
        targetLanguageInferred: false,
        masteryAssigned: false,
        competencySuccessAssigned: false,
        cefrLevelAssigned: false,
        progressionPerformed: false,
        automaticStudioLaunchPerformed:
          false,
        automaticTransactionCompletionPerformed:
          false,
      };
    }

    const runtime =
      this.platform.recordUserEvidence(
        "a1-navigate",
        {
          evidenceDefinitionId:
            task.evidenceDefinitionId,
          eventId: input.eventId,
          occurredAt: input.occurredAt,
          languageCode:
            input.languageCode,
          userActionConfirmed: true,
        },
      );

    return {
      taskId: task.taskId,
      lessonId: task.lessonId,
      evidenceDefinitionId:
        task.evidenceDefinitionId,
      languageCode:
        input.languageCode,
      selectedPhraseId:
        input.selectedPhraseId,
      selectionRecognized: true,
      correct: true,
      evidenceWritten: true,
      runtime,
      targetLanguageExplicit: true,
      targetLanguageInferred: false,
      masteryAssigned: false,
      competencySuccessAssigned: false,
      cefrLevelAssigned: false,
      progressionPerformed: false,
      automaticStudioLaunchPerformed:
        false,
      automaticTransactionCompletionPerformed:
        false,
    };
  }
}
