import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrPersonalLanguageProfileState,
  type CefrPersonalLanguageProfileState,
} from "../../core/learning/CefrPersonalLanguageProfileState";
import {
  createCefrA1ConnectGreetingComprehensionTask,
} from "../../core/learning/CefrA1ConnectGreetingComprehensionTask";
import type {
  CefrGuidanceRuntimeProfileRepository,
} from "./CefrGuidanceRuntimeProfileRepository";
import {
  CefrA1ConnectEvidenceProvenanceCoordinator,
} from "./CefrA1ConnectEvidenceProvenanceCoordinator";
import {
  CefrA1ConnectGreetingTaskCompletionService,
} from "./CefrA1ConnectGreetingTaskCompletionService";
import {
  CefrA1ConnectLanguageEvidenceProvenanceRepository,
} from "./CefrA1ConnectLanguageEvidenceProvenanceRepository";

class MemoryStorage {
  private readonly values =
    new Map<string, string>();

  getItem(key: string): string | null {
    return this.values.get(key) ?? null;
  }

  setItem(
    key: string,
    value: string,
  ): void {
    this.values.set(key, value);
  }

  removeItem(key: string): void {
    this.values.delete(key);
  }
}

class MemoryProfileRepository
  implements CefrGuidanceRuntimeProfileRepository {
  private state:
    CefrPersonalLanguageProfileState =
      createCefrPersonalLanguageProfileState(
        [],
        [],
      );

  load(): CefrPersonalLanguageProfileState {
    return this.state;
  }

  save(
    state: CefrPersonalLanguageProfileState,
  ): void {
    this.state = state;
  }

  hasPersistedProfile(): boolean {
    return true;
  }

  clear(): void {
    this.state =
      createCefrPersonalLanguageProfileState(
        [],
        [],
      );
  }
}

describe(
  "A1 CONNECT provenance constructor compatibility",
  () => {
    it("keeps the previously stable direct provenance-repository constructor contract", () => {
      const provenanceRepository =
        new CefrA1ConnectLanguageEvidenceProvenanceRepository(
          new MemoryStorage(),
        );

      const service =
        new CefrA1ConnectGreetingTaskCompletionService(
          new MemoryProfileRepository(),
          provenanceRepository,
        );

      const task =
        createCefrA1ConnectGreetingComprehensionTask(
          "it",
        );

      const result =
        service.submit({
          languageCode: "it",
          submittedAnswer:
            task.correctAnswer,
          eventId:
            "compat-direct-repository",
          occurredAt:
            new Date(
              "2026-08-11T19:30:00.000Z",
            ),
          userActionConfirmed: true,
        });

      expect(result.evidencePersisted).toBe(
        true,
      );

      expect(
        provenanceRepository
          .findByEvidenceId(
            result.evidence?.runtimeEvidenceId ??
              "",
          )
          ?.languageCode,
      ).toBe("it");
    });

    it("also supports the new recovery-aware coordinator constructor contract", () => {
      const provenanceRepository =
        new CefrA1ConnectLanguageEvidenceProvenanceRepository(
          new MemoryStorage(),
        );

      const service =
        new CefrA1ConnectGreetingTaskCompletionService(
          new MemoryProfileRepository(),
          new CefrA1ConnectEvidenceProvenanceCoordinator(
            provenanceRepository,
          ),
        );

      const task =
        createCefrA1ConnectGreetingComprehensionTask(
          "de",
        );

      const result =
        service.submit({
          languageCode: "de",
          submittedAnswer:
            task.correctAnswer,
          eventId:
            "compat-coordinator",
          occurredAt:
            new Date(
              "2026-08-11T19:31:00.000Z",
            ),
          userActionConfirmed: true,
        });

      expect(result.evidencePersisted).toBe(
        true,
      );

      expect(
        provenanceRepository
          .findByEvidenceId(
            result.evidence?.runtimeEvidenceId ??
              "",
          )
          ?.languageCode,
      ).toBe("de");
    });
  },
);
