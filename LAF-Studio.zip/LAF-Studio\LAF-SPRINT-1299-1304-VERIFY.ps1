﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app  = Join-Path $root "app"

$service = Join-Path $app "src\application\learning\CefrA1ConnectRuntimeEvidenceService.ts"
$contract = Join-Path $app "src\application\learning\CefrA1ConnectRuntimeExperienceContract.ts"
$readModel = Join-Path $app "src\application\learning\CefrA1ConnectRuntimeReadModel.ts"
$safety = Join-Path $app "src\core\learning\CefrA1ConnectRuntimeBindingSafety.ts"

foreach ($file in @($service, $contract, $readModel, $safety)) {
    if (-not (Test-Path $file)) {
        throw "Sprint 1299-1304 source missing: $file"
    }
}

$requiredMarkers = @{
    $service = @(
        'recordLearningStudioEvidence({',
        'learningItemType: "lesson"',
        'createLafCefrAuthoritativeCurriculumRegistry()',
        'createLafCefrCapabilityTaxonomyRegistry()',
        'createLafCefrCompetencyCapabilityMappingRegistry()'
    )
    $contract = @(
        'automaticPracticeEvidenceCapture: false',
        'automaticInteractionEvidenceCapture: false',
        'automaticActivationEvidenceCapture: false'
    )
    $readModel = @(
        'existingLearningRoute: "/learning"',
        'routeCreationRequired: false'
    )
    $safety = @(
        'newRouteInvented: false',
        'capabilityReference:',
        '"social-exchange"',
        'masteryAssignmentAllowed: false',
        'automaticProgressionAllowed: false'
    )
}

foreach ($entry in $requiredMarkers.GetEnumerator()) {
    foreach ($marker in $entry.Value) {
        if (-not (
            Select-String -Path $entry.Key -SimpleMatch `
                -Pattern $marker -Quiet
        )) {
            throw "Required Sprint 1299-1304 marker missing: $marker"
        }
    }
}

Write-Host "SPRINT-1299-1304 SOURCE CHECK PASSED"

Set-Location $app

$targets = @(
    "src/application/learning/CefrA1ConnectRuntimeEvidenceService.test.ts",
    "src/application/learning/CefrA1ConnectRuntimeExperienceContract.test.ts",
    "src/application/learning/CefrA1ConnectRuntimeReadModel.test.ts",
    "src/core/learning/CefrA1ConnectRuntimeBindingSafety.test.ts",
    "src/core/learning/CefrAuthoritativeCurriculumCatalog.test.ts",
    "src/core/learning/CefrAuthoritativeCurriculumRegistry.test.ts",
    "src/core/learning/CefrA1ConnectEvidenceDefinition.test.ts",
    "src/core/learning/CefrA1ConnectAuthoritativeCurriculumIntegration.test.ts",
    "src/core/learning/CefrCurriculumCapabilityObservationWrite.test.ts",
    "src/application/learning/CefrCurriculumCapabilityObservationWriter.test.ts"
)

& npx vitest run $targets
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1299-1304 target tests failed."
}

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Full regression failed."
}

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Production build failed."
}

Write-Host "SPRINT-1299-1304 VERIFICATION COMPLETE"
