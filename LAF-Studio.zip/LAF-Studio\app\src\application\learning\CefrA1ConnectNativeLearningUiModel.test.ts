import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrA1ConnectNativeLearningUiModel,
} from "./CefrA1ConnectNativeLearningUiModel";

describe(
  "CefrA1ConnectNativeLearningUiModel",
  () => {
    it("projects the approved authoritative A1 CONNECT unit into a native Learning Studio UI model", () => {
      const model =
        createCefrA1ConnectNativeLearningUiModel();

      expect(model).toMatchObject({
        eyebrow: "A1 · RESPOND · CONNECT",
        title: "First Social Encounter",
        competencyLabel:
          "connect-a1 · Basic Social Response",
        unitId:
          "a1-connect-first-social-encounter",
        meaningfulInteractionCount: 3,
        evidenceDefinitionCount: 7,
        realLifeActivationAvailable: true,
      });

      expect(model.lessonCards).toHaveLength(4);
      expect(
        model.lessonCards.map(
          lesson => lesson.lessonId,
        ),
      ).toEqual([
        "a1-connect-greeting-response",
        "a1-connect-self-introduction",
        "a1-connect-personal-questions",
        "a1-connect-complete-social-exchange",
      ]);

      expect(
        model.lessonCards.map(
          lesson => lesson.practiceStepCount,
        ),
      ).toEqual([5, 5, 5, 5]);

      expect(
        model.lessonCards.map(
          lesson =>
            lesson.evidenceOpportunityCount,
        ),
      ).toEqual([2, 1, 2, 2]);
    });

    it("keeps evidence capture closed until a real target-language realization is bound", () => {
      expect(
        createCefrA1ConnectNativeLearningUiModel(),
      ).toMatchObject({
        languageRealizationBound: false,
        evidenceCaptureEnabled: false,
        evidenceCaptureStatus:
          "language-realization-required",
        existingLearningQueuePreserved: true,
        userActionRequired: true,
        readOnlyCurriculumPreview: true,
      });
    });
  },
);
