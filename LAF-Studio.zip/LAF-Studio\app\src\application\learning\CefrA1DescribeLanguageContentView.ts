import type {
  LafLearningLanguageCode,
} from "../../core/language/LafLanguageProfile";
import {
  getLafA1DescribeLanguageContentPack,
  type CefrA1DescribeRealizedPhrase,
} from "../../core/learning/CefrA1DescribeLanguageContentRegistry";

export interface CefrA1DescribeLanguageContentView {
  readonly languageCode:
    LafLearningLanguageCode;
  readonly lessonId: string;
  readonly phrases:
    readonly CefrA1DescribeRealizedPhrase[];
  readonly languageContentAvailable: true;
  readonly assistantAuthoredV1: true;
  readonly nativeReviewValidated: false;
  readonly descriptionProductionOnly: true;
  readonly narrativeSequencingIntroduced:
    false;
  readonly executableTaskAvailable: false;
  readonly evidenceCaptureAvailable: false;
  readonly delayedRetrievalRuntimeAvailable:
    false;
}

export function createCefrA1DescribeLanguageContentView(
  languageCode: LafLearningLanguageCode,
  lessonId: string,
): CefrA1DescribeLanguageContentView {
  const pack =
    getLafA1DescribeLanguageContentPack(
      languageCode,
    );

  const lesson =
    pack.lessons.find(
      item => item.lessonId === lessonId,
    );

  if (!lesson) {
    throw new Error(
      `A1 DESCRIBE realized lesson not found: ${lessonId}`,
    );
  }

  return {
    languageCode,
    lessonId,
    phrases: lesson.phrases,
    languageContentAvailable: true,
    assistantAuthoredV1: true,
    nativeReviewValidated: false,
    descriptionProductionOnly: true,
    narrativeSequencingIntroduced:
      false,
    executableTaskAvailable: false,
    evidenceCaptureAvailable: false,
    delayedRetrievalRuntimeAvailable:
      false,
  };
}
