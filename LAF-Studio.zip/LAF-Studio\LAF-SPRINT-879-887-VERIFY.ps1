$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 879-881 Target Tests: Custodial Completion ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialCompletion.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialCompletionCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialCompletionAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 879-881 target tests failed." }

Write-Host "=== Sprint 882-884 Target Tests: Custodial Readiness ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialReadiness.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialReadinessCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialReadinessAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 882-884 target tests failed." }

Write-Host "=== Sprint 885-887 Target Tests: Custodial Activation ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialActivation.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialActivationCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialActivationAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 885-887 target tests failed." }

Write-Host "=== Combined Sprint 879-887 New Tests ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialCompletion.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialCompletionCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialCompletionAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialReadiness.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialReadinessCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialReadinessAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialActivation.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialActivationCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialActivationAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 879-887 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-879-887 VERIFICATION COMPLETE"
