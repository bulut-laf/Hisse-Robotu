﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app  = Join-Path $root "app"

$catalog = Join-Path $app "src\core\learning\CefrAuthoritativeCurriculumCatalog.ts"
$registry = Join-Path $app "src\core\learning\CefrAuthoritativeCurriculumRegistry.ts"

if (-not (Test-Path $catalog)) {
    throw "Authoritative curriculum catalog source missing."
}

if (-not (Test-Path $registry)) {
    throw "Authoritative curriculum registry source missing."
}

$requiredCatalogMarkers = @(
    'id: "a1-connect-first-social-encounter"',
    'id: "a1-connect-greeting-response"',
    'id: "a1-connect-self-introduction"',
    'id: "a1-connect-personal-questions"',
    'id: "a1-connect-complete-social-exchange"'
)

foreach ($marker in $requiredCatalogMarkers) {
    if (-not (
        Select-String -Path $catalog -SimpleMatch `
            -Pattern $marker -Quiet
    )) {
        throw "Required A1 CONNECT catalog marker missing: $marker"
    }
}

$requiredRegistryMarkers = @(
    'learningItemId:',
    '"a1-connect-greeting-response"',
    '"a1-connect-self-introduction"',
    '"a1-connect-personal-questions"',
    '"a1-connect-complete-social-exchange"',
    '"curriculum-map-a1-connect-v1"'
)

foreach ($marker in $requiredRegistryMarkers) {
    if (-not (
        Select-String -Path $registry -SimpleMatch `
            -Pattern $marker -Quiet
    )) {
        throw "Required A1 CONNECT registry marker missing: $marker"
    }
}

$forbiddenLegacyMarkers = @(
    'learningItemId: "lesson-1"',
    'learningItemId: "lesson-2"',
    'learningItemId: "lesson-3"'
)

foreach ($marker in $forbiddenLegacyMarkers) {
    if (
        Select-String -Path $registry -SimpleMatch `
            -Pattern $marker -Quiet
    ) {
        throw "Legacy lesson leaked into authoritative curriculum registry: $marker"
    }
}

Write-Host "SPRINT-1287-1292 SOURCE CHECK PASSED"

Set-Location $app

$targets = @(
    "src/core/learning/CefrAuthoritativeCurriculumCatalog.test.ts",
    "src/core/learning/CefrAuthoritativeCurriculumRegistry.test.ts",
    "src/core/learning/CefrA1ConnectAuthoritativeCurriculumIntegration.test.ts",
    "src/core/learning/CefrA1ConnectAuthoritativeCurriculumSafety.test.ts",
    "src/core/learning/CefrCurriculumCompetencyMapping.test.ts",
    "src/core/learning/CefrCurriculumCompetencyRegistry.test.ts",
    "src/core/learning/CefrCurriculumCapabilityObservationEligibility.test.ts",
    "src/core/learning/CefrAuthoritativeCapabilityRegistry.test.ts",
    "src/core/learning/CefrCurriculumCapabilityObservationWrite.test.ts"
)

& npx vitest run $targets
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1287-1292 target tests failed."
}

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Full regression failed."
}

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Production build failed."
}

Write-Host "SPRINT-1287-1292 VERIFICATION COMPLETE"
