$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 1125-1127 Target Tests: Operational Guidance State ==="
npx vitest run `
  "src/core/learning/CefrGuidanceOperationalSnapshot.test.ts" `
  "src/core/learning/CefrGuidanceOperationalStatus.test.ts" `
  "src/core/learning/CefrGuidanceOperationalSafetyBoundary.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1125-1127 target tests failed." }

Write-Host "=== Sprint 1128-1130 Target Tests: Application Projection ==="
npx vitest run `
  "src/core/learning/CefrApplicationGuidanceItem.test.ts" `
  "src/core/learning/CefrApplicationGuidanceProjection.test.ts" `
  "src/core/learning/CefrApplicationGuidanceGateway.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1128-1130 target tests failed." }

Write-Host "=== Sprint 1131-1133 Target Tests: Integrated Guidance Platform ==="
npx vitest run `
  "src/core/learning/CefrIntegratedGuidancePlatformState.test.ts" `
  "src/core/learning/CefrIntegratedGuidanceUserActionBoundary.test.ts" `
  "src/core/learning/CefrIntegratedGuidancePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1131-1133 target tests failed." }

Write-Host "=== Combined Sprint 1125-1133 New Tests ==="
npx vitest run `
  "src/core/learning/CefrGuidanceOperationalSnapshot.test.ts" `
  "src/core/learning/CefrGuidanceOperationalStatus.test.ts" `
  "src/core/learning/CefrGuidanceOperationalSafetyBoundary.test.ts" `
  "src/core/learning/CefrApplicationGuidanceItem.test.ts" `
  "src/core/learning/CefrApplicationGuidanceProjection.test.ts" `
  "src/core/learning/CefrApplicationGuidanceGateway.test.ts" `
  "src/core/learning/CefrIntegratedGuidancePlatformState.test.ts" `
  "src/core/learning/CefrIntegratedGuidanceUserActionBoundary.test.ts" `
  "src/core/learning/CefrIntegratedGuidancePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1125-1133 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-1125-1133 VERIFICATION COMPLETE"
