import {describe,expect,it} from "vitest";
import {createCefrPersonalLanguageProfileState,type CefrPersonalLanguageProfileState}
 from "../../core/learning/CefrPersonalLanguageProfileState";
import type {CefrLanguageEvidenceStorageLike}
 from "./CefrAuthoritativeLanguageEvidenceProvenanceRepository";
import type {CefrGuidanceRuntimeProfileRepository}
 from "./CefrGuidanceRuntimeProfileRepository";
import {CefrProductionRuntimePlatform} from "./CefrProductionRuntimePlatform";

class R implements CefrGuidanceRuntimeProfileRepository {
 private s:CefrPersonalLanguageProfileState=createCefrPersonalLanguageProfileState([],[]);
 load(){return this.s} save(s:CefrPersonalLanguageProfileState){this.s=s}
 hasPersistedProfile(){return false} clear(){}
}
class S implements CefrLanguageEvidenceStorageLike {
 private m=new Map<string,string>();
 getItem(k:string){return this.m.get(k)??null}
 setItem(k:string,v:string){this.m.set(k,v)}
 removeItem(k:string){this.m.delete(k)}
}

describe("C2 EXCHANGE IDEAS production runtime",()=>{
 it("resolves authoritative capability mapping observationally",()=>{
  const p=new CefrProductionRuntimePlatform(new R(),new S());
  const result=p.recordUserEvidence("c2-exchange-ideas",{
   evidenceDefinitionId:"c2-exchange-ideas-evidence-discourse-direction-conclusion",
   eventId:"c2-exchange-ideas-runtime-001",occurredAt:new Date("2026-08-16T02:50:00.000Z"),
   languageCode:"hu",userActionConfirmed:true
  });
  expect(result).toMatchObject({
   evidencePersisted:true,masteryAssigned:false,competencySuccessAssigned:false,
   cefrLevelAssigned:false,progressionPerformed:false
  });
  expect(result.runtime.resolvedCapabilityReferences).toEqual([
   "argumentation","persuasion-rhetorical-control","pragmatic-effect-control"
  ]);
 });
 it("rejects delayed retrieval until separate policy exists",()=>{
  const p=new CefrProductionRuntimePlatform(new R(),new S());
  expect(()=>p.recordUserEvidence("c2-exchange-ideas",{
   evidenceDefinitionId:"c2-exchange-ideas-evidence-delayed-retrieval",
   eventId:"c2-exchange-ideas-delayed",occurredAt:new Date("2026-08-16T02:55:00.000Z"),
   languageCode:"hu",userActionConfirmed:true
  })).toThrow("Unknown authoritative CEFR evidence definition");
 });
});
