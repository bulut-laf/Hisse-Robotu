import type { TranslationActivity } from "../core/activity";

import type {
  SessionActivityResult,
  SessionAnswer,
  SessionResult,
} from "../core/session";

import { LearningSessionController } from "../core/session";

export class LearningApplicationService {
  private readonly controller: LearningSessionController;

  constructor(controller: LearningSessionController) {
    this.controller = controller;
  }

  startSession(): SessionResult {
    return this.controller.start();
  }

  restartSession(): SessionResult {
    return this.controller.restart();
  }

  submitAnswer(
    answer: SessionAnswer,
  ): SessionActivityResult {
    return this.controller.submitAnswer(answer);
  }

  nextActivity(): SessionResult {
    return this.controller.next();
  }

  previousActivity(): SessionResult {
    return this.controller.previous();
  }

  retryCurrentActivity(): SessionResult {
    return this.controller.retryCurrentActivity();
  }

  revealCurrentHint(): SessionResult {
    return this.controller.revealCurrentHint();
  }

  getCurrentActivity():
    | TranslationActivity
    | undefined {
    return this.controller.getCurrentActivity();
  }
}
