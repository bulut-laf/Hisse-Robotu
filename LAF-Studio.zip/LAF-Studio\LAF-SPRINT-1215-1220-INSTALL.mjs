import fs from "node:fs";
import path from "node:path";

const root = "D:\\Projects\\LAF-Studio";

const hookFile = path.join(
  root,
  "app",
  "src",
  "ui",
  "hooks",
  "useLearningSession.ts",
);

const lessonFile = path.join(
  root,
  "app",
  "src",
  "ui",
  "pages",
  "LessonPage.tsx",
);

function read(file) {
  if (!fs.existsSync(file)) {
    throw new Error(`Required file not found: ${file}`);
  }
  return fs.readFileSync(file, "utf8");
}

function write(file, source) {
  fs.writeFileSync(file, source, "utf8");
}

function patchHook() {
  let source = read(hookFile);
  const eol = source.includes("\r\n") ? "\r\n" : "\n";

  const interfaceMarker =
    "  isCompleted: boolean;" +
    eol +
    "  currentActivityNumber: number;";

  const interfaceReplacement =
    "  isCompleted: boolean;" +
    eol +
    "  sessionId: string;" +
    eol +
    "  completedAt: Date | undefined;" +
    eol +
    "  currentActivityNumber: number;";

  if (!source.includes("  sessionId: string;")) {
    if (!source.includes(interfaceMarker)) {
      throw new Error(
        "useLearningSession result interface marker not found.",
      );
    }
    source = source.replace(
      interfaceMarker,
      interfaceReplacement,
    );
  }

  const returnMarker =
    "    isCompleted: sessionResult.isCompleted," +
    eol +
    "    currentActivityNumber:";

  const returnReplacement =
    "    isCompleted: sessionResult.isCompleted," +
    eol +
    "    sessionId: sessionResult.session.id," +
    eol +
    "    completedAt: sessionResult.session.completedAt," +
    eol +
    "    currentActivityNumber:";

  if (
    !source.includes(
      "    sessionId: sessionResult.session.id,",
    )
  ) {
    if (!source.includes(returnMarker)) {
      throw new Error(
        "useLearningSession return marker not found.",
      );
    }
    source = source.replace(
      returnMarker,
      returnReplacement,
    );
  }

  const sessionInterfaceCount =
    source.split("  sessionId: string;").length - 1;
  const sessionReturnCount =
    source.split(
      "    sessionId: sessionResult.session.id,",
    ).length - 1;

  if (
    sessionInterfaceCount !== 1 ||
    sessionReturnCount !== 1
  ) {
    throw new Error(
      `Unexpected useLearningSession binding counts: interface=${sessionInterfaceCount}, return=${sessionReturnCount}`,
    );
  }

  write(hookFile, source);
}

function patchLessonPage() {
  let source = read(lessonFile);
  const eol = source.includes("\r\n") ? "\r\n" : "\n";

  const storageImport =
    'import {' +
    eol +
    '  createLearningSessionStorageKey,' +
    eol +
    '  LocalStorageSessionStorage,' +
    eol +
    '} from "../storage/LocalStorageSessionStorage";';

  const runtimeImports =
    'import { CefrGuidanceRuntimeProfileService } from "../../application/learning/CefrGuidanceRuntimeProfileService";' +
    eol +
    'import { LocalStorageCefrGuidanceProfileRepository } from "../storage/LocalStorageCefrGuidanceProfileRepository";';

  if (
    !source.includes(
      "CefrGuidanceRuntimeProfileService",
    )
  ) {
    if (!source.includes(storageImport)) {
      throw new Error(
        "LessonPage storage import marker not found.",
      );
    }

    source = source.replace(
      storageImport,
      storageImport + eol + runtimeImports,
    );
  }

  const destructureMarker =
    "    isCompleted," +
    eol +
    "    currentActivityNumber,";

  const destructureReplacement =
    "    isCompleted," +
    eol +
    "    sessionId," +
    eol +
    "    completedAt," +
    eol +
    "    currentActivityNumber,";

  if (!source.includes("    sessionId,")) {
    if (!source.includes(destructureMarker)) {
      throw new Error(
        "LessonPage learning-session destructure marker not found.",
      );
    }

    source = source.replace(
      destructureMarker,
      destructureReplacement,
    );
  }

  const recorderMarker =
    "  const audioRecorderService = useMemo(";

  const serviceBlock =
    "  const cefrRuntimeProfileService = useMemo(" +
    eol +
    "    () =>" +
    eol +
    "      new CefrGuidanceRuntimeProfileService(" +
    eol +
    "        new LocalStorageCefrGuidanceProfileRepository()," +
    eol +
    "      )," +
    eol +
    "    []," +
    eol +
    "  );" +
    eol +
    eol;

  if (
    !source.includes(
      "const cefrRuntimeProfileService = useMemo(",
    )
  ) {
    if (!source.includes(recorderMarker)) {
      throw new Error(
        "LessonPage audio recorder marker not found.",
      );
    }

    source = source.replace(
      recorderMarker,
      serviceBlock + recorderMarker,
    );
  }

  const normalizedMarker =
    "  const normalizedAnswer = answer.trim();";

  const persistenceEffect =
    "  useEffect(() => {" +
    eol +
    "    if (!isCompleted || !completedAt) {" +
    eol +
    "      return;" +
    eol +
    "    }" +
    eol +
    eol +
    "    cefrRuntimeProfileService.recordLearningSessionCompletion({" +
    eol +
    "      sessionId," +
    eol +
    "      completedAt," +
    eol +
    "    });" +
    eol +
    "  }, [" +
    eol +
    "    cefrRuntimeProfileService," +
    eol +
    "    completedAt," +
    eol +
    "    isCompleted," +
    eol +
    "    sessionId," +
    eol +
    "  ]);" +
    eol +
    eol;

  if (
    !source.includes(
      "recordLearningSessionCompletion({",
    )
  ) {
    if (!source.includes(normalizedMarker)) {
      throw new Error(
        "LessonPage persistence effect insertion marker not found.",
      );
    }

    source = source.replace(
      normalizedMarker,
      persistenceEffect + normalizedMarker,
    );
  }

  const importCount =
    source.split(
      'import { CefrGuidanceRuntimeProfileService }',
    ).length - 1;
  const serviceCount =
    source.split(
      "const cefrRuntimeProfileService = useMemo(",
    ).length - 1;
  const writeCount =
    source.split(
      "recordLearningSessionCompletion({",
    ).length - 1;

  if (
    importCount !== 1 ||
    serviceCount !== 1 ||
    writeCount !== 1
  ) {
    throw new Error(
      `Unexpected LessonPage feedback binding counts: import=${importCount}, service=${serviceCount}, write=${writeCount}`,
    );
  }

  write(lessonFile, source);
}

patchHook();
patchLessonPage();

console.log("SPRINT-1215-1220 INSTALL COMPLETE");
console.log(
  "Real lesson completion evidence write binding installed.",
);
