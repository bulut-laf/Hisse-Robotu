﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$pagePath =
    Join-Path $app "src\ui\pages\LearningStudioPage.tsx"

$utf8 = New-Object System.Text.UTF8Encoding($false)

function Read-Utf8([string]$path) {
    return [System.IO.File]::ReadAllText($path, $utf8)
}

function Write-Utf8(
    [string]$path,
    [string]$text
) {
    [System.IO.File]::WriteAllText($path, $text, $utf8)
}

$required = @(
    "src\application\learning\CefrA1NavigateNativeLearningUiModel.ts",
    "src\application\learning\CefrA1NavigateNativeLearningUiModel.test.ts",
    "src\core\learning\CefrA1NavigateNativeLearningUiSafety.ts",
    "src\core\learning\CefrA1NavigateNativeLearningUiSafety.test.ts",
    "src\ui\learning\A1NavigateNativeLearningPanel.tsx",
    "src\ui\learning\A1NavigateNativeLearningPanel.css"
)

foreach ($relative in $required) {
    if (-not (Test-Path (Join-Path $app $relative))) {
        throw "Sprint 1467-1472 required file missing: $relative"
    }
}

if (-not (Test-Path $pagePath)) {
    throw "LearningStudioPage.tsx missing."
}

$page = Read-Utf8 $pagePath

# ------------------------------------------------------------
# Native /learning seam patch — preserve existing CONNECT panel.
# ------------------------------------------------------------
$navigateImport =
    'import { A1NavigateNativeLearningPanel } from "../learning/A1NavigateNativeLearningPanel";'

if (-not $page.Contains($navigateImport)) {
    $connectImportPattern =
        '(?ms)import\s*\{\s*A1ConnectNativeLearningPanel\s*,?\s*\}\s*from\s*["'']\.\./learning/A1ConnectNativeLearningPanel["''];'

    $connectImportMatches =
        [regex]::Matches(
            $page,
            $connectImportPattern
        )

    if ($connectImportMatches.Count -ne 1) {
        throw "Expected exactly one A1 CONNECT native panel import seam; found $($connectImportMatches.Count)."
    }

    $connectImport =
        $connectImportMatches[0].Value

    $page =
        $page.Replace(
            $connectImport,
            $connectImport + "`r`n" + $navigateImport
        )
}

if (-not $page.Contains(
    "<A1NavigateNativeLearningPanel />"
)) {
    $connectRenderPattern =
        '<A1ConnectNativeLearningPanel\s*/>'

    $renderMatches =
        [regex]::Matches(
            $page,
            $connectRenderPattern
        )

    if ($renderMatches.Count -ne 1) {
        throw "Expected exactly one A1 CONNECT native panel render seam; found $($renderMatches.Count)."
    }

    $connectRender =
        $renderMatches[0].Value

    $page =
        [regex]::Replace(
            $page,
            $connectRenderPattern,
            $connectRender +
              "`r`n          <A1NavigateNativeLearningPanel />",
            1
        )
}

Write-Utf8 $pagePath $page

# ------------------------------------------------------------
# Source checks after UI binding.
# ------------------------------------------------------------
$updated = Read-Utf8 $pagePath

$checks = @(
    @($pagePath, 'A1ConnectNativeLearningPanel'),
    @($pagePath, 'A1NavigateNativeLearningPanel'),
    @(
      (Join-Path $app "src\ui\learning\A1NavigateNativeLearningPanel.tsx"),
      'new CefrProductionRuntimePlatform('
    ),
    @(
      (Join-Path $app "src\ui\learning\A1NavigateNativeLearningPanel.tsx"),
      'userActionConfirmed: true'
    ),
    @(
      (Join-Path $app "src\ui\learning\A1NavigateNativeLearningPanel.tsx"),
      'Delayed Retrieval: kapalı'
    ),
    @(
      (Join-Path $app "src\core\learning\CefrA1NavigateNativeLearningUiSafety.ts"),
      'incorrectAnswerCreatesEvidence:'
    )
)

foreach ($check in $checks) {
    if (-not (
        Select-String `
            -Path $check[0] `
            -SimpleMatch `
            -Pattern $check[1] `
            -Quiet
    )) {
        throw "Sprint 1467-1472 source marker missing: $($check[1])"
    }
}

$navigateImportCount =
    [regex]::Matches(
        $updated,
        [regex]::Escape(
            "A1NavigateNativeLearningPanel"
        )
    ).Count

if ($navigateImportCount -lt 2) {
    throw "NAVIGATE native panel is not both imported and rendered."
}

Write-Host ""
Write-Host "SPRINT-1467-1469 SOURCE CHECK PASSED"

Set-Location $app

Write-Host ""
Write-Host "CHECKPOINT 1/2 — Native UI model + runtime boundary target tests"

& npx vitest run @(
    "src/application/learning/CefrA1NavigateNativeLearningUiModel.test.ts",
    "src/core/learning/CefrA1NavigateNativeLearningUiSafety.test.ts",
    "src/core/learning/CefrA1NavigateExecutableTaskDefinition.test.ts",
    "src/application/learning/CefrA1NavigateExecutableTaskService.test.ts",
    "src/application/learning/CefrA1NavigateTargetLanguageSelectionModel.test.ts"
)

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1467-1469 target checkpoint failed."
}

Write-Host "SPRINT-1467-1469 TARGET CHECKPOINT PASSED"

Write-Host ""
Write-Host "CHECKPOINT 2/2 — Production runtime + delayed-retrieval safety target tests"

& npx vitest run @(
    "src/core/learning/CefrA1NavigateRuntimeSliceDefinition.test.ts",
    "src/application/learning/CefrA1NavigateProductionRuntime.test.ts",
    "src/core/learning/CefrProductionRuntimeRegistryEnforcement.test.ts",
    "src/core/learning/CefrProductionRuntimeEvidenceEligibilityAudit.test.ts",
    "src/application/learning/CefrProductionRuntimeDelayedRetrievalVisibility.test.ts"
)

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1470-1472 target checkpoint failed."
}

Write-Host "SPRINT-1470-1472 TARGET CHECKPOINT PASSED"

Write-Host ""
Write-Host "FINAL 6-SPRINT BLOCK REGRESSION — one full run only"

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1467-1472 final full regression failed."
}

Write-Host ""
Write-Host "FINAL PRODUCTION BUILD"

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1467-1472 production build failed."
}

Write-Host ""
Write-Host "SPRINT-1467-1472 VERIFICATION COMPLETE"
