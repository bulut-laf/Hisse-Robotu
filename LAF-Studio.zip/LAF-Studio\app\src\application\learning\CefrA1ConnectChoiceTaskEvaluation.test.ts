import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrA1ConnectGreetingResponseTask,
} from "../../core/learning/CefrA1ConnectAdditionalExecutableTasks";
import {
  evaluateCefrA1ConnectChoiceTask,
} from "./CefrA1ConnectChoiceTaskEvaluation";

describe(
  "CefrA1ConnectChoiceTaskEvaluation",
  () => {
    it("opens evidence eligibility only for the correct submitted answer", () => {
      const task =
        createCefrA1ConnectGreetingResponseTask(
          "en",
        );

      expect(
        evaluateCefrA1ConnectChoiceTask(
          task,
          task.correctAnswer,
        ).evidenceEligible,
      ).toBe(true);

      expect(
        evaluateCefrA1ConnectChoiceTask(
          task,
          "not-correct",
        ).evidenceEligible,
      ).toBe(false);
    });
  },
);
