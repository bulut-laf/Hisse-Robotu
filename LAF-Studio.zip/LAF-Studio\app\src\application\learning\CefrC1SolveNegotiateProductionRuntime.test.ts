import {describe,expect,it} from "vitest";
import {
 createCefrPersonalLanguageProfileState,
 type CefrPersonalLanguageProfileState
} from "../../core/learning/CefrPersonalLanguageProfileState";
import type {CefrLanguageEvidenceStorageLike} from "./CefrAuthoritativeLanguageEvidenceProvenanceRepository";
import type {CefrGuidanceRuntimeProfileRepository} from "./CefrGuidanceRuntimeProfileRepository";
import {CefrProductionRuntimePlatform} from "./CefrProductionRuntimePlatform";

class R implements CefrGuidanceRuntimeProfileRepository {
 private s:CefrPersonalLanguageProfileState=createCefrPersonalLanguageProfileState([],[]);
 load(){return this.s}
 save(s:CefrPersonalLanguageProfileState){this.s=s}
 hasPersistedProfile(){return false}
 clear(){}
}
class S implements CefrLanguageEvidenceStorageLike {
 private m=new Map<string,string>();
 getItem(k:string){return this.m.get(k)??null}
 setItem(k:string,v:string){this.m.set(k,v)}
 removeItem(k:string){this.m.delete(k)}
}

describe("C1 SOLVE & NEGOTIATE production runtime",()=>{
 it("resolves discovered authoritative capability mapping observationally",()=>{
  const r=new R();
  const p=new CefrProductionRuntimePlatform(r,new S());
  const result=p.recordUserEvidence(
   "c1-solve-negotiate",
   {
    evidenceDefinitionId:"c1-solve-negotiate-evidence-outcome-confirmation-closure",
    eventId:"c1-solve-negotiate-runtime-001",
    occurredAt:new Date("2026-08-16T00:55:00.000Z"),
    languageCode:"hu",
    userActionConfirmed:true
   }
  );
  expect(result).toMatchObject({
   evidencePersisted:true,
   masteryAssigned:false,
   competencySuccessAssigned:false,
   cefrLevelAssigned:false,
   progressionPerformed:false
  });
  expect(result.runtime.resolvedCapabilityReferences).toEqual([
   "solution-negotiation",
   "audience-purpose-adaptation",
   "sensitive-diplomatic-management"
  ]);
  expect(
   r.load().capabilityObservationRegistry.observations
    .map(x=>x.capabilityReference)
  ).toEqual([
   "solution-negotiation",
   "audience-purpose-adaptation",
   "sensitive-diplomatic-management"
  ]);
 });
 it("rejects delayed retrieval until separate policy exists",()=>{
  const p=new CefrProductionRuntimePlatform(new R(),new S());
  expect(()=>p.recordUserEvidence(
   "c1-solve-negotiate",
   {
    evidenceDefinitionId:"c1-solve-negotiate-evidence-delayed-retrieval",
    eventId:"c1-solve-negotiate-delayed",
    occurredAt:new Date("2026-08-16T01:00:00.000Z"),
    languageCode:"hu",
    userActionConfirmed:true
   }
  )).toThrow("Unknown authoritative CEFR evidence definition");
 });
});
