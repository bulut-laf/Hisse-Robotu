import type {
  CefrA1ConnectChoiceTask,
} from "../../core/learning/CefrA1ConnectAdditionalExecutableTasks";

export interface CefrA1ConnectChoiceTaskEvaluation {
  readonly submitted: true;
  readonly correct: boolean;
  readonly evidenceEligible: boolean;
  readonly masteryAssigned: false;
  readonly competencySuccessAssigned: false;
  readonly cefrLevelAssigned: false;
  readonly progressionPerformed: false;
}

export function evaluateCefrA1ConnectChoiceTask(
  task: CefrA1ConnectChoiceTask,
  submittedAnswer: string,
): CefrA1ConnectChoiceTaskEvaluation {
  const correct =
    submittedAnswer === task.correctAnswer;

  return {
    submitted: true,
    correct,
    evidenceEligible: correct,
    masteryAssigned: false,
    competencySuccessAssigned: false,
    cefrLevelAssigned: false,
    progressionPerformed: false,
  };
}
