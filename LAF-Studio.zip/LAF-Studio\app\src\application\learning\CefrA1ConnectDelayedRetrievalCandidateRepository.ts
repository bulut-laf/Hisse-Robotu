import type {
  LafLearningLanguageCode,
} from "../../core/language/LafLanguageProfile";
import type {
  CefrA1ConnectDelayedRetrievalCandidate,
} from "../../core/learning/CefrA1ConnectDelayedRetrievalCandidate";

interface StorageLike {
  getItem(key: string): string | null;
  setItem(
    key: string,
    value: string,
  ): void;
  removeItem(key: string): void;
}

interface StoredCandidateEnvelope {
  readonly version: 1;
  readonly candidates:
    readonly CefrA1ConnectDelayedRetrievalCandidate[];
}

export const A1_CONNECT_DELAYED_RETRIEVAL_STORAGE_KEY =
  "laf.cefr.a1-connect.delayed-retrieval.v1";

function isCandidate(
  value: unknown,
): value is CefrA1ConnectDelayedRetrievalCandidate {
  if (
    typeof value !== "object" ||
    value === null
  ) {
    return false;
  }

  const candidate =
    value as Partial<CefrA1ConnectDelayedRetrievalCandidate>;

  return (
    typeof candidate.candidateId ===
      "string" &&
    typeof candidate.languageCode ===
      "string" &&
    candidate.sourceLearningItemId ===
      "a1-connect-complete-social-exchange" &&
    candidate.sourceEvidenceDefinitionId ===
      "a1-connect-evidence-reciprocal-exchange" &&
    typeof candidate.sourceEvidenceId ===
      "string" &&
    typeof candidate.sourceObservedAt ===
      "string" &&
    typeof candidate.queuedAt ===
      "string" &&
    candidate.status ===
      "waiting-for-approved-delay-policy" &&
    candidate.delayedRetrievalEvidenceWritten ===
      false &&
    candidate.masteryClaimed === false
  );
}

export class CefrA1ConnectDelayedRetrievalCandidateRepository {
  private readonly storage:
    StorageLike | null;

  constructor(
    storage:
      StorageLike | null =
        typeof window !== "undefined"
          ? window.localStorage
          : null,
  ) {
    this.storage = storage;
  }

  loadAll():
    readonly CefrA1ConnectDelayedRetrievalCandidate[] {
    if (!this.storage) {
      return [];
    }

    const raw =
      this.storage.getItem(
        A1_CONNECT_DELAYED_RETRIEVAL_STORAGE_KEY,
      );

    if (!raw) {
      return [];
    }

    try {
      const parsed =
        JSON.parse(
          raw,
        ) as Partial<StoredCandidateEnvelope>;

      if (
        parsed.version !== 1 ||
        !Array.isArray(parsed.candidates)
      ) {
        return [];
      }

      return parsed.candidates.filter(
        isCandidate,
      );
    }
    catch {
      return [];
    }
  }

  save(
    candidate:
      CefrA1ConnectDelayedRetrievalCandidate,
  ):
    readonly CefrA1ConnectDelayedRetrievalCandidate[] {
    if (!this.storage) {
      return [candidate];
    }

    const existing =
      this.loadAll().filter(
        item =>
          item.candidateId !==
          candidate.candidateId,
      );

    const next = [
      ...existing,
      candidate,
    ];

    const envelope:
      StoredCandidateEnvelope = {
        version: 1,
        candidates: next,
      };

    this.storage.setItem(
      A1_CONNECT_DELAYED_RETRIEVAL_STORAGE_KEY,
      JSON.stringify(envelope),
    );

    return next;
  }

  findLatestForLanguage(
    languageCode: LafLearningLanguageCode,
  ):
    CefrA1ConnectDelayedRetrievalCandidate | null {
    const matches =
      this.loadAll().filter(
        item =>
          item.languageCode ===
          languageCode,
      );

    return matches.at(-1) ?? null;
  }

  clear(): void {
    this.storage?.removeItem(
      A1_CONNECT_DELAYED_RETRIEVAL_STORAGE_KEY,
    );
  }
}
