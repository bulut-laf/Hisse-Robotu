$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 924-926 Target Tests: Custodial Resilience ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialResilience.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialResilienceCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialResilienceAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 924-926 target tests failed." }

Write-Host "=== Sprint 927-929 Target Tests: Custodial Recoverability ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialRecoverability.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialRecoverabilityCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialRecoverabilityAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 927-929 target tests failed." }

Write-Host "=== Sprint 930-932 Target Tests: Custodial Restoration ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialRestoration.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialRestorationCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialRestorationAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 930-932 target tests failed." }

Write-Host "=== Combined Sprint 924-932 New Tests ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialResilience.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialResilienceCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialResilienceAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialRecoverability.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialRecoverabilityCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialRecoverabilityAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialRestoration.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialRestorationCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialRestorationAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 924-932 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-924-932 VERIFICATION COMPLETE"
