import { describe, expect, it } from "vitest";
import { createCefrEmbeddedStudioCompletionBindingSafety } from "./CefrEmbeddedStudioCompletionBindingSafety";

describe("CefrEmbeddedStudioCompletionBindingSafety", () => {
  it("binds only verified user completion handlers and leaves writing pending", () => {
    expect(
      createCefrEmbeddedStudioCompletionBindingSafety(),
    ).toEqual({
      readingCompletionSignal:
        "finish-reading-mode",
      speakingCompletionSignal:
        "complete-speaking-session",
      dialogueCompletionSignal:
        "complete-dialogue-session",
      completionIsUserAuthorized: true,
      capabilityObservationFabricationAllowed: false,
      automaticMasteryMutationAllowed: false,
      automaticCefrLevelMutationAllowed: false,
      automaticProgressionAllowed: false,
      writingCompletionBindingPending: true,
    });
  });
});
