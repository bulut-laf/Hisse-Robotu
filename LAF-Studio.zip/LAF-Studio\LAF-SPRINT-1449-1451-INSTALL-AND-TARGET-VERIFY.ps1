﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$core = Join-Path $app "src\core\learning"

$utf8 = New-Object System.Text.UTF8Encoding($false)

function Read-Utf8([string]$path) {
    return [System.IO.File]::ReadAllText($path, $utf8)
}

function Write-Utf8(
    [string]$path,
    [string]$text
) {
    [System.IO.File]::WriteAllText($path, $text, $utf8)
}

$slicePath =
    Join-Path $core "CefrA1ConnectRuntimeSliceDefinition.ts"

if (-not (Test-Path $slicePath)) {
    throw "CefrA1ConnectRuntimeSliceDefinition.ts missing."
}

$slice = Read-Utf8 $slicePath

$newFactory =
    "createLafA1ConnectExecutableRuntimeEvidenceRegistry"

if (-not $slice.Contains($newFactory)) {
    $newImport = @'
import {
  createLafA1ConnectExecutableRuntimeEvidenceRegistry,
} from "./CefrA1ConnectExecutableRuntimeEvidenceCatalog";

'@

    $slice =
        $newImport + $slice
}

$evidencePattern =
    'evidenceRegistry:\s*[A-Za-z0-9_]+\(\),'

$matches =
    [regex]::Matches(
        $slice,
        $evidencePattern
    )

if ($matches.Count -ne 1) {
    throw "Expected exactly one evidenceRegistry factory in A1 CONNECT runtime slice; found $($matches.Count)."
}

$slice =
    [regex]::Replace(
        $slice,
        $evidencePattern,
        'evidenceRegistry:' +
        [Environment]::NewLine +
        '      createLafA1ConnectExecutableRuntimeEvidenceRegistry(),',
        1
    )

Write-Utf8 $slicePath $slice

# Source fail-closed checks
$sourceChecks = @(
    @(
      (Join-Path $core "CefrA1ConnectExecutableRuntimeEvidenceCatalog.ts"),
      '"a1-connect-evidence-delayed-retrieval"'
    ),
    @(
      (Join-Path $core "CefrA1ConnectExecutableRuntimeEvidenceCatalog.ts"),
      '.filter('
    ),
    @(
      $slicePath,
      'createLafA1ConnectExecutableRuntimeEvidenceRegistry()'
    ),
    @(
      (Join-Path $core "CefrA1ConnectDelayedRetrievalRuntimeSafety.ts"),
      'genericRuntimeAdvisoryEligible:'
    )
)

foreach ($pair in $sourceChecks) {
    if (-not (
        Select-String `
            -Path $pair[0] `
            -SimpleMatch `
            -Pattern $pair[1] `
            -Quiet
    )) {
        throw "Sprint 1449-1451 source marker missing: $($pair[1])"
    }
}

Write-Host "SPRINT-1449-1451 SOURCE CHECK PASSED"

Set-Location $app

Write-Host ""
Write-Host "CHECKPOINT 1/3 — Sprint 1449-1451 target tests only"

& npx vitest run @(
    "src/core/learning/CefrA1ConnectExecutableRuntimeEvidenceCatalog.test.ts",
    "src/core/learning/CefrA1ConnectDelayedRetrievalRuntimeSafety.test.ts",
    "src/core/learning/CefrA1ConnectRuntimeSliceDefinition.test.ts",
    "src/application/learning/CefrA1ConnectDelayedRetrievalGenericRuntime.test.ts",
    "src/application/learning/CefrRuntimeAssemblyFactory.test.ts"
)

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1449-1451 target checkpoint failed."
}

Write-Host ""
Write-Host "SPRINT-1449-1451 TARGET CHECKPOINT COMPLETE"
Write-Host "No full regression/build in this 3-sprint checkpoint by design."
Write-Host "Stable production checkpoint remains Sprint 1448 until the 9-sprint block closes."
