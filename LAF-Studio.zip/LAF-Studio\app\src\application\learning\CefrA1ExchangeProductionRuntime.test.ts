import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrPersonalLanguageProfileState,
  type CefrPersonalLanguageProfileState,
} from "../../core/learning/CefrPersonalLanguageProfileState";
import type {
  CefrLanguageEvidenceStorageLike,
} from "./CefrAuthoritativeLanguageEvidenceProvenanceRepository";
import type {
  CefrGuidanceRuntimeProfileRepository,
} from "./CefrGuidanceRuntimeProfileRepository";
import {
  CefrProductionRuntimePlatform,
} from "./CefrProductionRuntimePlatform";

class MemoryProfileRepository
  implements CefrGuidanceRuntimeProfileRepository {
  private state:
    CefrPersonalLanguageProfileState =
      createCefrPersonalLanguageProfileState(
        [],
        [],
      );

  load(): CefrPersonalLanguageProfileState {
    return this.state;
  }

  save(
    state: CefrPersonalLanguageProfileState,
  ): void {
    this.state = state;
  }

  hasPersistedProfile(): boolean {
    return false;
  }

  clear(): void {}
}

class MemoryStorage
  implements CefrLanguageEvidenceStorageLike {
  private readonly items =
    new Map<string, string>();

  getItem(
    key: string,
  ): string | null {
    return this.items.get(key) ?? null;
  }

  setItem(
    key: string,
    value: string,
  ): void {
    this.items.set(key, value);
  }

  removeItem(
    key: string,
  ): void {
    this.items.delete(key);
  }
}

describe(
  "A1 EXCHANGE IDEAS production runtime",
  () => {
    it("writes approved immediate evidence and resolves preference-opinion-expression observational capability", () => {
      const repository =
        new MemoryProfileRepository();

      const platform =
        new CefrProductionRuntimePlatform(
          repository,
          new MemoryStorage(),
        );

      const result =
        platform.recordUserEvidence(
          "a1-exchange",
          {
            evidenceDefinitionId:
              "a1-exchange-evidence-preference-expression",
            eventId:
              "exchange-runtime-001",
            occurredAt:
              new Date(
                "2026-08-13T00:00:00.000Z",
              ),
            languageCode: "hu",
            userActionConfirmed: true,
          },
        );

      expect(result).toMatchObject({
        languageCode: "hu",
        evidencePersisted: true,
        targetLanguageExplicit: true,
        targetLanguageInferred: false,
        masteryAssigned: false,
        competencySuccessAssigned: false,
        cefrLevelAssigned: false,
        progressionPerformed: false,
      });

      expect(
        result.runtime
          .resolvedCapabilityReferences,
      ).toEqual([
        "preference-opinion-expression",
      ]);

      expect(
        repository.load()
          .capabilityObservationRegistry
          .observations,
      ).toEqual([
        {
          capabilityReference:
            "preference-opinion-expression",
          evidenceId:
            "a1-exchange-runtime-evidence:a1-exchange-evidence-preference-expression:exchange-runtime-001",
          source: "learning-studio",
          observationalOnly: true,
        },
      ]);
    });

    it("refuses delayed retrieval runtime writing until a separate delay policy enables it", () => {
      const platform =
        new CefrProductionRuntimePlatform(
          new MemoryProfileRepository(),
          new MemoryStorage(),
        );

      expect(() =>
        platform.recordUserEvidence(
          "a1-exchange",
          {
            evidenceDefinitionId:
              "a1-exchange-evidence-delayed-retrieval",
            eventId:
              "exchange-delayed-001",
            occurredAt:
              new Date(
                "2026-08-13T00:05:00.000Z",
              ),
            languageCode: "hu",
            userActionConfirmed: true,
          },
        ),
      ).toThrow(
        "Unknown authoritative CEFR evidence definition",
      );
    });
  },
);
