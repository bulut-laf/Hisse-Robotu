import type {
  TranslationLanguageCode,
} from "../../core/translation/TranslationDraft";
import {
  getLafLanguageProfile,
} from "../../core/language/LafLanguageProfile";
import type {
  TranslationDialogueHistoryTurn,
} from "./TranslationDialogueTurn";

export interface TranslationDialogueSessionSummary {
  learnerTurnCount: number;
  partnerTurnCount: number;
  learnerWordCount: number;
  uniqueLearnerWordCount: number;
  totalTurnCount: number;
}

const tokenize = (
  language: TranslationLanguageCode,
  value: string,
): string[] => {
  const locale =
    getLafLanguageProfile(
      language,
    ).locale;

  return (
    value
      .toLocaleLowerCase(locale)
      .match(
        /\p{L}+(?:['’\-]\p{L}+)*|\p{N}+/gu,
      ) ?? []
  );
};

export function createTranslationDialogueSessionSummary(
  language: TranslationLanguageCode,
  history: TranslationDialogueHistoryTurn[],
): TranslationDialogueSessionSummary {
  const learnerTurns =
    history.filter(
      turn =>
        turn.speaker === "learner",
    );
  const partnerTurns =
    history.filter(
      turn =>
        turn.speaker === "partner",
    );
  const learnerWords =
    learnerTurns.flatMap(turn =>
      tokenize(language, turn.text),
    );

  return {
    learnerTurnCount:
      learnerTurns.length,
    partnerTurnCount:
      partnerTurns.length,
    learnerWordCount:
      learnerWords.length,
    uniqueLearnerWordCount:
      new Set(learnerWords).size,
    totalTurnCount:
      history.length,
  };
}
