import type {
  CefrA1ConnectEvidenceProvenanceRecoveryRecord,
} from "../../core/learning/CefrA1ConnectEvidenceProvenanceRecoveryRecord";

interface StorageLike {
  getItem(key: string): string | null;
  setItem(
    key: string,
    value: string,
  ): void;
  removeItem(key: string): void;
}

interface StoredEnvelope {
  readonly version: 1;
  readonly records:
    readonly CefrA1ConnectEvidenceProvenanceRecoveryRecord[];
}

export const A1_CONNECT_PROVENANCE_RECOVERY_STORAGE_KEY =
  "laf.cefr.a1-connect.provenance-recovery.v1";

function isRecord(
  value: unknown,
): value is CefrA1ConnectEvidenceProvenanceRecoveryRecord {
  if (
    typeof value !== "object" ||
    value === null
  ) {
    return false;
  }

  const item =
    value as Partial<CefrA1ConnectEvidenceProvenanceRecoveryRecord>;

  return (
    typeof item.recoveryId === "string" &&
    typeof item.evidenceId === "string" &&
    typeof item.languageCode === "string" &&
    typeof item.observedAt === "string" &&
    typeof item.createdAt === "string" &&
    item.reason ===
      "provenance-write-failed" &&
    item.evidenceAlreadyPersisted ===
      true &&
    item.masteryClaimed === false &&
    item.cefrLevelClaimed === false &&
    item.progressionTriggered === false
  );
}

export class CefrA1ConnectEvidenceProvenanceRecoveryRepository {
  private readonly storage:
    StorageLike | null;

  constructor(
    storage:
      StorageLike | null =
        typeof window !== "undefined"
          ? window.localStorage
          : null,
  ) {
    this.storage = storage;
  }

  loadAll():
    readonly CefrA1ConnectEvidenceProvenanceRecoveryRecord[] {
    if (!this.storage) {
      return [];
    }

    const raw =
      this.storage.getItem(
        A1_CONNECT_PROVENANCE_RECOVERY_STORAGE_KEY,
      );

    if (!raw) {
      return [];
    }

    try {
      const parsed =
        JSON.parse(
          raw,
        ) as Partial<StoredEnvelope>;

      if (
        parsed.version !== 1 ||
        !Array.isArray(parsed.records)
      ) {
        return [];
      }

      return parsed.records.filter(
        isRecord,
      );
    }
    catch {
      return [];
    }
  }

  save(
    record:
      CefrA1ConnectEvidenceProvenanceRecoveryRecord,
  ):
    CefrA1ConnectEvidenceProvenanceRecoveryRecord {
    if (!this.storage) {
      return record;
    }

    const existing =
      this.loadAll().find(
        item =>
          item.recoveryId ===
          record.recoveryId,
      );

    if (existing) {
      return existing;
    }

    const envelope:
      StoredEnvelope = {
        version: 1,
        records: [
          ...this.loadAll(),
          record,
        ],
      };

    this.storage.setItem(
      A1_CONNECT_PROVENANCE_RECOVERY_STORAGE_KEY,
      JSON.stringify(envelope),
    );

    return record;
  }

  remove(
    recoveryId: string,
  ): void {
    if (!this.storage) {
      return;
    }

    const next =
      this.loadAll().filter(
        item =>
          item.recoveryId !== recoveryId,
      );

    this.storage.setItem(
      A1_CONNECT_PROVENANCE_RECOVERY_STORAGE_KEY,
      JSON.stringify({
        version: 1,
        records: next,
      }),
    );
  }

  clear(): void {
    this.storage?.removeItem(
      A1_CONNECT_PROVENANCE_RECOVERY_STORAGE_KEY,
    );
  }
}
