﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$slicePath =
    Join-Path $app "src\core\learning\CefrA1ConnectRuntimeSliceDefinition.ts"

$utf8 = New-Object System.Text.UTF8Encoding($false)

function Read-Utf8([string]$path) {
    return [System.IO.File]::ReadAllText($path, $utf8)
}

function Write-Utf8(
    [string]$path,
    [string]$text
) {
    [System.IO.File]::WriteAllText($path, $text, $utf8)
}

if (-not (Test-Path $slicePath)) {
    throw "CefrA1ConnectRuntimeSliceDefinition.ts missing."
}

$text = Read-Utf8 $slicePath

$newFactoryCall =
    "createLafA1ConnectExecutableRuntimeEvidenceRegistry()"

if (-not $text.Contains($newFactoryCall)) {
    throw "Executable A1 CONNECT runtime evidence registry is not active; refusing import-only repair."
}

$staleSymbol =
    "createLafCefrAuthoritativeEvidenceRegistry"

$symbolCount =
    [regex]::Matches(
        $text,
        [regex]::Escape($staleSymbol)
    ).Count

if ($symbolCount -ne 1) {
    throw "Expected stale symbol exactly once before cleanup; found $symbolCount."
}

$staleImportPattern =
    '(?ms)^import\s*\{\s*' +
    [regex]::Escape($staleSymbol) +
    '\s*,?\s*\}\s*from\s*["'']\./CefrAuthoritativeEvidenceCatalog["''];\s*\r?\n?'

$importMatches =
    [regex]::Matches(
        $text,
        $staleImportPattern
    )

if ($importMatches.Count -ne 1) {
    throw "Expected exactly one stale evidence-registry import block; found $($importMatches.Count)."
}

$text =
    [regex]::Replace(
        $text,
        $staleImportPattern,
        "",
        1
    )

if (
    [regex]::Matches(
        $text,
        [regex]::Escape($staleSymbol)
    ).Count -ne 0
) {
    throw "Stale createLafCefrAuthoritativeEvidenceRegistry symbol remains after regex cleanup."
}

if (-not $text.Contains($newFactoryCall)) {
    throw "New executable runtime evidence registry call disappeared during cleanup."
}

Write-Utf8 $slicePath $text

Write-Host "SPRINT-1449-1457 REV3 SOURCE CHECK PASSED"

Set-Location $app

Write-Host ""
Write-Host "TARGET VERIFICATION — runtime guardrail"

& npx vitest run @(
    "src/core/learning/CefrA1ConnectRuntimeSliceDefinition.test.ts",
    "src/core/learning/CefrRuntimeSliceDefinition.test.ts",
    "src/core/learning/CefrProductionRuntimeRegistryEnforcement.test.ts",
    "src/application/learning/CefrA1ConnectDelayedRetrievalGenericRuntime.test.ts"
)

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1449-1457 Rev3 target verification failed."
}

Write-Host "SPRINT-1449-1457 REV3 TARGET CHECK PASSED"

Write-Host ""
Write-Host "PRODUCTION BUILD — prior full regression already passed"

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1449-1457 Rev3 production build failed."
}

Write-Host ""
Write-Host "SPRINT-1449-1457 REV3 VERIFICATION COMPLETE"
