﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$src = Join-Path $app "src"
$out = Join-Path $root "LAF_RUNTIME_PROFILE_BINDING_DISCOVERY.txt"

if (-not (Test-Path $src)) {
    throw "Source root not found: $src"
}

$report = New-Object System.Collections.Generic.List[string]

function Add-Line {
    param([string]$Text)
    if ($null -eq $Text) { $Text = "" }
    [void]$report.Add($Text)
}

function Add-Section {
    param([string]$Title)
    Add-Line ""
    Add-Line ("=" * 88)
    Add-Line $Title
    Add-Line ("=" * 88)
}

function Rel {
    param([string]$FullPath)
    $prefix = $root + "\"
    if ($FullPath.StartsWith($prefix)) {
        return $FullPath.Substring($prefix.Length)
    }
    return $FullPath
}

function Add-Preview {
    param(
        [string]$Path,
        [int]$MaxLines = 220
    )

    if (-not (Test-Path $Path)) {
        Add-Line ("MISSING: " + (Rel $Path))
        return
    }

    Add-Line ""
    Add-Line ("FILE: " + (Rel $Path))
    Add-Line ("-" * 88)

    $content = @(Get-Content -Path $Path)
    $limit = [Math]::Min($content.Count, $MaxLines)

    for ($i = 0; $i -lt $limit; $i++) {
        Add-Line ("{0,4}: {1}" -f ($i + 1), $content[$i])
    }

    if ($content.Count -gt $MaxLines) {
        Add-Line ("... truncated; total lines: " + $content.Count)
    }
}

function Search-Source {
    param(
        [string]$Title,
        [string[]]$Patterns,
        [int]$Limit = 180
    )

    Add-Section $Title

    $files = @(
        Get-ChildItem -Path $src -Recurse -File -ErrorAction SilentlyContinue |
        Where-Object {
            $_.Extension -eq ".ts" -or $_.Extension -eq ".tsx"
        }
    )

    $items = New-Object System.Collections.Generic.List[object]

    foreach ($file in $files) {
        foreach ($pattern in $Patterns) {
            $hits = @(
                Select-String -Path $file.FullName -Pattern $pattern -SimpleMatch -ErrorAction SilentlyContinue
            )

            foreach ($hit in $hits) {
                $obj = New-Object PSObject
                Add-Member -InputObject $obj -MemberType NoteProperty -Name File -Value (Rel $hit.Path)
                Add-Member -InputObject $obj -MemberType NoteProperty -Name Line -Value $hit.LineNumber
                Add-Member -InputObject $obj -MemberType NoteProperty -Name Pattern -Value $pattern
                Add-Member -InputObject $obj -MemberType NoteProperty -Name Text -Value $hit.Line.Trim()
                [void]$items.Add($obj)
            }
        }
    }

    $matches = @(
        $items |
        Sort-Object File, Line, Pattern -Unique |
        Select-Object -First $Limit
    )

    if ($matches.Count -eq 0) {
        Add-Line "(no matches)"
        return
    }

    foreach ($m in $matches) {
        Add-Line ("{0}:{1} [{2}] {3}" -f $m.File, $m.Line, $m.Pattern, $m.Text)
    }
}

Add-Line "LAF STUDIO - RUNTIME CEFR PROFILE BINDING DISCOVERY"
Add-Line ("Generated: " + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
Add-Line "READ ONLY - no project files are modified."

Search-Source -Title "1. PERSONAL LANGUAGE PROFILE STATE USAGE" -Patterns @(
    "createCefrPersonalLanguageProfileState"
    "CefrPersonalLanguageProfileState"
    "profileSnapshot"
    "capabilityObservationRegistry"
) -Limit 220

Search-Source -Title "2. EVIDENCE WRITE / RETURN USAGE" -Patterns @(
    "createCefrIntelligenceEvidenceEnvelope"
    "CefrIntelligenceEvidenceEnvelope"
    "evidenceReturn"
    "returnedToEvidencePipeline"
    "payloadReference"
) -Limit 220

Search-Source -Title "3. CAPABILITY OBSERVATION WRITE / RETURN USAGE" -Patterns @(
    "createCefrCapabilityObservation"
    "CefrCapabilityObservation"
    "observationReturn"
    "returnedToProfile"
    "observationalOnly"
) -Limit 220

Search-Source -Title "4. LOCAL STORAGE / REPOSITORY CANDIDATES" -Patterns @(
    "localStorage"
    "LocalStorage"
    "Repository"
    "repository"
    "load("
    "replace("
    "save("
) -Limit 240

Search-Source -Title "5. GUIDANCE UI PROFILE SOURCE USAGE" -Patterns @(
    "CefrGuidanceUiProfileSource"
    "createCefrGuidanceUiProfileSource"
    "LearningGuidanceEntryCard"
    "GuidanceCenterPage"
) -Limit 120

Add-Section "6. LIKELY STORAGE / PROFILE FILES"
$likely = @(
    Get-ChildItem -Path $src -Recurse -File -ErrorAction SilentlyContinue |
    Where-Object {
        $_.Name -match "Profile|Evidence|Observation|Storage|Repository|Session" -and
        ($_.Extension -eq ".ts" -or $_.Extension -eq ".tsx")
    } |
    Sort-Object FullName |
    Select-Object -First 160
)

foreach ($file in $likely) {
    Add-Line (Rel $file.FullName)
}

Add-Section "7. FOCUSED FILE PREVIEWS"

$previewNames = @(
    "CefrPersonalLanguageProfileState.ts",
    "CefrPersonalLanguageProfileSnapshot.ts",
    "CefrPersonalLanguageProfileEvidenceAggregation.ts",
    "CefrCapabilityObservationRegistry.ts",
    "CefrGuidanceUiProfileSource.ts",
    "CefrGuidanceApplicationIntegrationPlatform.ts",
    "CefrGuidanceApplicationFeedbackClosedLoop.ts",
    "LearningSessionService.ts",
    "LocalStorageProvider.ts"
)

foreach ($name in $previewNames) {
    $hits = @(
        Get-ChildItem -Path $src -Recurse -File -Filter $name -ErrorAction SilentlyContinue
    )

    foreach ($file in $hits) {
        Add-Preview -Path $file.FullName -MaxLines 260
    }
}

Add-Section "8. NEXT IMPLEMENTATION INPUT"
Add-Line "Need the real persistent source of CEFR evidence."
Add-Line "Need the real persistent source of capability observations."
Add-Line "Need whether those sources already survive browser restart."
Add-Line "Need exact application/UI service boundary for reading them."
Add-Line "Need to avoid fabricating profile history or deriving mastery automatically."

$report | Set-Content -Path $out -Encoding UTF8

Write-Host ""
Write-Host "LAF RUNTIME PROFILE BINDING DISCOVERY COMPLETE"
Write-Host "Report:"
Write-Host $out
Write-Host ""
Get-Content -Path $out
