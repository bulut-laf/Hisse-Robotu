import {
  describe,
  expect,
  it,
} from "vitest";

import {
  LAF_A1_CONNECT_LANGUAGE_EVIDENCE_PROVENANCE_AUTHORITY,
} from "../../core/learning/CefrLanguageEvidenceProvenanceAuthority";
import {
  createCefrPersonalLanguageProfileState,
  type CefrPersonalLanguageProfileState,
} from "../../core/learning/CefrPersonalLanguageProfileState";
import {
  CefrAuthoritativeLanguageEvidenceProvenanceRepository,
  type CefrLanguageEvidenceStorageLike,
} from "./CefrAuthoritativeLanguageEvidenceProvenanceRepository";
import {
  CefrAuthoritativeLanguageRuntimeEvidenceService,
} from "./CefrAuthoritativeLanguageRuntimeEvidenceService";
import type {
  CefrGuidanceRuntimeProfileRepository,
} from "./CefrGuidanceRuntimeProfileRepository";
import {
  CefrLanguageEvidenceProvenanceCoordinator,
} from "./CefrLanguageEvidenceProvenanceCoordinator";
import {
  CefrLanguageEvidenceProvenanceRecoveryRepository,
} from "./CefrLanguageEvidenceProvenanceRecoveryRepository";

class MemoryProfileRepository
  implements CefrGuidanceRuntimeProfileRepository {
  private state:
    CefrPersonalLanguageProfileState =
      createCefrPersonalLanguageProfileState(
        [],
        [],
      );

  private persisted = false;

  load(): CefrPersonalLanguageProfileState {
    return this.state;
  }

  save(
    state: CefrPersonalLanguageProfileState,
  ): void {
    this.state = state;
    this.persisted = true;
  }

  hasPersistedProfile(): boolean {
    return this.persisted;
  }

  clear(): void {
    this.state =
      createCefrPersonalLanguageProfileState(
        [],
        [],
      );
    this.persisted = false;
  }
}

class MemoryStorage
  implements CefrLanguageEvidenceStorageLike {
  private readonly items =
    new Map<string, string>();

  getItem(
    key: string,
  ): string | null {
    return this.items.get(key) ?? null;
  }

  setItem(
    key: string,
    value: string,
  ): void {
    this.items.set(key, value);
  }

  removeItem(
    key: string,
  ): void {
    this.items.delete(key);
  }
}

describe(
  "CefrAuthoritativeLanguageRuntimeEvidenceService",
  () => {
    it("persists real evidence, capability observation and explicit target-language provenance in one application boundary", () => {
      const profileRepository =
        new MemoryProfileRepository();
      const storage =
        new MemoryStorage();

      const provenanceRepository =
        new CefrAuthoritativeLanguageEvidenceProvenanceRepository(
          LAF_A1_CONNECT_LANGUAGE_EVIDENCE_PROVENANCE_AUTHORITY,
          storage,
        );

      const service =
        new CefrAuthoritativeLanguageRuntimeEvidenceService(
          profileRepository,
          LAF_A1_CONNECT_LANGUAGE_EVIDENCE_PROVENANCE_AUTHORITY,
          new CefrLanguageEvidenceProvenanceCoordinator(
            LAF_A1_CONNECT_LANGUAGE_EVIDENCE_PROVENANCE_AUTHORITY,
            provenanceRepository,
            new CefrLanguageEvidenceProvenanceRecoveryRepository(
              LAF_A1_CONNECT_LANGUAGE_EVIDENCE_PROVENANCE_AUTHORITY,
              storage,
            ),
          ),
        );

      const result =
        service.recordUserEvidence({
          evidenceDefinitionId:
            "a1-connect-evidence-greeting-response",
          eventId:
            "language-runtime-001",
          occurredAt:
            new Date(
              "2026-08-11T21:30:00.000Z",
            ),
          languageCode: "hu",
          userActionConfirmed: true,
        });

      expect(result).toMatchObject({
        evidenceId:
          "a1-connect-runtime-evidence:a1-connect-evidence-greeting-response:language-runtime-001",
        languageCode: "hu",
        evidencePersisted: true,
        targetLanguageExplicit: true,
        targetLanguageInferred: false,
        provenance: {
          provenanceWritten: true,
          recoveryQueued: false,
        },
        masteryAssigned: false,
        competencySuccessAssigned: false,
        cefrLevelAssigned: false,
        progressionPerformed: false,
      });

      expect(
        provenanceRepository
          .findForLanguage("hu"),
      ).toHaveLength(1);

      expect(
        profileRepository.load()
          .capabilityObservationRegistry
          .observations,
      ).toHaveLength(1);
    });
  },
);
