import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrPersonalLanguageProfileState,
  type CefrPersonalLanguageProfileState,
} from "../../core/learning/CefrPersonalLanguageProfileState";
import type {
  CefrLanguageEvidenceStorageLike,
} from "./CefrAuthoritativeLanguageEvidenceProvenanceRepository";
import type {
  CefrGuidanceRuntimeProfileRepository,
} from "./CefrGuidanceRuntimeProfileRepository";
import {
  CefrProductionRuntimePlatform,
} from "./CefrProductionRuntimePlatform";

class MemoryProfileRepository
  implements CefrGuidanceRuntimeProfileRepository {
  private state:
    CefrPersonalLanguageProfileState =
      createCefrPersonalLanguageProfileState(
        [],
        [],
      );

  load(): CefrPersonalLanguageProfileState {
    return this.state;
  }

  save(
    state: CefrPersonalLanguageProfileState,
  ): void {
    this.state = state;
  }

  hasPersistedProfile(): boolean {
    return false;
  }

  clear(): void {}
}

class MemoryStorage
  implements CefrLanguageEvidenceStorageLike {
  private readonly items =
    new Map<string, string>();

  getItem(key: string): string | null {
    return this.items.get(key) ?? null;
  }

  setItem(
    key: string,
    value: string,
  ): void {
    this.items.set(key, value);
  }

  removeItem(key: string): void {
    this.items.delete(key);
  }
}

describe(
  "A1 CONNECT delayed retrieval generic runtime guardrail",
  () => {
    it("refuses delayed retrieval runtime writing without an approved policy", () => {
      const platform =
        new CefrProductionRuntimePlatform(
          new MemoryProfileRepository(),
          new MemoryStorage(),
        );

      expect(() =>
        platform.recordUserEvidence(
          "a1-connect",
          {
            evidenceDefinitionId:
              "a1-connect-evidence-delayed-retrieval",
            eventId:
              "connect-delayed-001",
            occurredAt:
              new Date(
                "2026-08-12T09:00:00.000Z",
              ),
            languageCode: "hu",
            userActionConfirmed: true,
          },
        ),
      ).toThrow(
        "Unknown authoritative CEFR evidence definition",
      );
    });

    it("does not surface delayed retrieval as a generic language-scoped advisory candidate", () => {
      const platform =
        new CefrProductionRuntimePlatform(
          new MemoryProfileRepository(),
          new MemoryStorage(),
        );

      const read =
        platform.readLanguageEvidence(
          "a1-connect",
          "hu",
        );

      expect(
        read.coverage
          .totalEvidenceDefinitionCount,
      ).toBe(6);

      expect(
        read.coverage.items.some(
          item =>
            item.evidenceDefinitionId ===
            "a1-connect-evidence-delayed-retrieval",
        ),
      ).toBe(false);

      expect(
        read.advisory
          .evidenceDefinitionId,
      ).not.toBe(
        "a1-connect-evidence-delayed-retrieval",
      );
    });
  },
);
