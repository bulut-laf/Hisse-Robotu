import {
  describe,
  expect,
  it,
} from "vitest";

import type {
  CefrA1ConnectLanguageEvidenceProvenance,
} from "../../core/learning/CefrA1ConnectLanguageEvidenceProvenance";
import {
  CefrA1ConnectEvidenceProvenanceCoordinator,
} from "./CefrA1ConnectEvidenceProvenanceCoordinator";
import {
  CefrA1ConnectEvidenceProvenanceRecoveryRepository,
} from "./CefrA1ConnectEvidenceProvenanceRecoveryRepository";
import {
  CefrA1ConnectLanguageEvidenceProvenanceRepository,
} from "./CefrA1ConnectLanguageEvidenceProvenanceRepository";

class MemoryStorage {
  private readonly values =
    new Map<string, string>();

  getItem(key: string): string | null {
    return this.values.get(key) ?? null;
  }

  setItem(
    key: string,
    value: string,
  ): void {
    this.values.set(key, value);
  }

  removeItem(key: string): void {
    this.values.delete(key);
  }
}

class FailingProvenanceRepository extends
  CefrA1ConnectLanguageEvidenceProvenanceRepository {
  private shouldFail = true;

  setFailing(
    value: boolean,
  ): void {
    this.shouldFail = value;
  }

  override save(
    provenance:
      CefrA1ConnectLanguageEvidenceProvenance,
  ): CefrA1ConnectLanguageEvidenceProvenance {
    if (this.shouldFail) {
      throw new Error(
        "simulated provenance storage failure",
      );
    }

    return super.save(provenance);
  }
}

describe(
  "CefrA1ConnectEvidenceProvenanceCoordinator",
  () => {
    it("queues an explicit recovery record if evidence already exists but provenance write fails", () => {
      const provenanceRepository =
        new FailingProvenanceRepository(
          new MemoryStorage(),
        );
      const recoveryRepository =
        new CefrA1ConnectEvidenceProvenanceRecoveryRepository(
          new MemoryStorage(),
        );
      const coordinator =
        new CefrA1ConnectEvidenceProvenanceCoordinator(
          provenanceRepository,
          recoveryRepository,
        );

      expect(
        coordinator.recordPersistedEvidenceLanguage({
          evidenceId:
            "a1-connect-runtime-evidence:item-3",
          languageCode: "hu",
          observedAt:
            new Date(
              "2026-08-11T19:17:00.000Z",
            ),
          recoveryCreatedAt:
            new Date(
              "2026-08-11T19:17:01.000Z",
            ),
        }),
      ).toEqual({
        provenanceWritten: false,
        recoveryQueued: true,
        masteryAssigned: false,
        cefrLevelAssigned: false,
        progressionPerformed: false,
      });

      expect(
        recoveryRepository.loadAll(),
      ).toHaveLength(1);
    });

    it("repairs pending provenance later without changing evidence or learning decisions", () => {
      const provenanceRepository =
        new FailingProvenanceRepository(
          new MemoryStorage(),
        );
      const recoveryRepository =
        new CefrA1ConnectEvidenceProvenanceRecoveryRepository(
          new MemoryStorage(),
        );
      const coordinator =
        new CefrA1ConnectEvidenceProvenanceCoordinator(
          provenanceRepository,
          recoveryRepository,
        );

      coordinator.recordPersistedEvidenceLanguage({
        evidenceId:
          "a1-connect-runtime-evidence:item-4",
        languageCode: "it",
        observedAt:
          new Date(
            "2026-08-11T19:18:00.000Z",
          ),
        recoveryCreatedAt:
          new Date(
            "2026-08-11T19:18:01.000Z",
          ),
      });

      provenanceRepository.setFailing(
        false,
      );

      expect(
        coordinator.repairPending(),
      ).toEqual({
        repairedCount: 1,
        remainingCount: 0,
      });

      expect(
        provenanceRepository
          .findByEvidenceId(
            "a1-connect-runtime-evidence:item-4",
          )
          ?.languageCode,
      ).toBe("it");
    });
  },
);
