import fs from "node:fs";
import path from "node:path";

const root = "D:\\Projects\\LAF-Studio";
const file = path.join(
  root,
  "app",
  "src",
  "ui",
  "pages",
  "GuidanceCenterPage.tsx",
);

if (!fs.existsSync(file)) {
  throw new Error(
    `GuidanceCenterPage.tsx not found: ${file}`,
  );
}

let source =
  fs.readFileSync(file, "utf8");
const eol =
  source.includes("\r\n") ? "\r\n" : "\n";

const panelImport =
  'import { GuidanceEvidenceActivityPanel } from "../learning/GuidanceEvidenceActivityPanel";';

if (!source.includes(panelImport)) {
  const hookImport =
    'import { useCefrGuidanceRuntimeProfileSource } from "../hooks/useCefrGuidanceRuntimeProfileSource";';

  if (!source.includes(hookImport)) {
    throw new Error(
      "GuidanceCenter runtime profile hook import not found.",
    );
  }

  source =
    source.replace(
      hookImport,
      hookImport +
        eol +
        panelImport,
    );
}

const panelMarkup =
  "      <GuidanceEvidenceActivityPanel state={source.state} />";

if (!source.includes(panelMarkup)) {
  const headerClose =
    "      </header>";

  const index =
    source.indexOf(headerClose);

  if (index < 0) {
    throw new Error(
      "GuidanceCenter header closing marker not found.",
    );
  }

  const end =
    index + headerClose.length;

  source =
    source.slice(0, end) +
    eol +
    eol +
    panelMarkup +
    source.slice(end);
}

const importCount =
  source.split(panelImport).length - 1;
const panelCount =
  source.split(panelMarkup).length - 1;

if (
  importCount !== 1 ||
  panelCount !== 1
) {
  throw new Error(
    `GuidanceCenter evidence panel validation failed: import=${importCount}, panel=${panelCount}`,
  );
}

fs.writeFileSync(
  file,
  source,
  "utf8",
);

console.log(
  "SPRINT-1239-1244 INSTALL COMPLETE",
);
console.log(
  "Guidance Center evidence activity visibility installed.",
);
