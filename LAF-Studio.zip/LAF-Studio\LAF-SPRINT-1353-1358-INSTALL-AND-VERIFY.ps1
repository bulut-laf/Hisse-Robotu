﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$panel = Join-Path $app "src\ui\learning\A1ConnectNativeLearningPanel.tsx"

if (-not (Test-Path $panel)) {
    throw "A1ConnectNativeLearningPanel.tsx missing."
}

$utf8 =
    New-Object System.Text.UTF8Encoding($false)

$text =
    [System.IO.File]::ReadAllText(
        $panel,
        $utf8
    )

$importLine =
    'import { A1ConnectContinuityPanel } from "./A1ConnectContinuityPanel";'

if (-not $text.Contains($importLine)) {
    $anchor =
        'import { A1ConnectUnitRuntimePanel } from "./A1ConnectUnitRuntimePanel";'

    if (-not $text.Contains($anchor)) {
        throw "Continuity import anchor not found."
    }

    $text = $text.Replace(
        $anchor,
        $anchor +
        [Environment]::NewLine +
        $importLine
    )
}

$renderMarker =
    '<A1ConnectContinuityPanel'

if (-not $text.Contains($renderMarker)) {
    $anchor =
        '      <div className="a1-connect-native-gate">'

    if (-not $text.Contains($anchor)) {
        throw "Continuity render anchor not found."
    }

    $render = @'
      <A1ConnectContinuityPanel
        selectedLanguageCode={selectedLanguageCode}
        selectedLessonId={
          selectedLesson?.lessonId ?? null
        }
      />

'@

    $text = $text.Replace(
        $anchor,
        $render + $anchor
    )
}

[System.IO.File]::WriteAllText(
    $panel,
    $text,
    $utf8
)

$state = Join-Path $app "src\core\learning\CefrA1ConnectSessionState.ts"
$repo = Join-Path $app "src\application\learning\CefrA1ConnectSessionStateRepository.ts"
$next = Join-Path $app "src\core\learning\CefrA1ConnectAdvisoryNextStep.ts"
$continuity = Join-Path $app "src\ui\learning\A1ConnectContinuityPanel.tsx"
$safety = Join-Path $app "src\core\learning\CefrA1ConnectContinuitySafety.ts"

foreach ($file in @(
    $state,
    $repo,
    $next,
    $continuity,
    $safety
)) {
    if (-not (Test-Path $file)) {
        throw "Sprint 1353-1358 source missing: $file"
    }
}

$checks = @{
    $state = @(
        'learningDecisionClaimed: false',
        'masteryClaimed: false',
        'cefrLevelClaimed: false'
    )
    $repo = @(
        'laf.cefr.a1-connect.session.v1',
        'saveSelection('
    )
    $next = @(
        'advisoryOnly: true',
        'automaticLessonSelection: false',
        'automaticProgression: false'
    )
    $continuity = @(
        'Seçimi Hatırla',
        'SIRADAKİ ÖNERİ',
        'Ders otomatik seçilmez'
    )
    $panel = @(
        'A1ConnectContinuityPanel',
        'selectedLanguageCode={selectedLanguageCode}'
    )
}

foreach ($entry in $checks.GetEnumerator()) {
    foreach ($marker in $entry.Value) {
        if (-not (
            Select-String `
                -Path $entry.Key `
                -SimpleMatch `
                -Pattern $marker `
                -Quiet
        )) {
            throw "Required Sprint 1353-1358 marker missing: $marker"
        }
    }
}

Write-Host "SPRINT-1353-1358 SOURCE CHECK PASSED"

Set-Location $app

$targets = @(
    "src/core/learning/CefrA1ConnectSessionState.test.ts",
    "src/application/learning/CefrA1ConnectSessionStateRepository.test.ts",
    "src/core/learning/CefrA1ConnectAdvisoryNextStep.test.ts",
    "src/core/learning/CefrA1ConnectContinuitySafety.test.ts",
    "src/ui/learning/A1ConnectContinuityPanel.test.ts",
    "src/core/learning/CefrA1ConnectEvidenceCoverage.test.ts",
    "src/application/learning/CefrA1ConnectEvidenceCoverageReadModel.test.ts",
    "src/core/learning/CefrA1ConnectUnitRuntimeSafety.test.ts"
)

& npx vitest run $targets
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1353-1358 target tests failed."
}

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Full regression failed."
}

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Production build failed."
}

Write-Host "SPRINT-1353-1358 VERIFICATION COMPLETE"
