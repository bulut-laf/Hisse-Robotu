﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

$required = @(
    "src\core\learning\CefrAuthoritativeCurriculumRegistry.test.ts",
    "src\core\learning\CefrAuthoritativeCurriculumCatalog.test.ts",
    "src\core\learning\CefrA1NavigateCurriculumRegistry.test.ts"
)

foreach ($relative in $required) {
    $path = Join-Path $app $relative

    if (-not (Test-Path $path)) {
        throw "Sprint 1440-1448 Rev1 repair source missing: $relative"
    }
}

$markers = @(
    @(
        "src\core\learning\CefrAuthoritativeCurriculumRegistry.test.ts",
        "curriculum-map-a1-connect-v1"
    ),
    @(
        "src\core\learning\CefrAuthoritativeCurriculumRegistry.test.ts",
        "getA1ConnectMappings"
    ),
    @(
        "src\core\learning\CefrAuthoritativeCurriculumCatalog.test.ts",
        'unit.competencyOutcomeId ==='
    ),
    @(
        "src\core\learning\CefrA1NavigateCurriculumRegistry.test.ts",
        "curriculum-map-a1-navigate-v1"
    )
)

foreach ($pair in $markers) {
    $path = Join-Path $app $pair[0]

    if (-not (
        Select-String `
            -Path $path `
            -SimpleMatch `
            -Pattern $pair[1] `
            -Quiet
    )) {
        throw "Sprint 1440-1448 Rev1 marker missing: $($pair[1])"
    }
}

Write-Host "SPRINT-1440-1448 REV1 SOURCE CHECK PASSED"

Set-Location $app

Write-Host ""
Write-Host "RESUME CHECKPOINT 2/3 — Sprint 1443-1445"

& npx vitest run @(
    "src/core/learning/CefrAuthoritativeCurriculumRegistry.test.ts",
    "src/core/learning/CefrA1NavigateCurriculumRegistry.test.ts",
    "src/core/learning/CefrA1NavigateRuntimeEvidenceCatalog.test.ts",
    "src/core/learning/CefrAuthoritativeCapabilityRegistry.test.ts",
    "src/application/learning/CefrCurriculumCapabilityObservationWriter.test.ts"
)

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1443-1445 Rev1 target checkpoint failed."
}

Write-Host "SPRINT-1443-1445 REV1 TARGET CHECKPOINT PASSED"

Write-Host ""
Write-Host "RESUME CHECKPOINT 3/3 — Sprint 1446-1448"

& npx vitest run @(
    "src/core/learning/CefrA1NavigateRuntimeSliceDefinition.test.ts",
    "src/core/learning/CefrProductionRuntimeSliceRegistry.test.ts",
    "src/application/learning/CefrProductionRuntimePlatform.test.ts",
    "src/application/learning/CefrA1NavigateProductionRuntime.test.ts"
)

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1446-1448 Rev1 target checkpoint failed."
}

Write-Host "SPRINT-1446-1448 REV1 TARGET CHECKPOINT PASSED"

Write-Host ""
Write-Host "FINAL BLOCK REGRESSION — one full run only"

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1440-1448 Rev1 final full regression failed."
}

Write-Host ""
Write-Host "FINAL PRODUCTION BUILD"

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1440-1448 Rev1 production build failed."
}

Write-Host ""
Write-Host "SPRINT-1440-1448 REV1 VERIFICATION COMPLETE"
