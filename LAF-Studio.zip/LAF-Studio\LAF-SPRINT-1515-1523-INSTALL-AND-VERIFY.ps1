﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$payloadRoot =
    Join-Path $root "_sprint_payload"

$requiredBaseline = @(
    "src\core\learning\CefrA1DescribeExecutableTaskDefinition.ts",
    "src\application\learning\CefrA1DescribeExecutableTaskService.ts",
    "src\core\learning\CefrA1DescribeLanguageContentRegistry.ts",
    "src\core\learning\CefrA1DescribeLanguageRealizationRegistry.ts",
    "src\application\learning\CefrProductionRuntimePlatform.ts"
)

foreach ($relative in $requiredBaseline) {
    $path = Join-Path $app $relative
    if (-not (Test-Path $path)) {
        throw "Sprint 1514 stable baseline file missing: $relative"
    }
}

$baselineRegistry =
    [System.IO.File]::ReadAllText(
        (Join-Path $app "src\core\learning\CefrA1DescribeLanguageRealizationRegistry.ts")
    )

if (-not $baselineRegistry.Contains(
    "executableTaskCount: 3"
)) {
    throw "Sprint 1514 A1 DESCRIBE three-task baseline marker missing."
}

$backupRoot =
    Join-Path $root (
        "_sprint_backups\Sprint1515-1523-" +
        (Get-Date -Format "yyyyMMdd-HHmmss")
    )

New-Item `
    -ItemType Directory `
    -Path $backupRoot `
    -Force |
    Out-Null

function Install-CheckpointPayload {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Checkpoint
    )

    $sourceRoot =
        Join-Path $payloadRoot $Checkpoint

    if (-not (Test-Path $sourceRoot)) {
        throw "Checkpoint payload missing: $Checkpoint"
    }

    $files =
        Get-ChildItem `
            -Path $sourceRoot `
            -Recurse `
            -File

    foreach ($file in $files) {
        $relative =
            $file.FullName.Substring(
                $sourceRoot.Length
            ).TrimStart(
                [char[]]@("\", "/")
            )

        $destination =
            Join-Path $root $relative

        $destinationDir =
            Split-Path $destination -Parent

        New-Item `
            -ItemType Directory `
            -Path $destinationDir `
            -Force |
            Out-Null

        if (Test-Path $destination) {
            $backup =
                Join-Path $backupRoot $relative

            $backupDir =
                Split-Path $backup -Parent

            New-Item `
                -ItemType Directory `
                -Path $backupDir `
                -Force |
                Out-Null

            if (-not (Test-Path $backup)) {
                Copy-Item `
                    -LiteralPath $destination `
                    -Destination $backup `
                    -Force
            }
        }

        Copy-Item `
            -LiteralPath $file.FullName `
            -Destination $destination `
            -Force
    }
}

$vitestPath =
    Join-Path $app "node_modules\.bin\vitest.cmd"

if (-not (Test-Path $vitestPath)) {
    throw "Local Vitest command missing: $vitestPath"
}

$npmCommand =
    Get-Command "npm.cmd" -ErrorAction Stop
$npmPath = $npmCommand.Source

function Run-TargetTests {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Label,

        [Parameter(Mandatory = $true)]
        [string[]]$Tests
    )

    Write-Host ""
    Write-Host "============================================================"
    Write-Host $Label
    Write-Host "============================================================"

    $vitestCommandArgs = @("run")
    $vitestCommandArgs += $Tests

    & $vitestPath @vitestCommandArgs

    if ($LASTEXITCODE -ne 0) {
        throw "$Label failed."
    }
}

Set-Location $app

Install-CheckpointPayload `
    -Checkpoint "1515-1517"

Run-TargetTests `
    -Label "SPRINT-1515-1517 TARGET CHECKPOINT" `
    -Tests @(
        "src/core/learning/CefrA1DescribeSecondWaveExecutableTaskDefinition.test.ts",
        "src/core/learning/CefrA1DescribeImmediateEvidenceCompletionSafety.test.ts",
        "src/application/learning/CefrA1DescribeSecondWaveExecutableTaskService.test.ts",
        "src/application/learning/CefrA1DescribeExecutableTaskService.test.ts"
    )

Write-Host "SPRINT-1515-1517 TARGET CHECKPOINT PASSED"

Install-CheckpointPayload `
    -Checkpoint "1518-1520"

Run-TargetTests `
    -Label "SPRINT-1518-1520 TARGET CHECKPOINT" `
    -Tests @(
        "src/core/learning/CefrA1DescribeExecutableTaskCatalog.test.ts",
        "src/core/learning/CefrA1DescribeLanguageRealizationRegistry.test.ts",
        "src/core/learning/CefrA1DescribeCompleteImmediateTaskSafety.test.ts",
        "src/core/learning/CefrA1DescribeRuntimeSliceDefinition.test.ts",
        "src/application/learning/CefrA1DescribeProductionRuntime.test.ts"
    )

Write-Host "SPRINT-1518-1520 TARGET CHECKPOINT PASSED"

Install-CheckpointPayload `
    -Checkpoint "1521-1523"

Run-TargetTests `
    -Label "SPRINT-1521-1523 TARGET CHECKPOINT" `
    -Tests @(
        "src/application/learning/CefrA1DescribePersistedEvidenceView.test.ts",
        "src/core/learning/CefrA1DescribePersistedEvidenceSafety.test.ts",
        "src/core/learning/CefrA1DescribeExecutableTaskCatalog.test.ts",
        "src/application/learning/CefrA1DescribeExecutableTaskService.test.ts",
        "src/application/learning/CefrA1DescribeSecondWaveExecutableTaskService.test.ts",
        "src/application/learning/CefrProductionRuntimeDelayedRetrievalVisibility.test.ts"
    )

Write-Host "SPRINT-1521-1523 TARGET CHECKPOINT PASSED"

Write-Host ""
Write-Host "============================================================"
Write-Host "FINAL 9-SPRINT BLOCK REGRESSION"
Write-Host "============================================================"

& $npmPath run test

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1515-1523 final full regression failed."
}

Write-Host ""
Write-Host "============================================================"
Write-Host "FINAL PRODUCTION BUILD"
Write-Host "============================================================"

& $npmPath run build

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1515-1523 production build failed."
}

Write-Host ""
Write-Host "SPRINT-1515-1523 VERIFICATION COMPLETE"
Write-Host "Backup: $backupRoot"
