import type { TranslationDailyLearningSessionSummary } from "./TranslationDailyLearningSessionSummary";

export type CefrActivationExistingProgressStatus =
  TranslationDailyLearningSessionSummary["status"];

export interface CefrActivationProgressFeedbackView {
  readonly status: CefrActivationExistingProgressStatus;
  readonly statusLabel: "Başlamadı" | "Devam Ediyor" | "Tamamlandı";
  readonly completionLabel: "Gerçek hayat çalışması tamamlandı." | null;
  readonly observedLabel:
    | "Bu çalışmada mevcut authoritative learner evidence gözlemlendi."
    | "Bu activation completion yeni competency evidence üretmedi.";
  readonly masteryLabel: null;
  readonly safetyLabel: "Tamamlanma mastery veya CEFR doğrulaması değildir.";
  readonly evidenceCreatedByActivation: false;
  readonly masteryInferred: false;
  readonly cefrLevelInferred: false;
  readonly progressionPerformed: false;
  readonly automaticStudioLaunchPerformed: false;
}

export function createCefrActivationProgressFeedbackView(input: {
  readonly activationStarted: boolean;
  readonly activationCompleted: boolean;
  readonly existingAuthoritativeEvidenceObserved: boolean;
}): CefrActivationProgressFeedbackView {
  const status: CefrActivationExistingProgressStatus =
    input.activationCompleted
      ? "complete"
      : input.activationStarted
        ? "in-progress"
        : "not-started";

  return {
    status,
    statusLabel:
      status === "complete"
        ? "Tamamlandı"
        : status === "in-progress"
          ? "Devam Ediyor"
          : "Başlamadı",
    completionLabel:
      status === "complete"
        ? "Gerçek hayat çalışması tamamlandı."
        : null,
    observedLabel:
      input.existingAuthoritativeEvidenceObserved
        ? "Bu çalışmada mevcut authoritative learner evidence gözlemlendi."
        : "Bu activation completion yeni competency evidence üretmedi.",
    masteryLabel: null,
    safetyLabel: "Tamamlanma mastery veya CEFR doğrulaması değildir.",
    evidenceCreatedByActivation: false,
    masteryInferred: false,
    cefrLevelInferred: false,
    progressionPerformed: false,
    automaticStudioLaunchPerformed: false,
  };
}
