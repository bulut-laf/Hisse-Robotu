import {
  LAF_LEARNING_LANGUAGE_CODES,
  getLafLanguageProfile,
  type LafLearningLanguageCode,
} from "../../core/language/LafLanguageProfile";
import {
  getLafA1NavigateLanguageRealization,
  type CefrA1NavigateLanguageRealizationDescriptor,
} from "../../core/learning/CefrA1NavigateLanguageRealizationRegistry";

export interface CefrA1NavigateTargetLanguageOption {
  readonly code: LafLearningLanguageCode;
  readonly label: string;
  readonly nativeLabel: string;
  readonly locale: string;
}

export interface CefrA1NavigateTargetLanguageSelectionModel {
  readonly options:
    readonly CefrA1NavigateTargetLanguageOption[];
  readonly selectedLanguageCode:
    LafLearningLanguageCode | null;
  readonly selectionRequired: boolean;
  readonly selectedByUser: boolean;
  readonly realization:
    CefrA1NavigateLanguageRealizationDescriptor | null;
  readonly languageContentBound: boolean;
  readonly executableTaskAvailable: boolean;
  readonly evidenceCaptureAvailable: boolean;
  readonly delayedRetrievalRuntimeAvailable:
    boolean;
  readonly targetLanguageInferred: false;
}

export function createCefrA1NavigateTargetLanguageSelectionModel(
  selectedLanguageCode:
    LafLearningLanguageCode | null,
): CefrA1NavigateTargetLanguageSelectionModel {
  const options =
    LAF_LEARNING_LANGUAGE_CODES.map(code => {
      const profile = getLafLanguageProfile(code);

      return {
        code,
        label: profile.label,
        nativeLabel: profile.nativeLabel,
        locale: profile.locale,
      };
    });

  const realization =
    selectedLanguageCode === null
      ? null
      : getLafA1NavigateLanguageRealization(
          selectedLanguageCode,
        );

  return {
    options,
    selectedLanguageCode,
    selectionRequired:
      selectedLanguageCode === null,
    selectedByUser:
      selectedLanguageCode !== null,
    realization,
    languageContentBound:
      realization?.languageContentBound ??
      false,
    executableTaskAvailable:
      realization?.executableTaskAvailable ??
      false,
    evidenceCaptureAvailable:
      realization?.evidenceCaptureAvailable ??
      false,
    delayedRetrievalRuntimeAvailable:
      realization?.delayedRetrievalRuntimeAvailable ??
      false,
    targetLanguageInferred: false,
  };
}
