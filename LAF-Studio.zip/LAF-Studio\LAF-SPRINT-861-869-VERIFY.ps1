$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 861-863 Target Tests: Custodial Consolidation ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialConsolidation.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialConsolidationCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialConsolidationAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 861-863 target tests failed." }

Write-Host "=== Sprint 864-866 Target Tests: Custodial Harmonization ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialHarmonization.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialHarmonizationCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialHarmonizationAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 864-866 target tests failed." }

Write-Host "=== Sprint 867-869 Target Tests: Custodial Reconciliation ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialReconciliation.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialReconciliationCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialReconciliationAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 867-869 target tests failed." }

Write-Host "=== Combined Sprint 861-869 New Tests ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialConsolidation.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialConsolidationCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialConsolidationAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialHarmonization.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialHarmonizationCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialHarmonizationAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialReconciliation.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialReconciliationCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialReconciliationAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 861-869 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-861-869 VERIFICATION COMPLETE"
