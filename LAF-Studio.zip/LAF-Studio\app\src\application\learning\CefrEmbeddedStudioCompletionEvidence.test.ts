import { describe, expect, it } from "vitest";
import { createCefrEmbeddedStudioCompletionEvidenceInput } from "./CefrEmbeddedStudioCompletionEvidence";

describe("CefrEmbeddedStudioCompletionEvidence", () => {
  it.each([
    "reading",
    "speaking",
    "dialogue",
  ] as const)(
    "creates observational learning-studio evidence input for %s",
    studio => {
      const completedAt =
        new Date("2026-08-11T13:24:00+03:00");

      expect(
        createCefrEmbeddedStudioCompletionEvidenceInput(
          studio,
          completedAt,
        ),
      ).toEqual({
        evidenceId:
          `embedded-studio-completion:${studio}:2026-08-11T10:24:00.000Z`,
        observedAt: completedAt,
        payloadReference:
          `embedded-studio:${studio}:2026-08-11T10:24:00.000Z`,
      });
    },
  );

  it("keeps separate user completions distinct", () => {
    const first =
      new Date("2026-08-11T13:24:00+03:00");
    const second =
      new Date("2026-08-11T13:25:00+03:00");

    expect(
      createCefrEmbeddedStudioCompletionEvidenceInput(
        "reading",
        first,
      ).evidenceId,
    ).not.toBe(
      createCefrEmbeddedStudioCompletionEvidenceInput(
        "reading",
        second,
      ).evidenceId,
    );
  });
});
