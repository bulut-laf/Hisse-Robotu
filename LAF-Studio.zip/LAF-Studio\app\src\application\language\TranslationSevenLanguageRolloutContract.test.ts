import { describe, expect, it } from "vitest";
import { getLafLanguageProfile, LAF_LEARNING_LANGUAGE_CODES } from "../../core/language/LafLanguageProfile";
import { getTranslationDialogueScenario } from "../dialogue/TranslationDialogueScenario";

describe("seven-language rollout contract", () => {
  it.each(LAF_LEARNING_LANGUAGE_CODES)("has runtime and dialogue coverage for %s", language => {
    const profile=getLafLanguageProfile(language);
    const scenario=getTranslationDialogueScenario(language,"cafe");
    expect(profile.textToSpeechLocale).toBeTruthy();
    expect(profile.speechRecognitionLocale).toBeTruthy();
    expect(scenario.prompts[0]?.partnerText).toBeTruthy();
  });
});
