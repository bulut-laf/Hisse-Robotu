import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createTranslationDialogueSessionSummary,
} from "./TranslationDialogueSession";

describe(
  "createTranslationDialogueSessionSummary",
  () => {
    it("creates an empty summary", () => {
      expect(
        createTranslationDialogueSessionSummary(
          "hu",
          [],
        ),
      ).toEqual({
        learnerTurnCount: 0,
        partnerTurnCount: 0,
        learnerWordCount: 0,
        uniqueLearnerWordCount: 0,
        totalTurnCount: 0,
      });
    });

    it("counts learner and partner turns", () => {
      const result =
        createTranslationDialogueSessionSummary(
          "hu",
          [
            {
              speaker: "partner",
              text: "Szia!",
            },
            {
              speaker: "learner",
              text: "Szia!",
            },
          ],
        );

      expect(
        result.learnerTurnCount,
      ).toBe(1);
      expect(
        result.partnerTurnCount,
      ).toBe(1);
    });

    it("counts learner words only", () => {
      const result =
        createTranslationDialogueSessionSummary(
          "hu",
          [
            {
              speaker: "partner",
              text:
                "Mit kér?",
            },
            {
              speaker: "learner",
              text:
                "Kérek egy kávét.",
            },
          ],
        );

      expect(
        result.learnerWordCount,
      ).toBe(3);
    });

    it("counts unique learner words", () => {
      const result =
        createTranslationDialogueSessionSummary(
          "hu",
          [
            {
              speaker: "learner",
              text:
                "Kérek kávét.",
            },
            {
              speaker: "learner",
              text:
                "Kérek vizet.",
            },
          ],
        );

      expect(
        result.uniqueLearnerWordCount,
      ).toBe(3);
    });

    it("normalizes Hungarian case", () => {
      const result =
        createTranslationDialogueSessionSummary(
          "hu",
          [
            {
              speaker: "learner",
              text: "Ő ő",
            },
          ],
        );

      expect(
        result.uniqueLearnerWordCount,
      ).toBe(1);
    });

    it("normalizes Turkish case with locale", () => {
      const result =
        createTranslationDialogueSessionSummary(
          "tr",
          [
            {
              speaker: "learner",
              text: "İYİ iyi",
            },
          ],
        );

      expect(
        result.uniqueLearnerWordCount,
      ).toBe(1);
    });

    it("counts total turns", () => {
      expect(
        createTranslationDialogueSessionSummary(
          "hu",
          [
            {
              speaker: "partner",
              text: "A",
            },
            {
              speaker: "learner",
              text: "B",
            },
            {
              speaker: "partner",
              text: "C",
            },
          ],
        ).totalTurnCount,
      ).toBe(3);
    });

    it("ignores punctuation-only learner turns for words", () => {
      expect(
        createTranslationDialogueSessionSummary(
          "hu",
          [
            {
              speaker: "learner",
              text: "...",
            },
          ],
        ).learnerWordCount,
      ).toBe(0);
    });
  },
);
