import fs from "node:fs";
import path from "node:path";

const root = "D:\\Projects\\LAF-Studio";

const hookFile = path.join(
  root,
  "app",
  "src",
  "ui",
  "hooks",
  "useLearningSession.ts",
);

const lessonFile = path.join(
  root,
  "app",
  "src",
  "ui",
  "pages",
  "LessonPage.tsx",
);

function read(file) {
  if (!fs.existsSync(file)) {
    throw new Error(`Required file not found: ${file}`);
  }
  return fs.readFileSync(file, "utf8");
}

function write(file, source) {
  fs.writeFileSync(file, source, "utf8");
}

function eolOf(source) {
  return source.includes("\r\n") ? "\r\n" : "\n";
}

function count(source, needle) {
  return source.split(needle).length - 1;
}

function insertAfterFirstLine(
  source,
  exactLine,
  insertedLines,
  description,
) {
  const eol = eolOf(source);
  const lines = source.split(/\r?\n/);
  const index = lines.findIndex(
    line => line.trim() === exactLine.trim(),
  );

  if (index < 0) {
    throw new Error(
      `${description}: anchor line not found: ${exactLine}`,
    );
  }

  lines.splice(index + 1, 0, ...insertedLines);
  return lines.join(eol);
}

function insertBeforeFirstLine(
  source,
  exactLine,
  insertedLines,
  description,
) {
  const eol = eolOf(source);
  const lines = source.split(/\r?\n/);
  const index = lines.findIndex(
    line => line.trim() === exactLine.trim(),
  );

  if (index < 0) {
    throw new Error(
      `${description}: anchor line not found: ${exactLine}`,
    );
  }

  lines.splice(index, 0, ...insertedLines);
  return lines.join(eol);
}

function getLearningSessionDestructureLines(source) {
  const lines = source.split(/\r?\n/);

  const callIndex = lines.findIndex(
    line => line.includes("} = useLearningSession("),
  );

  if (callIndex < 0) {
    throw new Error(
      "useLearningSession destructuring boundary not found.",
    );
  }

  let startIndex = -1;

  for (let i = callIndex - 1; i >= 0; i--) {
    if (lines[i].includes("const {")) {
      startIndex = i;
      break;
    }
  }

  if (startIndex < 0) {
    throw new Error(
      "useLearningSession destructuring start not found.",
    );
  }

  return {
    lines,
    startIndex,
    callIndex,
    block: lines.slice(startIndex, callIndex + 1),
  };
}

function patchHook() {
  let source = read(hookFile);

  if (!source.includes("  sessionId: string;")) {
    source = insertAfterFirstLine(
      source,
      "isCompleted: boolean;",
      [
        "  sessionId: string;",
        "  completedAt: Date | undefined;",
      ],
      "useLearningSession interface",
    );
  }

  if (
    !source.includes(
      "    sessionId: sessionResult.session.id,",
    )
  ) {
    source = insertAfterFirstLine(
      source,
      "isCompleted: sessionResult.isCompleted,",
      [
        "    sessionId: sessionResult.session.id,",
        "    completedAt: sessionResult.session.completedAt,",
      ],
      "useLearningSession return",
    );
  }

  const checks = {
    interfaceSessionId:
      count(source, "  sessionId: string;"),
    interfaceCompletedAt:
      count(source, "  completedAt: Date | undefined;"),
    returnSessionId:
      count(
        source,
        "    sessionId: sessionResult.session.id,",
      ),
    returnCompletedAt:
      count(
        source,
        "    completedAt: sessionResult.session.completedAt,",
      ),
  };

  for (const [name, value] of Object.entries(checks)) {
    if (value !== 1) {
      throw new Error(
        `useLearningSession validation failed: ${name}=${value}`,
      );
    }
  }

  write(hookFile, source);
  console.log("OK: useLearningSession runtime completion fields");
}

function patchLessonPage() {
  let source = read(lessonFile);
  const eol = eolOf(source);

  const runtimeServiceImport =
    'import { CefrGuidanceRuntimeProfileService } from "../../application/learning/CefrGuidanceRuntimeProfileService";';
  const profileRepositoryImport =
    'import { LocalStorageCefrGuidanceProfileRepository } from "../storage/LocalStorageCefrGuidanceProfileRepository";';

  if (!source.includes(runtimeServiceImport)) {
    const storageImportEnd =
      '} from "../storage/LocalStorageSessionStorage";';

    const index = source.indexOf(storageImportEnd);
    if (index < 0) {
      throw new Error(
        "LessonPage imports: LocalStorageSessionStorage import end not found.",
      );
    }

    const end = index + storageImportEnd.length;
    source =
      source.slice(0, end) +
      eol +
      runtimeServiceImport +
      eol +
      profileRepositoryImport +
      source.slice(end);
  } else if (!source.includes(profileRepositoryImport)) {
    source = source.replace(
      runtimeServiceImport,
      runtimeServiceImport +
        eol +
        profileRepositoryImport,
    );
  }

  let destructure = getLearningSessionDestructureLines(source);

  const hasSessionId = destructure.block.some(
    line => line.trim() === "sessionId,",
  );
  const hasCompletedAt = destructure.block.some(
    line => line.trim() === "completedAt,",
  );

  if (!hasSessionId || !hasCompletedAt) {
    const insertIndex = destructure.block.findIndex(
      line => line.trim() === "isCompleted,",
    );

    if (insertIndex < 0) {
      throw new Error(
        "LessonPage isCompleted destructure anchor not found.",
      );
    }

    const additions = [];
    if (!hasSessionId) {
      additions.push("    sessionId,");
    }
    if (!hasCompletedAt) {
      additions.push("    completedAt,");
    }

    destructure.lines.splice(
      destructure.startIndex + insertIndex + 1,
      0,
      ...additions,
    );

    source = destructure.lines.join(eol);
  }

  if (
    !source.includes(
      "const cefrRuntimeProfileService = useMemo(",
    )
  ) {
    source = insertBeforeFirstLine(
      source,
      "const audioRecorderService = useMemo(",
      [
        "  const cefrRuntimeProfileService = useMemo(",
        "    () =>",
        "      new CefrGuidanceRuntimeProfileService(",
        "        new LocalStorageCefrGuidanceProfileRepository(),",
        "      ),",
        "    [],",
        "  );",
        "",
      ],
      "LessonPage runtime profile service",
    );
  }

  if (
    !source.includes(
      "cefrRuntimeProfileService.recordLearningSessionCompletion({",
    )
  ) {
    source = insertBeforeFirstLine(
      source,
      "const normalizedAnswer = answer.trim();",
      [
        "  useEffect(() => {",
        "    if (!isCompleted || !completedAt) {",
        "      return;",
        "    }",
        "",
        "    cefrRuntimeProfileService.recordLearningSessionCompletion({",
        "      sessionId,",
        "      completedAt,",
        "    });",
        "  }, [",
        "    cefrRuntimeProfileService,",
        "    completedAt,",
        "    isCompleted,",
        "    sessionId,",
        "  ]);",
        "",
      ],
      "LessonPage completion evidence effect",
    );
  }

  const finalDestructure =
    getLearningSessionDestructureLines(source);

  const destructureSessionIdCount =
    finalDestructure.block.filter(
      line => line.trim() === "sessionId,",
    ).length;
  const destructureCompletedAtCount =
    finalDestructure.block.filter(
      line => line.trim() === "completedAt,",
    ).length;

  const checks = {
    runtimeServiceImport:
      count(source, runtimeServiceImport),
    profileRepositoryImport:
      count(source, profileRepositoryImport),
    destructureSessionId: destructureSessionIdCount,
    destructureCompletedAt: destructureCompletedAtCount,
    runtimeService:
      count(
        source,
        "const cefrRuntimeProfileService = useMemo(",
      ),
    completionWrite:
      count(
        source,
        "cefrRuntimeProfileService.recordLearningSessionCompletion({",
      ),
  };

  for (const [name, value] of Object.entries(checks)) {
    if (value !== 1) {
      throw new Error(
        `LessonPage validation failed: ${name}=${value}`,
      );
    }
  }

  write(lessonFile, source);
  console.log("OK: LessonPage real completion evidence binding");
}

try {
  patchHook();
  patchLessonPage();

  console.log("");
  console.log("SPRINT-1215-1220 REV2 INSTALL COMPLETE");
} catch (error) {
  console.error("");
  console.error("SPRINT-1215-1220 REV2 INSTALL ERROR");
  console.error(
    error instanceof Error ? error.message : String(error),
  );
  process.exit(1);
}
