﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$panel = Join-Path $app "src\ui\learning\A1ConnectNativeLearningPanel.tsx"

if (-not (Test-Path $panel)) {
    throw "A1ConnectNativeLearningPanel.tsx missing."
}

$utf8 =
    New-Object System.Text.UTF8Encoding($false)

$text =
    [System.IO.File]::ReadAllText(
        $panel,
        $utf8
    )

$importLine =
    'import { A1ConnectExtendedTaskPanel } from "./A1ConnectExtendedTaskPanel";'

if (-not $text.Contains($importLine)) {
    $anchor =
        'import { A1ConnectAdditionalTaskPanel } from "./A1ConnectAdditionalTaskPanel";'

    if (-not $text.Contains($anchor)) {
        throw "Extended task import anchor not found."
    }

    $text = $text.Replace(
        $anchor,
        $anchor +
        [Environment]::NewLine +
        $importLine
    )
}

$personalMarker =
    'taskKind="personal-answer"'

if (-not $text.Contains($personalMarker)) {
    $anchor =
        '      <div className="a1-connect-native-gate">'

    if (-not $text.Contains($anchor)) {
        throw "Extended task render anchor not found."
    }

    $render = @'
      {selectedLanguageCode &&
      selectedLesson?.lessonId ===
        "a1-connect-personal-questions" ? (
        <>
          <A1ConnectExtendedTaskPanel
            languageCode={selectedLanguageCode}
            taskKind="personal-answer"
          />
          <A1ConnectExtendedTaskPanel
            languageCode={selectedLanguageCode}
            taskKind="personal-question"
          />
        </>
      ) : null}

      {selectedLanguageCode &&
      selectedLesson?.lessonId ===
        "a1-connect-complete-social-exchange" ? (
        <A1ConnectExtendedTaskPanel
          languageCode={selectedLanguageCode}
          taskKind="reciprocal-exchange"
        />
      ) : null}

'@

    $text = $text.Replace(
        $anchor,
        $render + $anchor
    )
}

[System.IO.File]::WriteAllText(
    $panel,
    $text,
    $utf8
)

$tasks = Join-Path $app "src\core\learning\CefrA1ConnectExtendedExecutableTasks.ts"
$completion = Join-Path $app "src\application\learning\CefrA1ConnectExtendedTaskCompletionService.ts"
$taskPanel = Join-Path $app "src\ui\learning\A1ConnectExtendedTaskPanel.tsx"
$safety = Join-Path $app "src\core\learning\CefrA1ConnectImmediateEvidenceCoverageSafety.ts"

foreach ($file in @(
    $tasks,
    $completion,
    $taskPanel,
    $safety
)) {
    if (-not (Test-Path $file)) {
        throw "Sprint 1335-1340 source missing: $file"
    }
}

$checks = @{
    $tasks = @(
        '"a1-connect-evidence-personal-answer"',
        '"a1-connect-evidence-personal-question"',
        '"a1-connect-evidence-reciprocal-exchange"',
        'evidenceOnCorrectSubmissionOnly: true'
    )
    $completion = @(
        'if (!evaluation.evidenceEligible)',
        'recordUserEvidence({'
    )
    $taskPanel = @(
        'Cevabı Gönder',
        'service.submit({'
    )
    $panel = @(
        'taskKind="personal-answer"',
        'taskKind="personal-question"',
        'taskKind="reciprocal-exchange"'
    )
    $safety = @(
        'immediateExecutableEvidenceDefinitions:',
        '6',
        'delayedRetrievalMayBeSimulated:',
        'false'
    )
}

foreach ($entry in $checks.GetEnumerator()) {
    foreach ($marker in $entry.Value) {
        if (-not (
            Select-String `
                -Path $entry.Key `
                -SimpleMatch `
                -Pattern $marker `
                -Quiet
        )) {
            throw "Required Sprint 1335-1340 marker missing: $marker"
        }
    }
}

Write-Host "SPRINT-1335-1340 SOURCE CHECK PASSED"

Set-Location $app

$targets = @(
    "src/core/learning/CefrA1ConnectExtendedExecutableTasks.test.ts",
    "src/application/learning/CefrA1ConnectExtendedTaskEvaluation.test.ts",
    "src/application/learning/CefrA1ConnectExtendedTaskCompletionService.test.ts",
    "src/core/learning/CefrA1ConnectImmediateEvidenceCoverageSafety.test.ts",
    "src/ui/learning/A1ConnectExtendedTaskPanel.test.ts",
    "src/core/learning/CefrA1ConnectAdditionalExecutableTasks.test.ts",
    "src/application/learning/CefrA1ConnectChoiceTaskCompletionService.test.ts",
    "src/core/learning/CefrA1ConnectGreetingComprehensionTask.test.ts",
    "src/application/learning/CefrA1ConnectGreetingTaskCompletionService.test.ts",
    "src/application/learning/CefrA1ConnectRuntimeEvidenceService.test.ts"
)

& npx vitest run $targets
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1335-1340 target tests failed."
}

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Full regression failed."
}

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Production build failed."
}

Write-Host "SPRINT-1335-1340 VERIFICATION COMPLETE"
