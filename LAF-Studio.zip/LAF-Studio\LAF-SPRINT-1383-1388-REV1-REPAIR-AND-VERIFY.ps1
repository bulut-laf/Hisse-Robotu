﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$panel = Join-Path $app "src\ui\learning\A1ConnectNativeLearningPanel.tsx"

if (-not (Test-Path $panel)) {
    throw "A1ConnectNativeLearningPanel.tsx missing."
}

$utf8 =
    New-Object System.Text.UTF8Encoding($false)

$text =
    [System.IO.File]::ReadAllText(
        $panel,
        $utf8
    )

# 1) Parent refresh counter/callback: insert once before the existing selectLanguage function.
if (-not $text.Contains(
    'const refreshEvidenceViews = () =>'
)) {
    $anchor =
        '  const selectLanguage = ('

    $anchorIndex =
        $text.IndexOf($anchor)

    if ($anchorIndex -lt 0) {
        throw "Evidence refresh state anchor not found."
    }

    $insert = @'
  const [
    evidenceRefreshToken,
    setEvidenceRefreshToken,
  ] = useState(0);

  const refreshEvidenceViews = () => {
    setEvidenceRefreshToken(
      value => value + 1,
    );
  };

'@

    $text =
        $text.Insert(
            $anchorIndex,
            $insert
        )
}

function Add-EvidenceRefreshCallback {
    param(
        [string]$Source,
        [string]$ComponentPattern,
        [string]$IdentityLabel
    )

    $matches =
        [regex]::Matches(
            $Source,
            $ComponentPattern,
            [System.Text.RegularExpressions.RegexOptions]::Singleline
        )

    if ($matches.Count -ne 1) {
        throw "Expected exactly one task component for $IdentityLabel; found $($matches.Count)."
    }

    $block =
        $matches[0].Value

    if ($block.Contains(
        'onEvidencePersisted={'
    )) {
        return $Source
    }

    $closingIndex =
        $block.LastIndexOf('/>')

    if ($closingIndex -lt 0) {
        throw "Task component closing marker missing for $IdentityLabel."
    }

    $lineStart =
        $block.LastIndexOf(
            "`n",
            $closingIndex
        )

    if ($lineStart -lt 0) {
        $indent = "        "
    }
    else {
        $closingLine =
            $block.Substring(
                $lineStart + 1,
                $closingIndex - ($lineStart + 1)
            )
        $indent =
            [regex]::Match(
                $closingLine,
                '^\s*'
            ).Value
    }

    $propIndent =
        $indent + "  "

    $callback =
        $propIndent +
        "onEvidencePersisted={`n" +
        $propIndent +
        "  refreshEvidenceViews`n" +
        $propIndent +
        "}`n"

    $newBlock =
        $block.Insert(
            $closingIndex,
            $callback
        )

    return $Source.Substring(
        0,
        $matches[0].Index
    ) +
    $newBlock +
    $Source.Substring(
        $matches[0].Index +
        $matches[0].Length
    )
}

# 2) Bind all six real executable task instances.
$text = Add-EvidenceRefreshCallback `
    -Source $text `
    -ComponentPattern '<A1ConnectGreetingComprehensionTaskPanel\b[\s\S]*?/>' `
    -IdentityLabel 'greeting-comprehension'

$text = Add-EvidenceRefreshCallback `
    -Source $text `
    -ComponentPattern '<A1ConnectAdditionalTaskPanel\b(?:(?!<A1ConnectAdditionalTaskPanel)[\s\S])*?taskKind="greeting-response"[\s\S]*?/>' `
    -IdentityLabel 'greeting-response'

$text = Add-EvidenceRefreshCallback `
    -Source $text `
    -ComponentPattern '<A1ConnectAdditionalTaskPanel\b(?:(?!<A1ConnectAdditionalTaskPanel)[\s\S])*?taskKind="self-introduction"[\s\S]*?/>' `
    -IdentityLabel 'self-introduction'

$text = Add-EvidenceRefreshCallback `
    -Source $text `
    -ComponentPattern '<A1ConnectExtendedTaskPanel\b(?:(?!<A1ConnectExtendedTaskPanel)[\s\S])*?taskKind="personal-answer"[\s\S]*?/>' `
    -IdentityLabel 'personal-answer'

$text = Add-EvidenceRefreshCallback `
    -Source $text `
    -ComponentPattern '<A1ConnectExtendedTaskPanel\b(?:(?!<A1ConnectExtendedTaskPanel)[\s\S])*?taskKind="personal-question"[\s\S]*?/>' `
    -IdentityLabel 'personal-question'

$text = Add-EvidenceRefreshCallback `
    -Source $text `
    -ComponentPattern '<A1ConnectExtendedTaskPanel\b(?:(?!<A1ConnectExtendedTaskPanel)[\s\S])*?taskKind="reciprocal-exchange"[\s\S]*?/>' `
    -IdentityLabel 'reciprocal-exchange'

# 3) Bind the same token to coverage panel.
$unitPattern =
    '<A1ConnectUnitRuntimePanel\b[\s\S]*?/>'

$unitMatches =
    [regex]::Matches(
        $text,
        $unitPattern,
        [System.Text.RegularExpressions.RegexOptions]::Singleline
    )

if ($unitMatches.Count -ne 1) {
    throw "Expected exactly one A1ConnectUnitRuntimePanel; found $($unitMatches.Count)."
}

$unitBlock =
    $unitMatches[0].Value

if (-not $unitBlock.Contains(
    'evidenceRefreshToken={'
)) {
    $closingIndex =
        $unitBlock.LastIndexOf('/>')

    $unitInsert = @'
          evidenceRefreshToken={
            evidenceRefreshToken
          }
'@

    $newUnitBlock =
        $unitBlock.Insert(
            $closingIndex,
            $unitInsert
        )

    $text =
        $text.Substring(
            0,
            $unitMatches[0].Index
        ) +
        $newUnitBlock +
        $text.Substring(
            $unitMatches[0].Index +
            $unitMatches[0].Length
        )
}

# 4) Bind the same token to advisory/continuity panel.
$continuityPattern =
    '<A1ConnectContinuityPanel\b[\s\S]*?/>'

$continuityMatches =
    [regex]::Matches(
        $text,
        $continuityPattern,
        [System.Text.RegularExpressions.RegexOptions]::Singleline
    )

if ($continuityMatches.Count -ne 1) {
    throw "Expected exactly one A1ConnectContinuityPanel; found $($continuityMatches.Count)."
}

$continuityBlock =
    $continuityMatches[0].Value

if (-not $continuityBlock.Contains(
    'evidenceRefreshToken={'
)) {
    $closingIndex =
        $continuityBlock.LastIndexOf('/>')

    $continuityInsert = @'
        evidenceRefreshToken={
          evidenceRefreshToken
        }
'@

    $newContinuityBlock =
        $continuityBlock.Insert(
            $closingIndex,
            $continuityInsert
        )

    $text =
        $text.Substring(
            0,
            $continuityMatches[0].Index
        ) +
        $newContinuityBlock +
        $text.Substring(
            $continuityMatches[0].Index +
            $continuityMatches[0].Length
        )
}

[System.IO.File]::WriteAllText(
    $panel,
    $text,
    $utf8
)

# 5) Structural verification after write.
$text =
    [System.IO.File]::ReadAllText(
        $panel,
        $utf8
    )

$refreshDeclarationCount =
    [regex]::Matches(
        $text,
        'const\s+refreshEvidenceViews\s*=\s*\('
    ).Count

if ($refreshDeclarationCount -ne 1) {
    throw "Expected exactly one refreshEvidenceViews declaration; found $refreshDeclarationCount."
}

$callbackBindingCount =
    [regex]::Matches(
        $text,
        'onEvidencePersisted\s*=\s*\{\s*refreshEvidenceViews\s*\}'
    ).Count

if ($callbackBindingCount -ne 6) {
    throw "Expected six task evidence refresh bindings; found $callbackBindingCount."
}

$tokenBindingCount =
    [regex]::Matches(
        $text,
        'evidenceRefreshToken\s*=\s*\{\s*evidenceRefreshToken\s*\}'
    ).Count

if ($tokenBindingCount -lt 2) {
    throw "Expected coverage and advisory refresh token bindings; found $tokenBindingCount."
}

$greeting = Join-Path $app "src\ui\learning\A1ConnectGreetingComprehensionTaskPanel.tsx"
$additional = Join-Path $app "src\ui\learning\A1ConnectAdditionalTaskPanel.tsx"
$extended = Join-Path $app "src\ui\learning\A1ConnectExtendedTaskPanel.tsx"
$unit = Join-Path $app "src\ui\learning\A1ConnectUnitRuntimePanel.tsx"
$continuity = Join-Path $app "src\ui\learning\A1ConnectContinuityPanel.tsx"
$signal = Join-Path $app "src\core\learning\CefrA1ConnectEvidenceUiRefreshSignal.ts"
$safety = Join-Path $app "src\core\learning\CefrA1ConnectEvidenceRefreshSafety.ts"

foreach ($file in @(
    $greeting,
    $additional,
    $extended,
    $unit,
    $continuity,
    $signal,
    $safety
)) {
    if (-not (Test-Path $file)) {
        throw "Sprint 1383-1388 Rev1 source missing: $file"
    }
}

$checks = @{
    $greeting = @(
        'onEvidencePersisted?: () => void',
        'if (result.evidencePersisted)',
        'onEvidencePersisted?.()'
    )
    $additional = @(
        'onEvidencePersisted?: () => void',
        'if (result.evidencePersisted)'
    )
    $extended = @(
        'onEvidencePersisted?: () => void',
        'if (result.evidencePersisted)'
    )
    $unit = @(
        'evidenceRefreshToken?: number',
        'evidenceRefreshToken,'
    )
    $continuity = @(
        'evidenceRefreshToken?: number',
        'evidenceRefreshToken,'
    )
    $signal = @(
        'refreshCoverageRequested:',
        'refreshAdvisoryRequested:',
        'automaticLessonSelection: false'
    )
    $safety = @(
        'uiRefreshCreatesEvidence: false',
        'uiRefreshSelectsLesson: false',
        'uiRefreshPerformsProgression: false'
    )
}

foreach ($entry in $checks.GetEnumerator()) {
    foreach ($marker in $entry.Value) {
        if (-not (
            Select-String `
                -Path $entry.Key `
                -SimpleMatch `
                -Pattern $marker `
                -Quiet
        )) {
            throw "Required Sprint 1383-1388 Rev1 marker missing: $marker"
        }
    }
}

Write-Host "SPRINT-1383-1388 REV1 SOURCE CHECK PASSED"

Set-Location $app

$targets = @(
    "src/core/learning/CefrA1ConnectEvidenceUiRefreshSignal.test.ts",
    "src/core/learning/CefrA1ConnectEvidenceRefreshSafety.test.ts",
    "src/ui/learning/A1ConnectEvidenceUiRefreshBinding.test.ts",
    "src/ui/learning/A1ConnectGreetingComprehensionTaskPanel.test.ts",
    "src/ui/learning/A1ConnectAdditionalTaskPanel.test.ts",
    "src/ui/learning/A1ConnectDelayedRetrievalCandidateBinding.test.ts",
    "src/ui/learning/A1ConnectUnitRuntimePanel.test.ts",
    "src/ui/learning/A1ConnectContinuityPanel.advisory.test.ts",
    "src/application/learning/CefrA1ConnectLanguageScopedCoverageReadModel.test.ts",
    "src/application/learning/CefrA1ConnectLanguageScopedAdvisoryReadModel.test.ts"
)

& npx vitest run $targets
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1383-1388 Rev1 target tests failed."
}

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Full regression failed."
}

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Production build failed."
}

Write-Host "SPRINT-1383-1388 REV1 VERIFICATION COMPLETE"
