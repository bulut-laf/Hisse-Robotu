import {
  describe,
  expect,
  it,
} from "vitest";

import {
  AI_TEACHER_SURFACE_BINDINGS,
  getAiTeacherSurfaceBinding,
} from "./AiTeacherCrossStudioConsistency";

describe("AI Teacher cross-Studio inventory", () => {
  it("binds every approved V1 surface explicitly", () => {
    expect(
      AI_TEACHER_SURFACE_BINDINGS.map(
        item => item.surfaceId,
      ),
    ).toEqual([
      "grammar-lab",
      "reading",
      "listening",
      "writing",
      "speaking",
      "dialogue",
      "cefr-learning-path",
      "translation-studio",
      "text-workshop",
    ]);
  });

  it("keeps learning surfaces in teacher or authoritative mixed mode", () => {
    for (const surfaceId of [
      "grammar-lab",
      "reading",
      "listening",
      "writing",
      "speaking",
      "dialogue",
    ] as const) {
      const binding =
        getAiTeacherSurfaceBinding(surfaceId);

      expect(binding.classification).toBe(
        "AI_TEACHER",
      );
      expect(
        binding.learnerAttemptFirstApplies,
      ).toBe(true);
    }

    expect(
      getAiTeacherSurfaceBinding(
        "cefr-learning-path",
      ).classification,
    ).toBe("MIXED_WITH_AUTHORITATIVE_CONTEXT");
  });

  it("preserves Translation Studio and Text Workshop as productivity AI", () => {
    for (const surfaceId of [
      "translation-studio",
      "text-workshop",
    ] as const) {
      const binding =
        getAiTeacherSurfaceBinding(surfaceId);

      expect(binding.classification).toBe(
        "AI_PRODUCTIVITY_TOOL",
      );
      expect(
        binding.learnerAttemptFirstApplies,
      ).toBe(false);
      expect(
        binding
          .legitimateToolOutputGenerationPreserved,
      ).toBe(true);
    }
  });
});
