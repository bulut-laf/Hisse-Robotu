﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$pagePath =
    Join-Path $app "src\ui\pages\LearningStudioPage.tsx"

$utf8 =
    New-Object System.Text.UTF8Encoding($false)

function Read-Utf8([string]$path) {
    return [System.IO.File]::ReadAllText(
        $path,
        $utf8
    )
}

function Write-Utf8(
    [string]$path,
    [string]$text
) {
    [System.IO.File]::WriteAllText(
        $path,
        $text,
        $utf8
    )
}

$required = @(
    "src\application\learning\CefrA1AuthoritativeJourneyView.ts",
    "src\application\learning\CefrA1AuthoritativeJourneyView.test.ts",
    "src\core\learning\CefrA1AuthoritativeJourneySafety.ts",
    "src\core\learning\CefrA1AuthoritativeJourneySafety.test.ts",
    "src\ui\learning\A1AuthoritativeJourneyPanel.tsx",
    "src\ui\learning\A1AuthoritativeJourneyPanel.css"
)

foreach ($relative in $required) {
    if (-not (Test-Path (Join-Path $app $relative))) {
        throw "Sprint 1491-1496 required file missing: $relative"
    }
}

if (-not (Test-Path $pagePath)) {
    throw "LearningStudioPage.tsx missing."
}

$page = Read-Utf8 $pagePath

$journeyImport =
    'import { A1AuthoritativeJourneyPanel } from "../learning/A1AuthoritativeJourneyPanel";'

if (-not $page.Contains($journeyImport)) {
    $connectImportPattern =
        '(?ms)import\s*\{\s*A1ConnectNativeLearningPanel\s*,?\s*\}\s*from\s*["'']\.\./learning/A1ConnectNativeLearningPanel["''];'

    $matches =
        [regex]::Matches(
            $page,
            $connectImportPattern
        )

    if ($matches.Count -ne 1) {
        throw "Expected exactly one A1 CONNECT native panel import seam; found $($matches.Count)."
    }

    $connectImport =
        $matches[0].Value

    $page =
        $page.Replace(
            $connectImport,
            $connectImport +
              "`r`n" +
              $journeyImport
        )
}

if (-not $page.Contains(
    "<A1AuthoritativeJourneyPanel />"
)) {
    $connectRenderPattern =
        '<A1ConnectNativeLearningPanel\s*/>'

    $matches =
        [regex]::Matches(
            $page,
            $connectRenderPattern
        )

    if ($matches.Count -ne 1) {
        throw "Expected exactly one A1 CONNECT native panel render seam; found $($matches.Count)."
    }

    $connectRender =
        $matches[0].Value

    $page =
        [regex]::Replace(
            $page,
            $connectRenderPattern,
            "<A1AuthoritativeJourneyPanel />`r`n          " +
              $connectRender,
            1
        )
}

Write-Utf8 $pagePath $page

$positiveChecks = @(
    @(
      "src\application\learning\CefrA1AuthoritativeJourneyView.ts",
      'platform.readLanguageEvidence('
    ),
    @(
      "src\application\learning\CefrA1AuthoritativeJourneyView.ts",
      '"a1-connect"'
    ),
    @(
      "src\application\learning\CefrA1AuthoritativeJourneyView.ts",
      '"a1-navigate"'
    ),
    @(
      "src\application\learning\CefrA1AuthoritativeJourneyView.ts",
      'totalImmediateEvidenceCount: 12'
    ),
    @(
      "src\core\learning\CefrA1AuthoritativeJourneySafety.ts",
      'unapprovedA1SlicesIncluded: false'
    ),
    @(
      "src\ui\learning\A1AuthoritativeJourneyPanel.tsx",
      'A1 Öğrenme Yolculuğu'
    ),
    @(
      "src\ui\learning\A1AuthoritativeJourneyPanel.tsx",
      'scrollIntoView'
    ),
    @(
      "src\ui\pages\LearningStudioPage.tsx",
      '<A1AuthoritativeJourneyPanel />'
    ),
    @(
      "src\ui\pages\LearningStudioPage.tsx",
      '<A1ConnectNativeLearningPanel />'
    ),
    @(
      "src\ui\pages\LearningStudioPage.tsx",
      '<A1NavigateNativeLearningPanel />'
    )
)

foreach ($check in $positiveChecks) {
    $path = Join-Path $app $check[0]

    if (-not (
        Select-String `
            -Path $path `
            -SimpleMatch `
            -Pattern $check[1] `
            -Quiet
    )) {
        throw "Sprint 1491-1496 source marker missing: $($check[1])"
    }
}

$journeyPath =
    Join-Path $app "src\application\learning\CefrA1AuthoritativeJourneyView.ts"
$journeyText =
    [System.IO.File]::ReadAllText($journeyPath)

if ($journeyText.Contains(
    "a1-describe"
)) {
    throw "Unapproved A1 DESCRIBE slice leaked into production journey."
}

Write-Host "SPRINT-1491-1496 SOURCE CHECK PASSED"

Set-Location $app

Write-Host ""
Write-Host "CHECKPOINT 1/2 — Sprint 1491-1493 cross-slice persisted journey view"

& npx vitest run @(
    "src/application/learning/CefrA1AuthoritativeJourneyView.test.ts",
    "src/core/learning/CefrA1AuthoritativeJourneySafety.test.ts",
    "src/application/learning/CefrA1NavigatePersistedEvidenceView.test.ts",
    "src/core/learning/CefrA1NavigatePersistedEvidenceSafety.test.ts",
    "src/core/learning/CefrProductionRuntimeRegistryEnforcement.test.ts"
)

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1491-1493 target checkpoint failed."
}

Write-Host "SPRINT-1491-1493 TARGET CHECKPOINT PASSED"

Write-Host ""
Write-Host "CHECKPOINT 2/2 — Sprint 1494-1496 native /learning journey integration"

& npx vitest run @(
    "src/application/learning/CefrA1AuthoritativeJourneyView.test.ts",
    "src/core/learning/CefrA1AuthoritativeJourneySafety.test.ts",
    "src/core/learning/CefrA1NavigateRuntimeSliceDefinition.test.ts",
    "src/application/learning/CefrA1NavigateProductionRuntime.test.ts",
    "src/application/learning/CefrProductionRuntimeDelayedRetrievalVisibility.test.ts"
)

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1494-1496 target checkpoint failed."
}

Write-Host "SPRINT-1494-1496 TARGET CHECKPOINT PASSED"

Write-Host ""
Write-Host "FINAL 6-SPRINT BLOCK REGRESSION — one full run only"

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1491-1496 final full regression failed."
}

Write-Host ""
Write-Host "FINAL PRODUCTION BUILD"

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1491-1496 production build failed."
}

Write-Host ""
Write-Host "SPRINT-1491-1496 VERIFICATION COMPLETE"
