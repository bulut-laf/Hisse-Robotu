﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$core = Join-Path $app "src\core\learning"

$auditPath =
    Join-Path $core "CefrProductionRuntimeEvidenceEligibilityAudit.ts"

if (-not (Test-Path $auditPath)) {
    throw "CefrProductionRuntimeEvidenceEligibilityAudit.ts missing."
}

$utf8 =
    New-Object System.Text.UTF8Encoding($false)

function Read-Utf8([string]$path) {
    return [System.IO.File]::ReadAllText(
        $path,
        $utf8
    )
}

function Write-Utf8(
    [string]$path,
    [string]$text
) {
    [System.IO.File]::WriteAllText(
        $path,
        $text,
        $utf8
    )
}

$backupPath =
    $auditPath +
    ".sprint1503-1505-rev4-backup"

if (-not (Test-Path $backupPath)) {
    Copy-Item `
        -LiteralPath $auditPath `
        -Destination $backupPath `
        -Force
}

$audit =
    Read-Utf8 $auditPath

$describeDelayedId =
    "a1-describe-evidence-delayed-retrieval"

# ------------------------------------------------------------
# 1. Remove every previously injected DESCRIBE delayed-retrieval
#    line from this audit file.
#
#    Rev1 inserted it using a loose text anchor and one occurrence
#    landed in the import/header area, leaving the TypeScript parser
#    in an invalid state. The ID did not exist in this file before
#    this block, so removing all injected lines is safe here.
# ------------------------------------------------------------

$lines =
    [regex]::Split(
        $audit,
        "\r?\n"
    )

$cleanLines =
    New-Object System.Collections.Generic.List[string]

$removedCount = 0

foreach ($line in $lines) {
    if ($line.Contains($describeDelayedId)) {
        $removedCount++
        continue
    }

    $cleanLines.Add($line)
}

if ($removedCount -lt 1) {
    throw "Rev4 expected at least one malformed/injected A1 DESCRIBE delayed-retrieval line."
}

$audit =
    $cleanLines -join [Environment]::NewLine

# ------------------------------------------------------------
# 2. Find the real policy-gated constant structurally.
#    Do not search for a neighboring CONNECT/NAVIGATE string.
# ------------------------------------------------------------

$constantName =
    "LAF_POLICY_GATED_DELAYED_RETRIEVAL_EVIDENCE_IDS"

$constantIndex =
    $audit.IndexOf($constantName)

if ($constantIndex -lt 0) {
    throw "Policy-gated delayed-retrieval constant not found."
}

$equalsIndex =
    $audit.IndexOf(
        "=",
        $constantIndex
    )

if ($equalsIndex -lt 0) {
    throw "Policy-gated delayed-retrieval constant initializer '=' not found."
}

$arrayOpenIndex =
    $audit.IndexOf(
        "[",
        $equalsIndex
    )

if ($arrayOpenIndex -lt 0) {
    throw "Policy-gated delayed-retrieval array opening '[' not found."
}

# Find the matching closing bracket for the initializer array.
$depth = 0
$arrayCloseIndex = -1

for (
    $i = $arrayOpenIndex;
    $i -lt $audit.Length;
    $i++
) {
    $char = $audit[$i]

    if ($char -eq "[") {
        $depth++
        continue
    }

    if ($char -eq "]") {
        $depth--

        if ($depth -eq 0) {
            $arrayCloseIndex = $i
            break
        }
    }
}

if ($arrayCloseIndex -lt 0) {
    throw "Policy-gated delayed-retrieval array closing ']' not found."
}

$arrayText =
    $audit.Substring(
        $arrayOpenIndex,
        $arrayCloseIndex -
        $arrayOpenIndex +
        1
    )

if (-not $arrayText.Contains(
    "a1-connect-evidence-delayed-retrieval"
)) {
    throw "CONNECT delayed-retrieval authority missing from policy array."
}

if (-not $arrayText.Contains(
    "a1-navigate-evidence-delayed-retrieval"
)) {
    throw "NAVIGATE delayed-retrieval authority missing from policy array."
}

# Deduce item indentation from NAVIGATE row.
$navigateMatch =
    [regex]::Match(
        $arrayText,
        '(?m)^(?<indent>[ \t]*)"a1-navigate-evidence-delayed-retrieval",?[ \t]*$'
    )

$itemIndent =
    if ($navigateMatch.Success) {
        $navigateMatch.Groups["indent"].Value
    }
    else {
        "  "
    }

$insertText =
    $itemIndent +
    '"' +
    $describeDelayedId +
    '",' +
    [Environment]::NewLine

$audit =
    $audit.Insert(
        $arrayCloseIndex,
        $insertText
    )

# ------------------------------------------------------------
# 3. Structural sanity checks.
# ------------------------------------------------------------

$occurrenceCount =
    [regex]::Matches(
        $audit,
        [regex]::Escape($describeDelayedId)
    ).Count

if ($occurrenceCount -ne 1) {
    throw "Expected exactly one A1 DESCRIBE delayed-retrieval ID after repair; found $occurrenceCount."
}

$repairedConstantIndex =
    $audit.IndexOf($constantName)

$repairedEqualsIndex =
    $audit.IndexOf(
        "=",
        $repairedConstantIndex
    )

$repairedArrayOpen =
    $audit.IndexOf(
        "[",
        $repairedEqualsIndex
    )

$repairedArrayClose = -1
$depth = 0

for (
    $i = $repairedArrayOpen;
    $i -lt $audit.Length;
    $i++
) {
    $char = $audit[$i]

    if ($char -eq "[") {
        $depth++
        continue
    }

    if ($char -eq "]") {
        $depth--

        if ($depth -eq 0) {
            $repairedArrayClose = $i
            break
        }
    }
}

if ($repairedArrayClose -lt 0) {
    throw "Repaired policy array closing bracket missing."
}

$repairedArrayText =
    $audit.Substring(
        $repairedArrayOpen,
        $repairedArrayClose -
        $repairedArrayOpen +
        1
    )

if (-not $repairedArrayText.Contains(
    $describeDelayedId
)) {
    throw "A1 DESCRIBE delayed-retrieval ID was not inserted into the real policy array."
}

# Ensure the injected ID is not before the policy constant.
$describeIndex =
    $audit.IndexOf($describeDelayedId)

if ($describeIndex -lt $repairedArrayOpen) {
    throw "A1 DESCRIBE delayed-retrieval ID still exists outside the policy array."
}

Write-Utf8 $auditPath $audit

Write-Host "SPRINT-1503-1505 REV4 AUDIT PARSE REPAIR APPLIED"
Write-Host "Removed malformed/injected rows: $removedCount"
Write-Host "Final DESCRIBE delayed-retrieval occurrences: $occurrenceCount"

Set-Location $app

# ------------------------------------------------------------
# 4. First prove the exact parser root cause is gone with the audit
#    test only. This is part of checkpoint 3, not a repeated earlier
#    checkpoint.
# ------------------------------------------------------------

Write-Host ""
Write-Host "REV4 PARSE PROBE — production eligibility audit"

& npx vitest run `
    "src/core/learning/CefrProductionRuntimeEvidenceEligibilityAudit.test.ts"

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1503-1505 Rev4 audit parse probe failed."
}

Write-Host "REV4 AUDIT PARSE PROBE PASSED"

# ------------------------------------------------------------
# 5. Resume only failed Sprint 1503-1505 checkpoint.
#    Sprint 1497-1499 and 1500-1502 already passed and are not rerun.
# ------------------------------------------------------------

Write-Host ""
Write-Host "CHECKPOINT 3/3 — Sprint 1503-1505 Rev4 production runtime integration"

& npx vitest run @(
    "src/core/learning/CefrA1DescribeRuntimeSliceDefinition.test.ts",
    "src/core/learning/CefrProductionRuntimeSliceRegistry.test.ts",
    "src/core/learning/CefrProductionRuntimeRegistryEnforcement.test.ts",
    "src/core/learning/CefrProductionRuntimeEvidenceEligibilityAudit.test.ts",
    "src/application/learning/CefrProductionRuntimeDelayedRetrievalVisibility.test.ts",
    "src/application/learning/CefrA1DescribeProductionRuntime.test.ts",
    "src/application/learning/CefrProductionRuntimePlatform.test.ts"
)

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1503-1505 Rev4 target checkpoint failed."
}

Write-Host "SPRINT-1503-1505 REV4 TARGET CHECKPOINT PASSED"

# ------------------------------------------------------------
# 6. Required block final verification.
#    Earlier full regression never ran because checkpoint 3 failed.
# ------------------------------------------------------------

Write-Host ""
Write-Host "FINAL 9-SPRINT BLOCK REGRESSION — one full run only"

& npm run test

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1497-1505 Rev4 final full regression failed."
}

Write-Host ""
Write-Host "FINAL PRODUCTION BUILD"

& npm run build

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1497-1505 Rev4 production build failed."
}

Write-Host ""
Write-Host "SPRINT-1497-1505 REV4 VERIFICATION COMPLETE"
