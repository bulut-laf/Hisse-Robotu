import fs from "node:fs";
import path from "node:path";

const root = "D:\\Projects\\LAF-Studio";

const hookFile = path.join(
  root,
  "app",
  "src",
  "ui",
  "hooks",
  "useLearningSession.ts",
);

const lessonFile = path.join(
  root,
  "app",
  "src",
  "ui",
  "pages",
  "LessonPage.tsx",
);

function read(file) {
  if (!fs.existsSync(file)) {
    throw new Error(`Required file not found: ${file}`);
  }
  return fs.readFileSync(file, "utf8");
}

function write(file, source) {
  fs.writeFileSync(file, source, "utf8");
}

function eolOf(source) {
  return source.includes("\r\n") ? "\r\n" : "\n";
}

function count(source, needle) {
  return source.split(needle).length - 1;
}

function insertAfterFirstLine(
  source,
  exactLine,
  insertedLines,
  description,
) {
  const eol = eolOf(source);
  const lines = source.split(/\r?\n/);
  const index = lines.findIndex(
    line => line.trim() === exactLine.trim(),
  );

  if (index < 0) {
    throw new Error(
      `${description}: anchor line not found: ${exactLine}`,
    );
  }

  lines.splice(index + 1, 0, ...insertedLines);
  return lines.join(eol);
}

function insertBeforeFirstLine(
  source,
  exactLine,
  insertedLines,
  description,
) {
  const eol = eolOf(source);
  const lines = source.split(/\r?\n/);
  const index = lines.findIndex(
    line => line.trim() === exactLine.trim(),
  );

  if (index < 0) {
    throw new Error(
      `${description}: anchor line not found: ${exactLine}`,
    );
  }

  lines.splice(index, 0, ...insertedLines);
  return lines.join(eol);
}

function patchHook() {
  let source = read(hookFile);

  if (!source.includes("  sessionId: string;")) {
    source = insertAfterFirstLine(
      source,
      "isCompleted: boolean;",
      [
        "  sessionId: string;",
        "  completedAt: Date | undefined;",
      ],
      "useLearningSession interface",
    );
  }

  if (
    !source.includes(
      "    sessionId: sessionResult.session.id,",
    )
  ) {
    source = insertAfterFirstLine(
      source,
      "isCompleted: sessionResult.isCompleted,",
      [
        "    sessionId: sessionResult.session.id,",
        "    completedAt: sessionResult.session.completedAt,",
      ],
      "useLearningSession return",
    );
  }

  const interfaceSessionIdCount =
    count(source, "  sessionId: string;");
  const interfaceCompletedAtCount =
    count(source, "  completedAt: Date | undefined;");
  const returnSessionIdCount =
    count(
      source,
      "    sessionId: sessionResult.session.id,",
    );
  const returnCompletedAtCount =
    count(
      source,
      "    completedAt: sessionResult.session.completedAt,",
    );

  if (
    interfaceSessionIdCount !== 1 ||
    interfaceCompletedAtCount !== 1 ||
    returnSessionIdCount !== 1 ||
    returnCompletedAtCount !== 1
  ) {
    throw new Error(
      "useLearningSession validation failed: " +
        `interfaceSessionId=${interfaceSessionIdCount}, ` +
        `interfaceCompletedAt=${interfaceCompletedAtCount}, ` +
        `returnSessionId=${returnSessionIdCount}, ` +
        `returnCompletedAt=${returnCompletedAtCount}`,
    );
  }

  write(hookFile, source);
  console.log("OK: useLearningSession runtime completion fields");
}

function patchLessonPage() {
  let source = read(lessonFile);
  const eol = eolOf(source);

  const runtimeServiceImport =
    'import { CefrGuidanceRuntimeProfileService } from "../../application/learning/CefrGuidanceRuntimeProfileService";';
  const profileRepositoryImport =
    'import { LocalStorageCefrGuidanceProfileRepository } from "../storage/LocalStorageCefrGuidanceProfileRepository";';

  if (!source.includes(runtimeServiceImport)) {
    const storageImportEnd =
      '} from "../storage/LocalStorageSessionStorage";';

    const index = source.indexOf(storageImportEnd);
    if (index < 0) {
      throw new Error(
        "LessonPage imports: LocalStorageSessionStorage import end not found.",
      );
    }

    const end = index + storageImportEnd.length;
    source =
      source.slice(0, end) +
      eol +
      runtimeServiceImport +
      eol +
      profileRepositoryImport +
      source.slice(end);
  } else if (!source.includes(profileRepositoryImport)) {
    source = source.replace(
      runtimeServiceImport,
      runtimeServiceImport +
        eol +
        profileRepositoryImport,
    );
  }

  const lines = source.split(/\r?\n/);

  const learningSessionCallIndex = lines.findIndex(
    line => line.includes("} = useLearningSession("),
  );

  if (learningSessionCallIndex < 0) {
    throw new Error(
      "LessonPage learning-session destructuring boundary not found.",
    );
  }

  if (!source.includes("    sessionId,")) {
    let isCompletedIndex = -1;

    for (let i = learningSessionCallIndex - 1; i >= 0; i--) {
      if (lines[i].trim() === "isCompleted,") {
        isCompletedIndex = i;
        break;
      }
      if (lines[i].includes("const {")) {
        break;
      }
    }

    if (isCompletedIndex < 0) {
      throw new Error(
        "LessonPage learning-session isCompleted destructure anchor not found.",
      );
    }

    lines.splice(
      isCompletedIndex + 1,
      0,
      "    sessionId,",
      "    completedAt,",
    );
    source = lines.join(eol);
  }

  const serviceMarker =
    "const cefrRuntimeProfileService = useMemo(";

  if (!source.includes(serviceMarker)) {
    source = insertBeforeFirstLine(
      source,
      "const audioRecorderService = useMemo(",
      [
        "  const cefrRuntimeProfileService = useMemo(",
        "    () =>",
        "      new CefrGuidanceRuntimeProfileService(",
        "        new LocalStorageCefrGuidanceProfileRepository(),",
        "      ),",
        "    [],",
        "  );",
        "",
      ],
      "LessonPage runtime profile service",
    );
  }

  if (
    !source.includes(
      "cefrRuntimeProfileService.recordLearningSessionCompletion({",
    )
  ) {
    source = insertBeforeFirstLine(
      source,
      "const normalizedAnswer = answer.trim();",
      [
        "  useEffect(() => {",
        "    if (!isCompleted || !completedAt) {",
        "      return;",
        "    }",
        "",
        "    cefrRuntimeProfileService.recordLearningSessionCompletion({",
        "      sessionId,",
        "      completedAt,",
        "    });",
        "  }, [",
        "    cefrRuntimeProfileService,",
        "    completedAt,",
        "    isCompleted,",
        "    sessionId,",
        "  ]);",
        "",
      ],
      "LessonPage completion evidence effect",
    );
  }

  const checks = {
    runtimeServiceImport:
      count(source, runtimeServiceImport),
    profileRepositoryImport:
      count(source, profileRepositoryImport),
    sessionIdDestructure:
      count(source, "    sessionId,"),
    completedAtDestructure:
      count(source, "    completedAt,"),
    runtimeService:
      count(
        source,
        "const cefrRuntimeProfileService = useMemo(",
      ),
    completionWrite:
      count(
        source,
        "cefrRuntimeProfileService.recordLearningSessionCompletion({",
      ),
  };

  for (const [name, value] of Object.entries(checks)) {
    if (value !== 1) {
      throw new Error(
        `LessonPage validation failed: ${name}=${value}`,
      );
    }
  }

  write(lessonFile, source);
  console.log("OK: LessonPage real completion evidence binding");
}

try {
  patchHook();
  patchLessonPage();

  console.log("");
  console.log("SPRINT-1215-1220 REV1 INSTALL COMPLETE");
} catch (error) {
  console.error("");
  console.error("SPRINT-1215-1220 REV1 INSTALL ERROR");
  console.error(
    error instanceof Error ? error.message : String(error),
  );
  process.exit(1);
}
