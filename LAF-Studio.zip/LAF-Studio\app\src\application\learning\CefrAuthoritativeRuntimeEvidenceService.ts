import {
  createLafCefrCapabilityTaxonomyRegistry,
  createLafCefrCompetencyCapabilityMappingRegistry,
} from "../../core/learning/CefrAuthoritativeCapabilityRegistry";
import {
  createLafCefrAuthoritativeCurriculumRegistry,
} from "../../core/learning/CefrAuthoritativeCurriculumRegistry";
import {
  createLafCefrAuthoritativeEvidenceRegistry,
} from "../../core/learning/CefrAuthoritativeEvidenceCatalog";
import type {
  CefrAuthoritativeEvidenceDefinition,
} from "../../core/learning/CefrAuthoritativeEvidenceDefinition";
import type {
  CefrAuthoritativeEvidenceRegistry,
} from "../../core/learning/CefrAuthoritativeEvidenceRegistry";
import {
  resolveCefrAuthoritativeEvidenceRuntimeAuthority,
  type CefrAuthoritativeEvidenceRuntimeAuthority,
} from "../../core/learning/CefrAuthoritativeEvidenceRuntimeAuthority";
import type {
  CefrCapabilityTaxonomyRegistry,
} from "../../core/learning/CefrCapabilityTaxonomyRegistry";
import type {
  CefrCompetencyCapabilityMappingRegistry,
} from "../../core/learning/CefrCompetencyCapabilityMappingRegistry";
import type {
  CefrCurriculumCompetencyRegistry,
} from "../../core/learning/CefrCurriculumCompetencyRegistry";
import type {
  CefrCurriculumCapabilityObservationWriteResult,
} from "../../core/learning/CefrCurriculumCapabilityObservationWrite";
import type {
  CefrGuidanceRuntimeProfileRepository,
} from "./CefrGuidanceRuntimeProfileRepository";
import {
  CefrCurriculumCapabilityObservationWriter,
} from "./CefrCurriculumCapabilityObservationWriter";
import {
  CefrGuidanceRuntimeProfileService,
  type CefrLearningStudioEvidenceWriteResult,
} from "./CefrGuidanceRuntimeProfileService";

export interface CefrAuthoritativeRuntimeEvidenceEventInput {
  readonly evidenceDefinitionId: string;
  readonly eventId: string;
  readonly occurredAt: Date;
  readonly userActionConfirmed: true;
}

export interface CefrAuthoritativeRuntimeEvidenceResult {
  readonly definition:
    CefrAuthoritativeEvidenceDefinition;
  readonly authority:
    CefrAuthoritativeEvidenceRuntimeAuthority;
  readonly evidence:
    CefrLearningStudioEvidenceWriteResult;
  readonly observation:
    CefrCurriculumCapabilityObservationWriteResult;
  readonly sourceLearningItemType: string;
  readonly sourceLearningItemId: string;
  readonly evidenceDefinitionId: string;
  readonly runtimeEvidenceId: string;
  readonly runtimePayloadReference: string;
  readonly capabilityObservationWritten:
    boolean;
  readonly resolvedCapabilityReferences:
    readonly string[];
  readonly masteryAssigned: false;
  readonly competencySuccessAssigned: false;
  readonly cefrLevelAssigned: false;
  readonly progressionPerformed: false;
  readonly automaticStudioLaunchPerformed:
    false;
}

function requireText(
  value: string,
  fieldName: string,
): string {
  const normalized = value.trim();

  if (normalized.length === 0) {
    throw new Error(
      `${fieldName} is required.`,
    );
  }

  return normalized;
}

export function createCefrAuthoritativeRuntimeEvidenceId(
  definition:
    CefrAuthoritativeEvidenceDefinition,
  eventId: string,
): string {
  return [
    requireText(
      definition.runtimeEvidenceNamespace,
      "runtimeEvidenceNamespace",
    ),
    requireText(
      definition.evidenceDefinitionId,
      "evidenceDefinitionId",
    ),
    requireText(
      eventId,
      "eventId",
    ),
  ].join(":");
}

export function createCefrAuthoritativeRuntimePayloadReference(
  definition:
    CefrAuthoritativeEvidenceDefinition,
  eventId: string,
): string {
  return [
    requireText(
      definition.runtimePayloadNamespace,
      "runtimePayloadNamespace",
    ),
    requireText(
      definition.sourceLearningItemId,
      "sourceLearningItemId",
    ),
    requireText(
      definition.evidenceDefinitionId,
      "evidenceDefinitionId",
    ),
    requireText(
      eventId,
      "eventId",
    ),
  ].join(":");
}

export class CefrAuthoritativeRuntimeEvidenceService {
  private readonly evidenceService:
    CefrGuidanceRuntimeProfileService;

  private readonly observationWriter:
    CefrCurriculumCapabilityObservationWriter;

  private readonly evidenceRegistry:
    CefrAuthoritativeEvidenceRegistry;

  private readonly curriculumRegistry:
    CefrCurriculumCompetencyRegistry;

  private readonly capabilityTaxonomyRegistry:
    CefrCapabilityTaxonomyRegistry;

  private readonly competencyCapabilityMappingRegistry:
    CefrCompetencyCapabilityMappingRegistry;

  constructor(
    repository:
      CefrGuidanceRuntimeProfileRepository,
    evidenceRegistry:
      CefrAuthoritativeEvidenceRegistry =
        createLafCefrAuthoritativeEvidenceRegistry(),
    curriculumRegistry:
      CefrCurriculumCompetencyRegistry =
        createLafCefrAuthoritativeCurriculumRegistry(),
    capabilityTaxonomyRegistry:
      CefrCapabilityTaxonomyRegistry =
        createLafCefrCapabilityTaxonomyRegistry(),
    competencyCapabilityMappingRegistry:
      CefrCompetencyCapabilityMappingRegistry =
        createLafCefrCompetencyCapabilityMappingRegistry(),
  ) {
    this.evidenceService =
      new CefrGuidanceRuntimeProfileService(
        repository,
      );

    this.observationWriter =
      new CefrCurriculumCapabilityObservationWriter(
        repository,
        curriculumRegistry,
        capabilityTaxonomyRegistry,
        competencyCapabilityMappingRegistry,
      );

    this.evidenceRegistry =
      evidenceRegistry;
    this.curriculumRegistry =
      curriculumRegistry;
    this.capabilityTaxonomyRegistry =
      capabilityTaxonomyRegistry;
    this.competencyCapabilityMappingRegistry =
      competencyCapabilityMappingRegistry;
  }

  recordUserEvidence(
    input:
      CefrAuthoritativeRuntimeEvidenceEventInput,
  ): CefrAuthoritativeRuntimeEvidenceResult {
    if (input.userActionConfirmed !== true) {
      throw new Error(
        "Authoritative CEFR runtime evidence requires an explicit user action.",
      );
    }

    requireText(
      input.eventId,
      "eventId",
    );

    const authority =
      resolveCefrAuthoritativeEvidenceRuntimeAuthority({
        evidenceRegistry:
          this.evidenceRegistry,
        curriculumRegistry:
          this.curriculumRegistry,
        capabilityTaxonomyRegistry:
          this.capabilityTaxonomyRegistry,
        competencyCapabilityMappingRegistry:
          this.competencyCapabilityMappingRegistry,
        evidenceDefinitionId:
          input.evidenceDefinitionId,
      });

    if (
      !authority.definition ||
      !authority.evidenceDefinitionFound
    ) {
      throw new Error(
        `Unknown authoritative CEFR evidence definition: ${input.evidenceDefinitionId.trim()}`,
      );
    }

    if (!authority.runtimeEvidenceEligible) {
      throw new Error(
        `Authoritative CEFR runtime evidence authority unresolved: ${authority.definition.evidenceDefinitionId}`,
      );
    }

    const definition =
      authority.definition;

    const runtimeEvidenceId =
      createCefrAuthoritativeRuntimeEvidenceId(
        definition,
        input.eventId,
      );

    const runtimePayloadReference =
      createCefrAuthoritativeRuntimePayloadReference(
        definition,
        input.eventId,
      );

    const evidence =
      this.evidenceService
        .recordLearningStudioEvidence({
          evidenceId:
            runtimeEvidenceId,
          observedAt:
            input.occurredAt,
          payloadReference:
            runtimePayloadReference,
        });

    const observation =
      this.observationWriter.write({
        learningItemType:
          definition.sourceLearningItemType,
        learningItemId:
          definition.sourceLearningItemId,
        evidenceId:
          evidence.evidenceId,
      });

    return {
      definition,
      authority,
      evidence,
      observation,
      sourceLearningItemType:
        definition.sourceLearningItemType,
      sourceLearningItemId:
        definition.sourceLearningItemId,
      evidenceDefinitionId:
        definition.evidenceDefinitionId,
      runtimeEvidenceId,
      runtimePayloadReference,
      capabilityObservationWritten:
        observation.capabilityObservationWritten,
      resolvedCapabilityReferences:
        observation.resolvedCapabilityReferences,
      masteryAssigned: false,
      competencySuccessAssigned: false,
      cefrLevelAssigned: false,
      progressionPerformed: false,
      automaticStudioLaunchPerformed: false,
    };
  }
}
