import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrPersonalLanguageProfileState,
  type CefrPersonalLanguageProfileState,
} from "../../core/learning/CefrPersonalLanguageProfileState";
import type {
  CefrGuidanceRuntimeProfileRepository,
} from "./CefrGuidanceRuntimeProfileRepository";
import {
  CefrAuthoritativeRuntimeEvidenceService,
} from "./CefrAuthoritativeRuntimeEvidenceService";

class MemoryRepository
  implements CefrGuidanceRuntimeProfileRepository {
  private state:
    CefrPersonalLanguageProfileState =
      createCefrPersonalLanguageProfileState(
        [],
        [],
      );

  private persisted = false;

  load(): CefrPersonalLanguageProfileState {
    return this.state;
  }

  save(
    state: CefrPersonalLanguageProfileState,
  ): void {
    this.state = state;
    this.persisted = true;
  }

  hasPersistedProfile(): boolean {
    return this.persisted;
  }

  clear(): void {
    this.state =
      createCefrPersonalLanguageProfileState(
        [],
        [],
      );
    this.persisted = false;
  }
}

describe(
  "CefrAuthoritativeRuntimeEvidenceService",
  () => {
    it("preserves the existing A1 CONNECT runtime evidence identity while using generic authority", () => {
      const repository =
        new MemoryRepository();

      const result =
        new CefrAuthoritativeRuntimeEvidenceService(
          repository,
        ).recordUserEvidence({
          evidenceDefinitionId:
            "a1-connect-evidence-greeting-response",
          eventId: "generic-001",
          occurredAt:
            new Date(
              "2026-08-11T20:00:00.000Z",
            ),
          userActionConfirmed: true,
        });

      expect(result).toMatchObject({
        sourceLearningItemType: "lesson",
        sourceLearningItemId:
          "a1-connect-greeting-response",
        evidenceDefinitionId:
          "a1-connect-evidence-greeting-response",
        runtimeEvidenceId:
          "a1-connect-runtime-evidence:a1-connect-evidence-greeting-response:generic-001",
        runtimePayloadReference:
          "a1-connect-runtime:a1-connect-greeting-response:a1-connect-evidence-greeting-response:generic-001",
        capabilityObservationWritten: true,
        resolvedCapabilityReferences: [
          "social-exchange",
        ],
        masteryAssigned: false,
        competencySuccessAssigned: false,
        cefrLevelAssigned: false,
        progressionPerformed: false,
        automaticStudioLaunchPerformed:
          false,
      });

      expect(
        repository.load()
          .capabilityObservationRegistry
          .observations,
      ).toEqual([
        {
          capabilityReference:
            "social-exchange",
          evidenceId:
            "a1-connect-runtime-evidence:a1-connect-evidence-greeting-response:generic-001",
          source: "learning-studio",
          observationalOnly: true,
        },
      ]);
    });

    it("keeps exact-event duplicate suppression across generic evidence and capability observation writes", () => {
      const repository =
        new MemoryRepository();
      const service =
        new CefrAuthoritativeRuntimeEvidenceService(
          repository,
        );

      const input = {
        evidenceDefinitionId:
          "a1-connect-evidence-self-introduction",
        eventId: "generic-duplicate",
        occurredAt:
          new Date(
            "2026-08-11T20:05:00.000Z",
          ),
        userActionConfirmed: true as const,
      };

      const first =
        service.recordUserEvidence(input);
      const second =
        service.recordUserEvidence(input);

      expect(
        first.evidence.evidenceAdded,
      ).toBe(true);
      expect(
        second.evidence.duplicateIgnored,
      ).toBe(true);
      expect(
        second.capabilityObservationWritten,
      ).toBe(false);

      expect(
        repository.load()
          .profileSnapshot
          .evidenceAggregation.evidence,
      ).toHaveLength(1);

      expect(
        repository.load()
          .capabilityObservationRegistry
          .observations,
      ).toHaveLength(1);
    });

    it("rejects unknown evidence before persistence", () => {
      const repository =
        new MemoryRepository();

      expect(() =>
        new CefrAuthoritativeRuntimeEvidenceService(
          repository,
        ).recordUserEvidence({
          evidenceDefinitionId:
            "not-authoritative",
          eventId: "generic-unknown",
          occurredAt:
            new Date(
              "2026-08-11T20:10:00.000Z",
            ),
          userActionConfirmed: true,
        }),
      ).toThrow(
        "Unknown authoritative CEFR evidence definition",
      );

      expect(
        repository.hasPersistedProfile(),
      ).toBe(false);
    });
  },
);
