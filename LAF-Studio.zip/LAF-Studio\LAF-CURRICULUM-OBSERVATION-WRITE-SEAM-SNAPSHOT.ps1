﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$src = Join-Path $root "app\src"
$out = Join-Path $root "LAF_CURRICULUM_OBSERVATION_WRITE_SEAM_SNAPSHOT.txt"

$targets = @(
    "core\learning\CefrCapabilityObservation.ts",
    "core\learning\CefrCapabilityObservation.test.ts",
    "core\learning\CefrCapabilityObservationRegistry.ts",
    "core\learning\CefrCapabilityObservationRegistryRefresh.ts",
    "core\learning\CefrPersonalLanguageProfileState.ts",
    "core\learning\CefrLearningLesson.ts",
    "core\learning\CefrLearningLessonCatalog.ts",
    "core\learning\CefrLearningLessonRuntime.ts",
    "application\learning\CefrGuidanceRuntimeProfileService.ts",
    "core\learning\CefrCurriculumCompetencyMapping.ts",
    "core\learning\CefrCurriculumCompetencyRegistry.ts",
    "core\learning\CefrCurriculumCapabilityObservationEligibility.ts",
    "core\learning\CefrAuthoritativeCurriculumRegistry.ts"
)

$report = New-Object System.Collections.Generic.List[string]

function Add-Line {
    param([string]$Text)
    if ($null -eq $Text) { $Text = "" }
    [void]$report.Add($Text)
}

function Add-Section {
    param([string]$Title)
    Add-Line ""
    Add-Line ("=" * 96)
    Add-Line $Title
    Add-Line ("=" * 96)
}

Add-Line "LAF STUDIO - CURRICULUM OBSERVATION WRITE SEAM SNAPSHOT"
Add-Line ("Generated: " + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
Add-Line "READ ONLY - no project source files are modified."

foreach ($relative in $targets) {
    $file = Join-Path $src $relative

    Add-Section ("FILE: app\src\" + $relative)

    if (-not (Test-Path $file)) {
        Add-Line "(file not found)"
        continue
    }

    $lines = @(Get-Content -Path $file)
    $limit = [Math]::Min($lines.Count, 420)

    for ($i = 0; $i -lt $limit; $i++) {
        Add-Line ("{0,4}: {1}" -f ($i + 1), $lines[$i])
    }

    if ($lines.Count -gt $limit) {
        Add-Line ("... truncated; total lines: " + $lines.Count)
    }
}

Add-Section "SEARCH: OBSERVATION / LESSON / MAPPING WRITE SEAMS"

$patterns = @(
    "createCefrCapabilityObservation("
    "capabilityReference"
    "observationId"
    "observedAt"
    "evidenceReference"
    "payloadReference"
    "createCefrCapabilityObservationRegistry("
    "capabilityObservationRegistry"
    "lessonId"
    "learningItemId"
    "competencyOutcomeIds"
    "recordLearningStudioEvidence("
)

$sourceFiles = @(
    Get-ChildItem -Path $src -Recurse -File |
    Where-Object {
        $_.Extension -eq ".ts" -or $_.Extension -eq ".tsx"
    }
)

foreach ($pattern in $patterns) {
    Add-Line ""
    Add-Line ("PATTERN: " + $pattern)

    $hits = @(
        $sourceFiles |
        Select-String -SimpleMatch -Pattern $pattern -ErrorAction SilentlyContinue |
        Select-Object -First 80
    )

    if ($hits.Count -eq 0) {
        Add-Line "(no matches)"
        continue
    }

    foreach ($hit in $hits) {
        $rel = $hit.Path.Substring($root.Length + 1)
        Add-Line ("{0}:{1}: {2}" -f $rel, $hit.LineNumber, $hit.Line.Trim())
    }
}

Add-Section "IMPLEMENTATION DECISION INPUT"
Add-Line "Need exact CefrCapabilityObservation constructor fields and semantics."
Add-Line "Need exact profile/registry persistence seam for adding one or more observations."
Add-Line "Need exact authoritative lesson identity available at completion."
Add-Line "Need to determine whether competencyOutcomeId itself is an approved capabilityReference; do not assume."
Add-Line "Do not derive capabilityReference from Studio labels, routes, or test fixture names."
Add-Line "No mastery, competency success, CEFR level, or automatic progression mutation."

$report | Set-Content -Path $out -Encoding UTF8

Write-Host ""
Write-Host "LAF CURRICULUM OBSERVATION WRITE SEAM SNAPSHOT COMPLETE"
Write-Host "Report:"
Write-Host $out
Write-Host ""
Get-Content -Path $out
