﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app  = Join-Path $root "app"

$registry = Join-Path $app "src\core\learning\CefrAuthoritativeCapabilityRegistry.ts"

if (-not (Test-Path $registry)) {
    throw "Production capability registry source missing."
}

$requiredMarkers = @(
    'capabilityReference: "social-exchange"',
    'capabilityReference: "nuance-preservation"',
    'competencyOutcomeId: "connect-a1"',
    'competencyOutcomeId: "interpret-transform-c2"',
    'mappingVersion: "capability-map-v1"'
)

foreach ($marker in $requiredMarkers) {
    if (-not (
        Select-String -Path $registry -SimpleMatch `
            -Pattern $marker -Quiet
    )) {
        throw "Required production marker missing: $marker"
    }
}

$forbiddenMarkers = @(
    '"speaking-fluency"',
    '"listening-detail-recognition"',
    '"reading-detail-comprehension"',
    '"writing-coherent-production"'
)

foreach ($marker in $forbiddenMarkers) {
    if (
        Select-String -Path $registry -SimpleMatch `
            -Pattern $marker -Quiet
    ) {
        throw "Test fixture capability leaked into production registry: $marker"
    }
}

Write-Host "SPRINT-1281-1286 SOURCE CHECK PASSED"

Set-Location $app

$targets = @(
    "src/core/learning/CefrAuthoritativeCapabilityRegistry.test.ts",
    "src/core/learning/CefrProductionCapabilityObservationActivation.test.ts",
    "src/core/learning/CefrProductionCapabilityActivationSafety.test.ts",
    "src/core/learning/CefrCapabilityTaxonomy.test.ts",
    "src/core/learning/CefrCapabilityTaxonomyRegistry.test.ts",
    "src/core/learning/CefrCompetencyCapabilityMapping.test.ts",
    "src/core/learning/CefrCompetencyCapabilityMappingRegistry.test.ts",
    "src/core/learning/CefrAuthoritativeCapabilityResolution.test.ts",
    "src/core/learning/CefrCurriculumCapabilityObservationWrite.test.ts",
    "src/application/learning/CefrCurriculumCapabilityObservationWriter.test.ts",
    "src/application/learning/CefrMappedListeningPracticeCompletionService.test.ts",
    "src/core/learning/CefrCapabilityMappingSafety.test.ts"
)

& npx vitest run $targets
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1281-1286 target tests failed."
}

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Full regression failed."
}

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Production build failed."
}

Write-Host "SPRINT-1281-1286 VERIFICATION COMPLETE"
