$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$file = Join-Path $app "src\core\learning\CefrLearningReflection.ts"
$backup = "$file.sprint669-repair.bak"

if (-not (Test-Path $file)) {
  throw "CefrLearningReflection.ts not found: $file"
}

$content = Get-Content -Path $file -Raw
$trimmed = $content.TrimEnd()

# Repair only the exact parse-error shape reported by Vite/OXC:
# function body ends with `return value` and is missing its closing brace.
if ($trimmed -match 'return\s+value\s*;?\s*$') {
  Copy-Item -Path $file -Destination $backup -Force

  $repaired = $trimmed + "`r`n}`r`n"
  Set-Content -Path $file -Value $repaired -Encoding utf8

  Write-Host "Repaired missing closing brace in CefrLearningReflection.ts"
  Write-Host "Backup: $backup"
}
elseif ($trimmed -match 'return\s+value\s*;?\s*\}\s*$') {
  Write-Host "CefrLearningReflection.ts already appears repaired; no source change made."
}
else {
  throw "Unexpected CefrLearningReflection.ts ending. Repair stopped without modifying the file."
}

Set-Location $app

Write-Host "=== Reflection Target Test ==="
npx vitest run "src/core/learning/CefrLearningReflection.test.ts"

if ($LASTEXITCODE -ne 0) {
  throw "CefrLearningReflection target test failed after repair."
}

Set-Location $root

Write-Host "=== Re-run Sprint 669-671 Verification ==="
& ".\LAF-SPRINT-669-671-VERIFY.ps1"

if ($LASTEXITCODE -ne 0) {
  throw "Sprint 669-671 verification failed after reflection repair."
}

Write-Host "SPRINT-669-671 REFLECTION REPAIR AND VERIFICATION COMPLETE"
