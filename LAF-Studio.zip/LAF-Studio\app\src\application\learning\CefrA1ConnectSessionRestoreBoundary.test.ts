import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrA1ConnectSessionState,
} from "../../core/learning/CefrA1ConnectSessionState";
import {
  createCefrA1ConnectSessionRestoreResult,
} from "./CefrA1ConnectSessionRestoreBoundary";

describe(
  "CefrA1ConnectSessionRestoreBoundary",
  () => {
    it("restores only authoritative lesson identities", () => {
      const state =
        createCefrA1ConnectSessionState({
          selectedLanguageCode: "de",
          selectedLessonId:
            "a1-connect-personal-questions",
          updatedAt:
            new Date(
              "2026-08-11T19:40:00.000Z",
            ),
        });

      expect(
        createCefrA1ConnectSessionRestoreResult(
          state,
          [
            "a1-connect-greeting-response",
            "a1-connect-self-introduction",
            "a1-connect-personal-questions",
            "a1-connect-complete-social-exchange",
          ],
        ),
      ).toMatchObject({
        restorable: true,
        invalidLessonIgnored: false,
        automaticRestorePerformed: false,
        request: {
          selectedLanguageCode: "de",
          selectedLessonId:
            "a1-connect-personal-questions",
          userActionConfirmed: true,
          evidenceCreated: false,
          masteryAssigned: false,
          cefrLevelAssigned: false,
          progressionPerformed: false,
        },
      });
    });

    it("keeps the language but refuses a stale or unknown lesson id", () => {
      const state =
        createCefrA1ConnectSessionState({
          selectedLanguageCode: "hu",
          selectedLessonId:
            "not-authoritative",
          updatedAt:
            new Date(
              "2026-08-11T19:41:00.000Z",
            ),
        });

      const result =
        createCefrA1ConnectSessionRestoreResult(
          state,
          [
            "a1-connect-greeting-response",
          ],
        );

      expect(result).toMatchObject({
        restorable: true,
        invalidLessonIgnored: true,
        automaticRestorePerformed: false,
        request: {
          selectedLanguageCode: "hu",
          selectedLessonId: null,
        },
      });
    });
  },
);
