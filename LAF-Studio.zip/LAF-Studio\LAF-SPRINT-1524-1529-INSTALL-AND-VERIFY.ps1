﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$payloadRoot =
    Join-Path $root "_sprint_payload"

$requiredBaseline = @(
    "src\application\learning\CefrA1AuthoritativeJourneyView.ts",
    "src\core\learning\CefrA1AuthoritativeJourneySafety.ts",
    "src\ui\learning\A1AuthoritativeJourneyPanel.tsx",
    "src\ui\pages\LearningStudioPage.tsx",
    "src\application\learning\CefrA1DescribeExecutableTaskService.ts",
    "src\application\learning\CefrA1DescribeSecondWaveExecutableTaskService.ts",
    "src\application\learning\CefrA1DescribePersistedEvidenceView.ts"
)

foreach ($relative in $requiredBaseline) {
    $path = Join-Path $app $relative

    if (-not (Test-Path $path)) {
        throw "Sprint 1523 stable baseline file missing: $relative"
    }
}

$journeyBaseline =
    [System.IO.File]::ReadAllText(
        (Join-Path $app "src\application\learning\CefrA1AuthoritativeJourneyView.ts")
    )

if (-not $journeyBaseline.Contains(
    "activeAuthoritativeSliceCount: 2"
)) {
    if (-not $journeyBaseline.Contains(
        "activeAuthoritativeSliceCount: 3"
    )) {
        throw "A1 Journey baseline is neither expected 2-slice nor already-upgraded 3-slice state."
    }
}

$backupRoot =
    Join-Path $root (
        "_sprint_backups\Sprint1524-1529-" +
        (Get-Date -Format "yyyyMMdd-HHmmss")
    )

New-Item `
    -ItemType Directory `
    -Path $backupRoot `
    -Force |
    Out-Null

function Install-CheckpointPayload {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Checkpoint
    )

    $sourceRoot =
        Join-Path $payloadRoot $Checkpoint

    if (-not (Test-Path $sourceRoot)) {
        throw "Checkpoint payload missing: $Checkpoint"
    }

    $files =
        Get-ChildItem `
            -Path $sourceRoot `
            -Recurse `
            -File

    foreach ($file in $files) {
        $relative =
            $file.FullName.Substring(
                $sourceRoot.Length
            ).TrimStart(
                [char[]]@("\", "/")
            )

        $destination =
            Join-Path $root $relative

        New-Item `
            -ItemType Directory `
            -Path (Split-Path $destination -Parent) `
            -Force |
            Out-Null

        if (Test-Path $destination) {
            $backup =
                Join-Path $backupRoot $relative

            New-Item `
                -ItemType Directory `
                -Path (Split-Path $backup -Parent) `
                -Force |
                Out-Null

            if (-not (Test-Path $backup)) {
                Copy-Item `
                    -LiteralPath $destination `
                    -Destination $backup `
                    -Force
            }
        }

        Copy-Item `
            -LiteralPath $file.FullName `
            -Destination $destination `
            -Force
    }
}

function Patch-LearningStudioPage {
    $pagePath =
        Join-Path $app "src\ui\pages\LearningStudioPage.tsx"

    $utf8 =
        New-Object System.Text.UTF8Encoding($false)

    $text =
        [System.IO.File]::ReadAllText(
            $pagePath,
            $utf8
        )

    $importMarker =
        'import { A1DescribeNativeLearningPanel } from "../learning/A1DescribeNativeLearningPanel";'

    if (-not $text.Contains($importMarker)) {
        $anchor =
            'import { A1AuthoritativeJourneyPanel } from "../learning/A1AuthoritativeJourneyPanel";'

        if (-not $text.Contains($anchor)) {
            throw "LearningStudioPage A1 Journey import anchor missing."
        }

        $text =
            $text.Replace(
                $anchor,
                $anchor + [Environment]::NewLine + $importMarker
            )
    }

    $mountMarker =
        '<A1DescribeNativeLearningPanel />'

    if (-not $text.Contains($mountMarker)) {
        $anchor =
            '<A1AuthoritativeJourneyPanel />'

        if (-not $text.Contains($anchor)) {
            throw "LearningStudioPage A1 Journey mount anchor missing."
        }

        $text =
            $text.Replace(
                $anchor,
                $anchor + [Environment]::NewLine + "        " + $mountMarker
            )
    }

    [System.IO.File]::WriteAllText(
        $pagePath,
        $text,
        $utf8
    )
}

$vitestPath =
    Join-Path $app "node_modules\.bin\vitest.cmd"

if (-not (Test-Path $vitestPath)) {
    throw "Local Vitest command missing: $vitestPath"
}

$npmPath =
    (Get-Command "npm.cmd" -ErrorAction Stop).Source

if (-not $npmPath) {
    throw "npm.cmd path could not be resolved."
}

function Run-TargetTests {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Label,

        [Parameter(Mandatory = $true)]
        [string[]]$Tests
    )

    Write-Host ""
    Write-Host "============================================================"
    Write-Host $Label
    Write-Host "============================================================"

    $vitestCommandArgs = @("run")
    $vitestCommandArgs += $Tests

    & $vitestPath @vitestCommandArgs

    if ($LASTEXITCODE -ne 0) {
        throw "$Label failed."
    }
}

Set-Location $app

# ------------------------------------------------------------
# Sprint 1524-1526
# A1 Journey: 2 approved slices -> 3 approved slices.
# ------------------------------------------------------------

Install-CheckpointPayload `
    -Checkpoint "1524-1526"

Run-TargetTests `
    -Label "SPRINT-1524-1526 TARGET CHECKPOINT" `
    -Tests @(
        "src/application/learning/CefrA1AuthoritativeJourneyView.test.ts",
        "src/core/learning/CefrA1AuthoritativeJourneySafety.test.ts",
        "src/application/learning/CefrProductionRuntimeDelayedRetrievalVisibility.test.ts",
        "src/core/learning/CefrProductionRuntimeSliceRegistryEligibility.test.ts"
    )

Write-Host "SPRINT-1524-1526 TARGET CHECKPOINT PASSED"

# ------------------------------------------------------------
# Sprint 1527-1529
# Native /learning A1 DESCRIBE panel using existing runtime.
# ------------------------------------------------------------

Install-CheckpointPayload `
    -Checkpoint "1527-1529"

$pagePath =
    Join-Path $app "src\ui\pages\LearningStudioPage.tsx"

$pageBackup =
    Join-Path $backupRoot "app\src\ui\pages\LearningStudioPage.tsx"

if (-not (Test-Path $pageBackup)) {
    New-Item `
        -ItemType Directory `
        -Path (Split-Path $pageBackup -Parent) `
        -Force |
        Out-Null

    Copy-Item `
        -LiteralPath $pagePath `
        -Destination $pageBackup `
        -Force
}

Patch-LearningStudioPage

$pageSource =
    [System.IO.File]::ReadAllText(
        $pagePath
    )

if (-not $pageSource.Contains(
    'A1DescribeNativeLearningPanel'
)) {
    throw "Native A1 DESCRIBE panel import/mount verification failed."
}

$panelSource =
    [System.IO.File]::ReadAllText(
        (Join-Path $app "src\ui\learning\A1DescribeNativeLearningPanel.tsx")
    )

foreach ($marker in @(
    'data-cefr-unit="a1-describe-basic-familiar-world"',
    'a1-describe-task-basic-comprehension',
    'a1-describe-task-basic-feature',
    'a1-describe-task-person-description',
    'a1-describe-task-place-thing-description',
    'a1-describe-task-follow-up-response',
    'a1-describe-task-reciprocal-description',
    'Evidence ≠ Mastery',
    'narrative-sequencing'
)) {
    if (-not $panelSource.Contains($marker)) {
        throw "Native A1 DESCRIBE panel marker missing: $marker"
    }
}

Run-TargetTests `
    -Label "SPRINT-1527-1529 TARGET CHECKPOINT" `
    -Tests @(
        "src/core/learning/CefrA1DescribeNativeLearningUiSafety.test.ts",
        "src/application/learning/CefrA1DescribePersistedEvidenceView.test.ts",
        "src/application/learning/CefrA1DescribeExecutableTaskService.test.ts",
        "src/application/learning/CefrA1DescribeSecondWaveExecutableTaskService.test.ts",
        "src/application/learning/CefrA1AuthoritativeJourneyView.test.ts"
    )

Write-Host "SPRINT-1527-1529 TARGET CHECKPOINT PASSED"

Write-Host ""
Write-Host "============================================================"
Write-Host "FINAL 6-SPRINT BLOCK REGRESSION"
Write-Host "============================================================"

& $npmPath run test

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1524-1529 final full regression failed."
}

Write-Host ""
Write-Host "============================================================"
Write-Host "FINAL PRODUCTION BUILD"
Write-Host "============================================================"

& $npmPath run build

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1524-1529 production build failed."
}

Write-Host ""
Write-Host "SPRINT-1524-1529 VERIFICATION COMPLETE"
Write-Host "Backup: $backupRoot"
