import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrPersonalLanguageProfileState,
  type CefrPersonalLanguageProfileState,
} from "../../core/learning/CefrPersonalLanguageProfileState";
import type {
  CefrLanguageEvidenceStorageLike,
} from "./CefrAuthoritativeLanguageEvidenceProvenanceRepository";
import type {
  CefrGuidanceRuntimeProfileRepository,
} from "./CefrGuidanceRuntimeProfileRepository";
import {
  CefrA1DescribeExecutableTaskService,
} from "./CefrA1DescribeExecutableTaskService";
import {
  CefrA1DescribeSecondWaveExecutableTaskService,
} from "./CefrA1DescribeSecondWaveExecutableTaskService";
import {
  createCefrA1DescribePersistedEvidenceView,
} from "./CefrA1DescribePersistedEvidenceView";
import {
  CefrProductionRuntimePlatform,
} from "./CefrProductionRuntimePlatform";

class MemoryProfileRepository
  implements CefrGuidanceRuntimeProfileRepository {
  private state:
    CefrPersonalLanguageProfileState =
      createCefrPersonalLanguageProfileState(
        [],
        [],
      );

  load(): CefrPersonalLanguageProfileState {
    return this.state;
  }

  save(
    state: CefrPersonalLanguageProfileState,
  ): void {
    this.state = state;
  }

  hasPersistedProfile(): boolean {
    return false;
  }

  clear(): void {}
}

class MemoryStorage
  implements CefrLanguageEvidenceStorageLike {
  private readonly items =
    new Map<string, string>();

  getItem(key: string): string | null {
    return this.items.get(key) ?? null;
  }

  setItem(
    key: string,
    value: string,
  ): void {
    this.items.set(key, value);
  }

  removeItem(key: string): void {
    this.items.delete(key);
  }
}

function createHarness() {
  const repository =
    new MemoryProfileRepository();
  const storage =
    new MemoryStorage();
  const platform =
    new CefrProductionRuntimePlatform(
      repository,
      storage,
    );

  return {
    platform,
    first:
      new CefrA1DescribeExecutableTaskService(
        platform,
      ),
    second:
      new CefrA1DescribeSecondWaveExecutableTaskService(
        platform,
      ),
  };
}

describe(
  "A1 DESCRIBE persisted evidence view",
  () => {
    it("starts with six target-language-scoped immediate evidence items and advises the first missing task", () => {
      const { platform } =
        createHarness();

      const view =
        createCefrA1DescribePersistedEvidenceView(
          platform,
          "hu",
        );

      expect(view.coverage).toMatchObject({
        languageCode: "hu",
        observedImmediateEvidenceCount:
          0,
        immediateEvidenceCount: 6,
        allImmediateEvidenceObserved:
          false,
        delayedRetrievalIncluded: false,
        crossLanguageEvidenceExcluded:
          true,
        unscopedEvidenceExcluded: true,
        persistedRealEvidenceOnly: true,
        coverageOnly: true,
        masteryInferred: false,
        cefrLevelInferred: false,
        progressionTriggered: false,
        narrativeSequencingInferred:
          false,
      });

      expect(view.coverage.items).toHaveLength(
        6,
      );

      expect(view.advisory).toMatchObject({
        status:
          "next-persisted-evidence-task",
        nextTaskId:
          "a1-describe-task-basic-comprehension",
        evidenceDefinitionId:
          "a1-describe-evidence-basic-comprehension",
        guidedActivationAvailable: false,
        advisoryOnly: true,
        userApplyRequired: true,
        delayedRetrievalRecommended:
          false,
        delayedRetrievalExecutable:
          false,
        automaticTaskSelection: false,
        automaticEvidenceWrite: false,
        masteryInferred: false,
        cefrLevelInferred: false,
        progressionTriggered: false,
        narrativeSequencingInferred:
          false,
      });
    });

    it("advances persisted advisory only from real evidence in the same selected language", () => {
      const {
        platform,
        first,
      } = createHarness();

      first.executeSelection({
        taskId:
          "a1-describe-task-basic-comprehension",
        languageCode: "de",
        selectedPhraseId:
          "identify-cat",
        eventId:
          "describe-coverage-de-001",
        occurredAt:
          new Date(
            "2026-08-12T20:20:00.000Z",
          ),
        userActionConfirmed: true,
      });

      const german =
        createCefrA1DescribePersistedEvidenceView(
          platform,
          "de",
        );

      const hungarian =
        createCefrA1DescribePersistedEvidenceView(
          platform,
          "hu",
        );

      expect(
        german.coverage
          .observedImmediateEvidenceCount,
      ).toBe(1);

      expect(
        german.advisory.nextTaskId,
      ).toBe(
        "a1-describe-task-basic-feature",
      );

      expect(
        hungarian.coverage
          .observedImmediateEvidenceCount,
      ).toBe(0);

      expect(
        hungarian.advisory.nextTaskId,
      ).toBe(
        "a1-describe-task-basic-comprehension",
      );
    });

    it("moves to guided activation availability after all six immediate evidence definitions are persisted without exposing delayed retrieval", () => {
      const {
        platform,
        first,
        second,
      } = createHarness();

      first.executeSelection({
        taskId:
          "a1-describe-task-basic-comprehension",
        languageCode: "en",
        selectedPhraseId:
          "identify-cat",
        eventId: "describe-all-01",
        occurredAt:
          new Date("2026-08-12T20:30:00.000Z"),
        userActionConfirmed: true,
      });

      first.executeSelection({
        taskId:
          "a1-describe-task-basic-feature",
        languageCode: "en",
        selectedPhraseId:
          "feature-white",
        eventId: "describe-all-02",
        occurredAt:
          new Date("2026-08-12T20:31:00.000Z"),
        userActionConfirmed: true,
      });

      first.executePersonDescription({
        languageCode: "en",
        selectedPhraseIds: [
          "person-identify",
          "person-tall",
          "person-kind",
        ],
        eventId: "describe-all-03",
        occurredAt:
          new Date("2026-08-12T20:32:00.000Z"),
        userActionConfirmed: true,
      });

      second.executeSequenceTask({
        taskId:
          "a1-describe-task-place-thing-description",
        languageCode: "en",
        selectedPhraseIds: [
          "place-identify",
          "place-small",
          "place-quiet",
        ],
        eventId: "describe-all-04",
        occurredAt:
          new Date("2026-08-12T20:33:00.000Z"),
        userActionConfirmed: true,
      });

      second.executeFollowUp({
        languageCode: "en",
        selectedPhraseId:
          "followup-answer",
        eventId: "describe-all-05",
        occurredAt:
          new Date("2026-08-12T20:34:00.000Z"),
        userActionConfirmed: true,
      });

      second.executeSequenceTask({
        taskId:
          "a1-describe-task-reciprocal-description",
        languageCode: "en",
        selectedPhraseIds: [
          "complete-identify",
          "complete-feature-one",
          "complete-feature-two",
          "followup-answer",
        ],
        eventId: "describe-all-06",
        occurredAt:
          new Date("2026-08-12T20:35:00.000Z"),
        userActionConfirmed: true,
      });

      const view =
        createCefrA1DescribePersistedEvidenceView(
          platform,
          "en",
        );

      expect(view.coverage).toMatchObject({
        observedImmediateEvidenceCount:
          6,
        immediateEvidenceCount: 6,
        allImmediateEvidenceObserved:
          true,
        delayedRetrievalIncluded: false,
        masteryInferred: false,
        cefrLevelInferred: false,
        progressionTriggered: false,
        narrativeSequencingInferred:
          false,
      });

      expect(view.advisory).toMatchObject({
        status:
          "guided-activation-available",
        nextTaskId: null,
        evidenceDefinitionId: null,
        guidedActivationAvailable: true,
        advisoryOnly: true,
        userApplyRequired: true,
        delayedRetrievalRecommended:
          false,
        delayedRetrievalExecutable:
          false,
        automaticTaskSelection: false,
        automaticEvidenceWrite: false,
        masteryInferred: false,
        cefrLevelInferred: false,
        progressionTriggered: false,
        narrativeSequencingInferred:
          false,
      });
    });
  },
);
