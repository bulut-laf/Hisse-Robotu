﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

Write-Host "=== Install Guidance Evidence Activity Visibility ==="
Set-Location $root
node ".\LAF-SPRINT-1239-1244-INSTALL.mjs"
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1239-1244 install failed."
}

$guidancePage = Join-Path $app "src\ui\pages\GuidanceCenterPage.tsx"

$panelMatches = @(
    Select-String `
        -Path $guidancePage `
        -SimpleMatch `
        '<GuidanceEvidenceActivityPanel state={source.state} />'
)

if ($panelMatches.Count -ne 1) {
    throw (
        "Guidance evidence panel binding validation failed. Count=" +
        $panelMatches.Count
    )
}

Set-Location $app

Write-Host "=== Sprint 1239-1242 Target Tests: Evidence Activity Read Model ==="
npx vitest run `
  "src/application/learning/CefrGuidanceEvidenceActivityView.test.ts"
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1239-1242 target tests failed."
}

Write-Host "=== Sprint 1243-1244 Safety Tests ==="
npx vitest run `
  "src/application/learning/CefrGuidanceEvidenceActivityVisibilitySafety.test.ts"
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1243-1244 safety tests failed."
}

Write-Host "=== Combined Sprint 1239-1244 Tests ==="
npx vitest run `
  "src/application/learning/CefrGuidanceEvidenceActivityView.test.ts" `
  "src/application/learning/CefrGuidanceEvidenceActivityVisibilitySafety.test.ts" `
  "src/application/learning/CefrGuidanceRuntimeProfileService.test.ts" `
  "src/core/learning/CefrPersonalLanguageProfileEvidence.test.ts"
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1239-1244 combined tests failed."
}

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Full regression failed."
}

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Production build failed."
}

Write-Host "SPRINT-1239-1244 VERIFICATION COMPLETE"
