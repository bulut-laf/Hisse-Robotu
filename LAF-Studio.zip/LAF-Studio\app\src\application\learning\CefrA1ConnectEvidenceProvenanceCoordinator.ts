import type {
  LafLearningLanguageCode,
} from "../../core/language/LafLanguageProfile";
import {
  createCefrA1ConnectEvidenceProvenanceRecoveryRecord,
} from "../../core/learning/CefrA1ConnectEvidenceProvenanceRecoveryRecord";
import {
  createCefrA1ConnectLanguageEvidenceProvenance,
} from "../../core/learning/CefrA1ConnectLanguageEvidenceProvenance";
import {
  CefrA1ConnectEvidenceProvenanceRecoveryRepository,
} from "./CefrA1ConnectEvidenceProvenanceRecoveryRepository";
import {
  CefrA1ConnectLanguageEvidenceProvenanceRepository,
} from "./CefrA1ConnectLanguageEvidenceProvenanceRepository";

export interface CefrA1ConnectEvidenceProvenanceWriteResult {
  readonly provenanceWritten: boolean;
  readonly recoveryQueued: boolean;
  readonly masteryAssigned: false;
  readonly cefrLevelAssigned: false;
  readonly progressionPerformed: false;
}

export class CefrA1ConnectEvidenceProvenanceCoordinator {
  private readonly provenanceRepository:
    CefrA1ConnectLanguageEvidenceProvenanceRepository;

  private readonly recoveryRepository:
    CefrA1ConnectEvidenceProvenanceRecoveryRepository;

  constructor(
    provenanceRepository:
      CefrA1ConnectLanguageEvidenceProvenanceRepository =
        new CefrA1ConnectLanguageEvidenceProvenanceRepository(),
    recoveryRepository:
      CefrA1ConnectEvidenceProvenanceRecoveryRepository =
        new CefrA1ConnectEvidenceProvenanceRecoveryRepository(),
  ) {
    this.provenanceRepository =
      provenanceRepository;
    this.recoveryRepository =
      recoveryRepository;
  }

  recordPersistedEvidenceLanguage(
    input: {
      readonly evidenceId: string;
      readonly languageCode:
        LafLearningLanguageCode;
      readonly observedAt: Date;
      readonly recoveryCreatedAt?: Date;
    },
  ): CefrA1ConnectEvidenceProvenanceWriteResult {
    try {
      this.provenanceRepository.save(
        createCefrA1ConnectLanguageEvidenceProvenance({
          evidenceId: input.evidenceId,
          languageCode:
            input.languageCode,
          observedAt:
            input.observedAt,
        }),
      );

      return {
        provenanceWritten: true,
        recoveryQueued: false,
        masteryAssigned: false,
        cefrLevelAssigned: false,
        progressionPerformed: false,
      };
    }
    catch {
      this.recoveryRepository.save(
        createCefrA1ConnectEvidenceProvenanceRecoveryRecord({
          evidenceId: input.evidenceId,
          languageCode:
            input.languageCode,
          observedAt:
            input.observedAt,
          createdAt:
            input.recoveryCreatedAt ??
            new Date(),
        }),
      );

      return {
        provenanceWritten: false,
        recoveryQueued: true,
        masteryAssigned: false,
        cefrLevelAssigned: false,
        progressionPerformed: false,
      };
    }
  }

  repairPending(): {
    readonly repairedCount: number;
    readonly remainingCount: number;
  } {
    let repairedCount = 0;

    for (
      const record of
      this.recoveryRepository.loadAll()
    ) {
      try {
        this.provenanceRepository.save(
          createCefrA1ConnectLanguageEvidenceProvenance({
            evidenceId:
              record.evidenceId,
            languageCode:
              record.languageCode,
            observedAt:
              new Date(
                record.observedAt,
              ),
          }),
        );

        this.recoveryRepository.remove(
          record.recoveryId,
        );
        repairedCount += 1;
      }
      catch {
        // Keep the real recovery record for a later explicit retry.
      }
    }

    return {
      repairedCount,
      remainingCount:
        this.recoveryRepository
          .loadAll().length,
    };
  }
}
