import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrPersonalLanguageProfileState,
  type CefrPersonalLanguageProfileState,
} from "../../core/learning/CefrPersonalLanguageProfileState";
import type {
  CefrLanguageEvidenceStorageLike,
} from "./CefrAuthoritativeLanguageEvidenceProvenanceRepository";
import type {
  CefrGuidanceRuntimeProfileRepository,
} from "./CefrGuidanceRuntimeProfileRepository";
import {
  CefrProductionRuntimePlatform,
} from "./CefrProductionRuntimePlatform";
import {
  createCefrA1NavigatePersistedEvidenceView,
} from "./CefrA1NavigatePersistedEvidenceView";

class MemoryProfileRepository
  implements CefrGuidanceRuntimeProfileRepository {
  private state:
    CefrPersonalLanguageProfileState =
      createCefrPersonalLanguageProfileState(
        [],
        [],
      );

  load(): CefrPersonalLanguageProfileState {
    return this.state;
  }

  save(
    state: CefrPersonalLanguageProfileState,
  ): void {
    this.state = state;
  }

  hasPersistedProfile(): boolean {
    return false;
  }

  clear(): void {}
}

class MemoryStorage
  implements CefrLanguageEvidenceStorageLike {
  private readonly items =
    new Map<string, string>();

  getItem(key: string): string | null {
    return this.items.get(key) ?? null;
  }

  setItem(
    key: string,
    value: string,
  ): void {
    this.items.set(key, value);
  }

  removeItem(key: string): void {
    this.items.delete(key);
  }
}

function createPlatform() {
  return new CefrProductionRuntimePlatform(
    new MemoryProfileRepository(),
    new MemoryStorage(),
  );
}

describe(
  "A1 NAVIGATE persisted language-scoped evidence view",
  () => {
    it("starts at 0/6 and advises the first missing immediate task", () => {
      const result =
        createCefrA1NavigatePersistedEvidenceView(
          createPlatform(),
          "hu",
        );

      expect(result.coverage).toMatchObject({
        languageCode: "hu",
        observedImmediateEvidenceCount: 0,
        immediateEvidenceCount: 6,
        allImmediateEvidenceObserved:
          false,
        delayedRetrievalIncluded: false,
        crossLanguageEvidenceExcluded:
          true,
        unscopedEvidenceExcluded: true,
        persistedRealEvidenceOnly: true,
        coverageOnly: true,
        masteryInferred: false,
        cefrLevelInferred: false,
      });

      expect(result.advisory).toMatchObject({
        status:
          "next-persisted-evidence-task",
        nextTaskId:
          "a1-navigate-task-need-comprehension",
        evidenceDefinitionId:
          "a1-navigate-evidence-need-comprehension",
        guidedActivationAvailable: false,
        userApplyRequired: true,
        delayedRetrievalRecommended: false,
        delayedRetrievalExecutable: false,
        automaticTaskSelection: false,
        automaticEvidenceWrite: false,
      });
    });

    it("excludes evidence from another target language", () => {
      const platform =
        createPlatform();

      platform.recordUserEvidence(
        "a1-navigate",
        {
          evidenceDefinitionId:
            "a1-navigate-evidence-need-comprehension",
          eventId: "hu-only-001",
          occurredAt:
            new Date(
              "2026-08-12T12:30:00.000Z",
            ),
          languageCode: "hu",
          userActionConfirmed: true,
        },
      );

      expect(
        createCefrA1NavigatePersistedEvidenceView(
          platform,
          "hu",
        ).coverage
          .observedImmediateEvidenceCount,
      ).toBe(1);

      expect(
        createCefrA1NavigatePersistedEvidenceView(
          platform,
          "en",
        ).coverage
          .observedImmediateEvidenceCount,
      ).toBe(0);
    });

    it("offers guided activation after all six persisted immediate evidence definitions and never adds delayed retrieval", () => {
      const platform =
        createPlatform();

      const evidenceIds = [
        "a1-navigate-evidence-need-comprehension",
        "a1-navigate-evidence-need-expression",
        "a1-navigate-evidence-information-question",
        "a1-navigate-evidence-practical-answer",
        "a1-navigate-evidence-practical-reading",
        "a1-navigate-evidence-reciprocal-exchange",
      ] as const;

      evidenceIds.forEach(
        (
          evidenceDefinitionId,
          index,
        ) => {
          platform.recordUserEvidence(
            "a1-navigate",
            {
              evidenceDefinitionId,
              eventId:
                `all-immediate-${index}`,
              occurredAt:
                new Date(
                  `2026-08-12T12:${40 + index}:00.000Z`,
                ),
              languageCode: "de",
              userActionConfirmed: true,
            },
          );
        },
      );

      const result =
        createCefrA1NavigatePersistedEvidenceView(
          platform,
          "de",
        );

      expect(result.coverage).toMatchObject({
        observedImmediateEvidenceCount: 6,
        immediateEvidenceCount: 6,
        allImmediateEvidenceObserved: true,
        delayedRetrievalIncluded: false,
        masteryInferred: false,
        cefrLevelInferred: false,
        progressionTriggered: false,
      });

      expect(
        result.coverage.items.map(
          item =>
            item.evidenceDefinitionId,
        ),
      ).not.toContain(
        "a1-navigate-evidence-delayed-retrieval",
      );

      expect(result.advisory).toMatchObject({
        status:
          "guided-activation-available",
        nextTaskId: null,
        guidedActivationAvailable: true,
        delayedRetrievalRecommended: false,
        delayedRetrievalExecutable: false,
        progressionTriggered: false,
      });
    });
  },
);
