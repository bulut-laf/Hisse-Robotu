﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app  = Join-Path $root "app"

$taxonomy = Join-Path $app "src\core\learning\CefrAuthoritativeCapabilityRegistry.ts"
$write = Join-Path $app "src\core\learning\CefrCurriculumCapabilityObservationWrite.ts"
$safety = Join-Path $app "src\core\learning\CefrCapabilityMappingSafety.ts"

if (-not (Test-Path $taxonomy)) {
    throw "Capability authority source missing."
}

if (
  Select-String -Path $taxonomy -SimpleMatch `
    -Pattern '"speaking-fluency"' -Quiet
) {
  throw "Test fixture capability promoted into production taxonomy."
}

if (
  -not (
    Select-String -Path $write -SimpleMatch `
      -Pattern "resolveCefrAuthoritativeCapabilities(" -Quiet
  )
) {
  throw "Authoritative capability resolution is not wired into observation write."
}

if (
  -not (
    Select-String -Path $safety -SimpleMatch `
      -Pattern 'competencyCapabilityCardinality:' -Quiet
  )
) {
  throw "Capability mapping safety contract missing."
}

Set-Location $app

$targets = @(
  "src/core/learning/CefrCapabilityTaxonomy.test.ts",
  "src/core/learning/CefrCapabilityTaxonomyRegistry.test.ts",
  "src/core/learning/CefrCompetencyCapabilityMapping.test.ts",
  "src/core/learning/CefrCompetencyCapabilityMappingRegistry.test.ts",
  "src/core/learning/CefrAuthoritativeCapabilityRegistry.test.ts",
  "src/core/learning/CefrAuthoritativeCapabilityResolution.test.ts",
  "src/core/learning/CefrCurriculumCapabilityObservationWrite.test.ts",
  "src/application/learning/CefrCurriculumCapabilityObservationWriter.test.ts",
  "src/application/learning/CefrMappedListeningPracticeCompletionService.test.ts",
  "src/core/learning/CefrCapabilityMappingSafety.test.ts",
  "src/core/learning/CefrCurriculumCompetencyMapping.test.ts",
  "src/core/learning/CefrCurriculumCapabilityObservationEligibility.test.ts"
)

& npx vitest run $targets
if ($LASTEXITCODE -ne 0) {
  throw "Sprint 1275-1280 target tests failed."
}

& npm run test
if ($LASTEXITCODE -ne 0) {
  throw "Full regression failed."
}

& npm run build
if ($LASTEXITCODE -ne 0) {
  throw "Production build failed."
}

Write-Host "SPRINT-1275-1280 VERIFICATION COMPLETE"
