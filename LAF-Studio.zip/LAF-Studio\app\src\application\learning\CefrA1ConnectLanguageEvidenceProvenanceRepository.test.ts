import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrA1ConnectLanguageEvidenceProvenance,
} from "../../core/learning/CefrA1ConnectLanguageEvidenceProvenance";
import {
  CefrA1ConnectLanguageEvidenceProvenanceRepository,
} from "./CefrA1ConnectLanguageEvidenceProvenanceRepository";

class MemoryStorage {
  private readonly values =
    new Map<string, string>();

  getItem(key: string): string | null {
    return this.values.get(key) ?? null;
  }

  setItem(
    key: string,
    value: string,
  ): void {
    this.values.set(key, value);
  }

  removeItem(key: string): void {
    this.values.delete(key);
  }
}

describe(
  "CefrA1ConnectLanguageEvidenceProvenanceRepository",
  () => {
    it("keeps evidence language provenance stable and rejects cross-language reassignment", () => {
      const repository =
        new CefrA1ConnectLanguageEvidenceProvenanceRepository(
          new MemoryStorage(),
        );

      const evidenceId =
        "a1-connect-runtime-evidence:item-1";

      repository.save(
        createCefrA1ConnectLanguageEvidenceProvenance({
          evidenceId,
          languageCode: "it",
          observedAt:
            new Date(
              "2026-08-11T18:51:00.000Z",
            ),
        }),
      );

      expect(
        repository.findForLanguage("it"),
      ).toHaveLength(1);
      expect(
        repository.findForLanguage("hu"),
      ).toHaveLength(0);

      expect(() =>
        repository.save(
          createCefrA1ConnectLanguageEvidenceProvenance({
            evidenceId,
            languageCode: "hu",
            observedAt:
              new Date(
                "2026-08-11T18:52:00.000Z",
              ),
          }),
        ),
      ).toThrow(
        "Evidence language provenance conflict",
      );
    });
  },
);
