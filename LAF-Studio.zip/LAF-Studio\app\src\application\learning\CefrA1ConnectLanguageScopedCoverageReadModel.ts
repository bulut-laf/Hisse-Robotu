import type {
  LafLearningLanguageCode,
} from "../../core/language/LafLanguageProfile";
import {
  createCefrA1ConnectEvidenceCoverage,
  type CefrA1ConnectEvidenceCoverage,
  type CefrA1ConnectEvidenceIdentity,
} from "../../core/learning/CefrA1ConnectEvidenceCoverage";
import type {
  CefrGuidanceRuntimeProfileRepository,
} from "./CefrGuidanceRuntimeProfileRepository";
import type {
  CefrA1ConnectLanguageEvidenceProvenanceRepository,
} from "./CefrA1ConnectLanguageEvidenceProvenanceRepository";

export interface CefrA1ConnectLanguageScopedCoverageReadModel {
  readonly languageCode:
    LafLearningLanguageCode;
  readonly coverage:
    CefrA1ConnectEvidenceCoverage;
  readonly scopedEvidence:
    readonly CefrA1ConnectEvidenceIdentity[];
  readonly unscopedImmediateEvidenceCount:
    number;
  readonly crossLanguageEvidenceExcluded:
    true;
  readonly unscopedEvidenceAttributed:
    false;
  readonly evidenceCoverageIsMastery: false;
}

function isImmediateA1ConnectEvidence(
  evidenceId: string,
): boolean {
  return (
    createCefrA1ConnectEvidenceCoverage([
      { evidenceId },
    ]).observedImmediateEvidenceCount > 0
  );
}

export function filterCefrA1ConnectEvidenceForLanguage(
  evidence:
    readonly CefrA1ConnectEvidenceIdentity[],
  provenanceRepository:
    CefrA1ConnectLanguageEvidenceProvenanceRepository,
  languageCode: LafLearningLanguageCode,
):
  readonly CefrA1ConnectEvidenceIdentity[] {
  const allowedEvidenceIds =
    new Set(
      provenanceRepository
        .findForLanguage(languageCode)
        .map(item => item.evidenceId),
    );

  return evidence.filter(
    item =>
      allowedEvidenceIds.has(
        item.evidenceId,
      ),
  );
}

export function createCefrA1ConnectLanguageScopedCoverageReadModel(
  repository:
    CefrGuidanceRuntimeProfileRepository,
  provenanceRepository:
    CefrA1ConnectLanguageEvidenceProvenanceRepository,
  languageCode: LafLearningLanguageCode,
): CefrA1ConnectLanguageScopedCoverageReadModel {
  const evidence =
    repository.load()
      .profileSnapshot
      .evidenceAggregation.evidence;

  const scopedEvidence =
    filterCefrA1ConnectEvidenceForLanguage(
      evidence,
      provenanceRepository,
      languageCode,
    );

  const allProvenanceIds =
    new Set(
      provenanceRepository
        .loadAll()
        .map(item => item.evidenceId),
    );

  const unscopedImmediateEvidenceCount =
    evidence.filter(
      item =>
        isImmediateA1ConnectEvidence(
          item.evidenceId,
        ) &&
        !allProvenanceIds.has(
          item.evidenceId,
        ),
    ).length;

  return {
    languageCode,
    coverage:
      createCefrA1ConnectEvidenceCoverage(
        scopedEvidence,
      ),
    scopedEvidence,
    unscopedImmediateEvidenceCount,
    crossLanguageEvidenceExcluded: true,
    unscopedEvidenceAttributed: false,
    evidenceCoverageIsMastery: false,
  };
}
