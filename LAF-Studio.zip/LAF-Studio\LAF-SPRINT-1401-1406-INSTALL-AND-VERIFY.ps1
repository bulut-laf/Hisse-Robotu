﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

$unitPanel = Join-Path $app "src\ui\learning\A1ConnectUnitRuntimePanel.tsx"
$unitCss = Join-Path $app "src\ui\learning\A1ConnectUnitRuntimePanel.css"
$cssPart = Join-Path $app "src\ui\learning\A1ConnectUnitRuntimePanel.lesson-state.css"
$state = Join-Path $app "src\core\learning\CefrA1ConnectLessonEvidenceState.ts"
$readModel = Join-Path $app "src\application\learning\CefrA1ConnectLessonEvidenceStateReadModel.ts"
$safety = Join-Path $app "src\core\learning\CefrA1ConnectLessonEvidenceStateSafety.ts"

foreach ($file in @(
    $unitPanel,
    $unitCss,
    $cssPart,
    $state,
    $readModel,
    $safety
)) {
    if (-not (Test-Path $file)) {
        throw "Sprint 1401-1406 source missing: $file"
    }
}

$utf8 =
    New-Object System.Text.UTF8Encoding($false)

$cssText =
    [System.IO.File]::ReadAllText(
        $unitCss,
        $utf8
    )
$extraCss =
    [System.IO.File]::ReadAllText(
        $cssPart,
        $utf8
    )

if (-not $cssText.Contains(
    ".a1-connect-unit-runtime-lesson-state {"
)) {
    [System.IO.File]::WriteAllText(
        $unitCss,
        $cssText +
        [Environment]::NewLine +
        $extraCss,
        $utf8
    )
}

Remove-Item $cssPart -Force

$checks = @{
    $state = @(
        '"no-immediate-evidence"',
        '"partial-immediate-evidence"',
        '"immediate-evidence-covered"',
        'lessonCompletedClaimed: false',
        'masteryClaimed: false',
        'cefrLevelClaimed: false',
        'progressionTriggered: false'
    )
    $readModel = @(
        'createCefrA1ConnectLessonEvidenceState(',
        'currentLessonContextOnly: true',
        'recommendsAutomaticAdvance: false',
        'selectsNextLesson: false'
    )
    $safety = @(
        'allImmediateEvidenceMeansLessonComplete:',
        'false',
        'allImmediateEvidenceMeansMastery:',
        'false',
        'automaticNextLessonAllowed: false',
        'automaticProgressionAllowed: false'
    )
    $unitPanel = @(
        'createCefrA1ConnectLessonEvidenceStateReadModel(',
        'Anlık evidence kapsamı',
        'Ders tamamlandı, mastery oluştu',
        'CEFR başarısı elde edildi'
    )
}

foreach ($entry in $checks.GetEnumerator()) {
    foreach ($marker in $entry.Value) {
        if (-not (
            Select-String `
                -Path $entry.Key `
                -SimpleMatch `
                -Pattern $marker `
                -Quiet
        )) {
            throw "Required Sprint 1401-1406 marker missing: $marker"
        }
    }
}

Write-Host "SPRINT-1401-1406 SOURCE CHECK PASSED"

Set-Location $app

$targets = @(
    "src/core/learning/CefrA1ConnectLessonEvidenceState.test.ts",
    "src/application/learning/CefrA1ConnectLessonEvidenceStateReadModel.test.ts",
    "src/core/learning/CefrA1ConnectLessonEvidenceStateSafety.test.ts",
    "src/ui/learning/A1ConnectUnitRuntimePanel.lesson-state.test.ts",
    "src/application/learning/CefrA1ConnectLessonScopedCoverageReadModel.test.ts",
    "src/core/learning/CefrA1ConnectLessonContextSafety.test.ts",
    "src/ui/learning/A1ConnectUnitRuntimePanel.lesson.test.ts",
    "src/application/learning/CefrA1ConnectLanguageScopedCoverageReadModel.test.ts"
)

& npx vitest run $targets
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1401-1406 target tests failed."
}

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Full regression failed."
}

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Production build failed."
}

Write-Host "SPRINT-1401-1406 VERIFICATION COMPLETE"
