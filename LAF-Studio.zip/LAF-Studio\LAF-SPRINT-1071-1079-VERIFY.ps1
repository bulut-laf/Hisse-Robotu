$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 1071-1073 Target Tests: Guidance Cycle History ==="
npx vitest run `
  "src/core/learning/CefrDailyGuidanceCycleRecord.test.ts" `
  "src/core/learning/CefrDailyGuidanceCycleHistory.test.ts" `
  "src/core/learning/CefrDailyGuidanceCycleHistorySnapshot.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1071-1073 target tests failed." }

Write-Host "=== Sprint 1074-1076 Target Tests: Incomplete Item Carryover ==="
npx vitest run `
  "src/core/learning/CefrIncompleteGuidanceItem.test.ts" `
  "src/core/learning/CefrGuidanceCarryoverCandidate.test.ts" `
  "src/core/learning/CefrUserGuidanceCarryoverChoice.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1074-1076 target tests failed." }

Write-Host "=== Sprint 1077-1079 Target Tests: Next-Day Continuity Plan ==="
npx vitest run `
  "src/core/learning/CefrGuidanceCarryoverReview.test.ts" `
  "src/core/learning/CefrNextDayGuidanceContinuityItem.test.ts" `
  "src/core/learning/CefrNextDayGuidanceContinuityPlan.test.ts" `
  "src/core/learning/CefrGuidanceContinuityOrchestration.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1077-1079 target tests failed." }

Write-Host "=== Combined Sprint 1071-1079 New Tests ==="
npx vitest run `
  "src/core/learning/CefrDailyGuidanceCycleRecord.test.ts" `
  "src/core/learning/CefrDailyGuidanceCycleHistory.test.ts" `
  "src/core/learning/CefrDailyGuidanceCycleHistorySnapshot.test.ts" `
  "src/core/learning/CefrIncompleteGuidanceItem.test.ts" `
  "src/core/learning/CefrGuidanceCarryoverCandidate.test.ts" `
  "src/core/learning/CefrUserGuidanceCarryoverChoice.test.ts" `
  "src/core/learning/CefrGuidanceCarryoverReview.test.ts" `
  "src/core/learning/CefrNextDayGuidanceContinuityItem.test.ts" `
  "src/core/learning/CefrNextDayGuidanceContinuityPlan.test.ts" `
  "src/core/learning/CefrGuidanceContinuityOrchestration.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1071-1079 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-1071-1079 VERIFICATION COMPLETE"
