import type {
  LafLearningLanguageCode,
} from "../../core/language/LafLanguageProfile";
import {
  getLafA1ConnectLanguageContentPack,
  type CefrA1ConnectRealizedPhrase,
} from "../../core/learning/CefrA1ConnectLanguageContentRegistry";

export interface CefrA1ConnectLanguageContentView {
  readonly languageCode:
    LafLearningLanguageCode;
  readonly lessonId: string;
  readonly phrases:
    readonly CefrA1ConnectRealizedPhrase[];
  readonly languageContentAvailable: true;
  readonly executableTaskAvailable: false;
  readonly evidenceCaptureAvailable: false;
}

export function createCefrA1ConnectLanguageContentView(
  languageCode: LafLearningLanguageCode,
  lessonId: string,
): CefrA1ConnectLanguageContentView {
  const pack =
    getLafA1ConnectLanguageContentPack(
      languageCode,
    );

  const lesson =
    pack.lessons.find(
      item => item.lessonId === lessonId,
    );

  if (!lesson) {
    throw new Error(
      `A1 CONNECT realized lesson not found: ${lessonId}`,
    );
  }

  return {
    languageCode,
    lessonId,
    phrases: lesson.phrases,
    languageContentAvailable: true,
    executableTaskAvailable: false,
    evidenceCaptureAvailable: false,
  };
}
