﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$panel = Join-Path $app "src\ui\learning\A1ConnectNativeLearningPanel.tsx"

if (-not (Test-Path $panel)) {
    throw "A1ConnectNativeLearningPanel.tsx missing."
}

$utf8 = New-Object System.Text.UTF8Encoding($false)
$text = [System.IO.File]::ReadAllText(
    $panel,
    $utf8
)

$importLine =
    'import { A1ConnectLanguageContentPanel } from "./A1ConnectLanguageContentPanel";'

if (-not $text.Contains($importLine)) {
    $anchor =
        'import "./A1ConnectNativeLearningPanel.css";'

    if (-not $text.Contains($anchor)) {
        throw "A1 CONNECT panel import anchor not found."
    }

    $text = $text.Replace(
        $anchor,
        $importLine +
        [Environment]::NewLine +
        [Environment]::NewLine +
        $anchor
    )
}

$renderMarker =
    '          <A1ConnectLanguageContentPanel'

if (-not $text.Contains($renderMarker)) {
    $anchor = '      <div className="a1-connect-native-gate">'

    if (-not $text.Contains($anchor)) {
        throw "A1 CONNECT render anchor not found."
    }

    $render = @'
      {selectedLanguageCode && selectedLesson ? (
        <A1ConnectLanguageContentPanel
          languageCode={selectedLanguageCode}
          lessonId={selectedLesson.lessonId}
        />
      ) : null}

'@

    $text = $text.Replace(
        $anchor,
        $render + $anchor
    )
}

[System.IO.File]::WriteAllText(
    $panel,
    $text,
    $utf8
)

$registry = Join-Path $app "src\core\learning\CefrA1ConnectLanguageContentRegistry.ts"
$view = Join-Path $app "src\application\learning\CefrA1ConnectLanguageContentView.ts"
$contentPanel = Join-Path $app "src\ui\learning\A1ConnectLanguageContentPanel.tsx"
$safety = Join-Path $app "src\core\learning\CefrA1ConnectLanguageContentSafety.ts"

foreach ($file in @(
    $registry,
    $view,
    $contentPanel,
    $safety
)) {
    if (-not (Test-Path $file)) {
        throw "Sprint 1317-1322 source missing: $file"
    }
}

$checks = @{
    $registry = @(
        '"hu"',
        '"tr"',
        '"de"',
        '"it"',
        '"en"',
        '"es"',
        '"ru"',
        'evidenceCaptureEnabled: false'
    )
    $view = @(
        'languageContentAvailable: true',
        'executableTaskAvailable: false',
        'evidenceCaptureAvailable: false'
    )
    $contentPanel = @(
        'A1 CONNECT hedef dil içeriği',
        'view.phrases.map('
    )
    $panel = @(
        'import { A1ConnectLanguageContentPanel } from "./A1ConnectLanguageContentPanel";',
        'languageCode={selectedLanguageCode}',
        'lessonId={selectedLesson.lessonId}'
    )
}

foreach ($entry in $checks.GetEnumerator()) {
    foreach ($marker in $entry.Value) {
        if (-not (
            Select-String `
                -Path $entry.Key `
                -SimpleMatch `
                -Pattern $marker `
                -Quiet
        )) {
            throw "Required Sprint 1317-1322 marker missing: $marker"
        }
    }
}

Write-Host "SPRINT-1317-1322 SOURCE CHECK PASSED"

Set-Location $app

$targets = @(
    "src/core/learning/CefrA1ConnectLanguageContentRegistry.test.ts",
    "src/application/learning/CefrA1ConnectLanguageContentView.test.ts",
    "src/core/learning/CefrA1ConnectLanguageContentSafety.test.ts",
    "src/ui/learning/A1ConnectLanguageContentPanel.test.ts",
    "src/core/learning/CefrA1ConnectLanguageRealizationRegistry.test.ts",
    "src/application/learning/CefrA1ConnectTargetLanguageSelectionModel.test.ts",
    "src/core/learning/CefrA1ConnectLanguageRealizationBoundary.test.ts"
)

& npx vitest run $targets
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1317-1322 target tests failed."
}

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Full regression failed."
}

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Production build failed."
}

Write-Host "SPRINT-1317-1322 VERIFICATION COMPLETE"
