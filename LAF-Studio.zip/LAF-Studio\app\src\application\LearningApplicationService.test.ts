import { describe, expect, it } from "vitest";

import { ApplicationFactory } from "./ApplicationFactory";

describe("LearningApplicationService", () => {
  it("starts a learning session", () => {
    const app = ApplicationFactory.create();

    const result = app.startSession();

    expect(result.session.state).toBe(
      "in-progress",
    );

    expect(result.currentActivity).toBeDefined();
    expect(result.isCompleted).toBe(false);
  });

  it("returns the current activity", () => {
    const app = ApplicationFactory.create();

    app.startSession();

    const activity = app.getCurrentActivity();

    expect(activity).toBeDefined();
    expect(activity?.id).toBe("translation-1");
  });

  it("submits an answer", () => {
    const app = ApplicationFactory.create();

    app.startSession();

    const activity = app.getCurrentActivity();

    expect(activity).toBeDefined();

    if (!activity) {
      throw new Error(
        "Current activity was not found.",
      );
    }

    const acceptedAnswer =
      activity.acceptedAnswers[0];

    expect(acceptedAnswer).toBeDefined();

    if (!acceptedAnswer) {
      throw new Error(
        "Accepted answer was not found.",
      );
    }

    const result = app.submitAnswer({
      activityId: activity.id,
      answer: acceptedAnswer,
      responseTimeMs: 1000,
      attemptNumber: 1,
      hintUsed: false,
    });

    expect(result.response.isCorrect).toBe(
      true,
    );

    expect(result.recommendation.action).toBe(
      "advance",
    );
  });

  it("moves to the next activity", () => {
    const app = ApplicationFactory.create();

    app.startSession();

    const result = app.nextActivity();

    expect(
      result.session.currentActivityIndex,
    ).toBe(1);
  });

  it("moves to the previous activity", () => {
    const app = ApplicationFactory.create();

    app.startSession();
    app.nextActivity();

    const result = app.previousActivity();

    expect(
      result.session.currentActivityIndex,
    ).toBe(0);

    expect(result.currentActivity?.id).toBe(
      "translation-1",
    );
  });

  it("does not move before the first activity", () => {
    const app = ApplicationFactory.create();

    app.startSession();

    const result = app.previousActivity();

    expect(
      result.session.currentActivityIndex,
    ).toBe(0);

    expect(result.currentActivity?.id).toBe(
      "translation-1",
    );
  });

  it("restarts a completed learning session", () => {
    const app = ApplicationFactory.create();

    let result = app.startSession();

    while (!result.isCompleted) {
      result = app.nextActivity();
    }

    const restarted = app.restartSession();

    expect(restarted.session.state).toBe(
      "in-progress",
    );

    expect(
      restarted.session.currentActivityIndex,
    ).toBe(0);

    expect(restarted.currentActivity?.id).toBe(
      "translation-1",
    );

    expect(restarted.isCompleted).toBe(false);
  });

  it("increments the current activity attempt", () => {
    const app = ApplicationFactory.create();

    app.startSession();

    const result =
      app.retryCurrentActivity();

    expect(
      result.session.currentAttemptNumber,
    ).toBe(2);
  });

  it("marks the current activity hint as used", () => {
    const app = ApplicationFactory.create();

    app.startSession();

    const result =
      app.revealCurrentHint();

    expect(
      result.session.currentHintUsed,
    ).toBe(true);
  });
});
