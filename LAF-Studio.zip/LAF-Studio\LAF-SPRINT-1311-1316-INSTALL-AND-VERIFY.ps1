﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$panel = Join-Path $app "src\ui\learning\A1ConnectNativeLearningPanel.tsx"
$css = Join-Path $app "src\ui\learning\A1ConnectNativeLearningPanel.css"
$cssPart = Join-Path $app "src\ui\learning\A1ConnectNativeLearningPanel.language-realization.css"

if (-not (Test-Path $panel)) {
    throw "A1ConnectNativeLearningPanel.tsx missing."
}

if (-not (Test-Path $css)) {
    throw "A1ConnectNativeLearningPanel.css missing."
}

if (-not (Test-Path $cssPart)) {
    throw "Language-realization CSS fragment missing."
}

$utf8 = New-Object System.Text.UTF8Encoding($false)

$cssText = [System.IO.File]::ReadAllText(
    $css,
    $utf8
)
$cssExtra = [System.IO.File]::ReadAllText(
    $cssPart,
    $utf8
)

$marker = ".a1-connect-native-language {"

if (-not $cssText.Contains($marker)) {
    [System.IO.File]::WriteAllText(
        $css,
        $cssText +
        [Environment]::NewLine +
        $cssExtra,
        $utf8
    )
}

Remove-Item $cssPart -Force

$registry = Join-Path $app "src\core\learning\CefrA1ConnectLanguageRealizationRegistry.ts"
$selection = Join-Path $app "src\application\learning\CefrA1ConnectTargetLanguageSelectionModel.ts"
$boundary = Join-Path $app "src\core\learning\CefrA1ConnectLanguageRealizationBoundary.ts"

foreach ($file in @(
    $registry,
    $selection,
    $boundary,
    $panel
)) {
    if (-not (Test-Path $file)) {
        throw "Sprint 1311-1316 source missing: $file"
    }
}

$checks = @{
    $registry = @(
        'LAF_LEARNING_LANGUAGE_CODES.map(',
        'languageContentBound: false',
        'evidenceCaptureAvailable: false',
        '"content-approval-required"'
    )
    $selection = @(
        'selectedLanguageCode:',
        'LafLearningLanguageCode | null',
        'selectionRequired:',
        'selectedByUser:'
    )
    $boundary = @(
        'targetLanguageMayBeInferredFromTranslationStudio:',
        'false',
        'targetLanguageMayBeDefaulted: false',
        'languageSelectionCreatesEvidence: false'
    )
    $panel = @(
        'Hedef dil seçin',
        'isLafLearningLanguageCode(value)',
        'selectedLanguageCode',
        'Dil seçimi, ders seçimi veya sayfa'
    )
}

foreach ($entry in $checks.GetEnumerator()) {
    foreach ($text in $entry.Value) {
        if (-not (
            Select-String -Path $entry.Key `
                -SimpleMatch `
                -Pattern $text `
                -Quiet
        )) {
            throw "Required Sprint 1311-1316 marker missing: $text"
        }
    }
}

Write-Host "SPRINT-1311-1316 SOURCE CHECK PASSED"

Set-Location $app

$targets = @(
    "src/core/learning/CefrA1ConnectLanguageRealizationRegistry.test.ts",
    "src/application/learning/CefrA1ConnectTargetLanguageSelectionModel.test.ts",
    "src/core/learning/CefrA1ConnectLanguageRealizationBoundary.test.ts",
    "src/ui/learning/A1ConnectTargetLanguageBinding.test.ts",
    "src/application/learning/CefrA1ConnectNativeLearningUiModel.test.ts",
    "src/core/learning/CefrA1ConnectNativeLearningUiSafety.test.ts",
    "src/application/learning/CefrA1ConnectRuntimeEvidenceService.test.ts"
)

& npx vitest run $targets
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1311-1316 target tests failed."
}

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Full regression failed."
}

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Production build failed."
}

Write-Host "SPRINT-1311-1316 VERIFICATION COMPLETE"
