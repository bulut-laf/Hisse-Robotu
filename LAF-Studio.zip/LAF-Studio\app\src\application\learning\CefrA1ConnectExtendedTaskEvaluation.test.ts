import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrA1ConnectPersonalAnswerTask,
} from "../../core/learning/CefrA1ConnectExtendedExecutableTasks";
import {
  evaluateCefrA1ConnectExtendedChoiceTask,
} from "./CefrA1ConnectExtendedTaskEvaluation";

describe(
  "CefrA1ConnectExtendedTaskEvaluation",
  () => {
    it("opens evidence only for a correct explicit submission", () => {
      const task =
        createCefrA1ConnectPersonalAnswerTask(
          "en",
        );

      expect(
        evaluateCefrA1ConnectExtendedChoiceTask(
          task,
          task.correctAnswer,
        ).evidenceEligible,
      ).toBe(true);

      expect(
        evaluateCefrA1ConnectExtendedChoiceTask(
          task,
          "not-correct",
        ).evidenceEligible,
      ).toBe(false);
    });
  },
);
