﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$report = Join-Path $root "SPRINT-1503-1505-REV3-DIAGNOSTIC.txt"

if (-not (Test-Path $app)) {
    throw "LAF Studio app klasoru bulunamadi: $app"
}

$npxCommand =
    Get-Command "npx.cmd" -ErrorAction Stop

$npxPath =
    $npxCommand.Source

if (-not $npxPath) {
    throw "npx.cmd yolu cozumlenemedi."
}

$tests = @(
    "src/core/learning/CefrA1DescribeRuntimeSliceDefinition.test.ts",
    "src/core/learning/CefrProductionRuntimeSliceRegistry.test.ts",
    "src/core/learning/CefrProductionRuntimeRegistryEnforcement.test.ts",
    "src/core/learning/CefrProductionRuntimeEvidenceEligibilityAudit.test.ts",
    "src/application/learning/CefrProductionRuntimeDelayedRetrievalVisibility.test.ts",
    "src/application/learning/CefrA1DescribeProductionRuntime.test.ts",
    "src/application/learning/CefrProductionRuntimePlatform.test.ts"
)

foreach ($test in $tests) {
    $full =
        Join-Path $app $test

    if (-not (Test-Path $full)) {
        throw "Checkpoint 3 test dosyasi bulunamadi: $test"
    }
}

if (Test-Path $report) {
    Remove-Item $report -Force
}

$utf8NoBom =
    New-Object System.Text.UTF8Encoding($false)

$header = @"
LAF STUDIO
SPRINT-1503-1505 REV3 DIAGNOSTIC
Generated: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")
Mode: READ ONLY
Previous checkpoints:
- Sprint 1497-1499 PASSED
- Sprint 1500-1502 PASSED

Scope:
- Sprint 1503-1505 target tests only
- No source mutation
- No full regression
- No production build

Native command capture:
- Start-Process
- stdout/stderr redirected to files
- PowerShell NativeCommandError conversion bypassed

NPX:
$npxPath

"@

[System.IO.File]::WriteAllText(
    $report,
    $header,
    $utf8NoBom
)

Set-Location $app

$failed =
    New-Object System.Collections.Generic.List[string]

$passed =
    New-Object System.Collections.Generic.List[string]

foreach ($test in $tests) {
    $separator = @"

================================================================================
TEST: $test
================================================================================
"@

    [System.IO.File]::AppendAllText(
        $report,
        $separator,
        $utf8NoBom
    )

    Write-Host ""
    Write-Host "============================================================"
    Write-Host "DIAGNOSTIC TEST: $test"
    Write-Host "============================================================"

    $token =
        [Guid]::NewGuid().ToString("N")

    $stdoutPath =
        Join-Path $env:TEMP (
            "laf-vitest-$token-out.txt"
        )

    $stderrPath =
        Join-Path $env:TEMP (
            "laf-vitest-$token-err.txt"
        )

    try {
        $arguments = @(
            "vitest",
            "run",
            $test,
            "--reporter=verbose"
        )

        $process =
            Start-Process `
                -FilePath $npxPath `
                -ArgumentList $arguments `
                -WorkingDirectory $app `
                -RedirectStandardOutput $stdoutPath `
                -RedirectStandardError $stderrPath `
                -Wait `
                -PassThru

        $exitCode =
            $process.ExitCode

        $stdout = ""
        $stderr = ""

        if (Test-Path $stdoutPath) {
            $stdout =
                [System.IO.File]::ReadAllText(
                    $stdoutPath
                )
        }

        if (Test-Path $stderrPath) {
            $stderr =
                [System.IO.File]::ReadAllText(
                    $stderrPath
                )
        }

        if ($stdout) {
            Write-Host $stdout

            [System.IO.File]::AppendAllText(
                $report,
                "`r`n--- STDOUT ---`r`n" +
                $stdout,
                $utf8NoBom
            )
        }

        if ($stderr) {
            Write-Host "STDERR:"
            Write-Host $stderr

            [System.IO.File]::AppendAllText(
                $report,
                "`r`n--- STDERR ---`r`n" +
                $stderr,
                $utf8NoBom
            )
        }

        [System.IO.File]::AppendAllText(
            $report,
            "`r`nEXIT_CODE=$exitCode`r`n",
            $utf8NoBom
        )

        if ($exitCode -eq 0) {
            $passed.Add($test)
            Write-Host "PASS: $test"
        }
        else {
            $failed.Add($test)
            Write-Host "FAIL: $test"
        }
    }
    finally {
        foreach ($tempPath in @(
            $stdoutPath,
            $stderrPath
        )) {
            if (Test-Path $tempPath) {
                Remove-Item `
                    -LiteralPath $tempPath `
                    -Force `
                    -ErrorAction SilentlyContinue
            }
        }
    }
}

$summary = @"

================================================================================
SUMMARY
================================================================================
PASSED=$($passed.Count)
FAILED=$($failed.Count)

PASSED TESTS:
$($passed -join [Environment]::NewLine)

FAILED TESTS:
$($failed -join [Environment]::NewLine)

REPORT:
$report
"@

[System.IO.File]::AppendAllText(
    $report,
    $summary,
    $utf8NoBom
)

Write-Host ""
Write-Host "============================================================"
Write-Host "SPRINT-1503-1505 REV3 DIAGNOSTIC COMPLETE"
Write-Host "Passed: $($passed.Count)"
Write-Host "Failed: $($failed.Count)"
Write-Host "Report: $report"
Write-Host "============================================================"

if ($failed.Count -gt 0) {
    Write-Host ""
    Write-Host "FAILED TESTS:"

    foreach ($item in $failed) {
        Write-Host " - $item"
    }

    throw "Sprint 1503-1505 Rev3 diagnostic found $($failed.Count) failing test file(s)."
}

Write-Host ""
Write-Host "All checkpoint-3 tests passed individually."
Write-Host "If grouped checkpoint still fails, verifier orchestration/group interaction is the remaining suspect."
