﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$src = Join-Path $root "app\src"
$out = Join-Path $root "LAF_FEEDBACK_WRITE_SEAM_SNAPSHOT.txt"

$relativePaths = @(
  "core\learning\CefrPersonalLanguageProfileEvidence.ts"
  "core\learning\CefrPersonalLanguageProfileRefresh.ts"
  "core\learning\CefrIntelligenceEvidenceEnvelope.ts"
  "core\session\LearningSession.ts"
  "ui\storage\LocalStorageSessionStorage.ts"
  "ui\hooks\useLearningSession.ts"
)

$lines = New-Object System.Collections.Generic.List[string]

function Add-Line {
    param([string]$Text)
    if ($null -eq $Text) { $Text = "" }
    [void]$lines.Add($Text)
}

Add-Line "LAF STUDIO - FEEDBACK WRITE SEAM SNAPSHOT"
Add-Line ("Generated: " + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
Add-Line "READ ONLY - no project files are modified."

foreach ($relative in $relativePaths) {
    $path = Join-Path $src $relative

    Add-Line ""
    Add-Line ("=" * 88)
    Add-Line ("FILE: app\src\" + $relative)
    Add-Line ("=" * 88)

    if (-not (Test-Path $path)) {
        Add-Line "(missing)"
        continue
    }

    $content = @(Get-Content -Path $path)
    for ($i = 0; $i -lt $content.Count; $i++) {
        Add-Line ("{0,4}: {1}" -f ($i + 1), $content[$i])
    }
}

Add-Line ""
Add-Line ("=" * 88)
Add-Line "CAPABILITY REFERENCE CHECK"
Add-Line ("=" * 88)

$capabilityHits = @(
  Get-ChildItem -Path $src -Recurse -File -ErrorAction SilentlyContinue |
  Where-Object {
    $_.Extension -eq ".ts" -or $_.Extension -eq ".tsx"
  } |
  Select-String -Pattern "capabilityReference" -SimpleMatch -ErrorAction SilentlyContinue |
  Where-Object {
    $_.Path -match "lesson|Lesson|activity|Activity|catalog|Catalog"
  } |
  Select-Object -First 120
)

if ($capabilityHits.Count -eq 0) {
    Add-Line "(no lesson/activity capabilityReference binding found)"
}
else {
    foreach ($hit in $capabilityHits) {
        $relative = $hit.Path.Substring(($root + "\").Length)
        Add-Line ("{0}:{1} {2}" -f $relative, $hit.LineNumber, $hit.Line.Trim())
    }
}

$lines | Set-Content -Path $out -Encoding UTF8

Write-Host ""
Write-Host "LAF FEEDBACK WRITE SEAM SNAPSHOT COMPLETE"
Write-Host "Report:"
Write-Host $out
Write-Host ""
Get-Content -Path $out
