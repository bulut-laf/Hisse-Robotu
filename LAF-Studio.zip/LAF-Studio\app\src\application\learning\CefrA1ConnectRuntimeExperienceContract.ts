import {
  LAF_A1_CONNECT_REAL_LIFE_ACTIVATION,
} from "../../core/learning/CefrA1ConnectActivationDefinition";
import {
  LAF_A1_CONNECT_EVIDENCE_DEFINITIONS,
} from "../../core/learning/CefrA1ConnectEvidenceDefinition";
import {
  LAF_A1_CONNECT_INTERACTIONS,
} from "../../core/learning/CefrA1ConnectInteractionDefinition";
import {
  LAF_A1_CONNECT_PRACTICE_DEFINITIONS,
} from "../../core/learning/CefrA1ConnectPracticeDefinition";

export interface CefrA1ConnectRuntimeExperienceContract {
  readonly practiceDefinitionCount: 4;
  readonly meaningfulInteractionCount: 3;
  readonly evidenceDefinitionCount: 7;
  readonly activationCount: 1;
  readonly explicitEvidenceDefinitionRequired: true;
  readonly explicitUserActionRequired: true;
  readonly automaticPracticeEvidenceCapture: false;
  readonly automaticInteractionEvidenceCapture: false;
  readonly automaticActivationEvidenceCapture: false;
  readonly persistedRealEvidenceRequired: true;
  readonly capabilityObservationTarget:
    "social-exchange";
  readonly observationalOnly: true;
  readonly masteryAssignmentAllowed: false;
  readonly competencySuccessAssignmentAllowed: false;
  readonly cefrLevelAssignmentAllowed: false;
  readonly automaticProgressionAllowed: false;
  readonly automaticStudioLaunchAllowed: false;
}

export function createCefrA1ConnectRuntimeExperienceContract():
  CefrA1ConnectRuntimeExperienceContract {
  return {
    practiceDefinitionCount:
      LAF_A1_CONNECT_PRACTICE_DEFINITIONS.length as 4,
    meaningfulInteractionCount:
      LAF_A1_CONNECT_INTERACTIONS.length as 3,
    evidenceDefinitionCount:
      LAF_A1_CONNECT_EVIDENCE_DEFINITIONS.length as 7,
    activationCount:
      LAF_A1_CONNECT_REAL_LIFE_ACTIVATION
        ? 1
        : 1,
    explicitEvidenceDefinitionRequired: true,
    explicitUserActionRequired: true,
    automaticPracticeEvidenceCapture: false,
    automaticInteractionEvidenceCapture: false,
    automaticActivationEvidenceCapture: false,
    persistedRealEvidenceRequired: true,
    capabilityObservationTarget:
      "social-exchange",
    observationalOnly: true,
    masteryAssignmentAllowed: false,
    competencySuccessAssignmentAllowed:
      false,
    cefrLevelAssignmentAllowed: false,
    automaticProgressionAllowed: false,
    automaticStudioLaunchAllowed: false,
  };
}
