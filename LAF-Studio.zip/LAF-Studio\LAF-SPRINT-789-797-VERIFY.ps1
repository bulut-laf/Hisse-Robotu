$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 789-791 Target Tests: Custodial Significance ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialSignificance.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialSignificanceCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialSignificanceAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 789-791 target tests failed." }

Write-Host "=== Sprint 792-794 Target Tests: Custodial Impact ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialImpact.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialImpactCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialImpactAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 792-794 target tests failed." }

Write-Host "=== Sprint 795-797 Target Tests: Custodial Consequence ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialConsequence.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialConsequenceCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialConsequenceAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 795-797 target tests failed." }

Write-Host "=== Combined Sprint 789-797 New Tests ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialSignificance.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialSignificanceCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialSignificanceAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialImpact.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialImpactCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialImpactAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialConsequence.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialConsequenceCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialConsequenceAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 789-797 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-789-797 VERIFICATION COMPLETE"
