﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

Write-Host "=== Install Guidance Evidence Coverage Summary ==="
Set-Location $root
node ".\LAF-SPRINT-1251-1256-INSTALL.mjs"
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1251-1256 install failed."
}

$guidancePage = Join-Path $app "src\ui\pages\GuidanceCenterPage.tsx"

$panelMatches = @(
    Select-String `
        -Path $guidancePage `
        -SimpleMatch `
        '<GuidanceEvidenceCoveragePanel state={source.state} />'
)

if ($panelMatches.Count -ne 1) {
    throw (
        "Guidance evidence coverage panel validation failed. Count=" +
        $panelMatches.Count
    )
}

Set-Location $app

Write-Host "=== Sprint 1251-1254 Target Tests: Evidence Coverage Read Model ==="
npx vitest run `
  "src/application/learning/CefrGuidanceEvidenceCoverageView.test.ts"
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1251-1254 target tests failed."
}

Write-Host "=== Sprint 1255-1256 Safety Tests ==="
npx vitest run `
  "src/application/learning/CefrGuidanceEvidenceCoverageSafety.test.ts"
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1255-1256 safety tests failed."
}

Write-Host "=== Combined Sprint 1251-1256 Tests ==="
npx vitest run `
  "src/application/learning/CefrGuidanceEvidenceCoverageView.test.ts" `
  "src/application/learning/CefrGuidanceEvidenceCoverageSafety.test.ts" `
  "src/application/learning/CefrGuidanceEvidenceActivityView.test.ts" `
  "src/application/learning/CefrGuidanceEvidenceProvenanceSafety.test.ts" `
  "src/application/learning/CefrGuidanceRuntimeProfileService.test.ts"
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1251-1256 combined tests failed."
}

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Full regression failed."
}

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Production build failed."
}

Write-Host "SPRINT-1251-1256 VERIFICATION COMPLETE"
