import type {
  LafLearningLanguageCode,
} from "../../core/language/LafLanguageProfile";
import {
  LAF_A1_NAVIGATE_ALL_EXECUTABLE_TASKS,
  type CefrA1NavigateAllExecutableTaskId,
} from "../../core/learning/CefrA1NavigateExecutableTaskCatalog";
import {
  CefrProductionRuntimePlatform,
} from "./CefrProductionRuntimePlatform";

export interface CefrA1NavigatePersistedCoverageItem {
  readonly taskId:
    CefrA1NavigateAllExecutableTaskId;
  readonly evidenceDefinitionId: string;
  readonly sourceLearningItemId: string;
  readonly observed: boolean;
  readonly matchingEvidenceIds:
    readonly string[];
  readonly persistedRealEvidenceOnly: true;
  readonly targetLanguageScoped: true;
  readonly masteryClaimed: false;
  readonly cefrLevelClaimed: false;
}

export interface CefrA1NavigatePersistedCoverageView {
  readonly languageCode:
    LafLearningLanguageCode;
  readonly items:
    readonly CefrA1NavigatePersistedCoverageItem[];
  readonly observedImmediateEvidenceCount:
    number;
  readonly immediateEvidenceCount: 6;
  readonly allImmediateEvidenceObserved:
    boolean;
  readonly delayedRetrievalIncluded: false;
  readonly crossLanguageEvidenceExcluded:
    true;
  readonly unscopedEvidenceExcluded: true;
  readonly persistedRealEvidenceOnly: true;
  readonly coverageOnly: true;
  readonly masteryInferred: false;
  readonly cefrLevelInferred: false;
  readonly progressionTriggered: false;
}

export type CefrA1NavigatePersistedAdvisoryStatus =
  | "next-persisted-evidence-task"
  | "guided-activation-available"
  | "no-runtime-evidence-defined";

export interface CefrA1NavigatePersistedAdvisoryView {
  readonly status:
    CefrA1NavigatePersistedAdvisoryStatus;
  readonly nextTaskId:
    CefrA1NavigateAllExecutableTaskId | null;
  readonly evidenceDefinitionId:
    string | null;
  readonly guidedActivationAvailable:
    boolean;
  readonly advisoryOnly: true;
  readonly userApplyRequired: true;
  readonly delayedRetrievalRecommended:
    false;
  readonly delayedRetrievalExecutable:
    false;
  readonly automaticTaskSelection: false;
  readonly automaticEvidenceWrite: false;
  readonly masteryInferred: false;
  readonly cefrLevelInferred: false;
  readonly progressionTriggered: false;
}

export interface CefrA1NavigatePersistedEvidenceView {
  readonly coverage:
    CefrA1NavigatePersistedCoverageView;
  readonly advisory:
    CefrA1NavigatePersistedAdvisoryView;
  readonly readOnly: true;
  readonly learningStateMutated: false;
  readonly masteryMutated: false;
  readonly cefrLevelMutated: false;
  readonly progressionPerformed: false;
}

const taskByEvidenceDefinitionId =
  new Map(
    LAF_A1_NAVIGATE_ALL_EXECUTABLE_TASKS.map(
      task => [
        task.evidenceDefinitionId,
        task,
      ] as const,
    ),
  );

export function createCefrA1NavigatePersistedEvidenceView(
  platform:
    CefrProductionRuntimePlatform,
  languageCode:
    LafLearningLanguageCode,
): CefrA1NavigatePersistedEvidenceView {
  const runtimeRead =
    platform.readLanguageEvidence(
      "a1-navigate",
      languageCode,
    );

  const items =
    runtimeRead.coverage.items.map(
      item => {
        const task =
          taskByEvidenceDefinitionId.get(
            item.evidenceDefinitionId,
          );

        if (!task) {
          throw new Error(
            `A1 NAVIGATE runtime evidence is not mapped to an immediate task: ${item.evidenceDefinitionId}`,
          );
        }

        return {
          taskId: task.taskId,
          evidenceDefinitionId:
            item.evidenceDefinitionId,
          sourceLearningItemId:
            item.sourceLearningItemId,
          observed: item.observed,
          matchingEvidenceIds:
            item.matchingEvidenceIds,
          persistedRealEvidenceOnly: true,
          targetLanguageScoped: true,
          masteryClaimed: false,
          cefrLevelClaimed: false,
        } satisfies
          CefrA1NavigatePersistedCoverageItem;
      },
    );

  if (
    items.length !==
    LAF_A1_NAVIGATE_ALL_EXECUTABLE_TASKS.length
  ) {
    throw new Error(
      `A1 NAVIGATE runtime evidence count mismatch: expected 6, received ${items.length}`,
    );
  }

  const observedCount =
    items.filter(
      item => item.observed,
    ).length;

  let advisory:
    CefrA1NavigatePersistedAdvisoryView;

  if (
    runtimeRead.advisory.status ===
    "no-authoritative-evidence-defined"
  ) {
    advisory = {
      status:
        "no-runtime-evidence-defined",
      nextTaskId: null,
      evidenceDefinitionId: null,
      guidedActivationAvailable: false,
      advisoryOnly: true,
      userApplyRequired: true,
      delayedRetrievalRecommended: false,
      delayedRetrievalExecutable: false,
      automaticTaskSelection: false,
      automaticEvidenceWrite: false,
      masteryInferred: false,
      cefrLevelInferred: false,
      progressionTriggered: false,
    };
  } else if (
    runtimeRead.advisory.status ===
    "authoritative-evidence-covered"
  ) {
    advisory = {
      status:
        "guided-activation-available",
      nextTaskId: null,
      evidenceDefinitionId: null,
      guidedActivationAvailable: true,
      advisoryOnly: true,
      userApplyRequired: true,
      delayedRetrievalRecommended: false,
      delayedRetrievalExecutable: false,
      automaticTaskSelection: false,
      automaticEvidenceWrite: false,
      masteryInferred: false,
      cefrLevelInferred: false,
      progressionTriggered: false,
    };
  } else {
    const evidenceDefinitionId =
      runtimeRead.advisory
        .evidenceDefinitionId;

    if (!evidenceDefinitionId) {
      throw new Error(
        "A1 NAVIGATE persisted advisory is missing its evidence definition.",
      );
    }

    const task =
      taskByEvidenceDefinitionId.get(
        evidenceDefinitionId,
      );

    if (!task) {
      throw new Error(
        `A1 NAVIGATE persisted advisory points outside immediate runtime tasks: ${evidenceDefinitionId}`,
      );
    }

    advisory = {
      status:
        "next-persisted-evidence-task",
      nextTaskId: task.taskId,
      evidenceDefinitionId,
      guidedActivationAvailable: false,
      advisoryOnly: true,
      userApplyRequired: true,
      delayedRetrievalRecommended: false,
      delayedRetrievalExecutable: false,
      automaticTaskSelection: false,
      automaticEvidenceWrite: false,
      masteryInferred: false,
      cefrLevelInferred: false,
      progressionTriggered: false,
    };
  }

  return {
    coverage: {
      languageCode,
      items,
      observedImmediateEvidenceCount:
        observedCount,
      immediateEvidenceCount: 6,
      allImmediateEvidenceObserved:
        observedCount === 6,
      delayedRetrievalIncluded: false,
      crossLanguageEvidenceExcluded:
        true,
      unscopedEvidenceExcluded: true,
      persistedRealEvidenceOnly: true,
      coverageOnly: true,
      masteryInferred: false,
      cefrLevelInferred: false,
      progressionTriggered: false,
    },
    advisory,
    readOnly: true,
    learningStateMutated: false,
    masteryMutated: false,
    cefrLevelMutated: false,
    progressionPerformed: false,
  };
}
