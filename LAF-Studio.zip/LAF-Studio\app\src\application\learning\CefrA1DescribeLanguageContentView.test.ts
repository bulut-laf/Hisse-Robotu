import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrA1DescribeLanguageContentView,
} from "./CefrA1DescribeLanguageContentView";

describe(
  "A1 DESCRIBE language content view",
  () => {
    it("shows selected target-language content without creating evidence or narration scope", () => {
      const result =
        createCefrA1DescribeLanguageContentView(
          "it",
          "a1-describe-familiar-person",
        );

      expect(result).toMatchObject({
        languageCode: "it",
        lessonId:
          "a1-describe-familiar-person",
        languageContentAvailable: true,
        assistantAuthoredV1: true,
        nativeReviewValidated: false,
        descriptionProductionOnly: true,
        narrativeSequencingIntroduced:
          false,
        executableTaskAvailable: false,
        evidenceCaptureAvailable: false,
        delayedRetrievalRuntimeAvailable:
          false,
      });

      expect(
        result.phrases.map(
          phrase => phrase.phraseId,
        ),
      ).toEqual([
        "person-identify",
        "person-tall",
        "person-kind",
        "person-busy",
      ]);
    });
  },
);
