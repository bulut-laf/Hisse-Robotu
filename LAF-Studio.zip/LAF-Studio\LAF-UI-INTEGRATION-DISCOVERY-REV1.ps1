$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$src = Join-Path $app "src"
$out = Join-Path $root "LAF_UI_INTEGRATION_DISCOVERY.txt"

if (-not (Test-Path $app)) {
    throw "App root not found: $app"
}

$lines = New-Object System.Collections.Generic.List[string]

function Add-Line {
    param([string]$Text = "")
    $lines.Add($Text)
}

function Add-Section {
    param([string]$Title)
    Add-Line ""
    Add-Line ("=" * 88)
    Add-Line $Title
    Add-Line ("=" * 88)
}

function Get-RelativeProjectPath {
    param([string]$FullPath)

    $prefix = $root + "\"
    if ($FullPath.StartsWith($prefix, [System.StringComparison]::OrdinalIgnoreCase)) {
        return $FullPath.Substring($prefix.Length)
    }

    return $FullPath
}

function Add-FilePreview {
    param(
        [string]$Path,
        [int]$MaxLines = 120
    )

    if (-not (Test-Path $Path)) {
        return
    }

    Add-Line ""
    Add-Line ("FILE: " + (Get-RelativeProjectPath $Path))
    Add-Line ("-" * 88)

    $content = @(Get-Content -Path $Path -ErrorAction Stop)
    $count = [Math]::Min($content.Count, $MaxLines)

    for ($i = 0; $i -lt $count; $i++) {
        Add-Line ("{0,4}: {1}" -f ($i + 1), $content[$i])
    }

    if ($content.Count -gt $MaxLines) {
        Add-Line ("... truncated; total lines: " + $content.Count)
    }
}

function Add-Matches {
    param(
        [string]$Title,
        [string[]]$Patterns,
        [int]$Limit = 120
    )

    Add-Section $Title

    $files = @(
        Get-ChildItem -Path $src -Recurse -File -Include *.ts,*.tsx,*.js,*.jsx,*.css -ErrorAction SilentlyContinue
    )

    $collected = New-Object System.Collections.Generic.List[object]

    foreach ($file in $files) {
        foreach ($pattern in $Patterns) {
            $hits = @(
                Select-String -Path $file.FullName -Pattern $pattern -SimpleMatch -ErrorAction SilentlyContinue
            )

            foreach ($hit in $hits) {
                $collected.Add(
                    [PSCustomObject]@{
                        File    = Get-RelativeProjectPath $hit.Path
                        Line    = $hit.LineNumber
                        Text    = $hit.Line.Trim()
                        Pattern = $pattern
                    }
                )
            }
        }
    }

    $matches = @(
        $collected |
            Sort-Object File, Line, Pattern -Unique |
            Select-Object -First $Limit
    )

    if ($matches.Count -eq 0) {
        Add-Line "(no matches)"
        return
    }

    foreach ($m in $matches) {
        Add-Line ("{0}:{1}  [{2}]  {3}" -f $m.File, $m.Line, $m.Pattern, $m.Text)
    }
}

Add-Line "LAF STUDIO — REAL UI / ROUTER INTEGRATION DISCOVERY"
Add-Line ("Generated: " + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
Add-Line ("Project: " + $root)
Add-Line "READ-ONLY DISCOVERY: no project source files are modified."

Add-Section "1. PACKAGE / BUILD CONFIG"
Add-FilePreview -Path (Join-Path $app "package.json") -MaxLines 180
Add-FilePreview -Path (Join-Path $app "vite.config.ts") -MaxLines 120
Add-FilePreview -Path (Join-Path $app "vite.config.js") -MaxLines 120
Add-FilePreview -Path (Join-Path $app "tsconfig.json") -MaxLines 120

Add-Section "2. TOP-LEVEL SRC FILE TREE"
$topFiles = @(
    Get-ChildItem -Path $src -File -ErrorAction SilentlyContinue |
        Sort-Object Name
)
if ($topFiles.Count -eq 0) {
    Add-Line "(no top-level src files found)"
}
else {
    foreach ($file in $topFiles) {
        Add-Line (Get-RelativeProjectPath $file.FullName)
    }
}

Add-Section "3. LIKELY APP / ROUTER / ENTRY FILES"
$candidates = @(
    Get-ChildItem -Path $src -Recurse -File -Include App.tsx,App.ts,main.tsx,main.ts,index.tsx,index.ts,router.tsx,router.ts,routes.tsx,routes.ts,Router.tsx,Routes.tsx -ErrorAction SilentlyContinue |
        Sort-Object FullName -Unique
)

if ($candidates.Count -eq 0) {
    Add-Line "(no conventional entry/router filenames found)"
}
else {
    foreach ($file in $candidates) {
        Add-FilePreview -Path $file.FullName -MaxLines 180
    }
}

$routerPatterns = @(
    "react-router"
    "BrowserRouter"
    "HashRouter"
    "MemoryRouter"
    "Routes"
    "Route"
    "useNavigate"
    "navigate("
    "router.push"
    "router.replace"
    "location.pathname"
    "window.location"
)
Add-Matches -Title "4. ROUTER / NAVIGATION SIGNALS" -Patterns $routerPatterns -Limit 180

$learningPatterns = @(
    "Today's Learning Focus"
    "Today’s Learning Focus"
    "Learning Focus"
    "Daily Learning"
    "Learning Path"
    "Continue Learning"
    "CEFR"
    "Language Orbit"
    "Sticky Learning Journey"
    "Hareket Kontrolü"
)
Add-Matches -Title "5. CURRENT LEARNING HOME / DASHBOARD SIGNALS" -Patterns $learningPatterns -Limit 180

$studioPatterns = @(
    "grammar-lab"
    "reading-studio"
    "listening-studio"
    "writing-studio"
    "speaking-pronunciation-studio"
    "dialogue-role-play-studio"
    "vocabulary-memory-studio"
    "translation-studio"
    "interpreting-studio"
    "Grammar Lab"
    "Reading Studio"
    "Listening Studio"
    "Writing Studio"
    "Speaking"
    "Dialogue"
    "Vocabulary"
    "Translation Studio"
)
Add-Matches -Title "6. STUDIO NAVIGATION / STUDIO COMPONENT SIGNALS" -Patterns $studioPatterns -Limit 220

$statePatterns = @(
    "createContext"
    "useContext"
    "useReducer"
    "useState"
    "zustand"
    "redux"
    "localStorage"
    "sessionStorage"
    "service"
    "repository"
    "store"
)
Add-Matches -Title "7. STATE / CONTEXT / SERVICE SIGNALS" -Patterns $statePatterns -Limit 180

$facadePatterns = @(
    "CefrGuidanceApplicationFacade"
    "cefrGuidanceApplicationFacade"
    "CefrIntegratedGuidancePlatform"
    "CefrApplicationGuidance"
)
Add-Matches -Title "8. EXISTING CEFR GUIDANCE PUBLIC FACADE REFERENCES" -Patterns $facadePatterns -Limit 160

Add-Section "9. LIKELY UI COMPONENT FILES"
$uiFiles = @(
    Get-ChildItem -Path $src -Recurse -File -Include *.tsx -ErrorAction SilentlyContinue |
        Where-Object {
            $_.FullName -match "component|page|screen|view|dashboard|home|learning|studio|cefr"
        } |
        Sort-Object FullName |
        Select-Object -First 120
)

if ($uiFiles.Count -eq 0) {
    Add-Line "(no likely UI files found by path heuristic)"
}
else {
    foreach ($file in $uiFiles) {
        Add-Line ("{0}  ({1} bytes)" -f (Get-RelativeProjectPath $file.FullName), $file.Length)
    }
}

Add-Section "10. TEST CONVENTIONS NEAR UI / APP"
$testFiles = @(
    Get-ChildItem -Path $src -Recurse -File -Include *.test.ts,*.test.tsx -ErrorAction SilentlyContinue |
        Where-Object {
            $_.FullName -match "component|page|screen|view|dashboard|home|learning|studio|cefr|App"
        } |
        Sort-Object FullName |
        Select-Object -First 100
)

if ($testFiles.Count -eq 0) {
    Add-Line "(no matching test files found)"
}
else {
    foreach ($file in $testFiles) {
        Add-Line (Get-RelativeProjectPath $file.FullName)
    }
}

Add-Section "11. INTEGRATION DECISION INPUT"
Add-Line "Use this report to determine:"
Add-Line "- exact application entry / router file"
Add-Line "- exact Learning Home / CEFR UI insertion point"
Add-Line "- exact Studio route identifiers"
Add-Line "- existing navigation mechanism"
Add-Line "- existing state/service pattern"
Add-Line "- nearby test conventions"
Add-Line "- whether first real UI block should touch 3 or fewer production files"

$lines | Set-Content -Path $out -Encoding UTF8

Write-Host ""
Write-Host "LAF UI INTEGRATION DISCOVERY REV1 COMPLETE"
Write-Host "Report:"
Write-Host $out
Write-Host ""
Get-Content -Path $out
