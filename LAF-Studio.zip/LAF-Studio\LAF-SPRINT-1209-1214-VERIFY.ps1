﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

Write-Host "=== Install Runtime Profile UI Binding ==="
Set-Location $root
node ".\LAF-SPRINT-1209-1214-INSTALL.mjs"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1209-1214 install failed." }

$guidancePage = Join-Path $app "src\ui\pages\GuidanceCenterPage.tsx"

$hookImport = @(
  Select-String -Path $guidancePage -SimpleMatch `
    'useCefrGuidanceRuntimeProfileSource } from "../hooks/useCefrGuidanceRuntimeProfileSource";'
)
$hookUse = @(
  Select-String -Path $guidancePage -SimpleMatch `
    'const source = useCefrGuidanceRuntimeProfileSource();'
)

if ($hookImport.Count -ne 1) {
  throw "GuidanceCenterPage runtime-profile import validation failed."
}

if ($hookUse.Count -ne 1) {
  throw "GuidanceCenterPage runtime-profile source validation failed."
}

Set-Location $app

Write-Host "=== Sprint 1209-1210 Target Tests: Persistent Runtime Repository ==="
npx vitest run `
  "src/ui/storage/LocalStorageCefrGuidanceProfileRepository.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1209-1210 target tests failed." }

Write-Host "=== Sprint 1211-1212 Target Tests: Runtime Service + UI Profile Source ==="
npx vitest run `
  "src/application/learning/CefrGuidanceRuntimeProfileService.test.ts" `
  "src/core/learning/CefrGuidanceUiProfileSource.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1211-1212 target tests failed." }

Write-Host "=== Sprint 1213-1214 Target Tests: Native Learning Studio Runtime Binding ==="
npx vitest run `
  "src/core/learning/CefrGuidanceLearningStudioEntryIntegration.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1213-1214 target tests failed." }

Write-Host "=== Combined Sprint 1209-1214 New Tests ==="
npx vitest run `
  "src/ui/storage/LocalStorageCefrGuidanceProfileRepository.test.ts" `
  "src/application/learning/CefrGuidanceRuntimeProfileService.test.ts" `
  "src/core/learning/CefrGuidanceUiProfileSource.test.ts" `
  "src/core/learning/CefrGuidanceLearningStudioEntryIntegration.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1209-1214 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-1209-1214 VERIFICATION COMPLETE"
