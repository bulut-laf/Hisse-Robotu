import fs from "node:fs";
import path from "node:path";

const root = "D:\\Projects\\LAF-Studio";
const file = path.join(
  root,
  "app",
  "src",
  "ui",
  "pages",
  "GuidanceCenterPage.tsx",
);

if (!fs.existsSync(file)) {
  throw new Error(
    `GuidanceCenterPage.tsx not found: ${file}`,
  );
}

let source =
  fs.readFileSync(file, "utf8");
const eol =
  source.includes("\r\n") ? "\r\n" : "\n";

const activityImport =
  'import { GuidanceEvidenceActivityPanel } from "../learning/GuidanceEvidenceActivityPanel";';
const coverageImport =
  'import { GuidanceEvidenceCoveragePanel } from "../learning/GuidanceEvidenceCoveragePanel";';

if (!source.includes(activityImport)) {
  throw new Error(
    "GuidanceEvidenceActivityPanel import not found.",
  );
}

if (!source.includes(coverageImport)) {
  source =
    source.replace(
      activityImport,
      activityImport +
        eol +
        coverageImport,
    );
}

const activityMarkup =
  "      <GuidanceEvidenceActivityPanel state={source.state} />";
const coverageMarkup =
  "      <GuidanceEvidenceCoveragePanel state={source.state} />";

if (!source.includes(activityMarkup)) {
  throw new Error(
    "GuidanceEvidenceActivityPanel markup not found.",
  );
}

if (!source.includes(coverageMarkup)) {
  source =
    source.replace(
      activityMarkup,
      activityMarkup +
        eol +
        eol +
        coverageMarkup,
    );
}

const importCount =
  source.split(coverageImport).length - 1;
const panelCount =
  source.split(coverageMarkup).length - 1;

if (
  importCount !== 1 ||
  panelCount !== 1
) {
  throw new Error(
    `Guidance evidence coverage validation failed: import=${importCount}, panel=${panelCount}`,
  );
}

fs.writeFileSync(
  file,
  source,
  "utf8",
);

console.log(
  "SPRINT-1251-1256 INSTALL COMPLETE",
);
console.log(
  "Guidance Center Evidence Coverage Summary installed.",
);
