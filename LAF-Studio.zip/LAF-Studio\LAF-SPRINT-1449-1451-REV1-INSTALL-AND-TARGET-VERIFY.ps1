﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

$factoryTest =
    Join-Path $app "src\application\learning\CefrRuntimeAssemblyFactory.test.ts"
$assemblyTest =
    Join-Path $app "src\application\learning\CefrRuntimeSliceAssembly.test.ts"
$sliceFile =
    Join-Path $app "src\core\learning\CefrA1ConnectRuntimeSliceDefinition.ts"
$execCatalog =
    Join-Path $app "src\core\learning\CefrA1ConnectExecutableRuntimeEvidenceCatalog.ts"

foreach ($path in @(
    $factoryTest,
    $assemblyTest,
    $sliceFile,
    $execCatalog
)) {
    if (-not (Test-Path $path)) {
        throw "Sprint 1449-1451 Rev1 required file missing: $path"
    }
}

$checks = @(
    @($factoryTest, "evidenceDefinitionCount: 6"),
    @($assemblyTest, "evidenceDefinitionCount: 6"),
    @($assemblyTest, "a1-connect-evidence-delayed-retrieval"),
    @($sliceFile, "createLafA1ConnectExecutableRuntimeEvidenceRegistry()"),
    @($execCatalog, '"a1-connect-evidence-delayed-retrieval"')
)

foreach ($check in $checks) {
    if (-not (
        Select-String `
            -Path $check[0] `
            -SimpleMatch `
            -Pattern $check[1] `
            -Quiet
    )) {
        throw "Sprint 1449-1451 Rev1 source marker missing: $($check[1])"
    }
}

Write-Host "SPRINT-1449-1451 REV1 SOURCE CHECK PASSED"

Set-Location $app

Write-Host ""
Write-Host "SPRINT-1449-1451 REV1 TARGET TESTS ONLY"

& npx vitest run @(
    "src/core/learning/CefrA1ConnectExecutableRuntimeEvidenceCatalog.test.ts",
    "src/core/learning/CefrA1ConnectDelayedRetrievalRuntimeSafety.test.ts",
    "src/core/learning/CefrA1ConnectRuntimeSliceDefinition.test.ts",
    "src/application/learning/CefrA1ConnectDelayedRetrievalGenericRuntime.test.ts",
    "src/application/learning/CefrRuntimeAssemblyFactory.test.ts",
    "src/application/learning/CefrRuntimeSliceAssembly.test.ts",
    "src/core/learning/CefrAuthoritativeEvidenceCatalog.test.ts"
)

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1449-1451 Rev1 target checkpoint failed."
}

Write-Host ""
Write-Host "SPRINT-1449-1451 REV1 TARGET CHECKPOINT COMPLETE"
Write-Host "No full regression/build in this 3-sprint checkpoint by design."
Write-Host "Stable production checkpoint remains Sprint 1448 until the 9-sprint block closes."
