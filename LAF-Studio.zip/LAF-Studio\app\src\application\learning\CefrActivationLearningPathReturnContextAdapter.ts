import {
  LAF_A1_NAVIGATE_REAL_LIFE_ACTIVATION,
} from "../../core/learning/CefrA1NavigateActivationDefinition";

export const LAF_CEFR_EXISTING_LEARNING_ROUTE =
  "/learning" as const;

export interface CefrActivationLearningPathReturnContext {
  readonly routePath:
    typeof LAF_CEFR_EXISTING_LEARNING_ROUTE;
  readonly activationId: string;
  readonly unitId: string;
  readonly targetSelector: string;
  readonly evidenceCreated: false;
  readonly masteryAssigned: false;
  readonly cefrLevelAssigned: false;
  readonly progressionPerformed: false;
  readonly automaticStudioLaunchPerformed: false;
}

export interface CefrActivationLearningPathReturnTarget {
  readonly routePath:
    typeof LAF_CEFR_EXISTING_LEARNING_ROUTE;
  readonly targetSelector: string;
}

export interface CaptureA1NavigateActivationReturnContextInput {
  readonly sourceRoutePath: string;
  readonly sourceUnitId: string;
  readonly activationId: string;
}

function createAuthoritativeA1NavigateTargetSelector():
  string {
  return `[data-cefr-unit="${LAF_A1_NAVIGATE_REAL_LIFE_ACTIVATION.unitId}"]`;
}

export function captureA1NavigateActivationLearningPathReturnContext(
  input: CaptureA1NavigateActivationReturnContextInput,
): CefrActivationLearningPathReturnContext | null {
  const authority =
    LAF_A1_NAVIGATE_REAL_LIFE_ACTIVATION;

  if (
    input.sourceRoutePath !==
      LAF_CEFR_EXISTING_LEARNING_ROUTE ||
    input.sourceUnitId !== authority.unitId ||
    input.activationId !== authority.activationId
  ) {
    return null;
  }

  return {
    routePath: LAF_CEFR_EXISTING_LEARNING_ROUTE,
    activationId: authority.activationId,
    unitId: authority.unitId,
    targetSelector:
      createAuthoritativeA1NavigateTargetSelector(),
    evidenceCreated: false,
    masteryAssigned: false,
    cefrLevelAssigned: false,
    progressionPerformed: false,
    automaticStudioLaunchPerformed: false,
  };
}

export function resolveCefrActivationLearningPathReturnTarget(
  context: CefrActivationLearningPathReturnContext,
): CefrActivationLearningPathReturnTarget | null {
  const authority =
    LAF_A1_NAVIGATE_REAL_LIFE_ACTIVATION;
  const authoritativeSelector =
    createAuthoritativeA1NavigateTargetSelector();

  if (
    context.routePath !==
      LAF_CEFR_EXISTING_LEARNING_ROUTE ||
    context.activationId !== authority.activationId ||
    context.unitId !== authority.unitId ||
    context.targetSelector !== authoritativeSelector ||
    context.evidenceCreated !== false ||
    context.masteryAssigned !== false ||
    context.cefrLevelAssigned !== false ||
    context.progressionPerformed !== false ||
    context.automaticStudioLaunchPerformed !== false
  ) {
    return null;
  }

  return {
    routePath: context.routePath,
    targetSelector: context.targetSelector,
  };
}

export function isCefrActivationCompletionEligible(
  requiredStepIds: readonly string[],
  completedStepIds: readonly string[],
): boolean {
  if (requiredStepIds.length === 0) {
    return false;
  }

  const completed =
    new Set(completedStepIds);

  return requiredStepIds.every(
    stepId => completed.has(stepId),
  );
}
