import {
  describe,
  expect,
  it,
} from "vitest";

import {
  prepareTranslationDialogueReview,
} from "./TranslationDialogueReview";

describe(
  "prepareTranslationDialogueReview",
  () => {
    it("accepts a complete review", () => {
      expect(
        prepareTranslationDialogueReview({
          strength:
            "Sipariş hedefini doğrudan ifade ettiniz.",
          nextFocus:
            "Kısa takip sorularına daha tam cevap vermeye odaklanın.",
          reusablePhraseHint:
            "Kérek ... / Nem kérek ...",
          nextPractice:
            "Aynı senaryoyu bu kez iki farklı ürünle tekrar edin.",
        }).status,
      ).toBe("ready");
    });

    it("trims review fields", () => {
      const result =
        prepareTranslationDialogueReview({
          strength: " A ",
          nextFocus: " B ",
          reusablePhraseHint: " C ",
          nextPractice: " D ",
        });

      expect(result).toMatchObject({
        status: "ready",
        review: {
          strength: "A",
          nextFocus: "B",
          reusablePhraseHint: "C",
          nextPractice: "D",
        },
      });
    });

    it("blocks missing strength", () => {
      const result =
        prepareTranslationDialogueReview({
          strength: "",
          nextFocus: "B",
          reusablePhraseHint: "C",
          nextPractice: "D",
        });

      expect(
        result.status === "blocked"
          ? result.issues
          : [],
      ).toContainEqual({
        code: "missing-strength",
      });
    });

    it("blocks missing focus", () => {
      const result =
        prepareTranslationDialogueReview({
          strength: "A",
          nextFocus: "",
          reusablePhraseHint: "C",
          nextPractice: "D",
        });

      expect(
        result.status === "blocked"
          ? result.issues
          : [],
      ).toContainEqual({
        code: "missing-next-focus",
      });
    });

    it("blocks missing phrase hint", () => {
      const result =
        prepareTranslationDialogueReview({
          strength: "A",
          nextFocus: "B",
          reusablePhraseHint: "",
          nextPractice: "D",
        });

      expect(
        result.status === "blocked"
          ? result.issues
          : [],
      ).toContainEqual({
        code: "missing-phrase-hint",
      });
    });

    it("blocks missing next practice", () => {
      const result =
        prepareTranslationDialogueReview({
          strength: "A",
          nextFocus: "B",
          reusablePhraseHint: "C",
          nextPractice: "",
        });

      expect(
        result.status === "blocked"
          ? result.issues
          : [],
      ).toContainEqual({
        code: "missing-next-practice",
      });
    });

    it("collects all missing fields", () => {
      const result =
        prepareTranslationDialogueReview({
          strength: "",
          nextFocus: "",
          reusablePhraseHint: "",
          nextPractice: "",
        });

      expect(
        result.status === "blocked"
          ? result.issues
          : [],
      ).toHaveLength(4);
    });

    it("blocks arrays", () => {
      expect(
        prepareTranslationDialogueReview(
          [],
        ).status,
      ).toBe("blocked");
    });

    it("blocks primitive output", () => {
      expect(
        prepareTranslationDialogueReview(
          5,
        ).status,
      ).toBe("blocked");
    });
  },
);
