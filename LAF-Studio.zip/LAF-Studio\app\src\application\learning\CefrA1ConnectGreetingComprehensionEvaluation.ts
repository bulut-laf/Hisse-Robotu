import type {
  CefrA1ConnectGreetingComprehensionTask,
} from "../../core/learning/CefrA1ConnectGreetingComprehensionTask";

export interface CefrA1ConnectTaskEvaluation {
  readonly submitted: true;
  readonly correct: boolean;
  readonly evidenceEligible: boolean;
  readonly masteryAssigned: false;
  readonly competencySuccessAssigned: false;
  readonly cefrLevelAssigned: false;
  readonly progressionPerformed: false;
}

export function evaluateCefrA1ConnectGreetingComprehension(
  task:
    CefrA1ConnectGreetingComprehensionTask,
  submittedAnswer: string,
): CefrA1ConnectTaskEvaluation {
  const correct =
    submittedAnswer === task.correctAnswer;

  return {
    submitted: true,
    correct,
    evidenceEligible: correct,
    masteryAssigned: false,
    competencySuccessAssigned: false,
    cefrLevelAssigned: false,
    progressionPerformed: false,
  };
}
