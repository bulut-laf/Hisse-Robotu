$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 966-968 Target Tests: Recommendation Signal / Guidance Candidate / Recommendation Context ==="
npx vitest run `
  "src/core/learning/CefrRecommendationSignal.test.ts" `
  "src/core/learning/CefrGuidanceCandidate.test.ts" `
  "src/core/learning/CefrRecommendationContext.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 966-968 target tests failed." }

Write-Host "=== Sprint 969-971 Target Tests: Guidance Policy / Safe Orchestration / Adaptive Guidance Platform ==="
npx vitest run `
  "src/core/learning/CefrAdaptiveGuidancePolicy.test.ts" `
  "src/core/learning/CefrSafeRecommendationOrchestration.test.ts" `
  "src/core/learning/CefrAdaptiveGuidancePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 969-971 target tests failed." }

Write-Host "=== Combined Sprint 966-971 New Tests ==="
npx vitest run `
  "src/core/learning/CefrRecommendationSignal.test.ts" `
  "src/core/learning/CefrGuidanceCandidate.test.ts" `
  "src/core/learning/CefrRecommendationContext.test.ts" `
  "src/core/learning/CefrAdaptiveGuidancePolicy.test.ts" `
  "src/core/learning/CefrSafeRecommendationOrchestration.test.ts" `
  "src/core/learning/CefrAdaptiveGuidancePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 966-971 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-966-971 VERIFICATION COMPLETE"
