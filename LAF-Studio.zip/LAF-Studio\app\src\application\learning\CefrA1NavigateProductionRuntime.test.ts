import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrPersonalLanguageProfileState,
  type CefrPersonalLanguageProfileState,
} from "../../core/learning/CefrPersonalLanguageProfileState";
import type {
  CefrLanguageEvidenceStorageLike,
} from "./CefrAuthoritativeLanguageEvidenceProvenanceRepository";
import type {
  CefrGuidanceRuntimeProfileRepository,
} from "./CefrGuidanceRuntimeProfileRepository";
import {
  CefrProductionRuntimePlatform,
} from "./CefrProductionRuntimePlatform";

class MemoryProfileRepository
  implements CefrGuidanceRuntimeProfileRepository {
  private state:
    CefrPersonalLanguageProfileState =
      createCefrPersonalLanguageProfileState(
        [],
        [],
      );

  load(): CefrPersonalLanguageProfileState {
    return this.state;
  }

  save(
    state: CefrPersonalLanguageProfileState,
  ): void {
    this.state = state;
  }

  hasPersistedProfile(): boolean {
    return false;
  }

  clear(): void {}
}

class MemoryStorage
  implements CefrLanguageEvidenceStorageLike {
  private readonly items =
    new Map<string, string>();

  getItem(
    key: string,
  ): string | null {
    return this.items.get(key) ?? null;
  }

  setItem(
    key: string,
    value: string,
  ): void {
    this.items.set(key, value);
  }

  removeItem(
    key: string,
  ): void {
    this.items.delete(key);
  }
}

describe(
  "A1 NAVIGATE production runtime",
  () => {
    it("writes approved immediate evidence and resolves needs-expression observational capability", () => {
      const repository =
        new MemoryProfileRepository();

      const platform =
        new CefrProductionRuntimePlatform(
          repository,
          new MemoryStorage(),
        );

      const result =
        platform.recordUserEvidence(
          "a1-navigate",
          {
            evidenceDefinitionId:
              "a1-navigate-evidence-need-expression",
            eventId:
              "navigate-runtime-001",
            occurredAt:
              new Date(
                "2026-08-12T08:00:00.000Z",
              ),
            languageCode: "hu",
            userActionConfirmed: true,
          },
        );

      expect(result).toMatchObject({
        languageCode: "hu",
        evidencePersisted: true,
        targetLanguageExplicit: true,
        targetLanguageInferred: false,
        masteryAssigned: false,
        competencySuccessAssigned: false,
        cefrLevelAssigned: false,
        progressionPerformed: false,
      });

      expect(
        result.runtime
          .resolvedCapabilityReferences,
      ).toEqual([
        "needs-expression",
      ]);

      expect(
        result.runtime
          .capabilityObservationWritten,
      ).toBe(true);

      expect(
        repository.load()
          .capabilityObservationRegistry
          .observations,
      ).toEqual([
        {
          capabilityReference:
            "needs-expression",
          evidenceId:
            "a1-navigate-runtime-evidence:a1-navigate-evidence-need-expression:navigate-runtime-001",
          source: "learning-studio",
          observationalOnly: true,
        },
      ]);
    });

    it("refuses delayed-retrieval runtime writing until a separate policy enables it", () => {
      const platform =
        new CefrProductionRuntimePlatform(
          new MemoryProfileRepository(),
          new MemoryStorage(),
        );

      expect(() =>
        platform.recordUserEvidence(
          "a1-navigate",
          {
            evidenceDefinitionId:
              "a1-navigate-evidence-delayed-retrieval",
            eventId:
              "navigate-delayed-001",
            occurredAt:
              new Date(
                "2026-08-12T08:05:00.000Z",
              ),
            languageCode: "hu",
            userActionConfirmed: true,
          },
        ),
      ).toThrow(
        "Unknown authoritative CEFR evidence definition",
      );
    });
  },
);
