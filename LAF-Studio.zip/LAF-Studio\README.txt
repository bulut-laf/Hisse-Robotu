Recovery Fix 2
- Feature implementation is unchanged from Recovery Fix 1.
- Both prior failing history tests were proven green in isolation.
- Full regression remains mandatory, but Vitest testTimeout is raised from 5000ms to 15000ms only for the full-suite validation run.
- Target test -> full regression -> production build; rollback on real failure.
