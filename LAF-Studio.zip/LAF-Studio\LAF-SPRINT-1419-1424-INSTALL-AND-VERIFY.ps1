﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

$required = @(
    "src\core\learning\CefrLanguageScopedEvidenceCoverage.ts",
    "src\core\learning\CefrLanguageScopedEvidenceAdvisory.ts",
    "src\application\learning\CefrLanguageScopedEvidenceReadService.ts",
    "src\core\learning\CefrGenericLanguageScopedEvidenceSafety.ts"
)

foreach ($relative in $required) {
    $path = Join-Path $app $relative

    if (-not (Test-Path $path)) {
        throw "Sprint 1419-1424 source missing: $relative"
    }
}

$markers = @(
    @(
        "src\core\learning\CefrLanguageScopedEvidenceCoverage.ts",
        "crossLanguageEvidenceExcluded:"
    ),
    @(
        "src\core\learning\CefrLanguageScopedEvidenceCoverage.ts",
        "unscopedEvidenceExcluded:"
    ),
    @(
        "src\core\learning\CefrLanguageScopedEvidenceCoverage.ts",
        "sourceLearningItemId?:"
    ),
    @(
        "src\core\learning\CefrLanguageScopedEvidenceAdvisory.ts",
        "automaticLearningItemSelection:"
    ),
    @(
        "src\core\learning\CefrLanguageScopedEvidenceAdvisory.ts",
        "automaticEvidenceWrite: false"
    ),
    @(
        "src\application\learning\CefrLanguageScopedEvidenceReadService.ts",
        "state.profileSnapshot"
    ),
    @(
        "src\application\learning\CefrLanguageScopedEvidenceReadService.ts",
        ".evidenceAggregation"
    ),
    @(
        "src\core\learning\CefrGenericLanguageScopedEvidenceSafety.ts",
        "coverageMeansMastery: false"
    ),
    @(
        "src\core\learning\CefrGenericLanguageScopedEvidenceSafety.ts",
        "automaticProgressionAllowed: false"
    )
)

foreach ($pair in $markers) {
    $path = Join-Path $app $pair[0]

    if (-not (
        Select-String `
            -Path $path `
            -SimpleMatch `
            -Pattern $pair[1] `
            -Quiet
    )) {
        throw "Sprint 1419-1424 marker missing: $($pair[1])"
    }
}

Write-Host "SPRINT-1419-1424 SOURCE CHECK PASSED"

Set-Location $app

$targets = @(
    "src/core/learning/CefrLanguageScopedEvidenceCoverage.test.ts",
    "src/core/learning/CefrLanguageScopedEvidenceAdvisory.test.ts",
    "src/application/learning/CefrLanguageScopedEvidenceReadService.test.ts",
    "src/core/learning/CefrGenericLanguageScopedEvidenceSafety.test.ts",
    "src/application/learning/CefrAuthoritativeLanguageRuntimeEvidenceService.test.ts",
    "src/application/learning/CefrAuthoritativeLanguageEvidenceProvenanceRepository.test.ts",
    "src/application/learning/CefrLanguageEvidenceProvenanceCoordinator.test.ts",
    "src/core/learning/CefrAuthoritativeEvidenceCatalog.test.ts",
    "src/application/learning/CefrAuthoritativeRuntimeEvidenceService.test.ts"
)

& npx vitest run $targets
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1419-1424 target tests failed."
}

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Full regression failed."
}

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Production build failed."
}

Write-Host "SPRINT-1419-1424 VERIFICATION COMPLETE"
