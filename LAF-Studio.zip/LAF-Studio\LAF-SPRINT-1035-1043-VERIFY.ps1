$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 1035-1037 Target Tests: Practice Priority Approval ==="
npx vitest run `
  "src/core/learning/CefrPracticePriorityChoiceReview.test.ts" `
  "src/core/learning/CefrPracticePriorityApprovalBoundary.test.ts" `
  "src/core/learning/CefrPracticePriorityActionPlan.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1035-1037 target tests failed." }

Write-Host "=== Sprint 1038-1040 Target Tests: Priority Studio Handoff ==="
npx vitest run `
  "src/core/learning/CefrPracticePriorityStudioRoute.test.ts" `
  "src/core/learning/CefrPracticePriorityHandoff.test.ts" `
  "src/core/learning/CefrPracticePrioritySessionActivation.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1038-1040 target tests failed." }

Write-Host "=== Sprint 1041-1043 Target Tests: Priority Feedback Loop ==="
npx vitest run `
  "src/core/learning/CefrPracticePriorityOutcomeObservation.test.ts" `
  "src/core/learning/CefrPracticePriorityFeedbackBundle.test.ts" `
  "src/core/learning/CefrPracticePriorityClosedLoop.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1041-1043 target tests failed." }

Write-Host "=== Combined Sprint 1035-1043 New Tests ==="
npx vitest run `
  "src/core/learning/CefrPracticePriorityChoiceReview.test.ts" `
  "src/core/learning/CefrPracticePriorityApprovalBoundary.test.ts" `
  "src/core/learning/CefrPracticePriorityActionPlan.test.ts" `
  "src/core/learning/CefrPracticePriorityStudioRoute.test.ts" `
  "src/core/learning/CefrPracticePriorityHandoff.test.ts" `
  "src/core/learning/CefrPracticePrioritySessionActivation.test.ts" `
  "src/core/learning/CefrPracticePriorityOutcomeObservation.test.ts" `
  "src/core/learning/CefrPracticePriorityFeedbackBundle.test.ts" `
  "src/core/learning/CefrPracticePriorityClosedLoop.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1035-1043 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-1035-1043 VERIFICATION COMPLETE"
