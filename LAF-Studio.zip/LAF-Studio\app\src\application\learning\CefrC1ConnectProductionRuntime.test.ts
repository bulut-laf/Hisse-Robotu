import {describe,expect,it} from "vitest";
import {
 createCefrPersonalLanguageProfileState,
 type CefrPersonalLanguageProfileState
} from "../../core/learning/CefrPersonalLanguageProfileState";
import type {CefrLanguageEvidenceStorageLike} from "./CefrAuthoritativeLanguageEvidenceProvenanceRepository";
import type {CefrGuidanceRuntimeProfileRepository} from "./CefrGuidanceRuntimeProfileRepository";
import {CefrProductionRuntimePlatform} from "./CefrProductionRuntimePlatform";

class R implements CefrGuidanceRuntimeProfileRepository {
 private s:CefrPersonalLanguageProfileState=createCefrPersonalLanguageProfileState([],[]);
 load(){return this.s}
 save(s:CefrPersonalLanguageProfileState){this.s=s}
 hasPersistedProfile(){return false}
 clear(){}
}
class S implements CefrLanguageEvidenceStorageLike {
 private m=new Map<string,string>();
 getItem(k:string){return this.m.get(k)??null}
 setItem(k:string,v:string){this.m.set(k,v)}
 removeItem(k:string){this.m.delete(k)}
}

describe("C1 CONNECT production runtime",()=>{
 it("resolves discovered authoritative capability mapping observationally",()=>{
  const r=new R();
  const p=new CefrProductionRuntimePlatform(r,new S());
  const result=p.recordUserEvidence(
   "c1-connect",
   {
    evidenceDefinitionId:"c1-connect-evidence-register-consistency-closure",
    eventId:"c1-connect-runtime-001",
    occurredAt:new Date("2026-08-15T19:30:00.000Z"),
    languageCode:"hu",
    userActionConfirmed:true
   }
  );
  expect(result).toMatchObject({
   evidencePersisted:true,
   masteryAssigned:false,
   competencySuccessAssigned:false,
   cefrLevelAssigned:false,
   progressionPerformed:false
  });
  expect(result.runtime.resolvedCapabilityReferences).toEqual([
   "interaction-management",
   "register-adaptation",
   "audience-purpose-adaptation"
  ]);
  expect(
   r.load().capabilityObservationRegistry.observations
    .map(x=>x.capabilityReference)
  ).toEqual([
   "interaction-management",
   "register-adaptation",
   "audience-purpose-adaptation"
  ]);
 });
 it("rejects delayed retrieval until separate policy exists",()=>{
  const p=new CefrProductionRuntimePlatform(new R(),new S());
  expect(()=>p.recordUserEvidence(
   "c1-connect",
   {
    evidenceDefinitionId:"c1-connect-evidence-delayed-retrieval",
    eventId:"c1-connect-delayed",
    occurredAt:new Date("2026-08-15T19:35:00.000Z"),
    languageCode:"hu",
    userActionConfirmed:true
   }
  )).toThrow("Unknown authoritative CEFR evidence definition");
 });
});
