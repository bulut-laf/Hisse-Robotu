$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 1161-1163 Target Tests: Router Acknowledgement ==="
npx vitest run `
  "src/core/learning/CefrGuidanceRouterDispatchResult.test.ts" `
  "src/core/learning/CefrGuidanceRouterDispatchAcknowledgement.test.ts" `
  "src/core/learning/CefrGuidanceNavigationCompletion.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1161-1163 target tests failed." }

Write-Host "=== Sprint 1164-1166 Target Tests: Studio Entry Confirmation ==="
npx vitest run `
  "src/core/learning/CefrGuidanceStudioEntryResult.test.ts" `
  "src/core/learning/CefrGuidanceStudioEntryValidation.test.ts" `
  "src/core/learning/CefrGuidanceStudioEntryConfirmation.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1164-1166 target tests failed." }

Write-Host "=== Sprint 1167-1169 Target Tests: Session Activation Handoff ==="
npx vitest run `
  "src/core/learning/CefrGuidanceSessionActivationRequest.test.ts" `
  "src/core/learning/CefrGuidanceSessionActivationGate.test.ts" `
  "src/core/learning/CefrGuidanceApplicationEntryCycle.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1167-1169 target tests failed." }

Write-Host "=== Combined Sprint 1161-1169 New Tests ==="
npx vitest run `
  "src/core/learning/CefrGuidanceRouterDispatchResult.test.ts" `
  "src/core/learning/CefrGuidanceRouterDispatchAcknowledgement.test.ts" `
  "src/core/learning/CefrGuidanceNavigationCompletion.test.ts" `
  "src/core/learning/CefrGuidanceStudioEntryResult.test.ts" `
  "src/core/learning/CefrGuidanceStudioEntryValidation.test.ts" `
  "src/core/learning/CefrGuidanceStudioEntryConfirmation.test.ts" `
  "src/core/learning/CefrGuidanceSessionActivationRequest.test.ts" `
  "src/core/learning/CefrGuidanceSessionActivationGate.test.ts" `
  "src/core/learning/CefrGuidanceApplicationEntryCycle.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1161-1169 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-1161-1169 VERIFICATION COMPLETE"
