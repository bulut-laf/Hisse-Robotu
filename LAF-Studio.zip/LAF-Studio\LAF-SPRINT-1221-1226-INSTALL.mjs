import fs from "node:fs";
import path from "node:path";

const root = "D:\\Projects\\LAF-Studio";
const file = path.join(
  root,
  "app",
  "src",
  "ui",
  "pages",
  "ListeningPracticePage.tsx",
);

if (!fs.existsSync(file)) {
  throw new Error(`ListeningPracticePage not found: ${file}`);
}

let source = fs.readFileSync(file, "utf8");
const eol = source.includes("\r\n") ? "\r\n" : "\n";

const runtimeServiceImport =
  'import { CefrGuidanceRuntimeProfileService } from "../../application/learning/CefrGuidanceRuntimeProfileService";';
const profileRepositoryImport =
  'import { LocalStorageCefrGuidanceProfileRepository } from "../storage/LocalStorageCefrGuidanceProfileRepository";';

if (!source.includes(runtimeServiceImport)) {
  const storageImportEnd =
    '} from "../storage/LocalStorageListeningPracticeStorage";';
  const index = source.indexOf(storageImportEnd);

  if (index < 0) {
    throw new Error(
      "ListeningPracticePage storage import marker not found.",
    );
  }

  const end = index + storageImportEnd.length;
  source =
    source.slice(0, end) +
    eol +
    runtimeServiceImport +
    eol +
    profileRepositoryImport +
    source.slice(end);
} else if (!source.includes(profileRepositoryImport)) {
  source = source.replace(
    runtimeServiceImport,
    runtimeServiceImport +
      eol +
      profileRepositoryImport,
  );
}

if (
  !source.includes(
    "const cefrRuntimeProfileService = useMemo(",
  )
) {
  const marker =
    "  const practiceStorage = useMemo(";
  const index = source.indexOf(marker);

  if (index < 0) {
    throw new Error(
      "ListeningPracticePage practice storage marker not found.",
    );
  }

  const block =
    "  const cefrRuntimeProfileService = useMemo(" +
    eol +
    "    () =>" +
    eol +
    "      new CefrGuidanceRuntimeProfileService(" +
    eol +
    "        new LocalStorageCefrGuidanceProfileRepository()," +
    eol +
    "      )," +
    eol +
    "    []," +
    eol +
    "  );" +
    eol +
    eol;

  source =
    source.slice(0, index) +
    block +
    source.slice(index);
}

if (
  !source.includes(
    "recordListeningPracticeCompletion({",
  )
) {
  const saveMarker =
    "        practiceStorage?.saveResult(" +
    eol +
    "          completedSummary.successPercentage," +
    eol +
    "        );";
  const index = source.indexOf(saveMarker);

  if (index < 0) {
    throw new Error(
      "ListeningPracticePage final saveResult marker not found.",
    );
  }

  const replacement =
    "        const completedAt = new Date();" +
    eol +
    eol +
    saveMarker +
    eol +
    eol +
    "        if (lessonId) {" +
    eol +
    "          cefrRuntimeProfileService.recordListeningPracticeCompletion({" +
    eol +
    "            lessonId," +
    eol +
    "            completedAt," +
    eol +
    "          });" +
    eol +
    "        }";

  source =
    source.slice(0, index) +
    replacement +
    source.slice(index + saveMarker.length);
}

const checks = {
  runtimeServiceImport:
    source.split(runtimeServiceImport).length - 1,
  profileRepositoryImport:
    source.split(profileRepositoryImport).length - 1,
  runtimeService:
    source.split(
      "const cefrRuntimeProfileService = useMemo(",
    ).length - 1,
  completionWrite:
    source.split(
      "recordListeningPracticeCompletion({",
    ).length - 1,
};

for (const [name, value] of Object.entries(checks)) {
  if (value !== 1) {
    throw new Error(
      `ListeningPracticePage validation failed: ${name}=${value}`,
    );
  }
}

fs.writeFileSync(file, source, "utf8");

console.log("SPRINT-1221-1226 INSTALL COMPLETE");
console.log(
  "Listening Practice completion bound to persistent CEFR evidence.",
);
