﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app  = Join-Path $root "app"
$src  = Join-Path $app "src"
$out  = Join-Path $root "LAF_A1_CONNECT_LANGUAGE_REALIZATION_SEAM_SNAPSHOT.txt"

if (-not (Test-Path $src)) {
    throw "Source root not found: $src"
}

$report = New-Object System.Collections.Generic.List[string]

function Add-Line {
    param([string]$Text)
    if ($null -eq $Text) { $Text = "" }
    [void]$report.Add($Text)
}

function Add-Section {
    param([string]$Title)
    Add-Line ""
    Add-Line ("=" * 96)
    Add-Line $Title
    Add-Line ("=" * 96)
}

function Add-File {
    param(
        [string]$Relative,
        [int]$Limit = 1600
    )

    $file = Join-Path $src $Relative
    Add-Section ("FILE: app\src\" + $Relative)

    if (-not (Test-Path $file)) {
        Add-Line "(file not found)"
        return
    }

    $lines = @(Get-Content -Path $file)
    $count = [Math]::Min($lines.Count, $Limit)

    for ($i = 0; $i -lt $count; $i++) {
        Add-Line ("{0,4}: {1}" -f ($i + 1), $lines[$i])
    }

    if ($lines.Count -gt $Limit) {
        Add-Line ("... truncated; total lines: " + $lines.Count)
    }
}

function Rel {
    param([string]$Path)
    $prefix = $root + "\"
    if ($Path.StartsWith($prefix)) {
        return $Path.Substring($prefix.Length)
    }
    return $Path
}

Add-Line "LAF STUDIO - A1 CONNECT LANGUAGE REALIZATION SEAM SNAPSHOT"
Add-Line ("Generated: " + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
Add-Line "READ ONLY - no project source files are modified."
Add-Line "Stable technical baseline expected: Sprint 1310."

Add-Section "1. CURRENT LANGUAGE AUTHORITY"

Add-File "core\language\LafLanguageProfile.ts" 1400
Add-File "core\translation\TranslationDraft.ts" 900
Add-File "core\language\Language.ts" 900
Add-File "application\learning\LearningStudioCatalog.ts" 1200

Add-Section "2. NATIVE A1 CONNECT UI / RUNTIME CONTRACT"

Add-File "application\learning\CefrA1ConnectNativeLearningUiModel.ts" 1000
Add-File "application\learning\CefrA1ConnectRuntimeReadModel.ts" 1000
Add-File "application\learning\CefrA1ConnectRuntimeEvidenceService.ts" 1500
Add-File "core\learning\CefrA1ConnectNativeLearningUiSafety.ts" 900
Add-File "ui\learning\A1ConnectNativeLearningPanel.tsx" 1600

Add-Section "3. EXISTING TARGET LANGUAGE SELECTION / STORAGE"

$files = @(
    Get-ChildItem -Path $src -Recurse -File |
    Where-Object {
        $_.Extension -eq ".ts" -or
        $_.Extension -eq ".tsx"
    }
)

$patterns = @(
    "targetLanguage",
    "targetLanguageCode",
    "selectedLanguage",
    "activeLanguage",
    "languageCode",
    "getLafLanguageProfile",
    "TranslationLanguageCode",
    "laf.language",
    "localStorage"
)

foreach ($pattern in $patterns) {
    Add-Line ""
    Add-Line ("PATTERN: " + $pattern)

    $matchList = New-Object System.Collections.Generic.List[object]

    foreach ($file in $files) {
        if (
            $file.Name.EndsWith(".test.ts") -or
            $file.Name.EndsWith(".test.tsx")
        ) {
            continue
        }

        $hits = @(
            Select-String `
                -Path $file.FullName `
                -SimpleMatch `
                -Pattern $pattern `
                -ErrorAction SilentlyContinue
        )

        foreach ($hit in $hits) {
            [void]$matchList.Add(
                [PSCustomObject]@{
                    File = Rel $hit.Path
                    Line = $hit.LineNumber
                    Text = $hit.Line.Trim()
                }
            )
        }
    }

    if ($matches.Count -eq 0) {
        Add-Line "(no production matches)"
    } else {
        foreach ($m in (
            $matches |
            Sort-Object File, Line |
            Select-Object -First 300
        )) {
            Add-Line (
                "{0}:{1}: {2}" -f
                $m.File,
                $m.Line,
                $m.Text
            )
        }
    }
}

Add-Section "4. EXISTING LANGUAGE-SPECIFIC LESSON / CONTENT SHAPES"

Add-File "features\lessons\data\lessons.ts" 1400
Add-File "features\lessons\types.ts" 1000
Add-File "features\lessons\types\Lesson.ts" 1000

$contentCandidates = @(
    $files |
    Where-Object {
        $_.Name -match "Lesson.*Content|Language.*Content|Phrase|Dialogue|Prompt|Utterance|Example"
    } |
    Sort-Object FullName
)

foreach ($file in ($contentCandidates | Select-Object -First 80)) {
    Add-Line ("CANDIDATE: " + (Rel $file.FullName))
}

Add-Section "5. SPEECH / LISTENING LANGUAGE REALIZATION SEAMS"

$audioPatterns = @(
    "speechSynthesis",
    "SpeechSynthesis",
    "utterance.lang",
    "lang =",
    "voice",
    "locale",
    "slow",
    "listen"
)

foreach ($pattern in $audioPatterns) {
    Add-Line ""
    Add-Line ("PATTERN: " + $pattern)

    foreach ($file in $files) {
        if (
            $file.Name.EndsWith(".test.ts") -or
            $file.Name.EndsWith(".test.tsx")
        ) {
            continue
        }

        $hits = @(
            Select-String `
                -Path $file.FullName `
                -SimpleMatch `
                -Pattern $pattern `
                -ErrorAction SilentlyContinue
        )

        foreach ($hit in ($hits | Select-Object -First 160)) {
            Add-Line (
                "{0}:{1}: {2}" -f
                (Rel $hit.Path),
                $hit.LineNumber,
                $hit.Line.Trim()
            )
        }
    }
}

Add-Section "6. REQUIRED DECISIONS FOR SPRINT 1311-1316"

Add-Line "Determine authoritative runtime target-language source for Learning Studio."
Add-Line "Determine whether curriculum realization is language-neutral core + per-language content registry or another existing pattern."
Add-Line "Determine exact stable language identifiers/locales already approved in production source."
Add-Line "Determine whether A1 CONNECT realization content can be implemented without changing curriculum identities."
Add-Line "Determine exact speech/listening locale binding if native audio support is used."
Add-Line "Determine whether first implementation should cover all approved languages or one explicitly approved pilot language."
Add-Line ""
Add-Line "Must remain:"
Add-Line "- curriculum identity language-neutral"
Add-Line "- no title/label inference as curriculum mapping"
Add-Line "- no fabricated learner evidence"
Add-Line "- no evidence capture until executable target-language task exists"
Add-Line "- no mastery assignment"
Add-Line "- no competency success"
Add-Line "- no CEFR-level assignment"
Add-Line "- no automatic progression"
Add-Line "- no automatic Studio launch"

$report | Set-Content -Path $out -Encoding UTF8

Write-Host ""
Write-Host "LAF A1 CONNECT LANGUAGE REALIZATION SEAM SNAPSHOT COMPLETE"
Write-Host "Report:"
Write-Host $out
