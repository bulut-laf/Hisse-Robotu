$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 834-836 Target Tests: Custodial Correlation ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialCorrelation.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialCorrelationCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialCorrelationAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 834-836 target tests failed." }

Write-Host "=== Sprint 837-839 Target Tests: Custodial Relationship ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialRelationship.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialRelationshipCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialRelationshipAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 837-839 target tests failed." }

Write-Host "=== Sprint 840-842 Target Tests: Custodial Linkage ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialLinkage.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialLinkageCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialLinkageAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 840-842 target tests failed." }

Write-Host "=== Combined Sprint 834-842 New Tests ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialCorrelation.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialCorrelationCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialCorrelationAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialRelationship.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialRelationshipCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialRelationshipAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialLinkage.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialLinkageCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialLinkageAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 834-842 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-834-842 VERIFICATION COMPLETE"
