﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$file = Join-Path $root "app\src\ui\writing\WritingStudioPanel.tsx"
$out = Join-Path $root "LAF_WRITING_COMPLETION_SEAM_SNAPSHOT.txt"

if (-not (Test-Path $file)) {
    throw "WritingStudioPanel.tsx not found: $file"
}

$lines = @(Get-Content -Path $file)

$report = New-Object System.Collections.Generic.List[string]

function Add-Line {
    param([string]$Text)
    if ($null -eq $Text) { $Text = "" }
    [void]$report.Add($Text)
}

function Add-Section {
    param([string]$Title)
    Add-Line ""
    Add-Line ("=" * 92)
    Add-Line $Title
    Add-Line ("=" * 92)
}

Add-Line "LAF STUDIO - WRITING COMPLETION SEAM SNAPSHOT"
Add-Line ("Generated: " + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
Add-Line "READ ONLY - no project source files are modified."

Add-Section "1. WRITING STUDIO LINES 280-390"

$start = 280
$end = [Math]::Min(390, $lines.Count)

for ($i = $start; $i -le $end; $i++) {
    Add-Line ("{0,4}: {1}" -f $i, $lines[$i - 1])
}

Add-Section "2. FUNCTIONS / CALLBACKS"

$functionPatterns = @(
    "const ",
    "function ",
    "=> {"
)

for ($i = 0; $i -lt $lines.Count; $i++) {
    $line = $lines[$i]

    if (
        $line -match "const\s+\w+\s*=\s*(async\s*)?\(" -or
        $line -match "const\s+\w+\s*=\s*(async\s*)?\w*\s*=>" -or
        $line -match "function\s+\w+\s*\("
    ) {
        Add-Line ("{0,4}: {1}" -f ($i + 1), $line)
    }
}

Add-Section "3. SESSION SUMMARY / RESET CONTEXT"

$hits = @(
    Select-String `
        -Path $file `
        -Pattern @(
            "createTranslationWritingSessionSummary"
            "resetWritingSession"
            "setSession"
            "setWriting"
            "revision"
            "summary"
            "complete"
            "finish"
        ) `
        -SimpleMatch `
        -ErrorAction SilentlyContinue
)

foreach ($hit in ($hits | Sort-Object LineNumber -Unique)) {
    Add-Line ("{0,4}: {1}" -f $hit.LineNumber, $hit.Line)
}

Add-Section "4. USER ACTION BINDINGS"

$uiHits = @(
    Select-String `
        -Path $file `
        -Pattern @(
            "onClick="
            "onSubmit="
            "<button"
            "type=""button"""
            "type=""submit"""
        ) `
        -SimpleMatch `
        -ErrorAction SilentlyContinue
)

foreach ($hit in ($uiHits | Sort-Object LineNumber -Unique)) {
    $lineNo = $hit.LineNumber
    $from = [Math]::Max(1, $lineNo - 3)
    $to = [Math]::Min($lines.Count, $lineNo + 5)

    Add-Line ""
    Add-Line ("--- around line " + $lineNo + " ---")

    for ($i = $from; $i -le $to; $i++) {
        Add-Line ("{0,4}: {1}" -f $i, $lines[$i - 1])
    }
}

Add-Section "5. IMPLEMENTATION DECISION"
Add-Line "Need the exact user-triggered Writing completion handler."
Add-Line "Need the exact point where createTranslationWritingSessionSummary is committed."
Add-Line "Need the exact identity already available for the Writing task/session."
Add-Line "Do not fabricate capabilityReference."
Add-Line "Do not assign mastery, CEFR level, or progression automatically."

$report | Set-Content -Path $out -Encoding UTF8

Write-Host ""
Write-Host "LAF WRITING COMPLETION SEAM SNAPSHOT COMPLETE"
Write-Host "Report:"
Write-Host $out
Write-Host ""
Get-Content -Path $out
