﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$core = Join-Path $app "src\core\learning"

$utf8 = New-Object System.Text.UTF8Encoding($false)

function Read-Utf8([string]$path) {
    return [System.IO.File]::ReadAllText($path, $utf8)
}

function Write-Utf8(
    [string]$path,
    [string]$text
) {
    [System.IO.File]::WriteAllText($path, $text, $utf8)
}

$catalogPath =
    Join-Path $core "CefrAuthoritativeCurriculumCatalog.ts"

if (-not (Test-Path $catalogPath)) {
    throw "CefrAuthoritativeCurriculumCatalog.ts missing."
}

$catalog = Read-Utf8 $catalogPath

# ------------------------------------------------------------
# Ensure import exists.
# ------------------------------------------------------------
$navigateImportModule =
    'from "./CefrA1NavigateCurriculum";'

if (-not $catalog.Contains(
    $navigateImportModule
)) {
    $exportAnchor =
        'export const LAF_A1_CONNECT_FIRST_SOCIAL_ENCOUNTER_UNIT:'

    $exportIndex =
        $catalog.IndexOf($exportAnchor)

    if ($exportIndex -lt 0) {
        throw "A1 CONNECT curriculum export anchor missing."
    }

    $navigateImport = @'
import {
  LAF_A1_NAVIGATE_IMMEDIATE_EVERYDAY_NEEDS_LESSONS,
  LAF_A1_NAVIGATE_IMMEDIATE_EVERYDAY_NEEDS_UNIT,
} from "./CefrA1NavigateCurriculum";

'@

    $catalog =
        $catalog.Insert(
            $exportIndex,
            $navigateImport
        )
}

# ------------------------------------------------------------
# Add Unit to authoritative Unit array.
# IMPORTANT: search only after array declaration so import lines
# cannot be mistaken for real catalog registration.
# ------------------------------------------------------------
$unitsStartMarker =
    'export const LAF_AUTHORITATIVE_CEFR_UNITS:'

$unitsStart =
    $catalog.IndexOf($unitsStartMarker)

if ($unitsStart -lt 0) {
    throw "Authoritative CEFR Unit array start missing."
}

$navigateUnitUse =
    '  LAF_A1_NAVIGATE_IMMEDIATE_EVERYDAY_NEEDS_UNIT,'

$navigateUnitIndex =
    $catalog.IndexOf(
        $navigateUnitUse,
        $unitsStart
    )

if ($navigateUnitIndex -lt 0) {
    $connectUnitUse =
        '  LAF_A1_CONNECT_FIRST_SOCIAL_ENCOUNTER_UNIT,'

    $connectUnitIndex =
        $catalog.IndexOf(
            $connectUnitUse,
            $unitsStart
        )

    if ($connectUnitIndex -lt 0) {
        throw "A1 CONNECT Unit array entry missing."
    }

    $insertAt =
        $connectUnitIndex +
        $connectUnitUse.Length

    $catalog =
        $catalog.Insert(
            $insertAt,
            [Environment]::NewLine +
            $navigateUnitUse
        )
}

# ------------------------------------------------------------
# Add four lessons to authoritative Lesson array.
# Again, search only after the actual Lesson array declaration.
# ------------------------------------------------------------
$lessonsStartMarker =
    'export const LAF_AUTHORITATIVE_CEFR_LESSONS:'

$lessonsStart =
    $catalog.IndexOf($lessonsStartMarker)

if ($lessonsStart -lt 0) {
    throw "Authoritative CEFR Lesson array start missing."
}

$navigateLessonsUse =
    '  ...LAF_A1_NAVIGATE_IMMEDIATE_EVERYDAY_NEEDS_LESSONS,'

$navigateLessonsIndex =
    $catalog.IndexOf(
        $navigateLessonsUse,
        $lessonsStart
    )

if ($navigateLessonsIndex -lt 0) {
    $connectLessonsUse =
        '  ...LAF_A1_CONNECT_FIRST_SOCIAL_ENCOUNTER_LESSONS,'

    $connectLessonsIndex =
        $catalog.IndexOf(
            $connectLessonsUse,
            $lessonsStart
        )

    if ($connectLessonsIndex -lt 0) {
        throw "A1 CONNECT Lesson array entry missing."
    }

    $insertAt =
        $connectLessonsIndex +
        $connectLessonsUse.Length

    $catalog =
        $catalog.Insert(
            $insertAt,
            [Environment]::NewLine +
            $navigateLessonsUse
        )
}

Write-Utf8 $catalogPath $catalog

# ------------------------------------------------------------
# Fail-closed source verification:
# import + actual array use must both exist.
# ------------------------------------------------------------
$catalog = Read-Utf8 $catalogPath

$unitsStart =
    $catalog.IndexOf($unitsStartMarker)

$lessonsStart =
    $catalog.IndexOf($lessonsStartMarker)

if (
    $unitsStart -lt 0 -or
    $catalog.IndexOf(
        $navigateUnitUse,
        $unitsStart
    ) -lt 0
) {
    throw "A1 NAVIGATE Unit is not registered in authoritative Unit array."
}

if (
    $lessonsStart -lt 0 -or
    $catalog.IndexOf(
        $navigateLessonsUse,
        $lessonsStart
    ) -lt 0
) {
    throw "A1 NAVIGATE lessons are not registered in authoritative Lesson array."
}

$navigateUnitOccurrenceCount =
    [regex]::Matches(
        $catalog,
        'LAF_A1_NAVIGATE_IMMEDIATE_EVERYDAY_NEEDS_UNIT'
    ).Count

$navigateLessonsOccurrenceCount =
    [regex]::Matches(
        $catalog,
        'LAF_A1_NAVIGATE_IMMEDIATE_EVERYDAY_NEEDS_LESSONS'
    ).Count

if ($navigateUnitOccurrenceCount -lt 2) {
    throw "A1 NAVIGATE Unit must appear in both import and catalog registration."
}

if ($navigateLessonsOccurrenceCount -lt 2) {
    throw "A1 NAVIGATE lessons must appear in both import and catalog registration."
}

Write-Host "SPRINT-1440-1448 REV3 SOURCE CHECK PASSED"

Set-Location $app

Write-Host ""
Write-Host "CATALOG REPAIR TARGET VERIFICATION"

& npx vitest run @(
    "src/core/learning/CefrA1NavigateAuthoritativeCatalog.test.ts",
    "src/core/learning/CefrAuthoritativeCurriculumCatalog.test.ts",
    "src/core/learning/CefrA1NavigateRuntimeSliceDefinition.test.ts",
    "src/application/learning/CefrA1NavigateProductionRuntime.test.ts"
)

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1440-1448 Rev3 catalog repair target verification failed."
}

Write-Host "SPRINT-1440-1448 REV3 TARGET CHECK PASSED"

Write-Host ""
Write-Host "FINAL BLOCK REGRESSION — one full run only"

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1440-1448 Rev3 final full regression failed."
}

Write-Host ""
Write-Host "FINAL PRODUCTION BUILD"

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1440-1448 Rev3 production build failed."
}

Write-Host ""
Write-Host "SPRINT-1440-1448 REV3 VERIFICATION COMPLETE"
