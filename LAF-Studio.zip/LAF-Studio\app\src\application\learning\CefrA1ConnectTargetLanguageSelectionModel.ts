import {
  LAF_LEARNING_LANGUAGE_CODES,
  getLafLanguageProfile,
  type LafLearningLanguageCode,
} from "../../core/language/LafLanguageProfile";
import {
  getLafA1ConnectLanguageRealization,
  type CefrA1ConnectLanguageRealizationDescriptor,
} from "../../core/learning/CefrA1ConnectLanguageRealizationRegistry";

export interface CefrA1ConnectTargetLanguageOption {
  readonly code: LafLearningLanguageCode;
  readonly label: string;
  readonly nativeLabel: string;
  readonly locale: string;
}

export interface CefrA1ConnectTargetLanguageSelectionModel {
  readonly options:
    readonly CefrA1ConnectTargetLanguageOption[];
  readonly selectedLanguageCode:
    LafLearningLanguageCode | null;
  readonly selectionRequired: boolean;
  readonly selectedByUser: boolean;
  readonly realization:
    CefrA1ConnectLanguageRealizationDescriptor | null;
  readonly languageContentBound: boolean;
  readonly executableTaskAvailable: boolean;
  readonly evidenceCaptureAvailable: boolean;
}

export function createCefrA1ConnectTargetLanguageSelectionModel(
  selectedLanguageCode:
    LafLearningLanguageCode | null,
): CefrA1ConnectTargetLanguageSelectionModel {
  const options =
    LAF_LEARNING_LANGUAGE_CODES.map(code => {
      const profile = getLafLanguageProfile(code);

      return {
        code,
        label: profile.label,
        nativeLabel: profile.nativeLabel,
        locale: profile.locale,
      };
    });

  const realization =
    selectedLanguageCode === null
      ? null
      : getLafA1ConnectLanguageRealization(
          selectedLanguageCode,
        );

  return {
    options,
    selectedLanguageCode,
    selectionRequired:
      selectedLanguageCode === null,
    selectedByUser:
      selectedLanguageCode !== null,
    realization,
    languageContentBound:
      realization?.languageContentBound ??
      false,
    executableTaskAvailable:
      realization?.executableTaskAvailable ??
      false,
    evidenceCaptureAvailable:
      realization?.evidenceCaptureAvailable ??
      false,
  };
}
