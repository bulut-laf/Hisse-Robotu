import {
  describe,
  expect,
  it,
} from "vitest";

import {
  createCefrA1NavigateNativeLearningUiModel,
} from "./CefrA1NavigateNativeLearningUiModel";

describe(
  "A1 NAVIGATE native Learning UI model",
  () => {
    it("uses /learning and exposes seven explicit target languages", () => {
      const model =
        createCefrA1NavigateNativeLearningUiModel();

      expect(model.route).toBe("/learning");
      expect(
        model.languageOptions.map(
          item => item.code,
        ),
      ).toEqual([
        "hu",
        "tr",
        "de",
        "it",
        "en",
        "es",
        "ru",
      ]);
    });

    it("exposes all six immediate executable tasks but preserves seven authoritative evidence identities", () => {
      const model =
        createCefrA1NavigateNativeLearningUiModel();

      expect(model.taskCards).toHaveLength(6);
      expect(model.immediateEvidenceCount).toBe(
        6,
      );
      expect(
        model.authoritativeEvidenceIdentityCount,
      ).toBe(7);
      expect(
        model.taskCards.map(
          task => task.evidenceDefinitionId,
        ),
      ).not.toContain(
        "a1-navigate-evidence-delayed-retrieval",
      );
    });

    it("keeps delayed retrieval and automatic learning decisions closed", () => {
      expect(
        createCefrA1NavigateNativeLearningUiModel(),
      ).toMatchObject({
        delayedRetrievalRuntimeAvailable:
          false,
        masteryAssignmentAllowed: false,
        cefrLevelAssignmentAllowed: false,
        automaticProgressionAllowed:
          false,
        automaticTransactionCompletionAllowed:
          false,
      });
    });
  },
);
