﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
$testPath = Join-Path $app "src\application\learning\CefrA1NavigateProductionRuntime.test.ts"

if (-not (Test-Path $testPath)) {
    throw "Sprint 1440-1448 Rev2 test repair source missing."
}

$requiredMarkers = @(
    "result.runtime",
    ".resolvedCapabilityReferences",
    '"needs-expression"',
    ".capabilityObservationWritten"
)

foreach ($marker in $requiredMarkers) {
    if (-not (
        Select-String `
            -Path $testPath `
            -SimpleMatch `
            -Pattern $marker `
            -Quiet
    )) {
        throw "Sprint 1440-1448 Rev2 marker missing: $marker"
    }
}

Write-Host "SPRINT-1440-1448 REV2 SOURCE CHECK PASSED"

Set-Location $app

Write-Host ""
Write-Host "RESUME CHECKPOINT 3/3 — Sprint 1446-1448"

& npx vitest run @(
    "src/core/learning/CefrA1NavigateRuntimeSliceDefinition.test.ts",
    "src/core/learning/CefrProductionRuntimeSliceRegistry.test.ts",
    "src/application/learning/CefrProductionRuntimePlatform.test.ts",
    "src/application/learning/CefrA1NavigateProductionRuntime.test.ts"
)

if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1446-1448 Rev2 target checkpoint failed."
}

Write-Host "SPRINT-1446-1448 REV2 TARGET CHECKPOINT PASSED"

Write-Host ""
Write-Host "FINAL BLOCK REGRESSION — one full run only"

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1440-1448 Rev2 final full regression failed."
}

Write-Host ""
Write-Host "FINAL PRODUCTION BUILD"

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1440-1448 Rev2 production build failed."
}

Write-Host ""
Write-Host "SPRINT-1440-1448 REV2 VERIFICATION COMPLETE"
