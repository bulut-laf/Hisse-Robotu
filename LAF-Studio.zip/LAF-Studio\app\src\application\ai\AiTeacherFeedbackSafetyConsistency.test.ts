import {
  describe,
  expect,
  it,
} from "vitest";

import {
  AI_TEACHER_CORE_CONTRACT_V1,
  resolveAiTeacherInteractionPolicy,
} from "./AiTeacherCrossStudioConsistency";

describe("AI Teacher feedback / level / safety consistency", () => {
  it("uses CEFR only when authoritative context already exists", () => {
    const withoutContext =
      resolveAiTeacherInteractionPolicy({
        surfaceId: "cefr-learning-path",
        learnerAttemptAvailable: true,
        authoritativeCefrContextAvailable:
          false,
      });
    const withContext =
      resolveAiTeacherInteractionPolicy({
        surfaceId: "cefr-learning-path",
        learnerAttemptAvailable: true,
        authoritativeCefrContextAvailable:
          true,
      });

    expect(
      withoutContext
        .mayUseCefrForSupportAdaptation,
    ).toBe(false);
    expect(
      withContext
        .mayUseCefrForSupportAdaptation,
    ).toBe(true);
    expect(withContext.mayAssignCefr).toBe(
      false,
    );
  });

  it("never turns AI support or feedback into mastery, CEFR, progression, or learner evidence", () => {
    const policy =
      resolveAiTeacherInteractionPolicy({
        surfaceId: "speaking",
        learnerAttemptAvailable: true,
        authoritativeCefrContextAvailable:
          true,
      });

    expect(
      policy.mayWriteLearnerEvidenceFromAiOutput,
    ).toBe(false);
    expect(
      policy.mayClaimMasteryFromFeedback,
    ).toBe(false);
    expect(policy.mayAssignCefr).toBe(false);
    expect(
      policy.mayProgressLearnerAutomatically,
    ).toBe(false);

    expect(
      AI_TEACHER_CORE_CONTRACT_V1
        .automaticStudioLaunchAllowed,
    ).toBe(false);
  });

  it("keeps task-specific Studio behavior instead of imposing one prompt shape", () => {
    expect(
      AI_TEACHER_CORE_CONTRACT_V1
        .taskSpecificBehaviorPreserved,
    ).toBe(true);
    expect(
      AI_TEACHER_CORE_CONTRACT_V1
        .minimumUsefulSupport,
    ).toBe(true);
    expect(
      AI_TEACHER_CORE_CONTRACT_V1
        .feedbackBeforeLecture,
    ).toBe(true);
  });
});
