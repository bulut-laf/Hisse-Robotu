﻿import { describe, expect, it } from "vitest";

import {
  LAF_A1_CONNECT_INSTRUCTIONAL_CONTENT,
  resolveCefrA1ConnectInstructionalContent,
} from "./CefrA1ConnectInstructionalContent";

describe("CefrA1ConnectInstructionalContent", () => {
  it("publishes Turkish UI instructional copy for all four authoritative A1 CONNECT lessons", () => {
    expect(LAF_A1_CONNECT_INSTRUCTIONAL_CONTENT).toHaveLength(4);

    for (const item of LAF_A1_CONNECT_INSTRUCTIONAL_CONTENT) {
      expect(item.uiLanguage).toBe("tr");
      expect(item.practiceSequence).toHaveLength(5);
      expect(item.authoritativeCurriculumIdentityPreserved).toBe(true);
      expect(item.masteryClaimed).toBe(false);
      expect(item.cefrLevelClaimed).toBe(false);
      expect(item.automaticProgressionPerformed).toBe(false);
    }
  });

  it("keeps canonical lesson identities and fails closed for unknown lessons", () => {
    expect(
      resolveCefrA1ConnectInstructionalContent(
        "a1-connect-greeting-response",
      ),
    ).toMatchObject({
      lessonId: "a1-connect-greeting-response",
      communicativeStep:
        "Yaygın bir selamlaşmayı tanıyın ve uygun kısa bir karşılık verin.",
    });

    expect(
      resolveCefrA1ConnectInstructionalContent("unknown-lesson"),
    ).toBeNull();
  });

  it("does not expose mastery, CEFR, or progression authority", () => {
    for (const item of LAF_A1_CONNECT_INSTRUCTIONAL_CONTENT) {
      expect(item).not.toHaveProperty("mastery");
      expect(item).not.toHaveProperty("cefrLevel");
      expect(item).not.toHaveProperty("progression");
    }
  });
});
