import { describe, expect, it } from "vitest";
import { createCefrGuidanceEvidenceActivityVisibilitySafety } from "./CefrGuidanceEvidenceActivityVisibilitySafety";

describe("CefrGuidanceEvidenceActivityVisibilitySafety", () => {
  it("keeps the evidence activity UI read-only", () => {
    expect(
      createCefrGuidanceEvidenceActivityVisibilitySafety(),
    ).toEqual({
      profileMutationAllowed: false,
      masteryAssignmentAllowed: false,
      cefrLevelAssignmentAllowed: false,
      progressionAllowed: false,
      automaticNavigationAllowed: false,
      evidenceDeletionAllowed: false,
      readOnlyVisibility: true,
    });
  });
});
