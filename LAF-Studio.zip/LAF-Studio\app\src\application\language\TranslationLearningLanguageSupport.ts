import type {
  LafLearningLanguageCode,
} from "../../core/language/LafLanguageProfile";

export function getTranslationLearningSupportLanguage(
  sourceLanguage: LafLearningLanguageCode,
): LafLearningLanguageCode {
  return sourceLanguage === "tr"
    ? "hu"
    : "tr";
}
