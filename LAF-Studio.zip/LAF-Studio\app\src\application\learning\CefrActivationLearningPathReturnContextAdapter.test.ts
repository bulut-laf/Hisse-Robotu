import {
  describe,
  expect,
  it,
} from "vitest";

import {
  LAF_A1_NAVIGATE_REAL_LIFE_ACTIVATION,
} from "../../core/learning/CefrA1NavigateActivationDefinition";
import {
  createCefrA1NavigateGuidedActivation,
} from "./CefrA1NavigateGuidedActivation";
import {
  captureA1NavigateActivationLearningPathReturnContext,
  isCefrActivationCompletionEligible,
  LAF_CEFR_EXISTING_LEARNING_ROUTE,
  resolveCefrActivationLearningPathReturnTarget,
} from "./CefrActivationLearningPathReturnContextAdapter";

describe(
  "CefrActivationLearningPathReturnContextAdapter",
  () => {
    it("captures only the existing authoritative A1 NAVIGATE source context", () => {
      const activation =
        createCefrA1NavigateGuidedActivation("hu");

      const result =
        captureA1NavigateActivationLearningPathReturnContext({
          sourceRoutePath:
            LAF_CEFR_EXISTING_LEARNING_ROUTE,
          sourceUnitId:
            LAF_A1_NAVIGATE_REAL_LIFE_ACTIVATION.unitId,
          activationId: activation.activationId,
        });

      expect(result).toEqual({
        routePath: "/learning",
        activationId:
          "a1-navigate-activation-immediate-everyday-need",
        unitId:
          "a1-navigate-immediate-everyday-needs",
        targetSelector:
          '[data-cefr-unit="a1-navigate-immediate-everyday-needs"]',
        evidenceCreated: false,
        masteryAssigned: false,
        cefrLevelAssigned: false,
        progressionPerformed: false,
        automaticStudioLaunchPerformed: false,
      });
    });

    it.each([
      {
        sourceRoutePath: "/other",
        sourceUnitId:
          "a1-navigate-immediate-everyday-needs",
        activationId:
          "a1-navigate-activation-immediate-everyday-need",
      },
      {
        sourceRoutePath: "/learning",
        sourceUnitId: "unknown-unit",
        activationId:
          "a1-navigate-activation-immediate-everyday-need",
      },
      {
        sourceRoutePath: "/learning",
        sourceUnitId:
          "a1-navigate-immediate-everyday-needs",
        activationId: "unknown-activation",
      },
    ])(
      "fails closed instead of guessing a return source: %#",
      input => {
        expect(
          captureA1NavigateActivationLearningPathReturnContext(
            input,
          ),
        ).toBeNull();
      },
    );

    it("requires every existing guided activation step before completion return is eligible", () => {
      const activation =
        createCefrA1NavigateGuidedActivation("hu");
      const required =
        activation.steps.map(step => step.stepId);

      expect(required).toEqual([
        "need-or-request",
        "essential-question",
        "understand-response",
        "acknowledge-or-close",
      ]);

      expect(
        isCefrActivationCompletionEligible(
          required,
          required.slice(0, 3),
        ),
      ).toBe(false);

      expect(
        isCefrActivationCompletionEligible(
          required,
          required,
        ),
      ).toBe(true);

      expect(
        isCefrActivationCompletionEligible([], []),
      ).toBe(false);
    });

    it("returns only the exact retained source and rejects tampering", () => {
      const context =
        captureA1NavigateActivationLearningPathReturnContext({
          sourceRoutePath: "/learning",
          sourceUnitId:
            LAF_A1_NAVIGATE_REAL_LIFE_ACTIVATION.unitId,
          activationId:
            LAF_A1_NAVIGATE_REAL_LIFE_ACTIVATION.activationId,
        });

      expect(context).not.toBeNull();
      if (!context) {
        throw new Error("Expected authoritative context.");
      }

      expect(
        resolveCefrActivationLearningPathReturnTarget(
          context,
        ),
      ).toEqual({
        routePath: "/learning",
        targetSelector:
          '[data-cefr-unit="a1-navigate-immediate-everyday-needs"]',
      });

      expect(
        resolveCefrActivationLearningPathReturnTarget({
          ...context,
          targetSelector:
            '[data-cefr-unit="invented-destination"]',
        }),
      ).toBeNull();
    });
  },
);
