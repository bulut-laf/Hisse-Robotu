$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 762-764 Target Tests: Custodial Soundness ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialSoundness.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialSoundnessCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialSoundnessAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 762-764 target tests failed." }

Write-Host "=== Sprint 765-767 Target Tests: Custodial Credibility ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialCredibility.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialCredibilityCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialCredibilityAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 765-767 target tests failed." }

Write-Host "=== Sprint 768-770 Target Tests: Custodial Defensibility ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialDefensibility.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialDefensibilityCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialDefensibilityAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 768-770 target tests failed." }

Write-Host "=== Combined Sprint 762-770 New Tests ==="
npx vitest run `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialSoundness.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialSoundnessCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialSoundnessAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialCredibility.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialCredibilityCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialCredibilityAwareCefrIntelligencePlatform.test.ts" `
  "src/core/learning/CefrIntelligenceCredentialEvidenceCustodialDefensibility.test.ts" `
  "src/core/learning/CefrLearningCredentialEvidenceCustodialDefensibilityCoordination.test.ts" `
  "src/core/learning/CefrEvidenceCustodialDefensibilityAwareCefrIntelligencePlatform.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 762-770 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-762-770 VERIFICATION COMPLETE"
