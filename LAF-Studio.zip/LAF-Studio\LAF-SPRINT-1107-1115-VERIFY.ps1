$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"
Set-Location $app

Write-Host "=== Sprint 1107-1109 Target Tests: Recovery Routing ==="
npx vitest run `
  "src/core/learning/CefrContinuityRecoveryRoute.test.ts" `
  "src/core/learning/CefrContinuityRecoveryRouteRegistry.test.ts" `
  "src/core/learning/CefrContinuityRecoveryRoutingOrchestration.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1107-1109 target tests failed." }

Write-Host "=== Sprint 1110-1112 Target Tests: User-Initiated Recovery Launch ==="
npx vitest run `
  "src/core/learning/CefrContinuityRecoveryLaunchRequest.test.ts" `
  "src/core/learning/CefrContinuityRecoveryLaunchGate.test.ts" `
  "src/core/learning/CefrUserInitiatedContinuityRecoveryLaunch.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1110-1112 target tests failed." }

Write-Host "=== Sprint 1113-1115 Target Tests: Recovery Feedback Reintegration ==="
npx vitest run `
  "src/core/learning/CefrContinuityRecoveryOutcome.test.ts" `
  "src/core/learning/CefrContinuityRecoveryCompletionRecord.test.ts" `
  "src/core/learning/CefrContinuityRecoveryReintegration.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1113-1115 target tests failed." }

Write-Host "=== Combined Sprint 1107-1115 New Tests ==="
npx vitest run `
  "src/core/learning/CefrContinuityRecoveryRoute.test.ts" `
  "src/core/learning/CefrContinuityRecoveryRouteRegistry.test.ts" `
  "src/core/learning/CefrContinuityRecoveryRoutingOrchestration.test.ts" `
  "src/core/learning/CefrContinuityRecoveryLaunchRequest.test.ts" `
  "src/core/learning/CefrContinuityRecoveryLaunchGate.test.ts" `
  "src/core/learning/CefrUserInitiatedContinuityRecoveryLaunch.test.ts" `
  "src/core/learning/CefrContinuityRecoveryOutcome.test.ts" `
  "src/core/learning/CefrContinuityRecoveryCompletionRecord.test.ts" `
  "src/core/learning/CefrContinuityRecoveryReintegration.test.ts"
if ($LASTEXITCODE -ne 0) { throw "Sprint 1107-1115 combined new tests failed." }

Write-Host "=== Full Regression ==="
npm run test
if ($LASTEXITCODE -ne 0) { throw "Full regression failed." }

Write-Host "=== Production Build ==="
npm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host "SPRINT-1107-1115 VERIFICATION COMPLETE"
