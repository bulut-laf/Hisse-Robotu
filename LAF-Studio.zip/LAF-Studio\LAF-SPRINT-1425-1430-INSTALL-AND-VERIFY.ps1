﻿$ErrorActionPreference = "Stop"

$root = "D:\Projects\LAF-Studio"
$app = Join-Path $root "app"

$required = @(
    "src\core\learning\CefrRuntimeSliceDefinition.ts",
    "src\core\learning\CefrA1ConnectRuntimeSliceDefinition.ts",
    "src\application\learning\CefrAuthoritativeLanguageRuntimeEvidenceService.ts",
    "src\application\learning\CefrRuntimeSliceAssembly.ts",
    "src\core\learning\CefrRuntimeSliceAssemblySafety.ts"
)

foreach ($relative in $required) {
    $path = Join-Path $app $relative

    if (-not (Test-Path $path)) {
        throw "Sprint 1425-1430 source missing: $relative"
    }
}

$markers = @(
    @(
        "src\core\learning\CefrRuntimeSliceDefinition.ts",
        "validateCefrRuntimeSliceDefinition("
    ),
    @(
        "src\core\learning\CefrRuntimeSliceDefinition.ts",
        "authorityPreflightComplete: true"
    ),
    @(
        "src\core\learning\CefrA1ConnectRuntimeSliceDefinition.ts",
        'LAF_A1_CONNECT_RUNTIME_SLICE_ID'
    ),
    @(
        "src\application\learning\CefrAuthoritativeLanguageRuntimeEvidenceService.ts",
        "runtimeService?:"
    ),
    @(
        "src\application\learning\CefrRuntimeSliceAssembly.ts",
        "new CefrAuthoritativeRuntimeEvidenceService("
    ),
    @(
        "src\application\learning\CefrRuntimeSliceAssembly.ts",
        "new CefrLanguageScopedEvidenceReadService("
    ),
    @(
        "src\application\learning\CefrRuntimeSliceAssembly.ts",
        "repairPendingLanguageProvenance()"
    ),
    @(
        "src\core\learning\CefrRuntimeSliceAssemblySafety.ts",
        "a1SpecificDefaultsRequiredByGenericAssembly:"
    ),
    @(
        "src\core\learning\CefrRuntimeSliceAssemblySafety.ts",
        "automaticProgressionAllowed: false"
    )
)

foreach ($pair in $markers) {
    $path = Join-Path $app $pair[0]

    if (-not (
        Select-String `
            -Path $path `
            -SimpleMatch `
            -Pattern $pair[1] `
            -Quiet
    )) {
        throw "Sprint 1425-1430 marker missing: $($pair[1])"
    }
}

Write-Host "SPRINT-1425-1430 SOURCE CHECK PASSED"

Set-Location $app

$targets = @(
    "src/core/learning/CefrRuntimeSliceDefinition.test.ts",
    "src/core/learning/CefrA1ConnectRuntimeSliceDefinition.test.ts",
    "src/application/learning/CefrAuthoritativeLanguageRuntimeEvidenceService.injection.test.ts",
    "src/application/learning/CefrRuntimeSliceAssembly.test.ts",
    "src/core/learning/CefrRuntimeSliceAssemblySafety.test.ts",
    "src/application/learning/CefrAuthoritativeLanguageRuntimeEvidenceService.test.ts",
    "src/application/learning/CefrAuthoritativeRuntimeEvidenceService.test.ts",
    "src/application/learning/CefrLanguageScopedEvidenceReadService.test.ts",
    "src/application/learning/CefrLanguageEvidenceProvenanceCoordinator.test.ts",
    "src/core/learning/CefrLanguageScopedEvidenceCoverage.test.ts",
    "src/core/learning/CefrLanguageScopedEvidenceAdvisory.test.ts"
)

& npx vitest run $targets
if ($LASTEXITCODE -ne 0) {
    throw "Sprint 1425-1430 target tests failed."
}

& npm run test
if ($LASTEXITCODE -ne 0) {
    throw "Full regression failed."
}

& npm run build
if ($LASTEXITCODE -ne 0) {
    throw "Production build failed."
}

Write-Host "SPRINT-1425-1430 VERIFICATION COMPLETE"
